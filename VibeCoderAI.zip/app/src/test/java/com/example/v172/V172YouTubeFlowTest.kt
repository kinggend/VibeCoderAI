package com.example.v172

import com.example.phone.CompactScreen
import com.example.phone.FastPaths
import com.example.phone.PhoneAction
import com.example.phone.ScreenElement
import com.example.phone.YouTubeFlow
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V172YouTubeFlowTest {
  private val yt = FastPaths.YOUTUBE_PKG
  private fun el(id: Int, label: String, click: Boolean = true, edit: Boolean = false, full: String = label) =
    ScreenElement(id, if (edit) "edit" else "button", label, click, edit, false, false, 100, id * 100, full)
  private fun scr(vararg e: ScreenElement) = CompactScreen("", e.toList(), 0)

  private val home = scr(el(1, "Home"), el(2, "Search"), el(3, "Shorts"))
  private val searchPage = scr(el(1, "Search YouTube", click = false, edit = true), el(2, "Voice search"), el(3, "Back"))
  private val results = scr(
    el(1, "Back"), el(2, "Filters"),
    el(3, "Ninnila Full Video Song | Tholi Prema…", full = "Ninnila Full Video Song | Tholi Prema Video Songs - 4 minutes, 21 seconds - Aditya Music - 65M views - 8 years ago - play video"),
    el(4, "Other video", full = "Other - 3 minutes, 1 second - Chan - 2M views - play video")
  )

  @Test fun queryDropsPlayWord() {
    assertEquals("telugu songs", YouTubeFlow("play telugu songs", true).query)
    assertEquals("telugu songs", YouTubeFlow("telugu songs play", true).query)
  }

  @Test fun positionWordsAreNotSearchTerms() {
    assertEquals("Diwali", YouTubeFlow("play Diwali first video", true).query)
    assertEquals("telugu songs", YouTubeFlow("telugu songs the first one", true).query)
  }

  @Test fun sponsoredResultIsSkipped() {
    val f = YouTubeFlow("x", true)
    f.next(searchPage, yt); f.next(searchPage, yt)
    val withAd = scr(
      el(1, "Back"), el(2, "Filters"),
      el(3, "Ad", full = "Sponsored - Wispr Flow - 1 minute, 5 seconds - 2M views - play video"),
      el(4, "Real", full = "Diwali - 3 minutes, 1 second - Chan - 2M views - play video")
    )
    assertEquals(PhoneAction.Tap(4), f.next(withAd, yt))
  }

  @Test fun wantsPlay() {
    assertTrue(FastPaths.wantsPlay("open youtube play telugu songs"))
    assertTrue(!FastPaths.wantsPlay("youtube lo telugu songs"))
  }

  @Test fun fullScriptTapTypeEnterPickDone() {
    val f = YouTubeFlow("play telugu songs", true)
    assertEquals(PhoneAction.Tap(2), f.next(home, yt))
    assertEquals(PhoneAction.Type(1, "telugu songs"), f.next(searchPage, yt))
    assertEquals(PhoneAction.Enter, f.next(searchPage, yt))
    assertEquals(PhoneAction.Wait(1000), f.next(scr(el(1, "Back"), el(2, "Filters"), el(3, "x")), yt))
    assertEquals(PhoneAction.Tap(3), f.next(results, yt))
    val done = f.next(results, yt)
    assertTrue(done is PhoneAction.Done && done.summary.contains("Ninnila"))
  }

  @Test fun otherAppIsNotHandled() {
    assertEquals(null, YouTubeFlow("x", true).next(home, "com.android.chrome"))
  }

  @Test fun givesUpWhenScreenIsUnknown() {
    val f = YouTubeFlow("x", true)
    val odd = scr(el(1, "Foo"), el(2, "Bar"), el(3, "Baz"))
    repeat(3) { assertEquals(null, f.next(odd, yt)) }
    assertTrue(f.gaveUp)
  }

  @Test fun nonPlayTaskStopsAtResults() {
    val f = YouTubeFlow("telugu songs", false)
    f.next(searchPage, yt); f.next(searchPage, yt)
    assertTrue(f.next(results, yt) is PhoneAction.Done)
  }
}
