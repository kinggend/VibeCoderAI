package com.example.v1920

import com.example.chat.ComposeSend
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V1920ComposeSendTest {
  @Test fun imageAloneCanBeSent() {
    assertFalse(ComposeSend.canSend("", 0, false, 0))
    assertFalse(ComposeSend.canSend("   ", 0, false, 0))
    assertTrue(ComposeSend.canSend("", 1, false, 0))
    assertTrue(ComposeSend.canSend("", 0, true, 0))
    assertTrue(ComposeSend.canSend("", 0, false, 2))
    assertTrue(ComposeSend.canSend("hi", 0, false, 0))
  }

  @Test fun typedTextWins() {
    assertEquals("fix this", ComposeSend.textFor("  fix this ", 2, true, 1, false))
  }

  @Test fun emptyTextGetsADefaultLine() {
    assertEquals("Look at the attached image.", ComposeSend.textFor("", 1, false, 0, false))
    assertEquals("Look at the attached images.", ComposeSend.textFor("", 3, false, 0, false))
    assertEquals("Look at the attached file.", ComposeSend.textFor("", 0, true, 0, false))
    assertEquals("Look at the attached file.", ComposeSend.textFor("", 0, false, 1, false))
  }

  @Test fun droppedImagesNeverBecomeAnEmptyMessage() {
    assertNull(ComposeSend.textFor("", 1, false, 0, true))
    assertNull(ComposeSend.textFor("  ", 0, false, 0, false))
    assertEquals("Look at the attached file.", ComposeSend.textFor("", 2, true, 0, true))
  }
}
