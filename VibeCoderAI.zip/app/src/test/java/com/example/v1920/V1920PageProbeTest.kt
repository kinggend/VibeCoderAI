package com.example.v1920

import com.example.agent.PageProbe
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** The probe itself is JavaScript (checked in a real Chromium against 16 page shapes); these guard the Kotlin string it lives in. */
class V1920PageProbeTest {
  @Test fun scriptIsAnExpressionWithNoKotlinTemplates() {
    assertFalse("a dollar sign would be a Kotlin template", PageProbe.JS.contains('$'))
    assertTrue(PageProbe.JS.trimStart().startsWith("(function(){"))
    assertTrue(PageProbe.JS.trimEnd().endsWith("})()"))
    assertTrue(PageProbe.JS.count { it == '(' } == PageProbe.JS.count { it == ')' })
    assertTrue(PageProbe.JS.count { it == '{' } == PageProbe.JS.count { it == '}' })
  }

  @Test fun reportsTheThreeSilentFailures() {
    assertTrue(PageProbe.JS.contains("The container has no real height"))
    assertTrue(PageProbe.JS.contains("no canvas was added to the page"))
    assertTrue(PageProbe.JS.contains("The JavaScript did not add any content"))
  }
}
