package com.example.v1924

import com.example.llama.RemoteSpeed
import com.example.llama.RemoteSpeed.Timing
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.Locale

class V1924RemoteSpeedTest {
  @Test fun speedIsChunksBetweenFirstAndLast() {
    // 101 chunks, first at 400 ms, last at 1400 ms: 100 intervals in one second.
    assertEquals(100.0, RemoteSpeed.tokensPerSecond(Timing(0, 400, 1400, 101))!!, 0.001)
  }

  @Test fun tooFewChunksGiveNoSpeed() {
    assertNull(RemoteSpeed.tokensPerSecond(Timing(0, 300, 900, RemoteSpeed.MIN_CHUNKS - 1)))
    assertNotNull(RemoteSpeed.tokensPerSecond(Timing(0, 300, 900, RemoteSpeed.MIN_CHUNKS)))
  }

  @Test fun noFirstChunkMeansNoSpeed() {
    assertNull(RemoteSpeed.tokensPerSecond(Timing(0, null, 5000, 0)))
  }

  @Test fun burstInsideOneInstantIsNotATrustedSpeed() {
    // Everything arrived in 10 ms (a buffering proxy): dividing by it would show a silly number.
    assertNull(RemoteSpeed.tokensPerSecond(Timing(0, 1000, 1010, 60)))
  }

  @Test fun noReplyTellsWhatToCheck() {
    val t = RemoteSpeed.summarize(Timing(0, null, 20000, 0))
    assertTrue(t.startsWith("No reply"))
    assertTrue(t.contains("key"))
  }

  @Test fun summaryNamesDelaySpeedAndFileTime() {
    val t = RemoteSpeed.summarize(Timing(0, 420, 1420, 101))
    assertTrue(t, t.startsWith("First token in 0.4 s."))
    assertTrue(t, t.contains("About 100 tokens/s"))
    assertTrue(t, t.contains("500-token file takes about 5.0 s"))
    assertTrue(t, t.contains("101 streamed pieces"))
  }

  @Test fun slowSpeedKeepsOneDecimal() {
    // 21 chunks over 10 s = 2 per second.
    val t = RemoteSpeed.summarize(Timing(0, 1000, 11000, 21))
    assertTrue(t, t.contains("About 2.0 tokens/s"))
    assertTrue(t, t.contains("takes about 250.0 s"))
  }

  @Test fun shortReplyStillReportsTheDelay() {
    val t = RemoteSpeed.summarize(Timing(100, 600, 650, 3))
    assertTrue(t, t.startsWith("First token in 0.5 s."))
    assertTrue(t, t.contains("too short"))
  }

  @Test fun decimalPointDoesNotDependOnTheLanguage() {
    val old = Locale.getDefault()
    try {
      Locale.setDefault(Locale.GERMANY)
      val t = RemoteSpeed.summarize(Timing(0, 420, 1420, 101))
      assertTrue(t, t.startsWith("First token in 0.4 s."))
    } finally { Locale.setDefault(old) }
  }

  @Test fun testCostIsBounded() {
    assertTrue(RemoteSpeed.CHUNK_CAP in 50..300)
    assertTrue(RemoteSpeed.TIME_CAP_MS in 5_000..30_000)
    assertTrue(RemoteSpeed.MAX_TOKENS >= RemoteSpeed.CHUNK_CAP)
  }
}
