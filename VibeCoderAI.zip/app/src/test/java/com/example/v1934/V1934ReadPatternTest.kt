package com.example.v1934

import com.example.data.model.SettingsState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.34: the streamed-model read pattern is an experiment and stays off unless the person turns it on. */
class V1934ReadPatternTest {
  @Test fun offByDefault() {
    assertFalse(SettingsState().streamReadRandom)
  }

  @Test fun copyKeepsItAndOtherSettingsAreUntouched() {
    val s = SettingsState().copy(streamReadRandom = true)
    assertTrue(s.streamReadRandom)
    assertEquals(SettingsState().cpuThreads, s.cpuThreads)
    assertEquals(SettingsState().lookupDecoding, s.lookupDecoding)
    assertFalse(s.copy(streamReadRandom = false).streamReadRandom)
  }

  @Test fun theTwoExperimentalSwitchesAreIndependent() {
    val s = SettingsState().copy(lookupDecoding = true)
    assertFalse(s.streamReadRandom)
    val t = SettingsState().copy(streamReadRandom = true)
    assertFalse(t.lookupDecoding)
  }
}
