package com.example.v1933

import com.example.llama.SpeedTestPlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.33: a model that streams from storage gets a shorter Speed test and is not started on a phone at Severe heat. */
class V1933SpeedTestPlanTest {
  @Test fun normalModelsKeepThe32TokenTest() {
    assertEquals(32, SpeedTestPlan.decodeTokens(false))
    assertEquals(128, SpeedTestPlan.PROMPT_TOKENS)
  }

  @Test fun streamingModelsGenerateFewerTokens() {
    assertEquals(8, SpeedTestPlan.decodeTokens(true))
    assertTrue(SpeedTestPlan.decodeTokens(true) >= 2) // the native test needs at least two tokens to time a step
  }

  @Test fun onlyStreamingModelsAreRefusedAndOnlyAtSevereOrWorse() {
    assertFalse(SpeedTestPlan.refuseToStart(false, 4))
    assertFalse(SpeedTestPlan.refuseToStart(true, null))
    assertFalse(SpeedTestPlan.refuseToStart(true, 0))
    assertFalse(SpeedTestPlan.refuseToStart(true, 2)) // Moderate still runs
    assertTrue(SpeedTestPlan.refuseToStart(true, 3))
    assertTrue(SpeedTestPlan.refuseToStart(true, 4))
  }

  @Test fun theMessagesSayWhatHappened() {
    assertTrue(SpeedTestPlan.refusal("Severe").contains("thermal status Severe"))
    assertTrue(SpeedTestPlan.refusal(null).contains("Severe or worse"))
    val n = SpeedTestPlan.shortenedNote()
    assertTrue(n, n.contains("8 generated tokens instead of 32"))
    assertTrue(n, n.contains("only 7 steps"))
  }
}
