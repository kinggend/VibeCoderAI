package com.example.v1933

import com.example.llama.PromptClock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.33: "hi" was answered with the phone clock as JSON because the clock was glued to every user message. */
class V1933ClockGateTest {
  private val t0107 = 1795482420000L // 2026-11-24 01:07 UTC (a Tuesday)
  private val t0108 = 1795482480000L // one minute later
  private val nextDay = t0107 + 24L * 3600 * 1000

  // ---- small talk and code requests get the message exactly as typed ----
  @Test fun smallTalkGetsNoClock() {
    for (m in listOf("hi", "Hi", "hello", "hey there", "thanks", "how are you", "what is a closure", "explain recursion",
      "write a python function to reverse a string", "ok", "yes please", "Hi, who are you?")) {
      assertFalse(m, PromptClock.asksForClock(m))
      assertEquals(m, "", PromptClock.tailFor(m, t0107, "UTC"))
    }
  }

  @Test fun wordsInsideOtherWordsDoNotCount() {
    for (m in listOf("update the page", "sometimes it fails", "add a datepicker", "overtimer", "know", "pamper", "dayton", "metal")) {
      assertFalse(m, PromptClock.asksForClock(m))
    }
  }

  // ---- date and time questions get the clock ----
  @Test fun dateAndTimeQuestionsGetTheClock() {
    for (m in listOf("what time is it", "What's the date today?", "WHAT TIME IS IT NOW", "ipudu time entha", "eroju date enti",
      "repu em roju", "samayam entha", "kitne baje hain", "aaj ki tarikh", "it starts at 5 pm", "meet at 5pm", "how many days until friday",
      "what happened a year ago", "good morning, what day is it")) {
      assertTrue(m, PromptClock.asksForClock(m))
    }
  }

  @Test fun teluguAndHindiInTheirOwnScriptCount() {
    assertTrue(PromptClock.asksForClock("ఇప్పుడు సమయం ఎంత"))
    assertTrue(PromptClock.asksForClock("अभी समय क्या है"))
    assertFalse(PromptClock.asksForClock("నమస్తే"))
  }

  @Test fun theTailIsTheSameClockLineAsBefore() {
    assertEquals(PromptClock.line(t0107, "UTC"), PromptClock.tailFor("what time is it", t0107, "UTC"))
    assertTrue(PromptClock.tailFor("what time is it", t0107, "Asia/Kolkata").contains("6:37 AM (Asia/Kolkata)"))
  }

  // ---- the date line in the system prompt ----
  @Test fun dateLineHasTheDateAndNoTimeOfDay() {
    val d = PromptClock.dateLine(t0107, "UTC")
    assertTrue(d, d.contains("Tuesday, 24 November 2026"))
    val date = d.substringAfter("phone: ")
    assertEquals("Tuesday, 24 November 2026.", date)
  }

  @Test fun dateLineIsTheSameAllDayAndChangesWithTheDay() {
    assertEquals(PromptClock.dateLine(t0107, "UTC"), PromptClock.dateLine(t0108, "UTC"))
    assertNotEquals(PromptClock.dateLine(t0107, "UTC"), PromptClock.dateLine(nextDay, "UTC"))
  }

  @Test fun dateLineFollowsThePhoneZone() {
    assertTrue(PromptClock.dateLine(t0107, "America/Los_Angeles").contains("Monday, 23 November 2026"))
    assertTrue(PromptClock.dateLine(t0107, "Asia/Kolkata").contains("Tuesday, 24 November 2026"))
    assertTrue(PromptClock.dateLine(t0107, "Not/AZone").contains("2026"))
  }

  // ---- what it buys: two "hi" requests a minute apart are identical, so the whole prompt can come from the cache ----
  @Test fun twoSmallTalkRequestsAMinuteApartAreByteIdentical() {
    fun request(now: Long, text: String) =
      "SYSTEM" + PromptClock.dateLine(now, "UTC") + PromptClock.LANGUAGE_NOTE + "\nUSER:" + text + PromptClock.tailFor(text, now, "UTC")
    assertEquals(request(t0107, "hi"), request(t0108, "hi"))
    // a time question differs only in its tail
    val a = request(t0107, "what time is it"); val b = request(t0108, "what time is it")
    assertNotEquals(a, b)
    assertTrue(a.substringBefore("[Phone clock") == b.substringBefore("[Phone clock"))
  }

  @Test fun requestsWithTheirOwnSystemPromptStillUseTheOldPlacement() {
    assertTrue(PromptClock.inUserTail(null))
    assertFalse(PromptClock.inUserTail("You control the phone."))
    assertTrue(PromptClock.systemLine(t0107, "UTC").contains("1:07 AM (UTC)"))
  }
}
