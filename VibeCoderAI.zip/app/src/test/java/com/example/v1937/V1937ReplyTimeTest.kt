package com.example.v1937

import com.example.agent.ReplyTime
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.37: the time a reply took is measured from the request, written in a short fixed form, and absent (not wrong) when unknown. */
class V1937ReplyTimeTest {
  // ---- format ----
  @Test fun underTenSecondsHasOneDecimal() {
    assertEquals("0.0 s", ReplyTime.format(0))
    assertEquals("0.4 s", ReplyTime.format(400))
    assertEquals("4.2 s", ReplyTime.format(4_200))
    assertEquals("9.9 s", ReplyTime.format(9_940))
  }

  @Test fun tenSecondsAndUpAreWholeSeconds() {
    assertEquals("10 s", ReplyTime.format(9_950))   // rounds up without printing "10.0 s"
    assertEquals("10 s", ReplyTime.format(10_000))
    assertEquals("34 s", ReplyTime.format(34_400))
    assertEquals("35 s", ReplyTime.format(34_500))
    assertEquals("59 s", ReplyTime.format(59_499))
  }

  @Test fun minutesAndHoursKeepTwoDigitRemainders() {
    assertEquals("1 min 00 s", ReplyTime.format(59_500))   // rounds up across the minute, never "60 s"
    assertEquals("1 min 00 s", ReplyTime.format(60_000))
    assertEquals("2 min 05 s", ReplyTime.format(125_000))
    assertEquals("12 min 30 s", ReplyTime.format(750_000))
    assertEquals("59 min 59 s", ReplyTime.format(3_599_400))
    assertEquals("1 h 00 min", ReplyTime.format(3_599_500)) // rounds up across the hour, never "60 min"
    assertEquals("1 h 02 min", ReplyTime.format(3_720_000))
    assertEquals("5 h 00 min", ReplyTime.format(5L * 3_600_000))
  }

  @Test fun negativeHasNoText() {
    assertNull(ReplyTime.format(-1))
    assertNull(ReplyTime.format(Long.MIN_VALUE))
  }

  @Test fun everyValueGivesANonEmptyShortText() {
    var ms = 0L
    while (ms < 2L * 3_600_000) {
      val s = ReplyTime.format(ms)
      assertTrue("$ms -> $s", s != null && s.isNotEmpty() && s.length <= 12)
      assertTrue("$ms -> $s", !s!!.startsWith("60 ") && !s.contains(" 60 ") && !s.startsWith("10.0"))
      ms += 997
    }
  }

  @Test fun formatIsMonotonicAtEachBoundaryStep() {
    // the number of seconds shown never goes down as time goes up
    fun secondsOf(s: String): Double {
      val parts = s.split(" ")
      return when {
        s.endsWith(" s") && parts.size == 2 -> parts[0].toDouble()
        s.endsWith(" s") -> parts[0].toDouble() * 60 + parts[2].toDouble()
        else -> parts[0].toDouble() * 3600 + parts[2].toDouble() * 60
      }
    }
    var last = -1.0
    var ms = 0L
    while (ms < 2L * 3_600_000) {
      val v = secondsOf(ReplyTime.format(ms)!!)
      assertTrue("$ms went from $last to $v", v >= last)
      last = v
      ms += 499
    }
  }

  // ---- since ----
  @Test fun sinceIsTheDifference() {
    assertEquals(1_500L, ReplyTime.since(1_000, 2_500))
    assertEquals(0L, ReplyTime.since(5_000, 5_000))
  }

  @Test fun sinceRejectsABackwardsClockAndAbsurdSpans() {
    assertNull(ReplyTime.since(2_000, 1_000))
    assertNull(ReplyTime.since(0, ReplyTime.MAX_MS + 1))
    assertEquals(ReplyTime.MAX_MS, ReplyTime.since(0, ReplyTime.MAX_MS))
  }

  // ---- the message ----
  @Test fun aMessageHasNoTimeUntilOneIsRecorded() {
    val m = ChatMessage(id = "m1", sender = MessageSender.AGENT, content = "hi")
    assertNull(m.elapsedMs)
    assertEquals(12_400L, m.copy(elapsedMs = 12_400L).elapsedMs)
    // copying a message for another reason keeps the time
    assertEquals(12_400L, m.copy(elapsedMs = 12_400L).copy(content = "edited").elapsedMs)
  }
}
