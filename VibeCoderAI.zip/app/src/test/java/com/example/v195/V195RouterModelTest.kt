package com.example.v195

import com.example.phone.IntentRouter
import com.example.phone.RouterModel
import org.junit.Assert.assertTrue
import org.junit.Assert.assertEquals
import org.junit.Test

class V195RouterModelTest {
  @Test fun promptMatchesTrainingFormat() {
    val p = RouterModel.prompt("youtube lo diwali songs play cheyyi")
    assertTrue(p.startsWith("<|im_start|>system\n" + RouterModel.SYSTEM + "<|im_end|>\n<|im_start|>user\n"))
    assertTrue(p.endsWith("<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"))
  }

  @Test fun trainingStyleReplyParses() {
    val r = IntentRouter.parse("{\"tool\": \"youtube\", \"query\": \"diwali songs\", \"play\": true}")
    assertEquals(com.example.phone.FastPaths.Route.YouTube("diwali songs", true), r)
  }
}
