package com.example.v1938

import com.example.data.model.SettingsState
import com.example.llama.BenchWatchdog
import com.example.llama.SpeedTestPlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** v1.9.38: a Speed test that runs past its limit no longer keeps the screen waiting, and a second test is refused while it runs. */
class V1938BenchWatchdogTest {
  private fun waitUntilIdle(w: BenchWatchdog, maxMs: Long = 3000) {
    val end = System.currentTimeMillis() + maxMs
    while (w.isBusy && System.currentTimeMillis() < end) Thread.sleep(5)
  }

  @Test fun aTestThatEndsInTimeReturnsItsText() {
    val w = BenchWatchdog()
    assertEquals(BenchWatchdog.Outcome.Done("numbers"), w.run(2000) { "numbers" })
    assertFalse(w.isBusy)
  }

  @Test fun aTestPastTheWaitGivesControlBackAndStaysBusyUntilItEnds() {
    val w = BenchWatchdog()
    val release = CountDownLatch(1)
    val started = CountDownLatch(1)
    val outcome = w.run(100) { started.countDown(); release.await(10, TimeUnit.SECONDS); "late" }
    assertTrue(started.await(2, TimeUnit.SECONDS))
    assertEquals(BenchWatchdog.Outcome.StillRunning, outcome)
    assertTrue("the measurement is still running", w.isBusy)
    // a second test is refused instead of queueing behind the first
    assertEquals(BenchWatchdog.Outcome.Busy, w.run(100) { "second" })
    release.countDown()
    waitUntilIdle(w)
    assertFalse("idle once the measurement has ended", w.isBusy)
    assertEquals(BenchWatchdog.Outcome.Done("third"), w.run(2000) { "third" })
  }

  @Test fun theRefusedSecondTestDoesNotRunItsBlock() {
    val w = BenchWatchdog()
    val release = CountDownLatch(1)
    w.run(50) { release.await(10, TimeUnit.SECONDS); "x" }
    var ran = false
    assertEquals(BenchWatchdog.Outcome.Busy, w.run(50) { ran = true; "y" })
    assertFalse(ran)
    release.countDown()
    waitUntilIdle(w)
  }

  @Test fun aFailureIsReportedAsText() {
    val w = BenchWatchdog()
    assertEquals(BenchWatchdog.Outcome.Done("Speed test failed: boom"), w.run(2000) { throw IllegalStateException("boom") })
    assertFalse(w.isBusy)
    assertEquals(BenchWatchdog.Outcome.Done("Speed test failed: IllegalStateException"), w.run(2000) { throw IllegalStateException() })
    assertFalse(w.isBusy)
  }

  @Test fun afterAFailureTheNextTestRuns() {
    val w = BenchWatchdog()
    w.run(2000) { throw RuntimeException("x") }
    assertEquals(BenchWatchdog.Outcome.Done("ok"), w.run(2000) { "ok" })
  }

  // ---- the plan ----
  @Test fun theScreenWaitsForTheProbeTheLimitAndTheGrace() {
    assertEquals((480 + 60 + 12) * 1000L, SpeedTestPlan.watchdogWaitMs(true))
    assertEquals((180 + 60) * 1000L, SpeedTestPlan.watchdogWaitMs(false))
    assertTrue(SpeedTestPlan.watchdogWaitMs(true) > SpeedTestPlan.timeLimitSec(true) * 1000L)
  }

  @Test fun probeLinesGoAboveTheReport() {
    assertEquals("probe a\nprobe b\nreport", SpeedTestPlan.withProbe("probe a\nprobe b\n", "report"))
    assertEquals("report", SpeedTestPlan.withProbe(null, "report"))
    assertEquals("report", SpeedTestPlan.withProbe("   ", "report"))
  }

  @Test fun stillRunningTextNamesTheLimitAndWhatToDo() {
    val t = SpeedTestPlan.stillRunningText(480)
    assertTrue(t, t.contains("480 s limit"))
    assertTrue(t.contains("cannot be interrupted"))
    assertTrue(t.contains("nothing is recorded"))
    assertTrue(t.contains("close the app from the recent apps list"))
    assertTrue(SpeedTestPlan.BUSY_TEXT.contains("still finishing in the background"))
  }

  @Test fun theRetiredReadAheadSettingStaysOffAndLoads() {
    assertFalse(SettingsState().streamReadRandom)
  }
}
