package com.example.v1914

import com.example.project.ProjectJunk
import com.example.security.SecurityManager
import com.example.security.ValidationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class V1914SecurityTest {
  @get:Rule val tmp = TemporaryFolder()
  private val sm = SecurityManager()
  private fun blocked(c: String, root: File? = null) = sm.validateCommand(c, root) is ValidationResult.Blocked

  @Test fun parentDirectoryWithoutSlashIsBlocked() {
    for (c in listOf("cd ..", "ls ..", "cd .. && ls", "cat a/..", "ls ..;ls", "cd \"..\"")) assertTrue(c, blocked(c))
  }

  @Test fun dotsThatAreNotAPathPartStayAllowed() {
    for (c in listOf("echo ...", "git log a..b", "echo \"wait...\"", "ls -la", "node app.js")) assertFalse(c, blocked(c))
  }

  @Test fun privateDataAndStorageAreBlocked() {
    for (c in listOf("cat /data/data/com.example.myapplication/files/x", "ls /storage/emulated/0", "cat /sdcard/DCIM/a.jpg", "cat</etc/hosts", "(cat /etc/hosts)", "echo x >/data/local/tmp/a"))
      assertTrue(c, blocked(c))
  }

  @Test fun theWorkspaceItselfMayBeNamedByItsFullPath() {
    val root = tmp.newFolder("proj")
    assertFalse(blocked("ls ${root.absolutePath}", root))
  }

  @Test fun symlinksAreBlocked() {
    for (c in listOf("ln -s / x", "ln -sf /data x", "ln --symbolic / x")) assertTrue(c, blocked(c))
  }

  @Test fun junkRemovalOnlyTouchesWhatTheSelfTestWrote() {
    val root = tmp.newFolder("p")
    File(root, "test_integration.txt").writeText("VibeCoderAI Integration 123")
    File(root, "patch_target.txt").writeText("line1\nREPLACED_SURGICAL\nline3")
    val mine = File(root, "notes.txt").apply { writeText("keep me") }
    val edited = File(root, "patch_target2.txt").apply { writeText("line1\nTARGET_CHUNK\nline3") }
    val userVersion = File(root, "test_integration.txt")
    assertEquals(2, ProjectJunk.clean(root))
    assertFalse(userVersion.exists())
    assertTrue(mine.exists() && edited.exists())
  }

  @Test fun aUserEditedFileWithTheSameNameIsKept() {
    val root = tmp.newFolder("p")
    val f = File(root, "patch_target.txt").apply { writeText("my real notes") }
    assertEquals(0, ProjectJunk.clean(root))
    assertTrue(f.exists())
  }

  @Test fun backupsAreCappedToTheNewest() {
    val root = tmp.newFolder("p")
    val dir = File(root, ".vibecoder_backups").apply { mkdirs() }
    repeat(15) { i -> File(dir, "a.$i.bak").apply { writeText("x"); setLastModified(1_000_000L + i * 1000L) } }
    assertEquals(5, ProjectJunk.pruneBackups(root))
    assertEquals(ProjectJunk.KEEP_BACKUPS, dir.listFiles()!!.size)
    assertTrue(File(dir, "a.14.bak").exists() && !File(dir, "a.0.bak").exists())
  }
}
