package com.example.v1914

import com.example.security.CommandGuard
import com.example.security.SecurityManager
import com.example.security.ShellWords
import com.example.security.ValidationResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class V1916GuardTest {
  @get:Rule val tmp = TemporaryFolder()
  private val sm = SecurityManager()
  private val ws: File by lazy { tmp.newFolder("ws").also { File(it, "setup.sh").writeText("echo a\necho b\necho c\n"); File(it, "app.js").writeText("1\n") } }
  private fun blocked(c: String, strict: Boolean = false) = sm.validateCommand(c, ws, strict) is ValidationResult.Blocked
  private fun words(c: String) = ShellWords.parse(c).tokens.filter { !it.op }.map { it.text }

  @Test fun quotesAndEscapesAreRemovedBeforeChecking() {
    assertEquals(listOf("cat", "/data/x"), words("cat /da\"\"ta/x"))
    assertEquals(listOf("cat", "/data/x"), words("cat /d\\ata/x"))
    assertEquals(listOf("echo", "a b", "c d"), words("echo 'a b' \"c d\""))
    assertNotNull(ShellWords.parse("echo \"abc").error)
  }

  @Test fun dynamicWordsAreRecognised() {
    assertTrue(ShellWords.parse("cat \$HOME/x").tokens.any { it.dynamic })
    assertTrue(ShellWords.parse("echo \"\$(ls)\"").tokens.any { it.dynamic })
    assertTrue(ShellWords.parse("cat {/etc,x}/passwd").tokens.any { it.dynamic })
    assertFalse(ShellWords.parse("grep 'foo\$x' f").tokens.any { it.dynamic })
    assertFalse(ShellWords.parse("find . -exec ls {} ;").tokens.any { it.dynamic })
  }

  @Test fun heredocBodiesAreTextUnlessTheyExpand() {
    assertFalse(ShellWords.parse("cat > a.txt <<'EOF'\nhello \$(rm x)\nEOF\nls").tokens.any { it.dynamic })
    assertTrue(ShellWords.parse("cat <<EOF\n\$(whoami)\nEOF\n").tokens.any { it.dynamic })
  }

  @Test fun obfuscatedPathsAreBlockedInBothModes() {
    for (c in listOf("cat /da\"\"ta/data/x", "cat '/'\"etc\"/hosts", "cat /d\\ata/x", "cd ..", "cat /e*c/passwd", "cat {/etc/hosts,x}", "cat --file=/etc/hosts", "PATH=/system/bin:/sbin ls", "cat /", "echo hi > /sdcard/x"))
      for (s in listOf(false, true)) assertTrue("$c strict=$s", blocked(c, s))
  }

  @Test fun agentCommandsMayNotLeaveTheProject() {
    for (c in listOf("cat ~/x", "ls /usr/bin", "cat /bin/ls", "cat /tmp/x")) assertTrue(c, blocked(c, true))
    assertFalse(blocked("ls ~", false))
  }

  @Test fun ordinaryCommandsStillRun() {
    for (c in listOf("ls -la", "echo \"hello world\"", "grep \"/api/\" src", "cat a.txt | grep foo", "echo hi > out.txt 2>/dev/null", "find . -name \"*.js\"", "mkdir -p a/b && cd a/b", "git log a..b", "ls ${ws.absolutePath}", "cat > f.txt <<'EOF'\nline /api\nEOF"))
      for (s in listOf(false, true)) assertFalse("$c strict=$s", blocked(c, s))
  }

  @Test fun codeRunningCommandsGetAWarningNamingTheFile() {
    assertTrue(CommandGuard.warning("sh setup.sh", ws)!!.contains("runs the script setup.sh (3 lines)"))
    assertTrue(CommandGuard.warning("node app.js", ws)!!.contains("node code from app.js (1 lines)"))
    for (c in listOf(". ./setup.sh", "bash -c 'ls'", "echo hi | sh", "eval \"\$x\"", "node -e \"1\"", "env FOO=1 ls", "ls | xargs rm", "find . -exec rm {} ;", "./gradlew build", "cat \$HOME/x", "FOO=1 sh setup.sh", "cd a && sh setup.sh", "if true; then sh setup.sh; fi"))
      assertNotNull(c, CommandGuard.warning(c, ws))
  }

  @Test fun plainFileCommandsGetNoWarning() {
    for (c in listOf("ls -la", "cat a | grep b", "echo hi > x.txt", "mkdir a && cd a", "grep -rn foo src", "echo hi > sh")) assertNull(c, CommandGuard.warning(c, ws))
  }
}
