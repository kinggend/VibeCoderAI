package com.example.v1914

import com.example.project.ProjectOrigin
import com.example.project.ProjectOrigin.Target
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class V1914OriginTest {
  @get:Rule val tmp = TemporaryFolder()

  private fun project(name: String) = tmp.newFolder(name).also {
    File(it, "index.html").writeText("<html>")
    File(it, "app.js").writeText("x")
    File(it, ".vibecoder/backups").mkdirs()
    File(it, ".vibecoder/backups/r.zip").writeText("z")
  }

  private fun at(root: File, path: String) = ProjectOrigin.resolve(root, "https://${ProjectOrigin.host(root)}$path")

  @Test fun everyProjectHasItsOwnStableOrigin() {
    val a = project("a"); val b = project("b")
    assertNotEquals(ProjectOrigin.host(a), ProjectOrigin.host(b))
    assertEquals(ProjectOrigin.host(a), ProjectOrigin.host(File(a.path + "/../a")))
    assertTrue(ProjectOrigin.owns(a, ProjectOrigin.url(a)))
    assertFalse(ProjectOrigin.owns(b, ProjectOrigin.url(a)))
    assertFalse(ProjectOrigin.owns(a, "http://${ProjectOrigin.host(a)}/index.html"))
    assertFalse(ProjectOrigin.owns(a, "https://example.com/index.html"))
  }

  @Test fun servesProjectFiles() {
    val a = project("a")
    assertTrue(at(a, "/") is Target.Ok)
    assertTrue(at(a, "/app.js?v=2") is Target.Ok)
    assertTrue(at(a, "/missing.js") is Target.NotFound)
  }

  @Test fun traversalDotFoldersAndSymlinksAreForbidden() {
    val a = project("a"); val b = project("b")
    File(b, "secret.txt").writeText("s")
    for (p in listOf("/../b/secret.txt", "/%2e%2e/b/secret.txt", "/sub/..%2f..%2fb/secret.txt", "/.vibecoder/backups/r.zip", "/..%5Cb/secret.txt", "/a%00.js"))
      assertTrue(p, at(a, p) is Target.Forbidden)
  }

  @Test fun mimeTypes() {
    assertEquals("text/javascript", ProjectOrigin.mime("app.js"))
    assertEquals("text/html", ProjectOrigin.mime("index.html"))
    assertEquals("image/png", ProjectOrigin.mime("x.PNG"))
    assertEquals("application/octet-stream", ProjectOrigin.mime("x.bin"))
  }
}
