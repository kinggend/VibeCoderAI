package com.example.v1919

import com.example.agent.DotsState
import com.example.agent.ProjectWatch
import com.example.agent.RunAlerts
import com.example.agent.RunDots
import com.example.agent.RunKind
import com.example.agent.RunRecord
import com.example.agent.RunStatus
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.File

class V1919WatchTest {
  private fun proj(vararg files: Pair<String, String>): File {
    val d = java.nio.file.Files.createTempDirectory("pw").toFile()
    files.forEach { (n, c) -> File(d, n).also { it.parentFile.mkdirs() }.writeText(c) }
    return d
  }

  @Test fun balancedAndCutOffScripts() {
    assertFalse(ProjectWatch.hasUnclosedBracket("function a(){ return [1,2,{x:3}]; }"))
    assertFalse(ProjectWatch.hasUnclosedBracket("var s = '{'; var t = \"(\"; var r = /[{(]/g; x = a / b;"))
    assertFalse(ProjectWatch.hasUnclosedBracket("const t = `a \${ b + `x \${ c }` } {`; f(t);"))
    assertFalse(ProjectWatch.hasUnclosedBracket("// { ( [\n/* { */ foo();"))
    assertTrue(ProjectWatch.hasUnclosedBracket("function a(){ if (x) { y(); "))
    assertTrue(ProjectWatch.hasUnclosedBracket("foo(1, 2"))
    assertTrue(ProjectWatch.hasUnclosedBracket("a(); /* never ends"))
    assertFalse(ProjectWatch.hasUnclosedBracket("a(); } }")) // a stray closer is not reported
    assertFalse(ProjectWatch.hasUnclosedBracket("a{background:url(//cdn.x.com/a.png)}", css = true))
    assertTrue(ProjectWatch.hasUnclosedBracket("body{margin:0} .a{color:red;", css = true))
  }

  @Test fun projectProblems() {
    val good = proj(
      "index.html" to "<link rel=\"stylesheet\" href=\"styles.css\"><link rel=\"icon\" href=\"favicon.ico\"><script src=\"app.js\"></script><script src=\"https://cdn.x.com/a.js\"></script>",
      "styles.css" to "body{margin:0}", "app.js" to "function a(){ return 1; }"
    )
    assertTrue(ProjectWatch.staticProblems(good).isEmpty())
    val missing = ProjectWatch.staticProblems(proj("index.html" to "<script src=\"app.js\"></script><link href=\"s.css\" rel=\"stylesheet\">"))
    assertEquals(2, missing.size)
    assertTrue(ProjectWatch.staticProblems(proj("index.html" to "<script src=\"app.js\"></script>", "app.js" to "function a(){ if (x) { run(); ")).single().contains("cut off"))
    assertTrue(ProjectWatch.staticProblems(proj("index.html" to "<script src=\"app.js\"></script>", "app.js" to "")).single().contains("empty"))
    assertTrue(ProjectWatch.staticProblems(proj("index.html" to "<script src=\"libs/three.min.js\"></script><script src=\"three.js\"></script>")).isEmpty())
    assertEquals(listOf("index.html is missing"), ProjectWatch.staticProblems(proj("app.js" to "a()")))
    assertTrue(ProjectWatch.staticProblems(proj("main.py" to "print(1)")).isEmpty())
    assertTrue(ProjectWatch.staticProblems(proj("index.html" to "<script src=\"../../etc/passwd\"></script><script src=\"a/../app.js\"></script>", "app.js" to "x()")).isEmpty())
  }

  @Test fun summaryAndSignature() {
    assertNull(ProjectWatch.summary(emptyList()))
    val f1 = ProjectWatch.Finding("Chess", listOf("app.js is empty", "index.html loads x.js but it does not exist"))
    val f2 = ProjectWatch.Finding("Car", listOf("styles.css looks cut off"))
    assertEquals("Chess: app.js is empty (+1 more)", ProjectWatch.summary(listOf(f1))!!.second)
    assertEquals("2 projects need attention", ProjectWatch.summary(listOf(f1, f2))!!.first)
    assertEquals(ProjectWatch.signature(listOf(f1, f2)), ProjectWatch.signature(listOf(f2, f1)))
  }

  @Test fun dotsStates() {
    assertEquals(DotsState.NEEDS_YOU, RunDots.of(true, true))
    assertEquals(DotsState.WORKING, RunDots.of(true, false))
    assertEquals(DotsState.IDLE, RunDots.of(false, false))
    assertEquals(DotsState.DONE, RunDots.of(RunStatus.DONE))
    assertEquals("Working", RunDots.label(DotsState.WORKING, ""))
    assertEquals("Waiting for you", RunDots.label(DotsState.NEEDS_YOU, "x"))
    for (s in DotsState.values()) for (k in 0..100) for (i in 0..2) assertTrue(RunDots.level(s, k / 100f, i) in 0f..1f)
  }

  @Test fun alertsOnlyForRunsSeenWorking() {
    fun rec(id: String, st: RunStatus, result: String = "") = RunRecord(id, RunKind.CODING, "Build chess", result = result, status = st, tag = "Chess", startedAt = 1L)
    val seen = HashMap<String, RunStatus>()
    assertTrue(RunAlerts.newlyFinished(seen, listOf(rec("a", RunStatus.DONE), rec("b", RunStatus.WORKING))).isEmpty())
    assertEquals(listOf("b"), RunAlerts.newlyFinished(seen, listOf(rec("a", RunStatus.DONE), rec("b", RunStatus.DONE))).map { it.id })
    assertTrue(RunAlerts.newlyFinished(seen, listOf(rec("a", RunStatus.DONE), rec("b", RunStatus.DONE))).isEmpty())
    assertTrue(RunAlerts.newlyFinished(seen, listOf(rec("d", RunStatus.WORKING))).isEmpty())
    assertTrue(RunAlerts.newlyFinished(seen, listOf(rec("d", RunStatus.STOPPED))).isEmpty())
    assertEquals("Chess finished", RunAlerts.title(rec("x", RunStatus.DONE)))
    assertEquals("Chess needs attention", RunAlerts.title(rec("x", RunStatus.FAILED)))
    assertEquals("All good", RunAlerts.text(rec("x", RunStatus.DONE, "\nAll good\nmore")))
  }
}
