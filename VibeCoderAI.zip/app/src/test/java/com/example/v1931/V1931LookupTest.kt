package com.example.v1931

import com.example.data.SpeedHistory
import com.example.data.SpeedRecord
import com.example.data.model.SettingsState
import com.example.llama.LookupBench
import com.example.llama.LookupNumbers
import com.example.llama.LookupRun
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.31: experimental prompt-lookup decoding: the numbers, the code-edit A/B report and how lookup replies sit in the speed history. */
class V1931LookupTest {
  private fun nums(active: Boolean = true, rounds: Long = 10, drafted: Long = 40, accepted: Long = 30, roundTokens: Long = 40, pauses: Long = 0, block: Int = 0) =
    LookupNumbers(block, true, active, rounds, drafted, accepted, 500.0, roundTokens, 20, 300.0, pauses)

  private fun run(lookup: Boolean, tps: Double?, text: String = "x = 1", n: Int = 100, numbers: LookupNumbers? = null) =
    LookupRun(lookup, n, tps, text, numbers ?: if (lookup) nums() else null)

  // ---- native numbers ----
  @Test fun nativeArrayBecomesNumbers() {
    val n = LookupNumbers.from(doubleArrayOf(0.0, 1.0, 1.0, 12.0, 60.0, 45.0, 800.0, 57.0, 9.0, 120.0, 2.0))!!
    assertEquals(0, n.block); assertTrue(n.enabled); assertTrue(n.active)
    assertEquals(12L, n.rounds); assertEquals(60L, n.drafted); assertEquals(45L, n.accepted)
    assertEquals(75.0, n.acceptPct!!, 0.0001)
    assertEquals(57.0 / 12.0, n.tokensPerRound!!, 0.0001)
    assertEquals(2L, n.pauses)
  }

  @Test fun shortOrMissingArrayIsNull() {
    assertNull(LookupNumbers.from(null))
    assertNull(LookupNumbers.from(DoubleArray(10)))
  }

  @Test fun noGuessesMeansNoPercentageNotZero() {
    val n = nums(rounds = 0, drafted = 0, accepted = 0, roundTokens = 0)
    assertNull(n.acceptPct)
    assertNull(n.tokensPerRound)
  }

  // ---- workload ----
  @Test fun workloadIsFixedAndMostlyCopyable() {
    assertTrue(LookupBench.WORKLOAD.contains("```python"))
    assertEquals(3, Regex("compute_total").findAll(LookupBench.WORKLOAD).count())
    assertEquals(listOf(false, true, true, false), LookupBench.ORDER)
    assertTrue(LookupBench.MAX_TOKENS in 64..256)
  }

  // ---- numbers helpers ----
  @Test fun decodeTpsUsesNMinusOneIntervals() {
    assertEquals(10.0, LookupBench.decodeTps(11, 1_000_000_000L, 2_000_000_000L)!!, 0.0001)
    assertNull(LookupBench.decodeTps(1, 1L, 2L))
    assertNull(LookupBench.decodeTps(5, 0L, 2L))
    assertNull(LookupBench.decodeTps(5, 5L, 5L))
  }

  @Test fun compareFindsTheFirstDifference() {
    assertTrue(LookupBench.compare("same", "same").identical)
    val d = LookupBench.compare("hello world\nfoo", "hello wxrld\nfoo")
    assertFalse(d.identical)
    assertEquals(7, d.index)
    assertFalse(d.a.contains('\n'))
    // one text is a prefix of the other
    val p = LookupBench.compare("abc", "abcdef")
    assertFalse(p.identical); assertEquals(3, p.index)
    // difference at 0, empty texts
    assertEquals(0, LookupBench.compare("a", "b").index)
    assertFalse(LookupBench.compare("", "x").identical)
    assertTrue(LookupBench.compare("", "").identical)
  }

  // ---- verdict ----
  @Test fun clearlyFasterAndClearlySlower() {
    assertTrue(LookupBench.verdict(listOf(10.0, 10.0), listOf(14.0, 14.0)).contains("faster"))
    val slower = LookupBench.verdict(listOf(10.0, 10.0), listOf(7.0, 7.0))
    assertTrue(slower.contains("SLOWER")); assertTrue(slower.contains("Leave it off"))
  }

  @Test fun smallGapIsNoClearDifference() {
    assertTrue(LookupBench.verdict(listOf(10.0, 10.0), listOf(10.3, 10.3)).startsWith("No clear difference"))
    assertTrue(LookupBench.verdict(listOf(10.0, 10.0), listOf(9.7, 9.7)).startsWith("No clear difference"))
  }

  @Test fun gapSmallerThanTheRunsOwnNoiseIsNotCalledFaster() {
    // the two "off" runs already differ by 40%: a 25% gain is inside that noise
    assertTrue(LookupBench.verdict(listOf(8.0, 11.2), listOf(12.0, 12.0)).startsWith("No clear difference"))
  }

  @Test fun missingNumbersGiveNoVerdict() {
    assertEquals("Not enough generated tokens to compare.", LookupBench.verdict(emptyList(), listOf(5.0)))
    assertEquals("Not enough generated tokens to compare.", LookupBench.verdict(listOf(5.0), emptyList()))
    assertEquals("Not enough generated tokens to compare.", LookupBench.verdict(listOf(0.0), listOf(5.0)))
  }

  // ---- report ----
  @Test fun fullReportShowsRunsOutputAndVerdict() {
    val runs = listOf(run(false, 10.0), run(true, 15.0), run(true, 15.5), run(false, 10.2))
    val r = LookupBench.report(runs, false)
    assertTrue(r.contains("off / on / on / off"))
    assertTrue(r.contains("off #1")); assertTrue(r.contains("off #2")); assertTrue(r.contains("on  #1")); assertTrue(r.contains("on  #2"))
    assertTrue(r.contains("75% of 40 guesses accepted"))
    assertTrue(r.contains("Output: identical"))
    assertTrue(r.contains("faster"))
    assertTrue(r.contains("not a general speed-up"))
    assertTrue(r.contains("Mean generation: off 10.1 tok/s, on 15.2 tok/s") || r.contains("Mean generation: off 10.1 tok/s, on 15.3 tok/s"))
  }

  @Test fun differingOutputIsReportedWithPositionNotHidden() {
    val runs = listOf(run(false, 10.0, "abcdef"), run(true, 10.0, "abcXef"), run(true, 10.0, "same"), run(false, 10.0, "same"))
    val r = LookupBench.report(runs, false)
    assertTrue(r.contains("Output differed in pair 1, first at character 3"))
    assertFalse(r.contains("pair 2"))
    assertFalse(r.contains("Output: identical"))
    assertTrue(r.contains("round floats slightly differently"))
  }

  @Test fun pairsAreMatchedByOrder() {
    // order off1, on1, on2, off2: pair 2 is off2 with on2
    val runs = listOf(run(false, 10.0, "same"), run(true, 10.0, "same"), run(true, 10.0, "ZZZ"), run(false, 10.0, "AAA"))
    val r = LookupBench.report(runs, false)
    assertTrue(r.contains("pair 2")); assertFalse(r.contains("pair 1"))
  }

  @Test fun stoppedEarlyHasNoVerdict() {
    val r = LookupBench.report(listOf(run(false, 3.0), run(true, 4.0)), true)
    assertTrue(r.contains("no verdict")); assertFalse(r.contains("faster")); assertFalse(r.contains("Mean generation"))
    // fewer runs than planned also counts as incomplete
    assertTrue(LookupBench.report(listOf(run(false, 3.0)), false).contains("no verdict"))
  }

  @Test fun lookupThatNeverRanIsSaidSo() {
    val inactive = nums(active = false, rounds = 0, drafted = 0, accepted = 0, roundTokens = 0, block = 4)
    val runs = listOf(run(false, 10.0), run(true, 10.0, numbers = inactive), run(true, 10.0, numbers = inactive), run(false, 10.0))
    val r = LookupBench.report(runs, false)
    assertTrue(r.contains("lookup did not run"))
    assertTrue(r.contains("nothing to compare"))
    assertFalse(r.contains("faster"))
  }

  @Test fun pausesAndMissingSpeedAreShown() {
    val paused = nums(pauses = 3)
    val runs = listOf(run(false, null), run(true, 9.0, numbers = paused), run(true, 9.0, numbers = paused), run(false, 10.0))
    val r = LookupBench.report(runs, false)
    assertTrue(r.contains("n/a"))
    assertTrue(r.contains("paused 3x"))
  }

  @Test fun everyBlockReasonHasWords() {
    for (b in 1..4) assertTrue(LookupBench.reason(b).length > 20)
    assertTrue(LookupBench.reason(1).contains("streams"))
    assertEquals("unknown reason", LookupBench.reason(99))
  }

  // ---- history and settings ----
  private fun rec(tps: Double, lookup: Boolean) = SpeedRecord(
    ts = 1, source = "chat", backend = "local", model = "m.gguf", promptTokens = 100, cachedTokens = 0, outputTokens = 50,
    ttftMs = 2000, decodeTps = tps, lookup = lookup
  )

  @Test fun lookupFlagRoundTripsAndOldLinesReadAsOff() {
    val line = SpeedHistory.toLine(rec(5.0, true))
    assertTrue(SpeedHistory.fromLine(line)!!.lookup)
    assertFalse(SpeedHistory.fromLine(SpeedHistory.toLine(rec(5.0, false)))!!.lookup)
    // a v1.9.30 line has no "lookup" key
    val old = line.replace(",\"lookup\":true", "").replace("\"lookup\":true,", "")
    assertFalse(old.contains("lookup"))
    assertFalse(SpeedHistory.fromLine(old)!!.lookup)
  }

  @Test fun lookupRepliesAreCountedButNotInTheMedians() {
    val list = listOf(rec(5.0, false), rec(5.0, false), rec(50.0, true), rec(60.0, true))
    val s = SpeedHistory.summary(list, "local")!!
    assertEquals(2, s.runs)
    assertEquals(2, s.lookupRuns)
    assertEquals(5.0, s.medianDecodeTps!!, 0.0001)
  }

  @Test fun onlyLookupRepliesStillShowACount() {
    val s = SpeedHistory.summary(listOf(rec(50.0, true)), "local")!!
    assertEquals(0, s.runs); assertEquals(1, s.lookupRuns); assertNull(s.medianDecodeTps)
  }

  @Test fun recentLineSaysLookupOn() {
    assertTrue(SpeedHistory.line(rec(5.0, true)).contains("lookup on"))
    assertFalse(SpeedHistory.line(rec(5.0, false)).contains("lookup"))
  }

  @Test fun lookupIsOffByDefault() {
    assertFalse(SettingsState().lookupDecoding)
    assertNotNull(SettingsState().copy(lookupDecoding = true))
    assertTrue(SettingsState().copy(lookupDecoding = true).lookupDecoding)
  }
}
