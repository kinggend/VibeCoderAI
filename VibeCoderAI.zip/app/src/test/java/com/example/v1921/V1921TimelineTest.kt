package com.example.v1921

import com.example.agent.RunTimeline
import com.example.agent.RunTimeline.FileState
import com.example.agent.RunTimeline.Item
import com.example.agent.RunTimeline.Kind
import com.example.agent.RunTimeline.State
import com.example.agent.RunTimeline.Status
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V1921TimelineTest {
  private fun n(t: String) = Item.Note(t)
  private fun f(p: String, lines: Int, s: FileState = FileState.APPLIED) = Item.File(p, lines, s)

  private val intro = n("Working on it. I will plan, build, then test the app myself.")
  private val plan = n(
    "Plan:\n1. index.html: page layout and canvas element\n2. styles.css: basic styling and responsive layout\n" +
      "3. app.js: Three.js setup, 3D board rendering, and chess game logic"
  )
  private val s1 = n("Step 1 of 3: index.html: page layout and canvas element")
  private val s2 = n("Step 2 of 3: styles.css: basic styling and responsive layout")
  private val s3 = n("Step 3 of 3: app.js: Three.js setup, 3D board rendering, and chess game logic")
  private val testing = n("Testing the app...")
  private val done = n("Done. The app loaded with no errors. Tap Preview to try it.")

  @Test fun finishedRunIsOneDoneTimeline() {
    val m = RunTimeline.build(listOf(intro, plan, s1, f("index.html", 21), s2, f("styles.css", 83), s3, f("app.js", 176), testing, done), running = false)
    assertEquals(State.DONE, m.state)
    assertEquals(3, m.done); assertEquals(3, m.total); assertEquals(3, m.modifiedFiles)
    assertEquals(1f, m.fraction!!, 0.001f)
    assertNull(m.current)
    assertEquals(4, m.rows.size)
    assertTrue(m.rows.take(3).all { it.kind == Kind.STEP && it.status == Status.DONE })
    assertEquals(listOf("index.html"), m.rows[0].files.map { it.path })
    assertEquals(176, m.rows[2].files.single().lines)
    assertEquals(Kind.CHECK, m.rows[3].kind); assertEquals(Status.DONE, m.rows[3].status)
    assertTrue(m.rows.none { it.status == Status.RUNNING || it.status == Status.PENDING })
  }

  @Test fun runningRunShowsTheCurrentStepAndProgress() {
    val m = RunTimeline.build(listOf(intro, plan, s1, f("index.html", 21), s2), running = true)
    assertEquals(State.RUNNING, m.state)
    assertEquals("styles.css: basic styling and responsive layout", m.current)
    assertEquals(1, m.done); assertEquals(3, m.total)
    assertEquals(Status.DONE, m.rows[0].status)
    assertEquals(Status.RUNNING, m.rows[1].status)
    assertEquals(Status.PENDING, m.rows[2].status)
    assertTrue(m.fraction!! > 0.3f && m.fraction!! < 0.4f)
  }

  @Test fun repairedRunEndsDoneWithTheHistoryKept() {
    val m = RunTimeline.build(
      listOf(plan, s1, s2, s3, f("app.js", 170), testing, n("Found 2 problem(s). Fixing, attempt 1 of 2."), f("app.js", 180), testing, done),
      running = false
    )
    assertEquals(State.DONE, m.state)
    val kinds = m.rows.map { it.kind }
    assertEquals(listOf(Kind.STEP, Kind.STEP, Kind.STEP, Kind.CHECK, Kind.FIX, Kind.CHECK), kinds)
    assertEquals(Status.FAILED, m.rows[3].status)
    assertEquals("Test found 2 problem(s)", m.rows[3].label)
    assertEquals("Fix attempt 1 of 2", m.rows[4].label)
    assertEquals(Status.DONE, m.rows[4].status)
    assertEquals(180, m.rows[4].files.single().lines)
    assertEquals(Status.DONE, m.rows[5].status)
    assertEquals(1, m.modifiedFiles) // app.js twice, one file
  }

  @Test fun gaveUpIsFailedWithDetails() {
    val m = RunTimeline.build(
      listOf(plan, s1, s2, s3, testing, n("Found 3 problem(s). Fixing, attempt 1 of 2."), testing,
        n("Stopped after 2 fix attempts. Remaining problems:\nThe canvas has zero size\nx is not defined\nTap Regenerate or describe what to fix.")),
      running = false
    )
    assertEquals(State.FAILED, m.state)
    assertNotNull(m.failure)
    assertTrue(m.failure!!.contains("zero size"))
    val last = m.rows.last()
    assertEquals(Status.FAILED, last.status)
    assertEquals("Stopped after 2 fix attempts", last.label)
    assertTrue(last.detail!!.contains("x is not defined"))
    assertTrue(m.rows.none { it.status == Status.RUNNING })
  }

  @Test fun userStoppedRunIsStoppedNotDone() {
    val m = RunTimeline.build(listOf(plan, s1, f("index.html", 21), s2), running = false)
    assertEquals(State.STOPPED, m.state)
    assertEquals(Status.DONE, m.rows[0].status)
    assertEquals(Status.STOPPED, m.rows[1].status)
    assertEquals(Status.PENDING, m.rows[2].status)
    assertEquals(1, m.done)
  }

  @Test fun specialistRunNamesTheAgentAndListsTools() {
    val m = RunTimeline.build(
      listOf(n("Auto: Debugger agent."), n("Debugger agent is working."), n("Tool: Reading app.js"), n("Tool: Editing app.js"), f("app.js", 120), n("Tested the app: no errors.")),
      running = false
    )
    assertEquals("Debugger", m.agent)
    assertEquals(State.DONE, m.state)
    assertEquals(listOf(Kind.TOOL, Kind.TOOL, Kind.CHECK), m.rows.map { it.kind })
    assertEquals(120, m.rows[1].files.single().lines)
    assertEquals(0, m.total); assertNull(m.fraction)
  }

  @Test fun singleStepPlanTakesItsFiles() {
    val m = RunTimeline.build(listOf(n("Plan:\n1. app.js: a tiny script"), f("app.js", 12), testing, done), running = false)
    assertEquals(State.DONE, m.state)
    assertEquals(1, m.total); assertEquals(1, m.done)
    assertEquals(12, m.rows[0].files.single().lines)
  }

  @Test fun declinedFixIsStopped() {
    val m = RunTimeline.build(listOf(plan, s1, s2, s3, testing, n("Found 1 problem(s). Fixing, attempt 1 of 2."), n("Fix not applied because you declined it. Stopping here.")), running = false)
    assertEquals(State.STOPPED, m.state)
    assertTrue(m.rows.none { it.status == Status.RUNNING })
  }

  @Test fun declinedStepIsMarkedFailedButTheRunGoesOn() {
    val m = RunTimeline.build(listOf(plan, s1, n("You declined the changes for step 1. Going on with the next step."), s2, s3, testing, done), running = false)
    assertEquals(State.DONE, m.state)
    assertEquals(Status.FAILED, m.rows[0].status)
    assertEquals("You declined these changes", m.rows[0].detail)
    assertEquals(2, m.done)
  }

  @Test fun unknownNotesAndFileFailuresDoNotBreakTheCard() {
    val m = RunTimeline.build(
      listOf(n("Something brand new happened"), n("Could not write app.js: disk full"), f("a.js", 3, FileState.FAILED), n("Cross-file check:\nindex.html loads x.js but it does not exist")),
      running = false
    )
    assertEquals(Kind.INFO, m.rows[0].kind)
    assertEquals("Could not write app.js", m.rows[1].label)
    assertEquals(Status.FAILED, m.rows[1].status)
    assertEquals(0, m.modifiedFiles)
    assertEquals("Cross-file check:", m.rows.last().label)
    assertFalse(m.rows.last().detail.isNullOrBlank())
  }

  @Test fun emptyRunIsHarmless() {
    val m = RunTimeline.build(emptyList(), running = true)
    assertEquals(State.RUNNING, m.state)
    assertTrue(m.rows.isEmpty())
    assertNull(m.current)
    assertNull(m.fraction)
  }

  @Test fun pendingFileKeepsItsState() {
    val m = RunTimeline.build(listOf(plan, s1, f("index.html", 21, FileState.PENDING)), running = false)
    assertEquals(FileState.PENDING, m.rows[0].files.single().state)
    assertEquals(0, m.modifiedFiles)
  }
}

class V1921GroupingTest {
  private val U = com.example.agent.RunGrouping.Kind.USER
  private val N = com.example.agent.RunGrouping.Kind.NOTE
  private val F = com.example.agent.RunGrouping.Kind.FILES
  private val O = com.example.agent.RunGrouping.Kind.OTHER
  private fun g(vararg k: com.example.agent.RunGrouping.Kind) = com.example.agent.RunGrouping.group(k.toList())

  @Test fun notesAndFilesBetweenMessagesBecomeOneRun() {
    val s = g(U, N, N, N, F, N, F, N, N)
    assertEquals(2, s.size)
    assertEquals(com.example.agent.RunGrouping.Span(0, 0, false), s[0])
    assertEquals(com.example.agent.RunGrouping.Span(1, 8, true), s[1])
  }

  @Test fun aStreamingOrTextMessageSplitsTheRun() {
    val s = g(U, N, F, O, N)
    assertEquals(listOf(false, true, false, true), s.map { it.isRun })
    assertEquals(1, s[1].start); assertEquals(2, s[1].end)
    assertEquals(4, s[3].start)
  }

  @Test fun filesWithoutNotesAreNotARun() {
    val s = g(U, F, F, O)
    assertTrue(s.none { it.isRun })
    assertEquals(4, s.size)
  }

  @Test fun everyMessageIsCoveredOnceInOrder() {
    val kinds = listOf(U, N, F, N, U, O, N, N, F, F, O)
    val s = com.example.agent.RunGrouping.group(kinds)
    val covered = s.flatMap { (it.start..it.end).toList() }
    assertEquals(kinds.indices.toList(), covered)
  }

  @Test fun latestRunIsTheOneWithNoUserMessageAfterIt() {
    val k1 = listOf(U, N, F, N)
    assertEquals(com.example.agent.RunGrouping.Span(1, 3, true), com.example.agent.RunGrouping.latestRun(com.example.agent.RunGrouping.group(k1), k1))
    val k2 = listOf(U, N, F, N, U)
    assertNull(com.example.agent.RunGrouping.latestRun(com.example.agent.RunGrouping.group(k2), k2))
    val k3 = listOf(U, N, N, O)
    assertEquals(com.example.agent.RunGrouping.Span(1, 2, true), com.example.agent.RunGrouping.latestRun(com.example.agent.RunGrouping.group(k3), k3))
    assertNull(com.example.agent.RunGrouping.latestRun(emptyList(), emptyList()))
  }
}
