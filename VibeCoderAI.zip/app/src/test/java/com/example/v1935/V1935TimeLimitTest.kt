package com.example.v1935

import com.example.llama.SpeedTestPlan
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.35: the Speed test has a time limit; a streamed model took 4 minutes at the default read pattern, so the limit is twice that. */
class V1935TimeLimitTest {
  @Test fun streamedModelsGetEightMinutesOthersThree() {
    assertEquals(480, SpeedTestPlan.timeLimitSec(true))
    assertEquals(180, SpeedTestPlan.timeLimitSec(false))
  }

  @Test fun theLimitIsLongerThanTheMeasuredDefaultRuns() {
    // measured on a phone: 121.4 s + 116.4 s and 34.8 s + 188.0 s for the shortened streamed test
    assertTrue(SpeedTestPlan.STREAMING_LIMIT_SEC > 2 * 237)
    assertTrue(SpeedTestPlan.STREAMING_LIMIT_SEC > 222)
  }

  @Test fun onlyTheLimitTextIsRecognisedAsEndedAtTheLimit() {
    assertTrue(SpeedTestPlan.endedAtLimit("Speed test stopped at its time limit (480 s) while generating. No speed numbers were recorded.\nStorage read so far: 1 MB"))
    assertFalse(SpeedTestPlan.endedAtLimit("Speed test stopped."))
    assertFalse(SpeedTestPlan.endedAtLimit("Prompt: 128 tokens in 1.4 s"))
    assertFalse(SpeedTestPlan.endedAtLimit(""))
  }
}
