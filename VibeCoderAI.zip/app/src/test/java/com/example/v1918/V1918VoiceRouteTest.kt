package com.example.v1918

import com.example.agent.VoiceRoute
import com.example.agent.VoiceRoute.Target
import org.junit.Assert.assertEquals
import org.junit.Test

class V1918VoiceRouteTest {
  private fun d(text: String, role: String = "auto", phoneOn: Boolean = false, chatOnly: Boolean = false, hasApp: Boolean = true) =
    VoiceRoute.decide(text, role, phoneOn, chatOnly, hasApp)

  @Test fun phoneCommandSwitchesThePhoneAgentOn() {
    assertEquals(Target.PHONE_SWITCH, d("open youtube").target)
    assertEquals(Target.PHONE_SWITCH, d("Open YouTube.").target)
    assertEquals(Target.PHONE_SWITCH, d("call mom", hasApp = false).target)
    assertEquals(Target.PHONE_SWITCH, d("please open the camera").target)
    assertEquals("Phone agent", d("open youtube").label)
  }

  @Test fun questionsAndProjectWordsStayWithTheCodingAgent() {
    assertEquals(Target.CODING, d("how does the camera api work").target)
    assertEquals(Target.CODING, d("open the project").target)
    assertEquals(Target.CODING, d("start a new project").target)
  }

  @Test fun chatTabNeverSwitchesToPhone() {
    assertEquals(Target.CHAT, d("open youtube", chatOnly = true).target)
  }

  @Test fun explicitRoleIsKept() {
    assertEquals("Debugger", d("open youtube", role = "debugger").label)
    assertEquals(Target.CODING, d("open youtube", role = "debugger").target)
  }

  @Test fun autoPicksTheRoleLikeTyping() {
    assertEquals("Builder", d("create a chess game", hasApp = false).label)
    assertEquals("Debugger", d("fix the login bug").label)
    assertEquals("Reviewer", d("review my code and list problems").label)
    assertEquals("Designer", d("make the UI beautiful with animations").label)
  }

  @Test fun phoneAgentAlreadyOnFollowsTheSameRulesAsSubmit() {
    assertEquals(Target.PHONE, d("open whatsapp", phoneOn = true).target)
    assertEquals(Target.CODING, d("create a todo app", phoneOn = true, hasApp = false).target)
    assertEquals(Target.PHONE, d("create a todo app", role = "builder", phoneOn = true, hasApp = false).target)
  }
}
