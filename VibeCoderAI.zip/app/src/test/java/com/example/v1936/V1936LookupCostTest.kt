package com.example.v1936

import com.example.llama.BatchCost
import com.example.llama.BatchCostRow
import com.example.llama.LookupBench
import com.example.llama.LookupNumbers
import com.example.llama.LookupRun
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.36: the Lookup test shows what a batch costs next to a plain step, probes the batch cost directly, and says when a run was disturbed. */
class V1936LookupCostTest {
  private val sizes = intArrayOf(1, 2, 4, 9)

  /** Native layout: context, passes, then median/min/max per size. */
  private fun probe(vararg medians: Double, ctx: Double = 402.0, passes: Double = 5.0): DoubleArray {
    val v = ArrayList<Double>()
    v.add(ctx); v.add(passes)
    for (m in medians) { v.add(m); v.add(m * 0.9); v.add(m * 1.2) }
    return v.toDoubleArray()
  }

  private fun nums(rounds: Long = 10, roundMs: Double = 5400.0, singles: Long = 20, singleMs: Double = 1220.0, drafted: Long = 80, accepted: Long = 64, roundTokens: Long = 74) =
    LookupNumbers(0, true, true, rounds, drafted, accepted, roundMs, roundTokens, singles, singleMs, 0)

  private fun run(lookup: Boolean, tps: Double?, numbers: LookupNumbers? = null, text: String = "x") =
    LookupRun(lookup, 100, tps, text, numbers ?: if (lookup) nums() else null)

  // ---- per-run cost of a batch vs a plain step ----
  @Test fun averagesAndRatioComeFromTheCounts() {
    val n = nums()
    assertEquals(540.0, n.roundAvgMs!!, 0.0001)
    assertEquals(61.0, n.singleStepMs!!, 0.0001)
    assertEquals(540.0 / 61.0, n.roundVsStep!!, 0.0001)
  }

  @Test fun noAverageWithoutBothCounts() {
    assertNull(nums(rounds = 0, roundMs = 0.0).roundVsStep)
    assertNull(nums(singles = 0, singleMs = 0.0).roundVsStep)
    assertNull(nums(rounds = 0, roundMs = 0.0).roundAvgMs)
    assertNull(nums(singles = 0, singleMs = 0.0).singleStepMs)
  }

  @Test fun runLineShowsTheBatchAndPlainStepCost() {
    val r = LookupBench.report(listOf(run(false, 10.0), run(true, 9.0), run(true, 9.0), run(false, 10.0)), false)
    assertTrue(r, r.contains("a batch took 540 ms, a plain step 61 ms (8.9x)"))
    assertTrue(r.contains("80% of 80 guesses accepted"))
  }

  @Test fun runLineHasNoCostLineWhenOnlyOneKindOfStepRan() {
    val onlyRounds = nums(singles = 0, singleMs = 0.0)
    val r = LookupBench.report(listOf(run(false, 10.0), run(true, 9.0, onlyRounds), run(true, 9.0, onlyRounds), run(false, 10.0)), false)
    assertFalse(r, r.contains("a batch took"))
  }

  // ---- the batch-cost probe ----
  @Test fun probeArrayBecomesRows() {
    val c = BatchCost.from(probe(62.0, 80.0, 150.0, 480.0), sizes)!!
    assertEquals(402, c.context); assertEquals(5, c.passes)
    assertEquals(listOf(1, 2, 4, 9), c.rows.map { it.tokens })
    assertEquals(62.0, c.rows[0].medianMs, 0.0001)
    assertEquals(62.0 * 0.9, c.rows[0].minMs, 0.0001)
    assertEquals(62.0 * 1.2, c.rows[0].maxMs, 0.0001)
  }

  @Test fun probeArrayThatDoesNotFitIsRejected() {
    assertNull(BatchCost.from(null, sizes))
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0), sizes))                 // too short
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0, 480.0, 600.0), sizes))   // too long
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0, 0.0), sizes))            // a zero median
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0, Double.NaN), sizes))
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0, Double.POSITIVE_INFINITY), sizes))
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0, 480.0, ctx = 0.0), sizes))
    assertNull(BatchCost.from(probe(62.0, 80.0, 150.0, 480.0, passes = 0.0), sizes))
    assertNull(BatchCost.from(probe(1.0), intArrayOf()))
    // max below min is not a measurement
    val bad = probe(62.0, 80.0, 150.0, 480.0); bad[4] = bad[3] / 2
    assertNull(BatchCost.from(bad, sizes))
  }

  @Test fun ratiosAndBestCaseAreArithmeticOnTheMedians() {
    val c = BatchCost.from(probe(60.0, 90.0, 180.0, 540.0), sizes)!!
    assertEquals(1.5, c.ratio(c.rows[1])!!, 0.0001)
    assertEquals(9.0, c.ratio(c.rows[3])!!, 0.0001)
    assertEquals(2.0 / 1.5, c.bestCase(c.rows[1])!!, 0.0001)   // 1.33x
    assertEquals(4.0 / 3.0, c.bestCase(c.rows[2])!!, 0.0001)   // 1.33x
    assertEquals(1.0, c.bestCase(c.rows[3])!!, 0.0001)         // 9 tokens for 9 steps of time: no gain even when every guess is right
    assertEquals(1.0, c.bestCase(c.rows[0])!!, 0.0001)
  }

  @Test fun bestOverallIgnoresTheOneTokenRow() {
    val c = BatchCost.from(probe(60.0, 90.0, 180.0, 540.0), sizes)!!
    val (row, gain) = c.bestOverall()!!
    // 2 and 4 tie at 1.33x: either is fine, never 1 or 9
    assertTrue(row.tokens == 2 || row.tokens == 4)
    assertEquals(4.0 / 3.0, gain, 0.0001)
  }

  @Test fun cannotHelpWhenNoBatchBeatsPlainSteps() {
    // every batch costs about its token count in plain steps: nothing to gain
    val flat = BatchCost.from(probe(60.0, 125.0, 250.0, 560.0), sizes)!!
    assertTrue(flat.cannotHelp())
    assertTrue(flat.describe().contains("lookup cannot help with this model on this phone"))
    // a typical GPU-less phone with cheap batches: real room
    val cheap = BatchCost.from(probe(60.0, 70.0, 90.0, 140.0), sizes)!!
    assertFalse(cheap.cannotHelp())
    assertTrue(cheap.describe().contains("At most 3.9x, at 9 tokens per batch"))
  }

  @Test fun describeListsEverySizeWithItsCost() {
    val d = BatchCost.from(probe(62.0, 78.0, 150.0, 480.0), sizes)!!.describe()
    assertTrue(d, d.contains("402 tokens of context, median of 5 passes"))
    assertTrue(d.contains("1 token : 62 ms"))
    assertTrue(d.contains("2 tokens: 78 ms (1.3x one token), best case 1.6x"))
    assertTrue(d.contains("4 tokens: 150 ms (2.4x one token), best case 1.7x"))
    assertTrue(d.contains("9 tokens: 480 ms (7.7x one token), best case 1.2x"))
    assertTrue(d.contains("a wrong guess still pays for the whole batch"))
  }

  @Test fun withoutAOneTokenRowNoRatioIsInvented() {
    val c = BatchCost(300, 5, listOf(BatchCostRow(2, 80.0, 70.0, 90.0), BatchCostRow(9, 480.0, 400.0, 500.0)))
    assertNull(c.ratio(c.rows[0])); assertNull(c.bestCase(c.rows[1])); assertNull(c.bestOverall())
    assertFalse(c.cannotHelp())
    val d = c.describe()
    assertFalse(d.contains("best case 1")); assertFalse(d.contains("cannot help")); assertFalse(d.contains("At most"))
  }

  @Test fun probeSizesCoverTheBatchesLookupBuilds() {
    assertEquals(1, BatchCost.SIZES.first())
    assertEquals(9, BatchCost.SIZES.max())  // 1 token + up to 8 guesses (LookupConfig.draft_max)
    assertTrue(BatchCost.REPS in 3..10)
    assertTrue(BatchCost.LIMIT_SEC in 10..120)
  }

  // ---- the report ----
  @Test fun reportShowsTheProbeBeforeTheVerdict() {
    val cost = BatchCost.from(probe(62.0, 80.0, 150.0, 480.0), sizes)
    val r = LookupBench.report(listOf(run(false, 10.0), run(true, 10.2), run(true, 10.1), run(false, 10.0)), false, cost)
    assertTrue(r.indexOf("Batch cost on this phone") in 0 until r.indexOf("No clear difference"))
    assertTrue(r.contains("9 tokens: 480 ms"))
  }

  @Test fun reportWithoutAProbeIsAsBefore() {
    val r = LookupBench.report(listOf(run(false, 10.0), run(true, 15.0), run(true, 15.0), run(false, 10.0)), false)
    assertFalse(r.contains("Batch cost"))
    assertTrue(r.contains("faster"))
  }

  @Test fun noProbeWhenTheTestStoppedEarlyOrLookupNeverRan() {
    val cost = BatchCost.from(probe(62.0, 80.0, 150.0, 480.0), sizes)
    assertFalse(LookupBench.report(listOf(run(false, 3.0), run(true, 4.0)), true, cost).contains("Batch cost"))
    val inactive = LookupNumbers(4, true, false, 0, 0, 0, 0.0, 0, 0, 0.0, 0)
    val r = LookupBench.report(listOf(run(false, 10.0), run(true, 10.0, inactive), run(true, 10.0, inactive), run(false, 10.0)), false, cost)
    assertFalse(r.contains("Batch cost")); assertFalse(r.contains("faster")); assertTrue(r.contains("nothing to compare"))
  }

  // ---- ranking and a disturbed run ----
  @Test fun rankingIsAFactAboutOverlap() {
    assertEquals("Every lookup run was slower than every plain run.", LookupBench.rankingLine(listOf(15.3, 16.7), listOf(2.0, 11.9)))
    assertEquals("Every lookup run beat every plain run.", LookupBench.rankingLine(listOf(10.0, 10.2), listOf(15.0, 15.5)))
    assertNull(LookupBench.rankingLine(listOf(10.0, 12.0), listOf(11.0, 13.0)))
    assertNull(LookupBench.rankingLine(emptyList(), listOf(1.0)))
    assertNull(LookupBench.rankingLine(listOf(1.0), emptyList()))
    assertNull(LookupBench.rankingLine(listOf(10.0), listOf(10.0)))
  }

  @Test fun aDisturbedRunIsNamedAndTheVerdictIsNotTrusted() {
    val note = LookupBench.unstableNote(listOf(15.3, 16.7), listOf(2.0, 11.9))!!
    assertTrue(note, note.contains("differ by 495%"))
    assertTrue(note.contains("not reliable"))
    assertNull(LookupBench.unstableNote(listOf(15.3, 16.7), listOf(11.9, 12.5)))
    assertNull(LookupBench.unstableNote(listOf(10.0), listOf(10.0)))
    // right at the limit is still fine, above it is not
    assertNull(LookupBench.unstableNote(listOf(10.0, 12.5), listOf(10.0, 10.0)))
    assertNotNull(LookupBench.unstableNote(listOf(10.0, 12.6), listOf(10.0, 10.0)))
  }

  @Test fun theReportFromTheFieldNamesItsOwnProblem() {
    // the numbers of the 1.5B test that prompted this change
    val r = LookupBench.report(listOf(run(false, 15.3), run(true, 2.0), run(true, 11.9), run(false, 16.7)), false)
    assertTrue(r, r.contains("Every lookup run was slower than every plain run."))
    assertTrue(r.contains("a run was disturbed"))
    assertTrue(r.contains("Run it again with the phone cool."))
    assertTrue(r.contains("Lookup stays off unless you turn it on in Settings."))
  }

  @Test fun aCleanReportHasNoDisturbanceNote() {
    val r = LookupBench.report(listOf(run(false, 10.0), run(true, 15.0), run(true, 15.5), run(false, 10.2)), false)
    assertFalse(r.contains("disturbed"))
    assertTrue(r.contains("Every lookup run beat every plain run."))
  }
}
