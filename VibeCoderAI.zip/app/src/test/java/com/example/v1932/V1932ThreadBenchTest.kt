package com.example.v1932

import com.example.llama.ThreadBench
import com.example.llama.ThreadRun
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.32: the thread-count A/B: which counts are tried, in what order, and when a difference is called real. */
class V1932ThreadBenchTest {
  private fun run(t: Int, decode: Double?, prefill: Double? = 100.0, median: Double? = 50.0, p95: Double? = 80.0) = ThreadRun(t, decode, prefill, median, p95)

  /** a b c c b a with the given decode speeds per thread count, first run of each slightly different from the second by [wobble]. */
  private fun runs(speeds: Map<Int, Double>, wobble: Double = 0.0): List<ThreadRun> {
    val keys = speeds.keys.sorted()
    val plan = ThreadBench.order(keys)
    val seen = HashMap<Int, Int>()
    return plan.map { t ->
      val n = seen.merge(t, 1, Int::plus)!!
      run(t, speeds.getValue(t) * (if (n == 1) 1.0 - wobble else 1.0 + wobble))
    }
  }

  // ---- plan ----
  @Test fun candidatesAreFourSixEightAndYours() {
    assertEquals(listOf(4, 6, 8), ThreadBench.candidates(8, 8))
    assertEquals(listOf(4, 5, 6, 8), ThreadBench.candidates(8, 5))
    assertEquals(listOf(4, 6, 8), ThreadBench.candidates(12, 4))
    assertEquals(listOf(4, 6, 8, 10), ThreadBench.candidates(12, 10))
  }

  @Test fun fewCoresStillGiveAtLeastTwoValues() {
    val c = ThreadBench.candidates(4, 4)
    assertTrue(c.size >= 2 && c.all { it in 1..4 })
    val d = ThreadBench.candidates(2, 2)
    assertTrue(d.size >= 2 && d.all { it in 1..2 })
    // a setting above the core count (a stale value) is not tried
    assertTrue(ThreadBench.candidates(4, 12).all { it <= 4 })
    assertTrue(ThreadBench.candidates(1, 1).isNotEmpty())
  }

  @Test fun orderIsAbcCba() {
    assertEquals(listOf(4, 6, 8, 8, 6, 4), ThreadBench.order(listOf(4, 6, 8)))
  }

  // ---- verdicts ----
  @Test fun clearlyFasterThanYoursIsSuggested() {
    val a = ThreadBench.analyze(runs(mapOf(4 to 13.0, 6 to 12.0, 8 to 9.0)), current = 8)
    assertEquals(4, a.suggested)
    assertEquals(4, a.bestDecode)
    assertTrue(a.verdict.contains("4 threads generated"))
    assertTrue(a.verdict.contains("faster than your 8"))
  }

  @Test fun yoursBeingFastestSuggestsNothing() {
    val a = ThreadBench.analyze(runs(mapOf(4 to 9.0, 6 to 10.0, 8 to 13.0)), current = 8)
    assertNull(a.suggested)
    assertEquals("Your setting (8 threads) generated fastest.", a.verdict)
  }

  @Test fun differenceInsideTheNoiseIsNotSuggested() {
    // 4 is 3% faster than yours: below the 5% floor
    val a = ThreadBench.analyze(runs(mapOf(4 to 12.4, 6 to 12.0, 8 to 12.0)), current = 8)
    assertNull(a.suggested)
    assertTrue(a.verdict.startsWith("No clear difference"))
  }

  @Test fun noisyRunsRaiseTheBar() {
    // each setting's two runs differ by about 30%: a 15% gain is not believable
    val a = ThreadBench.analyze(runs(mapOf(4 to 14.0, 6 to 12.5, 8 to 12.0), wobble = 0.13), current = 8)
    assertNull(a.suggested)
    assertTrue(a.noise > 0.2)
  }

  @Test fun amongClearlyBetterSettingsTheFewestThreadsWithinNoiseWins() {
    // 4 and 6 are both far above 8 and within 5% of each other: pick 4 (less heat), not 6
    val a = ThreadBench.analyze(runs(mapOf(4 to 12.8, 6 to 13.0, 8 to 8.0)), current = 8)
    assertEquals(4, a.suggested)
    assertEquals(6, a.bestDecode)
  }

  @Test fun aSettingClearlyAboveTheRestStillWinsOverFewerThreads() {
    val a = ThreadBench.analyze(runs(mapOf(4 to 8.0, 6 to 13.0, 8 to 8.0)), current = 8)
    assertEquals(6, a.suggested)
  }

  @Test fun yourSettingWithinNoiseOfTheBestIsKept() {
    val a = ThreadBench.analyze(runs(mapOf(4 to 13.0, 6 to 12.0, 8 to 12.6)), current = 8)
    assertNull(a.suggested)
  }

  @Test fun missingOrSingleRunsGiveNoVerdict() {
    assertNull(ThreadBench.analyze(emptyList(), 4).suggested)
    assertEquals("Not enough valid runs to compare.", ThreadBench.analyze(listOf(run(4, 10.0), run(8, 12.0)), 4).verdict)
    // a run without a decode speed does not count as a run
    val r = runs(mapOf(4 to 10.0, 8 to 14.0)).toMutableList()
    r[0] = run(4, null)
    assertEquals("Not enough valid runs to compare.", ThreadBench.analyze(r, 4).verdict)
  }

  @Test fun yourSettingMissingFromTheRunsIsSaid() {
    val a = ThreadBench.analyze(runs(mapOf(4 to 10.0, 6 to 14.0)), current = 8)
    assertNull(a.suggested)
    assertTrue(a.verdict.contains("not among the tested"))
  }

  @Test fun bestForPromptCanDifferFromBestForGeneration() {
    val r = ThreadBench.order(listOf(4, 8)).map { t -> run(t, if (t == 4) 13.0 else 9.0, prefill = if (t == 4) 90.0 else 140.0) }
    val a = ThreadBench.analyze(r, current = 8)
    assertEquals(4, a.bestDecode); assertEquals(8, a.bestPrefill)
    val text = ThreadBench.report(r, 8, ThreadBench.order(listOf(4, 8)), false, null, "Device: thermal None").text
    assertTrue(text.contains("Fastest for generation: 4 threads; for prompt processing: 8"))
  }

  // ---- report ----
  @Test fun reportShowsTableSuggestionAndThatNothingWasChanged() {
    val plan = ThreadBench.order(listOf(4, 6, 8))
    val res = ThreadBench.report(runs(mapOf(4 to 13.0, 6 to 12.0, 8 to 9.0)), 8, plan, false, null, "Device: thermal Moderate (unchanged)")
    assertEquals(4, res.suggested)
    val t = res.text
    assertTrue(t.contains("4 / 6 / 8 threads, order 4 6 8 8 6 4 after one warm-up run"))
    assertTrue(t.contains("8 (you)"))
    assertTrue(t.contains("Device: thermal Moderate (unchanged)"))
    assertTrue(t.contains("Nothing was changed; tap Use only if you agree."))
  }

  @Test fun noSuggestionReportHasNoUsePrompt() {
    val plan = ThreadBench.order(listOf(4, 6, 8))
    val res = ThreadBench.report(runs(mapOf(4 to 9.0, 6 to 10.0, 8 to 13.0)), 8, plan, false, null, "Device: thermal None")
    assertNull(res.suggested)
    assertFalse(res.text.contains("tap Use"))
    assertTrue(res.text.endsWith("Nothing was changed."))
  }

  @Test fun heatingBetweenRunsIsFlagged() {
    val plan = ThreadBench.order(listOf(4, 6, 8))
    val res = ThreadBench.report(runs(mapOf(4 to 12.0, 6 to 12.0, 8 to 12.0), wobble = 0.08), 8, plan, false, null, "Device: thermal Light → Moderate")
    assertTrue(res.text.contains("differ by more than 10%"))
  }

  @Test fun timeLimitAndAbortGiveNoSuggestion() {
    val plan = ThreadBench.order(listOf(4, 6, 8))
    val stopped = ThreadBench.report(runs(mapOf(4 to 13.0, 6 to 12.0, 8 to 9.0)).take(3), 8, plan, true, null, "Device: x")
    assertNull(stopped.suggested); assertTrue(stopped.text.contains("no suggestion"))
    val short = ThreadBench.report(runs(mapOf(4 to 13.0, 6 to 12.0, 8 to 9.0)).take(4), 8, plan, false, null, "Device: x")
    assertNull(short.suggested)
    val hot = ThreadBench.report(emptyList(), 8, plan, false, "The phone is at thermal status Severe", "Device: thermal Severe")
    assertNull(hot.suggested); assertTrue(hot.text.contains("Severe"))
    assertNotNull(hot.text)
  }
}
