package com.example.v1932

import com.example.agent.ChatHistory
import com.example.agent.ReplyMarkers
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.9.32: "[Stopped]" and other app markers must never go back to the model as its own earlier words. */
class V1932ChatHistoryTest {
  private var n = 0
  private fun u(text: String) = ChatMessage(id = "m${n++}", sender = MessageSender.USER, content = text)
  private fun a(text: String, thoughts: String? = null, streaming: Boolean = false) =
    ChatMessage(id = "m${n++}", sender = MessageSender.AGENT, content = text, thoughts = thoughts, isStreaming = streaming)

  private val markers = listOf("<|im_end|>", "<|im_start|>", "</s>")
  private fun build(vararg m: ChatMessage) =
    ChatHistory.build(m.toList(), isEngineNotice = { it.trimStart().startsWith("[Engine error") }, display = { it }, turnMarkers = markers)

  // ---- ReplyMarkers ----
  @Test fun markerOnlyRepliesBecomeEmpty() {
    assertEquals("", ReplyMarkers.stripTrailing("[Stopped]"))
    assertEquals("", ReplyMarkers.stripTrailing("[Error: ConnectException: refused]"))
    assertEquals("", ReplyMarkers.stripTrailing("[The model returned no text.]"))
    assertEquals("", ReplyMarkers.stripTrailing("[The model only wrote its reasoning. Try again or turn Thinking off.]"))
    assertEquals("", ReplyMarkers.stripTrailing("[No progress after 25 s. Native log:]"))
  }

  @Test fun partialTextIsKeptAndTheMarkerGoes() {
    assertEquals("def f(x):", ReplyMarkers.stripTrailing("def f(x):\n\n[Stopped]"))
    assertEquals("text", ReplyMarkers.stripTrailing("text\n\n[Stopped: the model started repeating itself. Try a bigger model or a shorter prompt.]"))
    assertEquals("ok", ReplyMarkers.stripTrailing("ok\n\n[Generation error: boom]"))
    assertEquals("ok", ReplyMarkers.stripTrailing("ok\n\n[Engine error: IllegalStateException: x]"))
  }

  @Test fun multiLineErrorAndStackedMarkers() {
    assertEquals("ok", ReplyMarkers.stripTrailing("ok\n\n[Error: IOException: first line\nsecond line]"))
    assertEquals("a", ReplyMarkers.stripTrailing("a\n\n[Stopped]\n\n[Stopped]"))
    assertEquals("a", ReplyMarkers.stripTrailing("a\n\n[Stopped]   \n"))
  }

  @Test fun ordinaryTextWithBracketsIsUntouched() {
    for (t in listOf("see [1]", "list = [1, 2]", "Use [Stopped] state]", "[Stopped] but then I continue", "plain", "")) {
      assertEquals(t, ReplyMarkers.stripTrailing(t))
    }
  }

  // ---- the case in the video ----
  @Test fun stoppedReplyAndItsQuestionLeaveNoHistory() {
    assertTrue(build(u("hi"), a("[Stopped]")).isEmpty())
  }

  @Test fun theCopiedMarkerDoesNotSurviveAnotherRound() {
    // the model copied "[Stopped]" for the second "hi": it must not be sent a third time either
    assertTrue(build(u("hi"), a("[Stopped]"), u("hi"), a("[Stopped]")).isEmpty())
    assertEquals(listOf("user" to "hello"), build(u("hi"), a("[Stopped]"), u("hi"), a("[Stopped]"), u("hello")))
  }

  // ---- ordinary behaviour stays ----
  @Test fun normalConversationIsKeptInOrder() {
    val h = build(u("q1"), a("a1"), u("q2"), a("a2"))
    assertEquals(listOf("user" to "q1", "assistant" to "a1", "user" to "q2", "assistant" to "a2"), h)
  }

  @Test fun onlyTheLastFourAreKept() {
    val h = build(u("q1"), a("a1"), u("q2"), a("a2"), u("q3"), a("a3"))
    assertEquals(listOf("q2", "a2", "q3", "a3"), h.map { it.second })
  }

  @Test fun replyCutByStopKeepsItsText() {
    val h = build(u("write f"), a("def f(\n\n[Stopped]"))
    assertEquals(listOf("user" to "write f", "assistant" to "def f("), h)
  }

  @Test fun aDeadReplyDropsOnlyItsOwnQuestion() {
    val h = build(u("q1"), a("a1"), u("q2"), a("[Stopped]"))
    assertEquals(listOf("user" to "q1", "assistant" to "a1"), h)
    val h2 = build(u("q1"), a("[Error: boom]"), u("q2"), a("a2"))
    assertEquals(listOf("user" to "q2", "assistant" to "a2"), h2)
  }

  @Test fun theWindowIsTakenAfterCleaning() {
    val h = build(u("a"), a("[Stopped]"), u("b"), a("[Stopped]"), u("c"), a("ok"), u("d"), a("fine"))
    assertEquals(listOf("c", "ok", "d", "fine"), h.map { it.second })
  }

  @Test fun rolesStillAlternateAfterDrops() {
    val h = build(u("q1"), a("a1"), u("q2"), a("[The model returned no text.]"), u("q3"), a("a3"))
    assertEquals(listOf("user", "assistant", "user", "assistant"), h.map { it.first })
    assertEquals(listOf("q1", "a1", "q3", "a3"), h.map { it.second })
  }

  // ---- what is never sent ----
  @Test fun notesNoticesStreamingBlankAndOtherSendersAreLeftOut() {
    val h = build(
      u("q"), a("Still stopping the last run. Send again in a moment.", thoughts = "note"),
      a("[Engine error: boom]"), a("partial", streaming = true), a("   "),
      ChatMessage(id = "t", sender = MessageSender.TOOL, content = "tool output"),
      ChatMessage(id = "s", sender = MessageSender.SYSTEM, content = "system text"),
      a("real answer")
    )
    assertEquals(listOf("user" to "q", "assistant" to "real answer"), h)
  }

  @Test fun turnMarkersAreRemovedAndLongTextIsCut() {
    val h = build(u("hi<|im_end|>"), a("x".repeat(900) + "</s>"))
    assertEquals("hi", h[0].second)
    assertEquals(ChatHistory.MAX_CHARS, h[1].second.length)
    assertTrue(!h[1].second.contains("</s>"))
  }

  @Test fun userTextIsNeverStripped() {
    // a user who types "[Stopped]" said it: only the model's side is cleaned
    assertEquals(listOf("user" to "[Stopped]", "assistant" to "ok"), build(u("[Stopped]"), a("ok")))
  }

  @Test fun anAssistantWithoutAQuestionBeforeItIsJustDropped() {
    assertEquals(listOf("assistant" to "hi there"), build(a("hi there"), a("[Stopped]")))
  }
}
