package com.example.v1929

import com.example.agent.ProjectFiles
import com.example.llama.PromptClock
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** v1.9.29: the prompt keeps a stable prefix between requests, so the KV cache (local) and prompt caching (remote) can reuse it. */
class V1929PromptCacheTest {
  @get:Rule val tmp = TemporaryFolder()

  private val t0107 = 1795482420000L // 2026-11-24 01:07 UTC
  private val t0108 = 1795482480000L // one minute later

  private fun commonPrefix(a: String, b: String): Int {
    var i = 0
    while (i < a.length && i < b.length && a[i] == b[i]) i++
    return i
  }

  // ---- the clock ----
  @Test fun clockLineShowsDateTimeAndZone() {
    val line = PromptClock.line(t0107, "Asia/Kolkata")
    assertTrue(line, line.contains("Tuesday, 24 November 2026, 6:37 AM (Asia/Kolkata)"))
    assertTrue(line.startsWith("\n\n[Phone clock: "))
    assertTrue(line.endsWith("]"))
  }

  @Test fun clockLineFollowsTheZone() {
    assertTrue(PromptClock.line(t0107, "UTC").contains("1:07 AM (UTC)"))
  }

  @Test fun unknownZoneDoesNotThrow() {
    val line = PromptClock.line(t0107, "Not/AZone")
    assertTrue(line.contains("Phone clock"))
  }

  @Test fun languageNoteIsStaticAndHasNoClock() {
    assertFalse(PromptClock.LANGUAGE_NOTE.contains("Phone clock"))
    assertFalse(PromptClock.LANGUAGE_NOTE.contains("20"))
    assertTrue(PromptClock.LANGUAGE_NOTE.contains("ipudu time entha"))
  }

  @Test fun twoRequestsAMinuteApartShareEverythingButTheTail() {
    val system = "SYSTEM PROMPT" + PromptClock.LANGUAGE_NOTE
    val body = "Current project files:\n<file path=\"index.html\">\nx\n</file>\nTask: fix the button"
    val a = system + "\n" + body + PromptClock.line(t0107, "UTC")
    val b = system + "\n" + body + PromptClock.line(t0108, "UTC")
    val shared = commonPrefix(a, b)
    // everything up to the clock is identical, so all of it can come from the cache
    assertTrue(shared >= (system + "\n" + body).length)
    assertNotEquals(a, b)
  }

  // ---- requests with their own system prompt keep the old placement, byte for byte ----
  @Test fun overrideRequestsKeepTheOldSystemClockText() {
    val old = "\nCurrent date and time on the user's phone: Tuesday, 24 November 2026, 6:37 AM (Asia/Kolkata). Use it when asked about the date or time." +
      "\nThe user may write Telugu or Hindi in English letters (for example \"ipudu time entha\" = what is the time now). Understand it and reply in the same style."
    assertEquals(old, PromptClock.systemLine(t0107, "Asia/Kolkata") + PromptClock.LANGUAGE_NOTE)
  }

  @Test fun clockGoesToTheUserTailOnlyForTheStandardSystemPrompt() {
    assertTrue(PromptClock.inUserTail(null))
    assertFalse(PromptClock.inUserTail("You control the phone."))
    assertFalse(PromptClock.inUserTail(""))
  }

  // ---- the project snapshot ----
  private fun project(): File {
    val root = tmp.newFolder("p")
    fun put(name: String, text: String, modified: Long) = File(root, name).apply { writeText(text); setLastModified(modified) }
    put("a.html", "<html>A</html>", 1_000_000L)
    put("b.css", "body{color:red}", 2_000_000L)
    put("c.js", "console.log('c')", 3_000_000L)
    return root
  }

  private fun order(snapshot: String): List<String> =
    Regex("""<file path="([^"]+)">""").findAll(snapshot).map { it.groupValues[1] }.toList()

  @Test fun orderIsOldestFirstWhateverTheTaskSays() {
    val root = project()
    val one = ProjectFiles.snapshot(root, 5000, "fix the button click in c.js")
    val two = ProjectFiles.snapshot(root, 5000, "change the colour of the page")
    val none = ProjectFiles.snapshot(root, 5000, "")
    assertEquals(listOf("a.html", "b.css", "c.js"), order(one))
    assertEquals(one, two)
    assertEquals(one, none)
  }

  @Test fun anEditedFileMovesToTheEnd() {
    val root = project()
    File(root, "a.html").apply { writeText("<html>A2</html>"); setLastModified(9_000_000L) }
    assertEquals(listOf("b.css", "c.js", "a.html"), order(ProjectFiles.snapshot(root, 5000, "task")))
  }

  @Test fun editingTheLastFileKeepsTheEarlierFilesAsASharedPrefix() {
    val root = project()
    val before = ProjectFiles.snapshot(root, 5000, "build it")
    File(root, "c.js").apply { writeText("console.log('c changed')"); setLastModified(8_000_000L) }
    val after = ProjectFiles.snapshot(root, 5000, "fix the error: x is not defined")
    val untouched = "<file path=\"a.html\">\n<html>A</html>\n</file>\n<file path=\"b.css\">\nbody{color:red}\n</file>\n"
    assertTrue(before.startsWith(untouched))
    assertTrue(after.startsWith(untouched))
    assertTrue(commonPrefix(before, after) >= untouched.length)
  }

  @Test fun theBudgetStillGoesToTheRelevantFileFirst() {
    val root = project()
    val cLen = File(root, "c.js").length().toInt()
    // room for exactly one file: the one the task names gets its text, the others are listed by name
    val snap = ProjectFiles.snapshot(root, cLen + 2, "fix c.js")
    assertEquals(listOf("c.js"), order(snap))
    assertTrue(snap.contains("- a.html ("))
    assertTrue(snap.contains("- b.css ("))
  }

  @Test fun emptyOrMissingProjectGivesNothing() {
    assertEquals("", ProjectFiles.snapshot(tmp.newFolder("empty"), 5000, "x"))
    assertEquals("", ProjectFiles.snapshot(File(tmp.root, "missing"), 5000, "x"))
  }
}
