package com.example.v1926

import com.example.llama.ExpertSplit
import com.example.llama.GgufExperts
import com.example.llama.MemoryEstimator
import com.example.llama.ModelMemory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

class V1926StreamingTest {
  private val MB = 1024L * 1024L
  private val GB = 1024L * MB

  // ---- a tiny synthetic GGUF v3 file ----
  private class Gguf {
    val out = ByteArrayOutputStream()
    fun u32(v: Long) = out.write(ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN).putInt(v.toInt()).array())
    fun u64(v: Long) = out.write(ByteBuffer.allocate(8).order(ByteOrder.LITTLE_ENDIAN).putLong(v).array())
    fun str(s: String) { val b = s.toByteArray(); u64(b.size.toLong()); out.write(b) }
    fun bytes() = out.toByteArray()
  }

  /** Experts: two tensors of 65536 bytes each. Everything else: 4096 + 4096 + 2048. Alignment 32. */
  private fun build(moe: Boolean, withTokenizerArray: Boolean = true, version: Long = 3): ByteArray {
    val g = Gguf()
    g.u32(0x46554747L); g.u32(version)
    val tensors = listOf(
      "token_embd.weight" to 4096L, "blk.0.attn_q.weight" to 4096L,
      "blk.0.ffn_gate_exps.weight" to 65536L, "blk.0.ffn_down_exps.weight" to 65536L, "output.weight" to 2048L
    )
    var kv = 2L + (if (moe) 2 else 0) + (if (withTokenizerArray) 1 else 0)
    g.u64(tensors.size.toLong()); g.u64(kv)
    g.str("general.architecture"); g.u32(8); g.str(if (moe) "qwen3moe" else "llama")
    g.str("general.alignment"); g.u32(4); g.u32(32)
    if (moe) {
      g.str("qwen3moe.expert_count"); g.u32(4); g.u32(128)
      g.str("qwen3moe.expert_used_count"); g.u32(4); g.u32(8)
    }
    if (withTokenizerArray) {
      // an array of strings (like the tokenizer vocabulary) must be skipped correctly
      g.str("tokenizer.ggml.tokens"); g.u32(9); g.u32(8); g.u64(1000)
      for (i in 0 until 1000) g.str("tok$i")
    }
    var off = 0L
    for ((name, size) in tensors) {
      g.str(name); g.u32(2); g.u64(64); g.u64(64); g.u32(12); g.u64(off)
      off += size
    }
    // pad to the alignment, then the tensor data
    val pad = (32 - g.out.size() % 32) % 32
    g.out.write(ByteArray(pad))
    g.out.write(ByteArray(off.toInt()))
    return g.bytes()
  }

  private fun parse(bytes: ByteArray) = GgufExperts.parse(ByteArrayInputStream(bytes), bytes.size.toLong())

  @Test fun expertBytesAreSummedFromTheTensorList() {
    val bytes = build(moe = true)
    val s = parse(bytes)!!
    assertEquals(131072L, s.expertBytes)
    assertEquals(128, s.expertCount)
    assertEquals(8, s.expertUsed)
    assertEquals(bytes.size.toLong(), s.totalBytes)
    assertEquals(bytes.size.toLong() - 131072L, s.coreBytes)
    assertTrue(s.isMoe)
  }

  @Test fun denseModelIsNotMoe() {
    val s = parse(build(moe = false))!!
    assertFalse(s.isMoe)
    assertEquals(0, s.expertCount)
  }

  @Test fun worksWithoutABigArrayToo() {
    assertEquals(131072L, parse(build(moe = true, withTokenizerArray = false))!!.expertBytes)
  }

  @Test fun notAGgufFileGivesNull() {
    assertNull(parse(ByteArray(100) { 7 }))
    assertNull(parse(ByteArray(0)))
  }

  @Test fun oldVersionAndTruncatedFileGiveNull() {
    assertNull(parse(build(moe = true, version = 1)))
    val full = build(moe = true)
    assertNull(parse(full.copyOf(120)))
  }

  @Test fun fileLengthShorterThanHeaderGivesNull() {
    val full = build(moe = true)
    assertNull(GgufExperts.parse(ByteArrayInputStream(full), 100))
  }

  // ---- the plan ----
  private val qwen30 = ExpertSplit(totalBytes = 18 * GB, expertBytes = 16 * GB + 512 * MB, expertCount = 128, expertUsed = 8)

  @Test fun moeBiggerThanRamStreams() {
    // 12 GB phone, 4.6 GB free (the numbers from a real screenshot).
    val v = MemoryEstimator.check(qwen30.totalBytes, 4096, 4600 * MB, qwen30)
    assertTrue(v.fits)
    val plan = v.streams!!
    assertEquals(qwen30.coreBytes, plan.residentBytes)
    assertEquals(qwen30.expertBytes, plan.streamedBytes)
    assertTrue(plan.neededBytes <= 4600 * MB)
    assertTrue(plan.cachedFraction > 0.0 && plan.cachedFraction < 1.0)
  }

  @Test fun denseModelBiggerThanRamStaysBlocked() {
    val v = MemoryEstimator.check(9 * GB, 4096, 4600 * MB, null)
    assertFalse(v.fits)
    assertNull(v.streams)
    assertFalse(MemoryEstimator.check(9 * GB, 4096, 4600 * MB, ExpertSplit(9 * GB, 0, 0, 0)).fits)
  }

  @Test fun coreThatDoesNotFitStaysBlocked() {
    // The core of this model is about 1.5 GB: with 1 GB free even that does not fit.
    val v = MemoryEstimator.check(qwen30.totalBytes, 4096, 1 * GB, qwen30)
    assertFalse(v.fits)
    assertNull(v.streams)
  }

  @Test fun modelThatFitsIsNotStreamed() {
    val v = MemoryEstimator.check(qwen30.totalBytes, 4096, 40 * GB, qwen30)
    assertTrue(v.fits)
    assertNull(v.streams)
  }

  @Test fun unknownFreeMemoryNeverBlocksAndNeverStreams() {
    val v = MemoryEstimator.check(qwen30.totalBytes, 4096, 0, qwen30)
    assertTrue(v.fits)
    assertNull(v.streams)
  }

  @Test fun moreFreeRamMeansMoreCachedExperts() {
    val a = MemoryEstimator.streamPlan(qwen30, 4096, 4 * GB)!!
    val b = MemoryEstimator.streamPlan(qwen30, 4096, 8 * GB)!!
    assertTrue(b.cachedFraction > a.cachedFraction)
  }

  @Test fun longerContextNeedsMoreRamAndSoCachesLess() {
    val short = MemoryEstimator.streamPlan(qwen30, 2048, 4600 * MB)!!
    val long = MemoryEstimator.streamPlan(qwen30, 8192, 4600 * MB)!!
    assertTrue(long.neededBytes > short.neededBytes)
    assertTrue(long.cachedFraction < short.cachedFraction)
  }

  @Test fun kvCacheIsSizedFromTheCoreNotFromTheWholeFile() {
    val plan = MemoryEstimator.streamPlan(qwen30, 4096, 6 * GB)!!
    val perTokenAsIfDense = MemoryEstimator.kvBytesPerToken(qwen30.totalBytes)
    val perTokenMoe = MemoryEstimator.kvBytesPerToken(plan.kvBasisBytes)
    assertTrue(perTokenMoe < perTokenAsIfDense / 3)
    // and it is not absurdly small either: a real 30B-A3B model needs about 52 KB per token
    assertTrue(perTokenMoe in 30_000L..120_000L)
  }

  @Test fun modelMemoryHelpersUseTheStreamingNumbers() {
    val plan = MemoryEstimator.streamPlan(qwen30, 4096, 4600 * MB)!!
    val m = ModelMemory(plan.residentBytes, 4600 * MB, 0, plan.kvBasisBytes, plan.streamedBytes, plan.extraBytes)
    assertEquals(plan.neededBytes, m.neededBytes(4096))
    assertEquals(plan.cachedFraction, m.cachedFraction(4096), 0.0001)
    assertFalse(m.guard(4096).lowered)
    // a plain model keeps the old behaviour: no streaming, fully cached
    val plain = ModelMemory(2 * GB, 8 * GB)
    assertEquals(1.0, plain.cachedFraction(4096), 0.0)
    assertEquals(MemoryEstimator.neededBytes(2 * GB, 4096), plain.neededBytes(4096))
  }

  // ---- v1.9.28: streaming decodes prompts in batches of 1024, so it reserves a little more ----
  @Test fun streamingPlanReservesTheBigBatchBuffers() {
    val plan = MemoryEstimator.streamPlan(qwen30, 4096, 6 * GB)!!
    assertEquals(MemoryEstimator.STREAM_BATCH_BYTES, plan.extraBytes)
    assertEquals(
      MemoryEstimator.neededBytes(plan.residentBytes, 4096, plan.kvBasisBytes) + MemoryEstimator.STREAM_BATCH_BYTES,
      plan.neededBytes
    )
  }

  @Test fun coreThatFitsOnlyWithoutTheBatchReserveStaysBlocked() {
    val core = qwen30.coreBytes
    val basis = core * 5 / 2
    val bare = MemoryEstimator.neededBytes(core, 4096, basis)
    // free RAM that covers the core but not the extra batch buffers: must not stream
    val tight = bare + MemoryEstimator.STREAM_BATCH_BYTES / 2
    assertNull(MemoryEstimator.streamPlan(qwen30, 4096, tight))
    assertFalse(MemoryEstimator.check(qwen30.totalBytes, 4096, tight, qwen30).fits)
    // and just enough with it does
    assertNotNull(MemoryEstimator.streamPlan(qwen30, 4096, bare + MemoryEstimator.STREAM_BATCH_BYTES))
  }

  @Test fun modelMemoryExtraBytesAffectNeedAndGuard() {
    val plan = MemoryEstimator.streamPlan(qwen30, 8192, 6 * GB)!!
    val with = ModelMemory(plan.residentBytes, plan.neededBytes - 1, 0, plan.kvBasisBytes, plan.streamedBytes, plan.extraBytes)
    val without = ModelMemory(plan.residentBytes, plan.neededBytes - 1, 0, plan.kvBasisBytes, plan.streamedBytes)
    assertTrue(with.guard(8192).lowered)
    assertEquals(without.neededBytes(8192) + plan.extraBytes, with.neededBytes(8192))
    // a plain model has no extra reserve
    assertEquals(0L, ModelMemory(2 * GB, 8 * GB).extraBytes)
  }

  @Test fun oldCallSitesStillWork() {
    // The signatures used before v1.9.26 keep their meaning.
    assertNotNull(MemoryEstimator.guard(1 * GB, 2048, 8 * GB))
    assertTrue(MemoryEstimator.check(1 * GB, 2048, 8 * GB).fits)
    assertEquals(MemoryEstimator.neededBytes(1 * GB, 2048), MemoryEstimator.neededBytes(1 * GB, 2048, 1 * GB))
  }
}
