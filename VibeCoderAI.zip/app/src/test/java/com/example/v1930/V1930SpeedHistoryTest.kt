package com.example.v1930

import com.example.data.BenchLine
import com.example.data.SpeedHistory
import com.example.data.SpeedHistoryStore
import com.example.data.SpeedMath
import com.example.data.SpeedRecord
import com.example.llama.DeviceSnapshot
import com.example.llama.DeviceTelemetry
import com.example.llama.MemSplit
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

/** v1.9.30: speed history (numbers only) and device telemetry wording/parsing. */
class V1930SpeedHistoryTest {
  @get:Rule val tmp = TemporaryFolder()

  private fun rec(ts: Long = 1L, source: String = "chat", backend: String = "local", decode: Double? = 5.0, ttft: Long? = 2000L, prompt: Int = 100, cached: Int? = 0) =
    SpeedRecord(ts = ts, source = source, backend = backend, model = "m.gguf", promptTokens = prompt, cachedTokens = cached, outputTokens = 50, ttftMs = ttft, decodeTps = decode)

  // ---- record <-> line ----
  @Test fun fullRecordRoundTrips() {
    val r = SpeedRecord(
      ts = 1795482420000L, source = "speedtest", backend = "local", model = "Qwen3-Coder-30B-A3B-Instruct-Q4_K_M.gguf",
      promptTokens = 128, cachedTokens = null, truncatedTokens = 0, outputTokens = 32, ttftMs = 3200L, prefillTps = 40.0, decodeTps = 6.1, medianMs = 160.0, p95Ms = 410.5,
      threads = 6, streaming = true, contextLength = 8192, readMb = 812.5, majorFaults = 20310L, minorFaults = 5000000L,
      thermalBefore = "None", thermalAfter = "Light", batteryTempC = 33.1, anonMb = 1420L, fileMb = 5200L
    )
    assertEquals(r, SpeedHistory.fromLine(SpeedHistory.toLine(r)))
  }

  @Test fun nullsStayNullNeverZero() {
    val r = rec(decode = null, ttft = null)
    val back = SpeedHistory.fromLine(SpeedHistory.toLine(r))!!
    assertNull(back.decodeTps)
    assertNull(back.ttftMs)
    assertNull(back.readMb)
    assertNull(back.majorFaults)
    assertNull(back.thermalAfter)
  }

  @Test fun damagedAndIncompleteLinesAreSkipped() {
    val good = SpeedHistory.toLine(rec(ts = 7L))
    val text = "garbage\n\n{\"ts\":1}\n$good\n{\"ts\":2,\"source\":\"chat\"\n"
    val list = SpeedHistory.decode(text)
    assertEquals(1, list.size)
    assertEquals(7L, list[0].ts)
  }

  @Test fun unknownFieldsAreIgnored() {
    val line = "{\"ts\":5,\"source\":\"chat\",\"backend\":\"remote\",\"model\":\"x\",\"futureField\":\"y\",\"promptTokens\":3}"
    val r = SpeedHistory.fromLine(line)
    assertNotNull(r)
    assertEquals("remote", r!!.backend)
    assertEquals(3, r.promptTokens)
  }

  @Test fun historyKeepsTheNewest100() {
    var list = emptyList<SpeedRecord>()
    for (i in 1L..105L) list = SpeedHistory.append(list, rec(ts = i))
    assertEquals(100, list.size)
    assertEquals(6L, list.first().ts)
    assertEquals(105L, list.last().ts)
    assertEquals(100, SpeedHistory.decode(SpeedHistory.encode(list)).size)
  }

  @Test fun encodedLineHoldsNoPromptOrPath() {
    val line = SpeedHistory.toLine(rec())
    assertFalse(line.contains("/"))
    assertFalse(line.contains("prompt\":"))
    assertTrue(line.contains("\"model\":\"m.gguf\""))
  }

  // ---- summary ----
  @Test fun summaryUsesRealRequestsOnlyAndMedians() {
    val list = listOf(
      rec(decode = 4.0, ttft = 1000L), rec(decode = 6.0, ttft = 3000L), rec(decode = 100.0, ttft = 9000L),
      rec(source = "speedtest", decode = 999.0)
    )
    val s = SpeedHistory.summary(list, "local")!!
    assertEquals(3, s.runs)
    assertEquals(6.0, s.medianDecodeTps!!, 1e-9)
    assertEquals(3000L, s.medianTtftMs)
  }

  @Test fun backendsAreKeptApart() {
    val list = listOf(rec(backend = "local", decode = 5.0), rec(backend = "remote", decode = 500.0))
    assertEquals(5.0, SpeedHistory.summary(list, "local")!!.medianDecodeTps!!, 1e-9)
    assertEquals(500.0, SpeedHistory.summary(list, "remote")!!.medianDecodeTps!!, 1e-9)
    assertNull(SpeedHistory.summary(listOf(rec(backend = "local")), "remote"))
  }

  @Test fun cacheReuseIsAShareOfPromptTokens() {
    val list = listOf(rec(prompt = 1000, cached = 900), rec(prompt = 1000, cached = 100))
    assertEquals(50, SpeedHistory.summary(list, "local")!!.cacheReusePct)
    assertNull(SpeedHistory.summary(listOf(rec(backend = "remote", prompt = 1000, cached = 0)), "remote")!!.cacheReusePct)
  }

  // ---- prompt reuse is only reported when the app counted it ----
  @Test fun unmeasuredReuseIsLeftOutNotCountedAsZero() {
    val list = listOf(rec(prompt = 1000, cached = 900), rec(prompt = 1000, cached = null))
    assertEquals(90, SpeedHistory.summary(list, "local")!!.cacheReusePct) // not 45
    // nothing measured at all: no percentage, never a made-up 0
    assertNull(SpeedHistory.summary(listOf(rec(prompt = 1000, cached = null)), "local")!!.cacheReusePct)
  }

  @Test fun measuredZeroReuseIsReportedAsZero() {
    assertEquals(0, SpeedHistory.summary(listOf(rec(prompt = 1000, cached = 0)), "local")!!.cacheReusePct)
    assertTrue(SpeedHistory.line(rec(prompt = 1000, cached = 0)).contains("prompt reused 0%"))
  }

  @Test fun unmeasuredReuseShowsNoReuseTextAndSurvivesTheFile() {
    assertFalse(SpeedHistory.line(rec(prompt = 1000, cached = null)).contains("reused"))
    val back = SpeedHistory.fromLine(SpeedHistory.toLine(rec(cached = null)))!!
    assertNull(back.cachedTokens)
    assertNull(back.truncatedTokens)
  }

  @Test fun remoteRecordsNeverCarryAReuseFigure() {
    val r = rec(backend = "remote", prompt = 1000, cached = null)
    assertFalse(SpeedHistory.line(r).contains("reused"))
    assertNull(SpeedHistory.summary(listOf(r), "remote")!!.cacheReusePct)
  }

  @Test fun cutPromptIsFlagged() {
    val line = SpeedHistory.line(rec(prompt = 800, cached = 0).copy(truncatedTokens = 312))
    assertTrue(line, line.contains("prompt cut by 312 tokens"))
    assertFalse(SpeedHistory.line(rec(prompt = 800, cached = 0).copy(truncatedTokens = 0)).contains("cut"))
  }

  @Test fun medianOfEvenAndEmpty() {
    assertEquals(2.5, SpeedHistory.median(listOf(1.0, 2.0, 3.0, 4.0))!!, 1e-9)
    assertNull(SpeedHistory.median(emptyList()))
  }

  @Test fun recentLineIsShortAndReadable() {
    val line = SpeedHistory.line(rec(prompt = 1000, cached = 850))
    assertEquals("Chat · m.gguf · 50 tokens · 5.0 tok/s · first token 2.0 s · prompt reused 85%", line)
    val st = SpeedHistory.line(rec(source = "speedtest", decode = null, ttft = null, cached = null))
    assertEquals("Speed test · m.gguf · 50 tokens", st)
    val long = SpeedHistory.line(rec().copy(model = "a-very-long-model-file-name-that-keeps-going.gguf"))
    assertTrue(long.contains("…"))
  }

  // ---- per-request math ----
  @Test fun firstTokenAndDecodeMath() {
    assertEquals(2500L, SpeedMath.ttftMs(1000L, 3500L))
    assertNull(SpeedMath.ttftMs(1000L, 0L))
    assertNull(SpeedMath.ttftMs(5000L, 4000L))
    // 11 tokens over 2 s: the first came with the prompt, 10 intervals
    assertEquals(5.0, SpeedMath.decodeTps(11, 1000L, 3000L)!!, 1e-9)
    assertNull(SpeedMath.decodeTps(1, 1000L, 3000L))
    assertNull(SpeedMath.decodeTps(5, 1000L, 1000L))
  }

  @Test fun promptSpeedNeedsEnoughProcessedTokens() {
    assertEquals(100.0, SpeedMath.prefillTps(1000, 0, 10_000L)!!, 1e-9)
    assertEquals(50.0, SpeedMath.prefillTps(1000, 500, 10_000L)!!, 1e-9)
    assertNull(SpeedMath.prefillTps(1000, 995, 10_000L)) // almost all cached: not a prompt-speed measurement
    assertNull(SpeedMath.prefillTps(1000, 0, null))
    assertNull(SpeedMath.prefillTps(1000, 0, 0L))
  }

  // ---- Speed test native line ----
  private val nativeLine = "@@bench {\"promptTokens\":128,\"promptMs\":3200.0,\"genTokens\":32,\"steps\":31,\"genMs\":6200.0,\"medianMs\":160.0,\"p95Ms\":410.0," +
    "\"readMb\":812.0,\"majFaults\":20310,\"minFaults\":-1,\"threads\":6,\"streaming\":true,\"batch\":1024}\nPrompt: 128 tokens in 3.2 s\nCPU: x"

  @Test fun benchLineSplitsNumbersFromText() {
    val (n, text) = BenchLine.split(nativeLine)
    assertNotNull(n)
    assertEquals("Prompt: 128 tokens in 3.2 s\nCPU: x", text)
    n!!
    assertEquals(128, n.promptTokens)
    assertEquals(40.0, n.prefillTps!!, 1e-9)
    assertEquals(5.0, n.decodeTps!!, 1e-9) // 31 steps in 6.2 s
    assertEquals(812.0, n.readMb!!, 1e-9)
    assertEquals(20310L, n.majorFaults)
    assertNull(n.minorFaults) // -1 means the OS hid it
    assertTrue(n.streaming)
    assertEquals(6, n.threads)
  }

  @Test fun benchLineLeavesOtherTextAlone() {
    assertEquals(null to "Speed test stopped.", BenchLine.split("Speed test stopped."))
    assertEquals(null to "No model loaded.", BenchLine.split("No model loaded."))
    val (n, text) = BenchLine.split("@@bench {broken\nline two")
    assertNull(n)
    assertEquals("line two", text)
    assertEquals(null to "", BenchLine.split("")) // never throws
  }

  // ---- the store ----
  @Test fun storeWritesReloadsAndClears() {
    val f = File(tmp.newFolder("s"), "speed_history.jsonl")
    val a = SpeedHistoryStore(f)
    a.add(rec(ts = 1L)); a.add(rec(ts = 2L))
    assertEquals(2, SpeedHistoryStore(f).all().size) // a fresh instance reads the file
    assertFalse(File(f.parentFile, "speed_history.jsonl.tmp").exists())
    a.clear()
    assertFalse(f.exists())
    assertEquals(0, a.all().size)
    assertEquals(0, SpeedHistoryStore(f).all().size)
  }

  @Test fun storeSurvivesACorruptFile() {
    val f = File(tmp.newFolder("c"), "speed_history.jsonl")
    f.writeText("\u0000\u0001 not json at all\n{{{\n")
    val s = SpeedHistoryStore(f)
    assertEquals(0, s.all().size)
    s.add(rec(ts = 9L))
    assertEquals(listOf(9L), SpeedHistoryStore(f).all().map { it.ts })
  }

  @Test fun concurrentAddsAreAllKept() {
    val s = SpeedHistoryStore(File(tmp.newFolder("t"), "speed_history.jsonl"))
    val threads = (1..8).map { t -> Thread { for (i in 1..10) s.add(rec(ts = (t * 100 + i).toLong())) } }
    threads.forEach { it.start() }
    threads.forEach { it.join() }
    assertEquals(80, s.all().size)
    assertEquals(80, SpeedHistoryStore(File(tmp.root, "t/speed_history.jsonl")).all().size)
  }

  @Test fun storeToleratesAnUnwritableFolder() {
    val blocker = tmp.newFile("blocker") // a file where the folder should be
    val s = SpeedHistoryStore(File(blocker, "speed_history.jsonl"))
    s.add(rec()) // must not throw
    assertEquals(1, s.all().size) // still available in memory
  }

  // ---- device telemetry ----
  @Test fun thermalLabels() {
    assertEquals("None", DeviceTelemetry.thermalLabel(0))
    assertEquals("Moderate", DeviceTelemetry.thermalLabel(2))
    assertEquals("Shutdown", DeviceTelemetry.thermalLabel(6))
    assertNull(DeviceTelemetry.thermalLabel(null))
    assertNull(DeviceTelemetry.thermalLabel(99))
    assertTrue(DeviceTelemetry.isThrottling(2))
    assertFalse(DeviceTelemetry.isThrottling(1))
    assertFalse(DeviceTelemetry.isThrottling(null))
  }

  @Test fun smapsRollupWithPssSplit() {
    val text = """
      56a1c000-7ffd5000 ---p 00000000 00:00 0                                  [rollup]
      Rss:             7340032 kB
      Pss:             6291456 kB
      Pss_Anon:        1454080 kB
      Pss_File:        4800000 kB
      Pss_Shmem:             0 kB
      Anonymous:       1500000 kB
    """.trimIndent()
    val m = DeviceTelemetry.parseSmapsRollup(text)!!
    assertTrue(m.byPss)
    assertEquals(1420L, m.anonMb)
    assertEquals(4687L, m.fileMb)
    assertEquals(7168L, m.rssMb)
  }

  @Test fun smapsRollupFallsBackToRss() {
    val m = DeviceTelemetry.parseSmapsRollup("Rss: 2097152 kB\nPss: 1000000 kB\nAnonymous: 1048576 kB\n")!!
    assertFalse(m.byPss)
    assertEquals(1024L, m.anonMb)
    assertEquals(1024L, m.fileMb)
  }

  @Test fun smapsRollupGarbageGivesNull() {
    assertNull(DeviceTelemetry.parseSmapsRollup(""))
    assertNull(DeviceTelemetry.parseSmapsRollup("nonsense\nRss: abc kB\n"))
    assertNull(DeviceTelemetry.parseSmapsRollup("Pss: 1000 kB\n")) // cannot split anonymous from file-backed
  }

  @Test fun describeShowsThermalChangeBatteryAndMemory() {
    val before = DeviceSnapshot(thermal = "None", thermalLevel = 0)
    val after = DeviceSnapshot("Light", 1, 33.1, 87, false, MemSplit(7000, 1420, 5200, true))
    val text = DeviceTelemetry.describe(before, after)
    assertTrue(text, text.contains("Device: thermal None → Light · battery 33.1 °C · charge 87%"))
    assertTrue(text, text.contains("Memory after the run (PSS): anonymous 1,420 MB, file-backed 5,200 MB"))
    assertTrue(text.contains("not heap use"))
    assertFalse(text.contains("throttling"))
    assertFalse(text.lowercase().contains("peak"))
  }

  @Test fun describeWarnsWhenThrottlingAndHandlesMissingValues() {
    val hot = DeviceTelemetry.describe(DeviceSnapshot("Light", 1), DeviceSnapshot("Severe", 3, 41.0, 50, true))
    assertTrue(hot, hot.contains("thermal Light → Severe"))
    assertTrue(hot.contains("charging"))
    assertTrue(hot.contains("throttling"))
    val none = DeviceTelemetry.describe(DeviceSnapshot(), DeviceSnapshot())
    assertTrue(none, none.startsWith("Device: thermal status not available"))
    assertFalse(none.contains("Memory"))
    val same = DeviceTelemetry.describe(DeviceSnapshot("None", 0), DeviceSnapshot("None", 0))
    assertTrue(same.contains("thermal None (unchanged)"))
  }

  @Test fun insertBeforeCpuLine() {
    assertEquals("a\nb\nDevice\nCPU: x", DeviceTelemetry.insertBeforeCpu("a\nb\nCPU: x", "Device"))
    assertEquals("a\nDevice", DeviceTelemetry.insertBeforeCpu("a", "Device"))
    assertEquals("a", DeviceTelemetry.insertBeforeCpu("a", ""))
  }
}
