// v1.9.28: how many tokens go through one llama_decode call. Pure, no dependencies, unit tested on the host.
#pragma once

#include <algorithm>
#include <cstddef>

namespace vibe {

// A model that fits in RAM: contexts decode up to 512 tokens per batch, but the prompt goes in 32-token chunks
// so progress and Stop stay responsive on a slow phone.
constexpr int kPlainBatch = 512;
constexpr int kPlainPromptChunk = 32;

// A streaming model (mixture of experts bigger than free RAM) reads most of its experts from storage for every
// decode call, however few tokens the call holds, so it takes the biggest batch it can.
constexpr int kStreamingBatch = 1024;

// n_batch (and n_ubatch) for a context of ctx_len tokens.
inline int context_batch(bool streaming, int ctx_len) {
    return std::min(streaming ? kStreamingBatch : kPlainBatch, ctx_len);
}

// Tokens for the next prompt decode call: at most one batch for a streaming model, at most 32 otherwise.
inline int prompt_chunk(bool streaming, int n_batch, size_t remaining) {
    const int cap = streaming ? n_batch : std::min(n_batch, kPlainPromptChunk);
    return static_cast<int>(std::min<size_t>(static_cast<size_t>(cap), remaining));
}

}  // namespace vibe
