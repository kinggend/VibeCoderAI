// v1.9.31: prompt-lookup decoding (experimental, off by default). Pure C++ with no llama.cpp dependency so the logic is
// unit tested on a host (scratchpad/h33/lookup_test.cpp).
//
// The idea: when the answer repeats text that is already in the context (a code edit copies most of the file), the next
// few tokens can be GUESSED by finding the last few tokens earlier in the context and taking what followed them there.
// All guessed tokens are then checked in ONE batched decode. A guess is kept only when the token the sampler really
// picks at that position is the same token; the first difference ends the round and the sampler's own token is used.
// So the sequence of tokens comes from the sampler at every position, exactly as in plain decoding.
//
// What is NOT guaranteed:
//  * Speed. One batch of k+1 tokens costs more than one single-token decode, and a wrong guess wastes that extra cost.
//    LookupGate measures both on the running phone and stops guessing when guessing is not faster.
//  * Bit-identical logits. A batched decode and a single-token decode can differ in the last float digits, so a greedy
//    choice between two nearly equal tokens may rarely flip. The app reports match / first difference, not "regression".
#pragma once

#include <algorithm>
#include <cstddef>
#include <cstdint>
#include <vector>

namespace vibe {

struct LookupConfig {
    int ngram_min = 3;   // shortest repeated run of tokens that may start a guess (shorter matches are mostly noise)
    int ngram_max = 5;   // longest run tried first (a longer match is a more reliable guess)
    int draft_max = 8;   // most tokens guessed per round
};

// Why lookup is not used for this model/load. 0 = it may be used.
enum LookupBlock : int {
    kLookupOk = 0,
    kLookupStreaming = 1,   // memory-mapped MoE: a batch of k tokens touches many more experts than one token does
    kLookupRecurrent = 2,   // recurrent / hybrid memory cannot drop the last few tokens again
    kLookupSwa = 3,         // sliding-window attention cache: removing the newest tokens is not reliable
    kLookupNoRollback = 4,  // the memory does not report support for partial removal / shift
};

inline int lookup_block_reason(bool streaming, bool recurrent, bool hybrid, int n_swa, bool can_shift) {
    if (streaming) return kLookupStreaming;
    if (recurrent || hybrid) return kLookupRecurrent;
    if (n_swa > 0) return kLookupSwa;
    if (!can_shift) return kLookupNoRollback;
    return kLookupOk;
}

// Tokens that followed the most recent earlier occurrence of the last n tokens of `hist` (n from ngram_max down to
// ngram_min). `hist` ends with the token that is about to be decoded, so the guess continues after it.
// Stops before any token for which is_stop(token) is true (an end-of-generation token is never guessed).
// Returns an empty vector when nothing matches.
template <class IsStop>
std::vector<int32_t> lookup_draft(const std::vector<int32_t> &hist, const LookupConfig &cfg, int max_len, IsStop is_stop) {
    std::vector<int32_t> out;
    const long size = static_cast<long>(hist.size());
    const int cap = std::min(cfg.draft_max, max_len);
    if (cap <= 0 || cfg.ngram_min < 1) return out;
    for (int n = std::max(cfg.ngram_max, cfg.ngram_min); n >= cfg.ngram_min; --n) {
        if (size < n + 1) continue;  // need an earlier place for the run and at least one token after it
        const int32_t *tail = hist.data() + (size - n);
        // The earlier run must end before the tail itself: start <= size - n - 1.
        for (long start = size - n - 1; start >= 0; --start) {
            if (hist[static_cast<size_t>(start)] != tail[0]) continue;
            bool same = true;
            for (int k = 1; k < n; ++k) {
                if (hist[static_cast<size_t>(start + k)] != tail[k]) { same = false; break; }
            }
            if (!same) continue;
            for (long p = start + n; p < size && static_cast<int>(out.size()) < cap; ++p) {
                const int32_t t = hist[static_cast<size_t>(p)];
                if (is_stop(t)) break;
                out.push_back(t);
            }
            if (!out.empty()) return out;
            break;  // this run is followed by a stop token right away: try a shorter run
        }
    }
    return out;
}

struct VerifyResult {
    int accepted = 0;     // leading draft tokens that are exactly what the sampler picked
    int32_t next = 0;     // the sampler's token for the position right after them (it has NOT been decoded yet)
};

// `sample(j)` must return the token the real sampler picks from the logits of batch row j (row 0 = after the first batch token)
// and must record it as accepted in the sampler (llama_sampler_sample does). It is called for j = 0, 1, ... in order and stops
// at the first row whose token differs from draft[j]; when every guess matched, one more row (draft.size()) gives the next token.
// Every row it samples is valid: row j only uses context that has been confirmed equal to what plain decoding would hold.
template <class Sample>
VerifyResult verify_draft(const std::vector<int32_t> &draft, Sample sample) {
    VerifyResult r;
    for (size_t j = 0; j < draft.size(); ++j) {
        const int32_t s = sample(static_cast<int>(j));
        if (s != draft[j]) { r.next = s; return r; }
        ++r.accepted;
    }
    r.next = sample(static_cast<int>(draft.size()));
    return r;
}

// Decides on the running phone whether guessing is faster than plain decoding. Both rates are measured, nothing is assumed:
//  * a plain step: one token took `ms`.
//  * a round: it took `ms` and confirmed `tokens` tokens (1 + accepted guesses).
// After a warm-up of plain steps, rounds are allowed. When the recent rounds are not faster than the recent plain steps, guessing
// pauses for `pause_tokens` plain tokens and then probes again.
class LookupGate {
public:
    struct Config {
        int warmup_single = 3;   // plain steps measured before the first round
        int window = 8;          // recent steps / rounds the rates are taken from
        int min_rounds = 4;      // rounds needed before a verdict
        int pause_tokens = 32;   // plain tokens to run after a slow verdict; doubles after each repeated slow verdict
        int max_pause_tokens = 512;
        double margin = 1.0;     // rounds must reach this share of the plain rate to continue (1.0 = at least as fast)
    };

    LookupGate() : LookupGate(Config()) {}
    explicit LookupGate(const Config &c) : cfg_(c) {}

    bool allow() const { return paused_left_ == 0 && singles_.size() >= static_cast<size_t>(cfg_.warmup_single); }

    void on_single(double ms) {
        push(singles_, ms, 1);
        ++total_singles_;
        if (paused_left_ > 0 && --paused_left_ == 0) rounds_.clear();  // probe again with fresh numbers
    }

    void on_round(double ms, int tokens) {
        push(rounds_, ms, tokens);
        if (static_cast<int>(rounds_.size()) < cfg_.min_rounds || singles_.empty()) return;
        double rms = 0, rtok = 0, sms = 0, stok = 0;
        for (const auto &s : rounds_) { rms += s.ms; rtok += s.tokens; }
        for (const auto &s : singles_) { sms += s.ms; stok += s.tokens; }
        if (rms <= 0 || sms <= 0) return;
        const double spec_rate = rtok / rms;
        const double plain_rate = stok / sms;
        if (spec_rate < plain_rate * cfg_.margin) {
            // Each repeated slow verdict doubles the pause, so a text with nothing to copy pays for a probe only now and then.
            long pause = static_cast<long>(cfg_.pause_tokens) << std::min(backoff_, 10);
            paused_left_ = static_cast<int>(std::min<long>(pause, cfg_.max_pause_tokens));
            ++backoff_;
            ++pauses_;
        } else {
            backoff_ = 0;
        }
    }

    int pauses() const { return pauses_; }
    int paused_left() const { return paused_left_; }
    int total_singles() const { return total_singles_; }

private:
    struct Sample { double ms; int tokens; };
    void push(std::vector<Sample> &v, double ms, int tokens) {
        v.push_back({ms, tokens});
        if (static_cast<int>(v.size()) > cfg_.window) v.erase(v.begin());
    }
    Config cfg_;
    std::vector<Sample> singles_;
    std::vector<Sample> rounds_;
    int paused_left_ = 0;
    int backoff_ = 0;
    int pauses_ = 0;
    int total_singles_ = 0;
};

// Counts of one generation, reported as measured. Nothing in here is estimated.
struct LookupStats {
    bool active = false;       // lookup actually ran for this generation (enabled and allowed for this model)
    int block = 0;             // LookupBlock reason when it could not run
    long rounds = 0;           // verification rounds (batched decodes)
    long drafted = 0;          // guessed tokens sent for checking
    long accepted = 0;         // of those, the ones the sampler also picked
    double round_ms = 0;       // decode time spent in rounds
    long round_tokens = 0;     // tokens confirmed by rounds (1 + accepted each)
    long single_steps = 0;     // plain one-token decodes (no guess available, warm-up, or paused)
    double single_ms = 0;      // decode time spent in them
    long pauses = 0;           // times the gate paused guessing because it was not faster
};

inline double accept_percent(const LookupStats &s) {
    return s.drafted > 0 ? 100.0 * static_cast<double>(s.accepted) / static_cast<double>(s.drafted) : 0.0;
}

}  // namespace vibe
