#include <cstring>
// Real llama.cpp JNI bridge for VibeCoderAI (fully offline; CPU inference, optional Vulkan offload).
// v1.4: the llama context is kept between turns and the KV cache is reused for the common prompt prefix
// (llama_memory_seq_rm), exact token counting, GPU layer count from Kotlin, llama_supports_gpu_offload.
#include <jni.h>
#include <android/log.h>

#include <algorithm>
#include <atomic>
#include <chrono>
#include <cstdarg>
#include <cstdint>
#include <cstdio>
#include <sys/resource.h>
#include <exception>
#include <mutex>
#include <new>
#include <string>
#include <vector>

#include "batch_plan.h"
#include "bench_stats.h"
#include "llama.h"
#include "ngram_lookup.h"
#include "read_advice.h"
#include "mtmd.h"
#include "mtmd-helper.h"

#define TAG "VibeCoderLlamaJNI"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG, __VA_ARGS__)

namespace {

std::mutex g_dbg_lock;
std::string g_dbg;
const auto g_t0 = std::chrono::steady_clock::now();

// Timeline of what the native side is doing, readable from Kotlin without taking the engine lock.
void dbg(const char *fmt, ...) {
    char buf[480];
    va_list ap;
    va_start(ap, fmt);
    std::vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    long long ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - g_t0).count();
    char line[520];
    std::snprintf(line, sizeof(line), "[%lld.%03lld] %s\n", ms / 1000, ms % 1000, buf);
    {
        std::lock_guard<std::mutex> g(g_dbg_lock);
        g_dbg += line;
        if (g_dbg.size() > 3500) g_dbg.erase(0, g_dbg.size() - 3500);
    }
    LOGI("%s", buf);
}

struct Engine {
    llama_model *model = nullptr;
    llama_context *ctx = nullptr;
    const llama_vocab *vocab = nullptr;
    int n_ctx = 0;
    int n_batch = 0;
    // v1.9.28: true when the weights are memory-mapped from storage (a mixture-of-experts model bigger than free RAM).
    bool streaming = false;
    // v1.9.34: the model file as the app opened it, and the read-ahead hint last applied to its mapping (experimental, streaming only).
    std::string path;
    std::atomic<int> read_advice{0};
    std::atomic<long long> advice_bytes{0};
    // v1.4: tokens currently held in KV cache sequence 0 (prompt + decoded output), in order.
    std::vector<llama_token> cache_tokens;
    std::atomic<int> last_cached{0};
    // v1.9.30: prompt tokens the last generation actually processed (after any cut) and how many oldest tokens were cut to fit.
    std::atomic<int> last_prompt{0};
    std::atomic<int> last_truncated{0};
    // v1.9.31: prompt-lookup decoding (experimental). lookup_block != 0 means this load can never use it (see ngram_lookup.h).
    std::atomic<bool> lookup_on{false};
    int lookup_block = 0;
    std::atomic<bool> lookup_broken{false};  // a KV rollback failed once: lookup stays off for this load
    std::mutex lookup_lock;
    vibe::LookupStats lookup_stats;  // of the last text generation; guarded by lookup_lock
    std::atomic<bool> stop{false};
    std::mutex lock;  // serialises generate / free
    // v1.7.3: image input. mtmd holds the vision encoder (mmproj); images are encoded JPEG/PNG bytes
    // for the NEXT generate call only.
    mtmd_context *mtmd = nullptr;
    std::vector<std::string> images;
};

std::once_flag g_backend_once;

// v1.9.26: set from Kotlin before a load of a mixture-of-experts model that is bigger than free RAM.
std::atomic<bool> g_streaming_load{false};
std::mutex g_error_lock;
std::string g_last_error;

void set_error(const std::string &msg) {
    std::lock_guard<std::mutex> g(g_error_lock);
    g_last_error = msg;
    LOGE("%s", msg.c_str());
}

std::string jstr(JNIEnv *env, jstring s) {
    if (s == nullptr) return {};
    const char *c = env->GetStringUTFChars(s, nullptr);
    std::string out(c ? c : "");
    if (c) env->ReleaseStringUTFChars(s, c);
    return out;
}

// Returns how many leading bytes of `s` form complete UTF-8 sequences.
size_t utf8_complete_prefix(const std::string &s) {
    size_t n = s.size();
    if (n == 0) return 0;
    // Look back at most 3 bytes for an incomplete multi-byte sequence start.
    for (size_t back = 1; back <= std::min<size_t>(3, n); ++back) {
        unsigned char c = static_cast<unsigned char>(s[n - back]);
        if ((c & 0xC0) == 0x80) continue;  // continuation byte, keep looking
        size_t need = 1;
        if ((c & 0xE0) == 0xC0) need = 2;
        else if ((c & 0xF0) == 0xE0) need = 3;
        else if ((c & 0xF8) == 0xF0) need = 4;
        return (need > back) ? n - back : n;
    }
    return n;
}

jbyteArray to_jbytes(JNIEnv *env, const std::string &s) {
    jbyteArray arr = env->NewByteArray(static_cast<jsize>(s.size()));
    if (arr != nullptr && !s.empty()) {
        env->SetByteArrayRegion(arr, 0, static_cast<jsize>(s.size()),
                                reinterpret_cast<const jbyte *>(s.data()));
    }
    return arr;
}

Engine *as_engine(jlong h) { return reinterpret_cast<Engine *>(h); }

// v1.7.3: one generation whose prompt contains images. The prompt text holds one "<__media__>" marker per
// image; mtmd turns each marker into image tokens, which are encoded and decoded into the KV cache before the
// answer is sampled. The KV cache is not reused across image turns (it cannot be tracked as plain tokens).
int generate_with_images(JNIEnv *env, Engine *e, const std::string &text, const std::vector<std::string> &images,
                         int max_tokens, float temp, float top_p, int top_k, float repeat_penalty,
                         jobject callback, jmethodID on_piece, jmethodID on_progress) {
    llama_memory_t mem = llama_get_memory(e->ctx);
    std::vector<mtmd_bitmap *> bitmaps;
    mtmd_input_chunks *chunks = nullptr;
    llama_sampler *smpl = nullptr;
    llama_batch one = {};
    bool one_ready = false;
    auto cleanup = [&]() {
        if (one_ready) llama_batch_free(one);
        if (smpl != nullptr) llama_sampler_free(smpl);
        if (chunks != nullptr) mtmd_input_chunks_free(chunks);
        for (auto *b : bitmaps) mtmd_bitmap_free(b);
        llama_memory_clear(mem, true);
        e->cache_tokens.clear();
        e->last_cached = 0;
        e->last_prompt = 0;
        e->last_truncated = 0;
    };

    // The marker must appear once per image.
    {
        const std::string marker = mtmd_default_marker();
        size_t found = 0;
        for (size_t at = text.find(marker); at != std::string::npos; at = text.find(marker, at + marker.size())) ++found;
        if (found != images.size()) {
            set_error("The prompt has " + std::to_string(found) + " image markers for " + std::to_string(images.size()) + " images.");
            cleanup();
            return -1;
        }
    }
    for (const auto &img : images) {
        mtmd_helper_bitmap_wrapper w = mtmd_helper_bitmap_init_from_buf(
            e->mtmd, reinterpret_cast<const unsigned char *>(img.data()), img.size(), false, mtmd_helper_init_opt_default());
        if (w.bitmap == nullptr) {
            set_error("Could not decode the image (use JPEG or PNG).");
            cleanup();
            return -1;
        }
        bitmaps.push_back(w.bitmap);
    }

    mtmd_input_text itext;
    itext.text = text.c_str();
    itext.text_len = text.size();
    itext.add_special = false;
    itext.parse_special = true;
    chunks = mtmd_input_chunks_init();
    std::vector<const mtmd_bitmap *> bptr(bitmaps.begin(), bitmaps.end());
    int32_t rc = mtmd_tokenize(e->mtmd, chunks, &itext, bptr.data(), bptr.size());
    if (rc != 0) {
        set_error("Could not prepare the image prompt (code " + std::to_string(rc) + ").");
        cleanup();
        return -1;
    }

    const size_t n_tokens = mtmd_helper_get_n_tokens(chunks);
    const llama_pos n_pos_total = mtmd_helper_get_n_pos(chunks);
    const int reserve = std::max(32, std::min(static_cast<int>(max_tokens), e->n_ctx / 4));
    if (static_cast<int>(n_pos_total) + reserve > e->n_ctx) {
        set_error("The image and prompt need " + std::to_string(n_pos_total) + " tokens but the context is " +
                  std::to_string(e->n_ctx) + ". Raise Context length to 4096 or more.");
        cleanup();
        return -1;
    }

    llama_memory_clear(mem, true);
    e->cache_tokens.clear();
    e->last_cached = 0;
    e->last_prompt = 0;
    e->last_truncated = 0;
    dbg("generate(images): %zu images, prompt=%zu tokens", images.size(), n_tokens);

    jboolean go = env->CallBooleanMethod(callback, on_progress, static_cast<jint>(0), static_cast<jint>(n_tokens));
    if (env->ExceptionCheck()) { env->ExceptionClear(); cleanup(); return 0; }
    if (!go) { cleanup(); return 0; }

    llama_pos n_past = 0;
    int32_t ev = mtmd_helper_eval_chunks(e->mtmd, e->ctx, chunks, 0, 0, e->n_batch, true, &n_past);
    if (ev != 0) {
        if (!e->stop) set_error("Reading the image failed (code " + std::to_string(ev) + "). Try a smaller context or fewer image tokens.");
        const bool stopped = e->stop;
        cleanup();
        return stopped ? 0 : -1;
    }
    dbg("image decoded: n_past=%d", static_cast<int>(n_past));
    go = env->CallBooleanMethod(callback, on_progress, static_cast<jint>(n_tokens), static_cast<jint>(n_tokens));
    if (env->ExceptionCheck()) { env->ExceptionClear(); cleanup(); return 0; }
    if (!go) { cleanup(); return 0; }

    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    smpl = llama_sampler_chain_init(sparams);
    if (repeat_penalty > 1.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(e->vocab), 256, repeat_penalty, 0.0f, 0.1f));
    }
    if (temp <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        if (top_k > 0) llama_sampler_chain_add(smpl, llama_sampler_init_top_k(top_k));
        if (top_p > 0.0f && top_p < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    // Explicit positions: after an image the next position is n_past (M-RoPE models count positions, not tokens).
    one = llama_batch_init(1, 0, 1);
    one_ready = true;

    int generated = 0;
    int result = 0;
    std::string pending;
    char piece[256];
    const int limit = std::min(static_cast<int>(max_tokens), e->n_ctx - static_cast<int>(n_past));
    bool keep_going = true;
    while (keep_going && generated < limit && !e->stop) {
        llama_token tok = llama_sampler_sample(smpl, e->ctx, -1);
        if (llama_vocab_is_eog(e->vocab, tok)) break;

        int plen = llama_token_to_piece(e->vocab, tok, piece, sizeof(piece), 0, false);
        if (plen > 0) pending.append(piece, static_cast<size_t>(plen));
        ++generated;

        size_t ready = utf8_complete_prefix(pending);
        if (ready > 0) {
            jbyteArray bytes = to_jbytes(env, pending.substr(0, ready));
            pending.erase(0, ready);
            jboolean cont = env->CallBooleanMethod(callback, on_piece, bytes);
            env->DeleteLocalRef(bytes);
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                keep_going = false;
            } else if (!cont) {
                keep_going = false;
            }
        }
        if (!keep_going) break;

        one.n_tokens = 1;
        one.token[0] = tok;
        one.pos[0] = n_past;
        one.n_seq_id[0] = 1;
        one.seq_id[0][0] = 0;
        one.logits[0] = 1;
        if (llama_decode(e->ctx, one) != 0) {
            if (e->stop) break;
            set_error("llama_decode failed during generation.");
            result = -1;
            break;
        }
        ++n_past;
    }
    cleanup();
    return result < 0 ? -1 : generated;
}

// v1.9.29: process counters for the detailed Speed test. All best effort: a platform that hides a value gives -1.
struct ProcCounters {
    long long major_faults = -1;   // page faults that needed physical I/O
    long long minor_faults = -1;   // page faults served from memory (logical access, no I/O)
    long long storage_read_bytes = -1;  // bytes the process caused to be read from storage
    bool read_from_rusage = false;      // storage_read_bytes is getrusage's block count (/proc/self/io was not readable)
    double cpu_ms = -1.0;               // user + system CPU time of ALL threads of this process so far
    double sys_ms = -1.0;               // of which kernel (system) time: page-fault handling, file system work
};

ProcCounters read_proc_counters() {
    ProcCounters c;
    long long inblock_bytes = 0;
    struct rusage ru;
    if (getrusage(RUSAGE_SELF, &ru) == 0) {
        c.major_faults = static_cast<long long>(ru.ru_majflt);
        c.minor_faults = static_cast<long long>(ru.ru_minflt);
        inblock_bytes = static_cast<long long>(ru.ru_inblock) * 512LL;
        c.cpu_ms = static_cast<double>(ru.ru_utime.tv_sec + ru.ru_stime.tv_sec) * 1000.0 +
                   static_cast<double>(ru.ru_utime.tv_usec + ru.ru_stime.tv_usec) / 1000.0;
        c.sys_ms = static_cast<double>(ru.ru_stime.tv_sec) * 1000.0 + static_cast<double>(ru.ru_stime.tv_usec) / 1000.0;
    }
    if (FILE *f = std::fopen("/proc/self/io", "r")) {
        char line[128];
        while (std::fgets(line, sizeof(line), f) != nullptr) {
            long long v = 0;
            if (std::sscanf(line, "read_bytes: %lld", &v) == 1) c.storage_read_bytes = v;
        }
        std::fclose(f);
    }
    // Some phones hide /proc/self/io. getrusage's block count is the same kind of number (512-byte blocks read), but it is only
    // trusted when it is above zero: a kernel that does not count it reports 0 forever, and 0 must not be shown as "no reads".
    if (c.storage_read_bytes < 0 && inblock_bytes > 0) {
        c.storage_read_bytes = inblock_bytes;
        c.read_from_rusage = true;
    }
    return c;
}

// Varied (non-repeating) code-like text, so the benchmark prompt does not route to the same few experts every token.
std::string bench_text(int block) {
    std::string t;
    for (int i = block * 20; i < block * 20 + 20; ++i) {
        t += "Line " + std::to_string(i) + ": value " + std::to_string((i * 7919) % 1000) + " is stored in item_" +
             std::to_string(i) + "; call update(item_" + std::to_string(i) + ", " + std::to_string(i * 31) + ") to refresh it.\n";
    }
    return t;
}

}  // namespace

extern "C" {

JNIEXPORT jlong JNICALL
Java_com_example_llama_LlamaBridge_nativeLoad(JNIEnv *env, jobject, jstring model_path,
                                              jint n_threads, jint n_ctx, jint n_gpu_layers) {
    std::call_once(g_backend_once, []() { llama_backend_init(); });

    std::string path = jstr(env, model_path);
    const bool gpu = n_gpu_layers > 0 && llama_supports_gpu_offload();
    LOGI("Loading model: %s (threads=%d ctx=%d gpu_layers=%d)", path.c_str(), n_threads, n_ctx, gpu ? n_gpu_layers : 0);

    // Read and clear: the flag belongs to this one load, so a later load (the router model) is not affected.
    const bool streaming = g_streaming_load.exchange(false);
    llama_model_params mparams = llama_model_default_params();
    mparams.n_gpu_layers = gpu ? static_cast<int32_t>(n_gpu_layers) : 0;
    if (streaming) {
        // Keep the weights memory-mapped: repacked weights are copied into RAM, which a model bigger than RAM cannot afford.
        mparams.use_extra_bufts = false;
        LOGI("Streaming load: extra buffer types (weight repacking) off, weights stay memory-mapped");
    }

    llama_model *model = nullptr;
    try {
        model = llama_model_load_from_file(path.c_str(), mparams);
    } catch (const std::bad_alloc &) {
        set_error("Out of memory while loading the model.");
        return 0;
    } catch (const std::exception &ex) {
        set_error(std::string("Model load failed: ") + ex.what());
        return 0;
    }
    if (model == nullptr) {
        set_error("Failed to load GGUF model (file corrupt, unsupported architecture, or out of memory).");
        return 0;
    }

    dbg("model weights mapped");
    int ctx_len = n_ctx > 0 ? n_ctx : 2048;
    int threads = n_threads > 0 ? n_threads : 4;

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = static_cast<uint32_t>(ctx_len);
    // v1.9.28: a streaming model reads most of its experts from storage for every batch, however small the batch is.
    // Big batches pay that read once per 1024 prompt tokens instead of once per 32.
    // v1.9.29: llama.cpp's own timers are off by default (no_perf = true). They cost two clock reads per decode call.
    cparams.no_perf = false;
    cparams.n_batch = static_cast<uint32_t>(vibe::context_batch(streaming, ctx_len));
    cparams.n_ubatch = cparams.n_batch;
    cparams.n_threads = threads;
    cparams.n_threads_batch = threads;

    // v1.9.1 low-RAM: an 8-bit KV cache is about half the size of the default f16 one (34 vs 64 bytes per 32
    // values) with no visible quality loss. A quantised V cache needs flash attention. Only on the CPU path:
    // with Vulkan offload the KV cache lives on the GPU and keeps the default type.
    const llama_context_params default_cparams = cparams;
    const bool kv_q8 = !gpu;
    if (kv_q8) {
        cparams.flash_attn_type = LLAMA_FLASH_ATTN_TYPE_ENABLED;
        cparams.type_k = GGML_TYPE_Q8_0;
        cparams.type_v = GGML_TYPE_Q8_0;
    }

    llama_context *ctx = nullptr;
    try {
        ctx = llama_init_from_model(model, cparams);
    } catch (const std::bad_alloc &) {
        ctx = nullptr;
    } catch (const std::exception &) {
        ctx = nullptr;
    }
    if (ctx == nullptr && kv_q8) {
        // This build/device rejected the quantised cache: fall back to the default f16 cache.
        LOGI("q8_0 KV cache failed, retrying with the default cache");
        cparams = default_cparams;
        try {
            ctx = llama_init_from_model(model, cparams);
        } catch (const std::exception &) {
            ctx = nullptr;
        }
    }
    if (ctx == nullptr) {
        llama_model_free(model);
        set_error("Failed to create llama context (try a smaller context length; likely out of memory).");
        return 0;
    }

    auto *e = new Engine();
    e->model = model;
    e->ctx = ctx;
    e->vocab = llama_model_get_vocab(model);
    e->n_ctx = static_cast<int>(llama_n_ctx(ctx));
    e->n_batch = static_cast<int>(cparams.n_batch);
    e->streaming = streaming;
    e->path = path;
    e->lookup_block = vibe::lookup_block_reason(streaming, llama_model_is_recurrent(model), llama_model_is_hybrid(model),
                                                llama_model_n_swa(model), llama_memory_can_shift(llama_get_memory(ctx)));
    dbg("context ready: n_ctx=%d n_batch=%d threads=%d gpu_layers=%d kv=%s", e->n_ctx, e->n_batch, threads, mparams.n_gpu_layers, cparams.type_k == GGML_TYPE_Q8_0 ? "q8_0" : "f16");
    dbg("cpu: %s", llama_print_system_info());
    // Lets Stop interrupt a long llama_decode (prompt processing) instead of waiting for it to finish.
    llama_set_abort_callback(ctx, [](void *data) -> bool {
        return static_cast<Engine *>(data)->stop.load();
    }, e);
    return reinterpret_cast<jlong>(e);
}

JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeFree(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return;
    e->stop = true;
    std::lock_guard<std::mutex> g(e->lock);  // wait for any running generation
    if (e->mtmd != nullptr) mtmd_free(e->mtmd);
    llama_free(e->ctx);
    llama_model_free(e->model);
    delete e;
}

// v1.7.3: loads the vision encoder (mmproj GGUF) that goes with the loaded text model.
JNIEXPORT jboolean JNICALL
Java_com_example_llama_LlamaBridge_nativeLoadMmproj(JNIEnv *env, jobject, jlong handle, jstring path,
                                                    jint n_threads, jint image_max_tokens) {
    Engine *e = as_engine(handle);
    if (e == nullptr) {
        set_error("No model loaded.");
        return JNI_FALSE;
    }
    std::lock_guard<std::mutex> g(e->lock);
    if (e->mtmd != nullptr) {
        mtmd_free(e->mtmd);
        e->mtmd = nullptr;
    }
    std::string p = jstr(env, path);
    mtmd_context_params mp = mtmd_context_params_default();
    mp.use_gpu = false;
    mp.print_timings = false;
    mp.warmup = false;
    mp.n_threads = n_threads > 0 ? n_threads : 4;
    if (image_max_tokens > 0) mp.image_max_tokens = image_max_tokens;
    try {
        e->mtmd = mtmd_init_from_file(p.c_str(), e->model, mp);
    } catch (const std::bad_alloc &) {
        e->mtmd = nullptr;
        set_error("Out of memory while loading the image helper (mmproj).");
        return JNI_FALSE;
    } catch (const std::exception &ex) {
        e->mtmd = nullptr;
        set_error(std::string("Image helper load failed: ") + ex.what());
        return JNI_FALSE;
    }
    if (e->mtmd == nullptr) {
        set_error("Could not load the image helper (mmproj). It must be the mmproj file of this exact model.");
        return JNI_FALSE;
    }
    if (!mtmd_support_vision(e->mtmd)) {
        mtmd_free(e->mtmd);
        e->mtmd = nullptr;
        set_error("This mmproj file has no image support.");
        return JNI_FALSE;
    }
    e->images.clear();
    dbg("vision ready (mmproj loaded, image_max_tokens=%d)", static_cast<int>(image_max_tokens));
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL
Java_com_example_llama_LlamaBridge_nativeHasVision(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    return (e != nullptr && e->mtmd != nullptr) ? JNI_TRUE : JNI_FALSE;
}

// Images (encoded JPEG/PNG bytes) for the next nativeGenerate only; the prompt needs one "<__media__>" each.
JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeSetImages(JNIEnv *env, jobject, jlong handle, jobjectArray images) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return;
    std::vector<std::string> out;
    if (images != nullptr) {
        jsize n = env->GetArrayLength(images);
        for (jsize i = 0; i < n; ++i) {
            auto arr = static_cast<jbyteArray>(env->GetObjectArrayElement(images, i));
            if (arr == nullptr) continue;
            jsize len = env->GetArrayLength(arr);
            std::string bytes(static_cast<size_t>(len), '\0');
            if (len > 0) env->GetByteArrayRegion(arr, 0, len, reinterpret_cast<jbyte *>(&bytes[0]));
            env->DeleteLocalRef(arr);
            out.push_back(std::move(bytes));
        }
    }
    std::lock_guard<std::mutex> g(e->lock);
    e->images = std::move(out);
}

JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeStop(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e != nullptr) e->stop = true;
}

JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeLastError(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> g(g_error_lock);
    return env->NewStringUTF(g_last_error.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeDebug(JNIEnv *env, jobject) {
    std::lock_guard<std::mutex> g(g_dbg_lock);
    return env->NewStringUTF(g_dbg.c_str());
}

// Decodes a short fixed prompt and reports CPU features and speed (for diagnosing slow devices).
JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeBench(JNIEnv *env, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewStringUTF("No model loaded.");
    std::lock_guard<std::mutex> guard(e->lock);
    e->stop = false;
    llama_memory_clear(llama_get_memory(e->ctx), true);
    e->cache_tokens.clear();
    const std::string text = "The quick brown fox jumps over the lazy dog. Write a function that adds two numbers.";
    std::vector<llama_token> tokens(64);
    int n = llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(),
                           static_cast<int32_t>(tokens.size()), false, true);
    if (n <= 0) return env->NewStringUTF("Tokenization failed.");
    if (n > 16) n = 16;
    auto t0 = std::chrono::steady_clock::now();
    int rc = llama_decode(e->ctx, llama_batch_get_one(tokens.data(), n));
    long long ms = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - t0).count();
    llama_memory_clear(llama_get_memory(e->ctx), true);
    char out[1536];
    std::snprintf(out, sizeof(out), "Prompt batch: %d tokens in %lld ms (rc=%d) = %.1f tok/s\nCPU: %s",
                  n, ms, rc, ms > 0 ? n * 1000.0 / static_cast<double>(ms) : 0.0, llama_print_system_info());
    return env->NewStringUTF(out);
}

// v1.9.29: Speed test that measures the prompt and the generation separately (the short test above is one prompt batch).
// The first generated token comes from the prompt's own logits, so n generated tokens have n-1 timed decode steps.
JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeBenchDetailed(JNIEnv *env, jobject, jlong handle, jint prompt_tokens, jint decode_tokens) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewStringUTF("No model loaded.");
    std::lock_guard<std::mutex> guard(e->lock);
    e->stop = false;
    llama_memory_clear(llama_get_memory(e->ctx), true);
    e->cache_tokens.clear();

    const int want_prompt = std::max(8, std::min(static_cast<int>(prompt_tokens), e->n_ctx / 2));
    const int want_gen = std::max(2, std::min(std::min(static_cast<int>(decode_tokens), 256), e->n_ctx - want_prompt - 1));

    std::vector<llama_token> tokens;
    for (int block = 0; static_cast<int>(tokens.size()) < want_prompt && block < 400; ++block) {
        const std::string text = bench_text(block);
        const int n = -llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), nullptr, 0, false, true);
        if (n <= 0) return env->NewStringUTF("Tokenization failed.");
        std::vector<llama_token> part(static_cast<size_t>(n));
        if (llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), part.data(), n, false, true) < 0) {
            return env->NewStringUTF("Tokenization failed.");
        }
        tokens.insert(tokens.end(), part.begin(), part.end());
    }
    if (static_cast<int>(tokens.size()) > want_prompt) tokens.resize(static_cast<size_t>(want_prompt));

    auto reset = [&]() {
        llama_memory_clear(llama_get_memory(e->ctx), true);
        e->cache_tokens.clear();
    };
    using clock = std::chrono::steady_clock;
    auto ms_since = [](clock::time_point t) {
        return std::chrono::duration<double, std::milli>(clock::now() - t).count();
    };

    // llama.cpp counts a decode only when the context is synchronized, and its perf reset does not clear tokens still queued from an
    // earlier decode that nobody read. Synchronize first so nothing queued before this run can be counted in it. (A phone showed 144
    // tokens for a 128-token prompt; this did not reproduce on a host, so the cause is not proven. The timers line now says when its
    // counts do not match the run.)
    llama_synchronize(e->ctx);
    llama_perf_context_reset(e->ctx);
    const ProcCounters before = read_proc_counters();
    const auto t_prompt = clock::now();
    size_t pos = 0;
    while (pos < tokens.size()) {
        if (e->stop) { reset(); return env->NewStringUTF("Speed test stopped."); }
        const int chunk = vibe::prompt_chunk(e->streaming, e->n_batch, tokens.size() - pos);
        if (llama_decode(e->ctx, llama_batch_get_one(tokens.data() + pos, chunk)) != 0) {
            reset();
            return env->NewStringUTF(e->stop ? "Speed test stopped." : "Speed test failed while processing the prompt.");
        }
        pos += static_cast<size_t>(chunk);
    }
    const double prompt_ms = ms_since(t_prompt);
    const ProcCounters mid = read_proc_counters();
    const auto t_gen = clock::now();

    llama_sampler *smpl = llama_sampler_chain_init(llama_sampler_chain_default_params());
    llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    std::vector<double> step_ms;
    step_ms.reserve(static_cast<size_t>(want_gen));
    int produced = 0;
    bool interrupted = false;
    for (int i = 0; i < want_gen; ++i) {
        if (e->stop) { interrupted = true; break; }
        llama_token tok = llama_sampler_sample(smpl, e->ctx, -1);
        if (llama_vocab_is_eog(e->vocab, tok)) break;
        ++produced;
        if (i == want_gen - 1) break;
        const auto t_step = clock::now();
        if (llama_decode(e->ctx, llama_batch_get_one(&tok, 1)) != 0) { interrupted = true; break; }
        step_ms.push_back(ms_since(t_step));
    }
    llama_sampler_free(smpl);
    const double gen_wall_ms = ms_since(t_gen);
    const ProcCounters after = read_proc_counters();
    const llama_perf_context_data perf = llama_perf_context(e->ctx);
    reset();

    if (interrupted) return env->NewStringUTF("Speed test stopped.");
    if (produced < 2 || step_ms.empty()) return env->NewStringUTF("The model ended its answer too early to time the generation. Try again.");

    const double gen_ms = vibe::sum(step_ms);
    // llama.cpp's own counts must equal what this run did; when they do not, its timers are not about this run and the line says so.
    const bool perf_matches = static_cast<size_t>(perf.n_p_eval) == tokens.size() && static_cast<size_t>(perf.n_eval) == step_ms.size();
    char faults[96];
    char reads[128];
    if (before.major_faults >= 0 && after.major_faults >= 0 && before.minor_faults >= 0 && after.minor_faults >= 0) {
        std::snprintf(faults, sizeof(faults), "major %lld, minor %lld", after.major_faults - before.major_faults,
                      after.minor_faults - before.minor_faults);
    } else {
        std::snprintf(faults, sizeof(faults), "not available");
    }
    if (before.storage_read_bytes >= 0 && after.storage_read_bytes >= 0) {
        const double mb = static_cast<double>(after.storage_read_bytes - before.storage_read_bytes) / 1048576.0;
        const double secs = (prompt_ms + gen_ms) / 1000.0;
        std::snprintf(reads, sizeof(reads), "%.0f MB read, %.0f MB/s%s", mb, secs > 0.0 ? mb / secs : 0.0,
                      after.read_from_rusage ? " (block count from getrusage)" : "");
    } else {
        std::snprintf(reads, sizeof(reads), "read bytes not available");
    }

    // CPU time of all threads of this app per phase. ggml's worker threads spin while they wait for each other, so a HIGH value does
    // not show that the CPU limited the speed; a LOW value does show the threads were mostly waiting (storage or other work).
    char cpu_line[256];
    if (before.cpu_ms >= 0.0 && mid.cpu_ms >= 0.0 && after.cpu_ms >= 0.0 && prompt_ms > 0.0 && gen_wall_ms > 0.0) {
        const double p_cpu = mid.cpu_ms - before.cpu_ms;
        const double g_cpu = after.cpu_ms - mid.cpu_ms;
        char kernel[96] = "";
        if (before.sys_ms >= 0.0 && mid.sys_ms >= 0.0 && after.sys_ms >= 0.0 && p_cpu > 0.0 && g_cpu > 0.0) {
            // How much of that CPU time was the kernel (page faults, file system), not the model's own arithmetic.
            std::snprintf(kernel, sizeof(kernel), "; kernel time: prompt %.0f%%, generation %.0f%%",
                          100.0 * (mid.sys_ms - before.sys_ms) / p_cpu, 100.0 * (after.sys_ms - mid.sys_ms) / g_cpu);
        }
        std::snprintf(cpu_line, sizeof(cpu_line), "CPU busy (all threads of this app): prompt %.1f cores, generation %.1f cores, of %d threads%s",
                      p_cpu / prompt_ms, g_cpu / gen_wall_ms, llama_n_threads(e->ctx), kernel);
    } else {
        std::snprintf(cpu_line, sizeof(cpu_line), "CPU busy: not available");
    }

    // v1.9.34: what each phase read from storage, and per generated token, measured by the same counter as the line above. For a model
    // that streams its experts this is the number that explains the speed: reading X MB per token at Y MB/s cannot be faster than X / Y.
    char split[320] = "";
    if (before.storage_read_bytes >= 0 && mid.storage_read_bytes >= 0 && after.storage_read_bytes >= 0) {
        const double p_mb = static_cast<double>(mid.storage_read_bytes - before.storage_read_bytes) / 1048576.0;
        const double g_mb = static_cast<double>(after.storage_read_bytes - mid.storage_read_bytes) / 1048576.0;
        if (p_mb >= 1.0 || g_mb >= 1.0) {
            std::snprintf(split, sizeof(split), "Storage reads: prompt %.0f MB, generation %.0f MB = %.0f MB per generated token\n",
                          p_mb, g_mb, g_mb / static_cast<double>(step_ms.size()));
        }
    }
    char pattern[192] = "";
    if (e->streaming) {
        if (e->read_advice.load() == vibe::kAdviceRandom) {
            std::snprintf(pattern, sizeof(pattern), "Read pattern: no read-ahead on %.0f MB of the model file (experimental setting)\n",
                          static_cast<double>(e->advice_bytes.load()) / 1048576.0);
        } else {
            std::snprintf(pattern, sizeof(pattern), "Read pattern: kernel default read-ahead\n");
        }
    }

    // First line: the same numbers as one flat JSON object for the app's speed history (the app removes it before showing the text).
    char out[4096];
    const int head = std::snprintf(
        out, sizeof(out),
        "@@bench {\"promptTokens\":%zu,\"promptMs\":%.1f,\"genTokens\":%d,\"steps\":%zu,\"genMs\":%.1f,\"medianMs\":%.1f,\"p95Ms\":%.1f,"
        "\"readMb\":%.1f,\"majFaults\":%lld,\"minFaults\":%lld,\"threads\":%d,\"streaming\":%s,\"batch\":%d}\n",
        tokens.size(), prompt_ms, produced, step_ms.size(), gen_ms, vibe::percentile(step_ms, 50.0), vibe::percentile(step_ms, 95.0),
        (before.storage_read_bytes >= 0 && after.storage_read_bytes >= 0)
            ? static_cast<double>(after.storage_read_bytes - before.storage_read_bytes) / 1048576.0 : -1.0,
        (before.major_faults >= 0 && after.major_faults >= 0) ? after.major_faults - before.major_faults : -1LL,
        (before.minor_faults >= 0 && after.minor_faults >= 0) ? after.minor_faults - before.minor_faults : -1LL,
        llama_n_threads(e->ctx), e->streaming ? "true" : "false", e->n_batch);
    const size_t off = head > 0 ? std::min(static_cast<size_t>(head), sizeof(out) - 1) : 0;
    std::snprintf(out + off, sizeof(out) - off,
                  "Prompt: %zu tokens in %.1f s = %.1f tok/s (first token after %.1f s)\n"
                  "Generation: %d tokens, %.1f s of decoding = %.1f tok/s (median %.0f ms, P95 %.0f ms per token)\n"
                  "Storage: %s. Page faults: %s.\n"
                  "(Storage read and major faults are physical I/O; minor faults are pages already in memory. The OS may hide them.)\n"
                  "%s%s"
                  "llama.cpp timers (compute only): prompt %.0f ms for %d tokens, generation %.0f ms for %d steps.%s\n"
                  "%s, %d threads, batch %d, greedy sampling\n"
                  "%s\n"
                  "CPU: %s",
                  tokens.size(), prompt_ms / 1000.0, vibe::tokens_per_second(tokens.size(), prompt_ms), prompt_ms / 1000.0,
                  produced, gen_ms / 1000.0, vibe::decode_tokens_per_second(step_ms), vibe::percentile(step_ms, 50.0),
                  vibe::percentile(step_ms, 95.0),
                  reads, faults, split, pattern,
                  perf.t_p_eval_ms, perf.n_p_eval, perf.t_eval_ms, perf.n_eval,
                  perf_matches ? "" : " These counts do not match this run, so ignore this line.",
                  e->streaming ? "Experts stream from storage" : "Model in RAM", llama_n_threads(e->ctx), e->n_batch,
                  cpu_line, llama_print_system_info());
    return env->NewStringUTF(out);
}

JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeSetThreads(JNIEnv *, jobject, jlong handle, jint threads) {
    Engine *e = as_engine(handle);
    if (e == nullptr || threads <= 0) return;
    llama_set_n_threads(e->ctx, threads, threads);
}

// v1.4: true when this build has a GPU backend (Vulkan) with at least one usable device.
JNIEXPORT jboolean JNICALL
Java_com_example_llama_LlamaBridge_nativeHasGpu(JNIEnv *, jobject) {
    std::call_once(g_backend_once, []() { llama_backend_init(); });
    return llama_supports_gpu_offload() ? JNI_TRUE : JNI_FALSE;
}

// v1.9.26: the next load keeps weights memory-mapped (see nativeLoad).
JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeSetStreamingLoad(JNIEnv *, jobject, jboolean on) {
    g_streaming_load.store(on == JNI_TRUE);
}

// v1.4: exact prompt token count (same tokenizer flags as generation). -1 on failure.
JNIEXPORT jint JNICALL
Java_com_example_llama_LlamaBridge_nativeCountTokens(JNIEnv *env, jobject, jlong handle, jstring text) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return -1;
    std::string s = jstr(env, text);
    if (s.empty()) return 0;
    int n = llama_tokenize(e->vocab, s.c_str(), static_cast<int32_t>(s.size()), nullptr, 0, false, true);
    // With a null buffer llama_tokenize returns minus the number of tokens it needs.
    return n <= 0 ? static_cast<jint>(-n) : static_cast<jint>(n);
}

// v1.9.34 (experimental): sets or clears the kernel's read-ahead hint on the mapping of a model that streams its experts from storage.
// mode 0 = kernel default, 1 = no read-ahead around a page fault (MADV_RANDOM). Returns the bytes of the model file the hint was
// applied to, or a negative reason: -1 no model, -2 the model is not streamed (nothing is changed), -3 its mapping was not found,
// -4 the kernel refused. Never reloads the model and never changes what the model computes, only how its file is read.
JNIEXPORT jlong JNICALL
Java_com_example_llama_LlamaBridge_nativeSetReadAdvice(JNIEnv *, jobject, jlong handle, jint mode) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return -1;
    if (!e->streaming) return -2;
    const auto regions = vibe::regions_of_model(vibe::read_text_file("/proc/self/maps"), e->path);
    if (regions.empty()) return -3;
    const int want = mode == 1 ? vibe::kAdviceRandom : vibe::kAdviceDefault;
    const long long n = vibe::advise_regions(regions, want);
    if (n < 0) return -4;
    e->read_advice.store(want);
    e->advice_bytes.store(n);
    return static_cast<jlong>(n);
}

// v1.9.31: turns prompt-lookup decoding on or off for the next generations (experimental, default off). It still never runs on a
// load that cannot use it (see nativeLookupInfo).
JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeSetLookup(JNIEnv *, jobject, jlong handle, jboolean on) {
    Engine *e = as_engine(handle);
    if (e != nullptr) e->lookup_on.store(on == JNI_TRUE);
}

// v1.9.31: [block reason (0 = usable), enabled, active in the last generation, rounds, drafted, accepted, round ms, round tokens,
// plain steps, plain ms, pauses] of the last text generation. Counts only: nothing here is estimated.
JNIEXPORT jdoubleArray JNICALL
Java_com_example_llama_LlamaBridge_nativeLookupInfo(JNIEnv *env, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    jdoubleArray out = env->NewDoubleArray(11);
    if (out == nullptr) return nullptr;
    double v[11] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0};
    if (e != nullptr) {
        vibe::LookupStats st;
        {
            std::lock_guard<std::mutex> g(e->lookup_lock);
            st = e->lookup_stats;
        }
        v[0] = e->lookup_broken.load() ? static_cast<double>(vibe::kLookupNoRollback) : static_cast<double>(e->lookup_block);
        v[1] = e->lookup_on.load() ? 1.0 : 0.0;
        v[2] = st.active ? 1.0 : 0.0;
        v[3] = static_cast<double>(st.rounds);
        v[4] = static_cast<double>(st.drafted);
        v[5] = static_cast<double>(st.accepted);
        v[6] = st.round_ms;
        v[7] = static_cast<double>(st.round_tokens);
        v[8] = static_cast<double>(st.single_steps);
        v[9] = st.single_ms;
        v[10] = static_cast<double>(st.pauses);
    }
    env->SetDoubleArrayRegion(out, 0, 11, v);
    return out;
}

// v1.9.30: [prompt tokens processed, of those reused from the KV cache, oldest tokens cut to fit] for the last generation.
// All three are counted by this file's own prompt cache (llama.cpp has no prefix-hit counter): reused = tokens whose KV entries were kept
// and not decoded again. A generation that did not go through the text path reports zeros.
JNIEXPORT jintArray JNICALL
Java_com_example_llama_LlamaBridge_nativeLastPrompt(JNIEnv *env, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    jintArray out = env->NewIntArray(3);
    if (out == nullptr) return nullptr;
    const jint v[3] = {
        e == nullptr ? 0 : static_cast<jint>(e->last_prompt.load()),
        e == nullptr ? 0 : static_cast<jint>(e->last_cached.load()),
        e == nullptr ? 0 : static_cast<jint>(e->last_truncated.load())
    };
    env->SetIntArrayRegion(out, 0, 3, v);
    return out;
}

// v1.4: prompt tokens reused from the KV cache by the last generation.
JNIEXPORT jint JNICALL
Java_com_example_llama_LlamaBridge_nativeCachedTokens(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    return e == nullptr ? 0 : static_cast<jint>(e->last_cached.load());
}

// v1.4: drops the KV cache (next generation re-reads the whole prompt).
JNIEXPORT void JNICALL
Java_com_example_llama_LlamaBridge_nativeResetCache(JNIEnv *, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return;
    e->stop = true;
    std::lock_guard<std::mutex> g(e->lock);
    e->stop = false;
    llama_memory_clear(llama_get_memory(e->ctx), true);
    e->cache_tokens.clear();
    e->last_cached = 0;
    e->last_prompt = 0;
    e->last_truncated = 0;
}

JNIEXPORT jintArray JNICALL
Java_com_example_llama_LlamaBridge_nativeTokenize(JNIEnv *env, jobject, jlong handle, jstring text) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewIntArray(0);
    std::string s = jstr(env, text);
    int n = -llama_tokenize(e->vocab, s.c_str(), static_cast<int32_t>(s.size()), nullptr, 0, false, true);
    if (n <= 0) return env->NewIntArray(0);
    std::vector<llama_token> toks(static_cast<size_t>(n));
    int got = llama_tokenize(e->vocab, s.c_str(), static_cast<int32_t>(s.size()), toks.data(), n, false, true);
    if (got < 0) return env->NewIntArray(0);
    jintArray out = env->NewIntArray(got);
    env->SetIntArrayRegion(out, 0, got, reinterpret_cast<const jint *>(toks.data()));
    return out;
}

// Applies the model's own chat template. Returns null if it cannot be applied.
JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeApplyChatTemplate(JNIEnv *env, jobject, jlong handle,
                                                           jobjectArray roles, jobjectArray contents) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return nullptr;

    jsize n = env->GetArrayLength(roles);
    std::vector<std::string> role_s, content_s;
    for (jsize i = 0; i < n; ++i) {
        auto r = static_cast<jstring>(env->GetObjectArrayElement(roles, i));
        auto c = static_cast<jstring>(env->GetObjectArrayElement(contents, i));
        role_s.push_back(jstr(env, r));
        content_s.push_back(jstr(env, c));
        env->DeleteLocalRef(r);
        env->DeleteLocalRef(c);
    }
    std::vector<llama_chat_message> msgs(static_cast<size_t>(n));
    size_t total = 0;
    for (jsize i = 0; i < n; ++i) {
        msgs[i].role = role_s[i].c_str();
        msgs[i].content = content_s[i].c_str();
        total += content_s[i].size() + role_s[i].size();
    }

    const char *tmpl = llama_model_chat_template(e->model, nullptr);
    if (tmpl == nullptr) tmpl = "chatml";

    // Gemma 4 (<|turn>role ... <turn|>) is not in llama.cpp's built-in list; format it by hand
    // so it is not wrongly sent as ChatML (which makes the model echo <|im_end|> and never stop).
    if (std::strstr(tmpl, "<|turn>") != nullptr) {
        std::string g;
        for (jsize i = 0; i < n; ++i) {
            std::string role = role_s[i] == "assistant" ? "model" : role_s[i];
            g += "<|turn>" + role + "\n" + content_s[i] + "<turn|>\n";
        }
        g += "<|turn>model\n";
        return env->NewStringUTF(g.c_str());
    }

    std::vector<char> buf(total * 2 + 1024);
    int32_t len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(),
                                            static_cast<int32_t>(buf.size()));
    if (len > static_cast<int32_t>(buf.size())) {
        buf.resize(static_cast<size_t>(len) + 1);
        len = llama_chat_apply_template(tmpl, msgs.data(), msgs.size(), true, buf.data(),
                                        static_cast<int32_t>(buf.size()));
    }
    if (len < 0) {
        // Template not in llama.cpp's built-in list: fall back to ChatML.
        len = llama_chat_apply_template("chatml", msgs.data(), msgs.size(), true, buf.data(),
                                        static_cast<int32_t>(buf.size()));
        if (len > static_cast<int32_t>(buf.size())) {
            buf.resize(static_cast<size_t>(len) + 1);
            len = llama_chat_apply_template("chatml", msgs.data(), msgs.size(), true, buf.data(),
                                            static_cast<int32_t>(buf.size()));
        }
    }
    if (len < 0) return nullptr;
    std::string out(buf.data(), static_cast<size_t>(len));
    return env->NewStringUTF(out.c_str());
}

JNIEXPORT jstring JNICALL
Java_com_example_llama_LlamaBridge_nativeInfo(JNIEnv *env, jobject, jlong handle) {
    Engine *e = as_engine(handle);
    if (e == nullptr) return env->NewStringUTF("{}");
    char desc[256] = {0};
    llama_model_desc(e->model, desc, sizeof(desc));
    char out[640];
    std::snprintf(out, sizeof(out),
                  "{\"desc\":\"%s\",\"sizeBytes\":%llu,\"params\":%llu,\"nCtx\":%d,\"nCtxTrain\":%d,\"nVocab\":%d}",
                  desc, static_cast<unsigned long long>(llama_model_size(e->model)),
                  static_cast<unsigned long long>(llama_model_n_params(e->model)), e->n_ctx,
                  llama_model_n_ctx_train(e->model), llama_vocab_n_tokens(e->vocab));
    return env->NewStringUTF(out);
}

// Streams generated text to callback.onPiece(byte[]): boolean (false = stop).
// Returns number of generated tokens, or -1 on error (see nativeLastError).
JNIEXPORT jint JNICALL
Java_com_example_llama_LlamaBridge_nativeGenerate(JNIEnv *env, jobject, jlong handle, jstring prompt,
                                                  jint max_tokens, jfloat temp, jfloat top_p,
                                                  jint top_k, jfloat repeat_penalty,
                                                  jobject callback) {
    Engine *e = as_engine(handle);
    if (e == nullptr) {
        set_error("No model loaded.");
        return -1;
    }
    std::lock_guard<std::mutex> guard(e->lock);
    e->stop = false;

    jclass cb_cls = env->GetObjectClass(callback);
    jmethodID on_piece = env->GetMethodID(cb_cls, "onPiece", "([B)Z");
    jmethodID on_progress = env->GetMethodID(cb_cls, "onProgress", "(II)Z");
    if (on_piece == nullptr || on_progress == nullptr) {
        env->ExceptionClear();
        set_error("Callback is missing onPiece/onProgress");
        return -1;
    }

    std::string text = jstr(env, prompt);
    {
        // v1.7.3: images are consumed by exactly one generation.
        std::vector<std::string> images;
        images.swap(e->images);
        if (!images.empty()) {
            if (e->mtmd != nullptr) {
                return generate_with_images(env, e, text, images, max_tokens, temp, top_p, top_k, repeat_penalty, callback, on_piece, on_progress);
            }
            dbg("images ignored: no mmproj loaded");
        }
    }
    llama_memory_t mem = llama_get_memory(e->ctx);

    int n_tok = -llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), nullptr, 0, false, true);
    if (n_tok <= 0) {
        set_error("Prompt tokenization failed.");
        return -1;
    }
    std::vector<llama_token> tokens(static_cast<size_t>(n_tok));
    if (llama_tokenize(e->vocab, text.c_str(), static_cast<int32_t>(text.size()), tokens.data(), n_tok, false, true) < 0) {
        set_error("Prompt tokenization failed.");
        return -1;
    }

    // Keep the newest tokens if the prompt does not fit; reserve room to answer.
    int reserve = std::max(32, std::min(static_cast<int>(max_tokens), e->n_ctx / 2));
    int max_prompt = e->n_ctx - reserve;
    if (max_prompt < 8) max_prompt = std::max(1, e->n_ctx - 8);
    int truncated = 0;
    if (static_cast<int>(tokens.size()) > max_prompt) {
        LOGI("Prompt truncated from %zu to %d tokens", tokens.size(), max_prompt);
        truncated = static_cast<int>(tokens.size()) - max_prompt;
        tokens.erase(tokens.begin(), tokens.end() - max_prompt);
    }

    // v1.4 prompt cache: keep the KV entries of the longest common prefix with the previous turn and
    // decode only the new tail. If the cache bookkeeping and the memory disagree (an aborted decode), or a
    // partial removal is not supported (recurrent / SWA memory), fall back to a clean cache.
    {
        const llama_pos pos_max = llama_memory_seq_pos_max(mem, 0);
        if (static_cast<long>(pos_max) + 1 != static_cast<long>(e->cache_tokens.size())) {
            llama_memory_clear(mem, true);
            e->cache_tokens.clear();
        }
    }
    size_t n_keep = 0;
    while (n_keep < e->cache_tokens.size() && n_keep < tokens.size() && e->cache_tokens[n_keep] == tokens[n_keep]) ++n_keep;
    // Always decode at least one prompt token so the sampler has fresh logits.
    if (n_keep >= tokens.size()) n_keep = tokens.size() - 1;
    if (n_keep < e->cache_tokens.size()) {
        if (!llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(n_keep), -1)) {
            llama_memory_clear(mem, true);
            n_keep = 0;
            e->cache_tokens.clear();
        } else {
            e->cache_tokens.resize(n_keep);
        }
    }
    e->last_cached = static_cast<int>(n_keep);
    e->last_prompt = static_cast<int>(tokens.size());
    e->last_truncated = truncated;

    dbg("generate: prompt=%zu tokens, cached=%zu", tokens.size(), n_keep);

    // Sampler chain.
    llama_sampler_chain_params sparams = llama_sampler_chain_default_params();
    llama_sampler *smpl = llama_sampler_chain_init(sparams);
    if (repeat_penalty > 1.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_penalties(llama_vocab_n_tokens(e->vocab), 256, repeat_penalty, 0.0f, 0.1f));
    }
    if (temp <= 0.0f) {
        llama_sampler_chain_add(smpl, llama_sampler_init_greedy());
    } else {
        if (top_k > 0) llama_sampler_chain_add(smpl, llama_sampler_init_top_k(top_k));
        if (top_p > 0.0f && top_p < 1.0f) llama_sampler_chain_add(smpl, llama_sampler_init_top_p(top_p, 1));
        llama_sampler_chain_add(smpl, llama_sampler_init_temp(temp));
        llama_sampler_chain_add(smpl, llama_sampler_init_dist(LLAMA_DEFAULT_SEED));
    }

    int generated = 0;
    int result = 0;
    int n_past = static_cast<int>(n_keep);

    // Decode the new part of the prompt in batches.
    size_t pos = n_keep;
    while (pos < tokens.size()) {
        if (e->stop) goto done;
        // A model that fits in RAM keeps the small chunks (steady progress, quick Stop). A streaming model takes a
        // full batch: each decode call re-reads the experts it needs from storage.
        int chunk = vibe::prompt_chunk(e->streaming, e->n_batch, tokens.size() - pos);
        llama_batch batch = llama_batch_get_one(tokens.data() + pos, chunk);
        dbg("decode start pos=%zu chunk=%d", pos, chunk);
        if (llama_decode(e->ctx, batch) != 0) {
            if (e->stop) goto done;
            set_error("llama_decode failed while processing the prompt.");
            result = -1;
            goto done;
        }
        e->cache_tokens.insert(e->cache_tokens.end(), tokens.begin() + static_cast<long>(pos), tokens.begin() + static_cast<long>(pos) + chunk);
        pos += static_cast<size_t>(chunk);
        n_past += chunk;
        dbg("decode done pos=%zu", pos);
        {
            jboolean go = env->CallBooleanMethod(callback, on_progress, static_cast<jint>(pos),
                                                 static_cast<jint>(tokens.size()));
            if (env->ExceptionCheck()) {
                env->ExceptionClear();
                goto done;
            }
            if (!go) goto done;
        }
    }

    {
        std::string pending;
        char piece[256];
        const int limit = std::min(static_cast<int>(max_tokens), e->n_ctx - n_past);
        bool keep_going = true;

        // Hands one sampled token to the app as text. False = stop (the app returned false or threw).
        auto emit = [&](llama_token t) -> bool {
            int plen = llama_token_to_piece(e->vocab, t, piece, sizeof(piece), 0, false);
            if (plen > 0) pending.append(piece, static_cast<size_t>(plen));
            ++generated;

            size_t ready = utf8_complete_prefix(pending);
            if (ready > 0) {
                jbyteArray bytes = to_jbytes(env, pending.substr(0, ready));
                pending.erase(0, ready);
                jboolean cont = env->CallBooleanMethod(callback, on_piece, bytes);
                env->DeleteLocalRef(bytes);
                if (env->ExceptionCheck()) {
                    env->ExceptionClear();
                    keep_going = false;
                } else if (!cont) {
                    keep_going = false;
                }
            }
            return keep_going;
        };

        // v1.9.31: prompt-lookup decoding. Experimental and off unless the user turned it on; never for a streaming MoE load or a
        // memory that cannot drop its newest tokens. Everything below the `if` is the plain loop that was always here.
        const bool want_lookup = e->lookup_on.load() && !e->lookup_broken.load();
        const bool use_lookup = want_lookup && e->lookup_block == vibe::kLookupOk;
        vibe::LookupStats stats;
        stats.block = e->lookup_block;
        stats.active = use_lookup;
        auto publish_stats = [&]() {
            std::lock_guard<std::mutex> g(e->lookup_lock);
            e->lookup_stats = stats;
        };

        if (use_lookup) {
            const vibe::LookupConfig lcfg;
            vibe::LookupGate gate;
            // Tokens in the KV cache plus the token about to be decoded: the text the guesses are looked up in.
            std::vector<llama_token> hist = e->cache_tokens;
            hist.reserve(static_cast<size_t>(e->n_ctx));
            bool have_next = false;
            llama_token next_tok = 0;
            auto is_eog = [&](int32_t t) { return llama_vocab_is_eog(e->vocab, static_cast<llama_token>(t)); };
            auto now_ms = []() {
                return std::chrono::duration<double, std::milli>(std::chrono::steady_clock::now().time_since_epoch()).count();
            };

            while (keep_going && generated < limit && !e->stop) {
                llama_token tok;
                if (have_next) {
                    tok = next_tok;
                    have_next = false;
                } else {
                    tok = llama_sampler_sample(smpl, e->ctx, -1);
                }
                if (llama_vocab_is_eog(e->vocab, tok)) break;
                if (!emit(tok)) break;
                hist.push_back(tok);

                // Guess what follows, never more than the tokens still allowed and never past the context.
                std::vector<int32_t> draft;
                const int room = std::min(limit - generated, e->n_ctx - n_past - 1);
                if (gate.allow() && room > 0) draft = vibe::lookup_draft(hist, lcfg, room, is_eog);

                if (draft.empty()) {
                    const double t0 = now_ms();
                    llama_batch next = llama_batch_get_one(&tok, 1);
                    if (llama_decode(e->ctx, next) != 0) {
                        if (e->stop) break;
                        set_error("llama_decode failed during generation.");
                        result = -1;
                        break;
                    }
                    const double ms = now_ms() - t0;
                    e->cache_tokens.push_back(tok);
                    ++n_past;
                    gate.on_single(ms);
                    ++stats.single_steps;
                    stats.single_ms += ms;
                    continue;
                }

                // One batched decode of [tok, guesses...] with logits for every row. Positions and sequence are tracked by
                // llama_decode itself (the same as llama_batch_get_one).
                std::vector<llama_token> toks;
                toks.reserve(draft.size() + 1);
                toks.push_back(tok);
                toks.insert(toks.end(), draft.begin(), draft.end());
                std::vector<int8_t> want_logits(toks.size(), 1);
                llama_batch vb = {};
                vb.n_tokens = static_cast<int32_t>(toks.size());
                vb.token = toks.data();
                vb.logits = want_logits.data();

                const double t0 = now_ms();
                if (llama_decode(e->ctx, vb) != 0) {
                    // Whatever part of the batch reached the cache must not stay: cache_tokens does not include it.
                    if (!llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(n_past), -1)) {
                        llama_memory_clear(mem, true);
                        e->cache_tokens.clear();
                    }
                    if (e->stop) break;
                    set_error("llama_decode failed during generation.");
                    result = -1;
                    break;
                }
                const double ms = now_ms() - t0;

                // Row j holds the logits for the position after toks[j]. Sample row by row; a guess stays only while the sampler
                // itself picks the same token (llama_sampler_sample also records each pick in the sampler, as plain decoding does).
                const vibe::VerifyResult vr = vibe::verify_draft(draft, [&](int j) { return static_cast<int32_t>(llama_sampler_sample(smpl, e->ctx, j)); });

                int kept = 1;  // tok itself stays in the cache
                for (int j = 0; j < vr.accepted; ++j) {
                    ++kept;
                    hist.push_back(draft[static_cast<size_t>(j)]);
                    if (!emit(draft[static_cast<size_t>(j)])) break;
                }
                // Cache and memory must agree: keep tok + the confirmed guesses, drop the rest.
                e->cache_tokens.push_back(tok);
                for (int j = 0; j + 1 < kept; ++j) e->cache_tokens.push_back(draft[static_cast<size_t>(j)]);
                n_past += kept;
                if (kept < static_cast<int>(toks.size())) {
                    if (!llama_memory_seq_rm(mem, 0, static_cast<llama_pos>(n_past), -1)) {
                        // Not expected (the load was checked for this). Do not continue on a cache that holds tokens that were never accepted.
                        llama_memory_clear(mem, true);
                        e->cache_tokens.clear();
                        e->lookup_broken.store(true);
                        set_error("KV rollback failed; lookup decoding is turned off until the model is reloaded.");
                        result = -1;
                        break;
                    }
                }
                const int confirmed = 1 + vr.accepted;  // tokens advanced by this decode (a plain step advances 1)
                gate.on_round(ms, confirmed);
                ++stats.rounds;
                stats.drafted += static_cast<long>(draft.size());
                stats.accepted += vr.accepted;
                stats.round_ms += ms;
                stats.round_tokens += confirmed;
                next_tok = static_cast<llama_token>(vr.next);
                have_next = true;
            }
            stats.pauses = gate.pauses();
        } else {
            while (keep_going && generated < limit && !e->stop) {
                llama_token tok = llama_sampler_sample(smpl, e->ctx, -1);
                if (llama_vocab_is_eog(e->vocab, tok)) break;
                if (!emit(tok)) break;

                llama_batch next = llama_batch_get_one(&tok, 1);
                if (llama_decode(e->ctx, next) != 0) {
                    if (e->stop) break;
                    set_error("llama_decode failed during generation.");
                    result = -1;
                    break;
                }
                e->cache_tokens.push_back(tok);
                ++n_past;
            }
        }
        publish_stats();
    }

done:
    llama_sampler_free(smpl);
    return result < 0 ? -1 : generated;
}

}  // extern "C"
