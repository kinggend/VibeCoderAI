// v1.9.34: finds the memory mapping of the loaded model file in /proc/self/maps and sets the kernel's read-ahead hint on it.
//
// Why: a model that streams its experts from storage touches them through a memory mapping. On the phone this was measured with the
// Speed test: ~585 MB/s read from storage, 130 GB read for a 128-token prompt plus 7 generated tokens, at least ~15.9 GB per generated
// token, while the experts one token needs are about 1.1 to 1.3 GB (architecture estimate). With the kernel's default every page fault
// reads a window around the page (3 MB per major fault on average there), and most of it is never used before it is dropped.
// MADV_RANDOM tells the kernel not to read around a fault. Whether that is faster on a phone is NOT known: it makes the reads smaller
// but more numerous. It is an experiment, off by default, measured by the Speed test (MB read per generated token and seconds per token).
//
// Pure text parsing plus one madvise call, so it is unit tested on a host (scratchpad/h37/advice_test.cpp).
#pragma once

#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

#include <sys/mman.h>

namespace vibe {

struct MapRegion {
    uintptr_t start = 0;
    uintptr_t end = 0;
};

enum ReadAdvice : int { kAdviceDefault = 0, kAdviceRandom = 1 };

inline std::string path_base(const std::string &p) {
    const size_t i = p.find_last_of('/');
    return i == std::string::npos ? p : p.substr(i + 1);
}

inline bool all_digits(const std::string &s, size_t pos, size_t n) {
    if (s.size() < pos + n) return false;
    for (size_t i = pos; i < pos + n; ++i) {
        if (s[i] < '0' || s[i] > '9') return false;
    }
    return true;
}

// "name.gguf" and "name-00001-of-00003.gguf" both give "name": the stem shared by every shard of one model.
inline std::string model_stem(std::string base) {
    const std::string ext = ".gguf";
    if (base.size() >= ext.size() && base.compare(base.size() - ext.size(), ext.size(), ext) == 0) base.resize(base.size() - ext.size());
    const size_t n = base.size();
    if (n >= 15) {  // "-00001-of-00003"
        const std::string tail = base.substr(n - 15);
        if (tail[0] == '-' && all_digits(tail, 1, 5) && tail.compare(6, 4, "-of-") == 0 && all_digits(tail, 10, 5)) base.resize(n - 15);
    }
    return base;
}

// One line of /proc/self/maps: "start-end perms offset dev inode   path". Returns false for a line that does not parse.
inline bool parse_maps_line(const std::string &line, MapRegion *region, std::string *path) {
    unsigned long long a = 0, b = 0, off = 0, inode = 0;
    char perms[8] = {0};
    char dev[32] = {0};
    int consumed = 0;
    const int got = std::sscanf(line.c_str(), "%llx-%llx %7s %llx %31s %llu %n", &a, &b, perms, &off, dev, &inode, &consumed);
    if (got < 6 || b <= a) return false;
    region->start = static_cast<uintptr_t>(a);
    region->end = static_cast<uintptr_t>(b);
    std::string p = consumed > 0 && static_cast<size_t>(consumed) <= line.size() ? line.substr(static_cast<size_t>(consumed)) : std::string();
    while (!p.empty() && (p.back() == '\n' || p.back() == '\r' || p.back() == ' ')) p.pop_back();
    const std::string deleted = " (deleted)";
    if (p.size() >= deleted.size() && p.compare(p.size() - deleted.size(), deleted.size(), deleted) == 0) p.resize(p.size() - deleted.size());
    *path = p;
    return true;
}

// Every mapping in `maps_text` whose file is the model (or another shard of it). Compared by file name, because the kernel prints
// the resolved path (/data/data/... for /data/user/0/...), which can differ from the path the app used to open it.
inline std::vector<MapRegion> regions_of_model(const std::string &maps_text, const std::string &model_path) {
    std::vector<MapRegion> out;
    const std::string stem = model_stem(path_base(model_path));
    if (stem.empty()) return out;
    size_t pos = 0;
    while (pos < maps_text.size()) {
        size_t nl = maps_text.find('\n', pos);
        if (nl == std::string::npos) nl = maps_text.size();
        const std::string line = maps_text.substr(pos, nl - pos);
        pos = nl + 1;
        MapRegion r;
        std::string path;
        if (!parse_maps_line(line, &r, &path) || path.empty()) continue;
        const std::string base = path_base(path);
        if (base.size() < 5 || base.compare(base.size() - 5, 5, ".gguf") != 0) continue;
        if (model_stem(base) == stem) out.push_back(r);
    }
    return out;
}

inline std::string read_text_file(const char *path) {
    std::string out;
    FILE *f = std::fopen(path, "r");
    if (f == nullptr) return out;
    char buf[4096];
    size_t n;
    while ((n = std::fread(buf, 1, sizeof(buf), f)) > 0) out.append(buf, n);
    std::fclose(f);
    return out;
}

// Applies the hint to every region. Returns the number of bytes the kernel accepted it for, or -1 when no region accepted it.
inline long long advise_regions(const std::vector<MapRegion> &regions, int advice) {
    long long total = 0;
    bool any = false;
    const int flag = advice == kAdviceRandom ? MADV_RANDOM : MADV_NORMAL;
    for (const auto &r : regions) {
        if (r.end <= r.start) continue;
        if (madvise(reinterpret_cast<void *>(r.start), static_cast<size_t>(r.end - r.start), flag) == 0) {
            total += static_cast<long long>(r.end - r.start);
            any = true;
        }
    }
    return any ? total : -1;
}

}  // namespace vibe
