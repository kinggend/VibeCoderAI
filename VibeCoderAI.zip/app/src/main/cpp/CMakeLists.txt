cmake_minimum_required(VERSION 3.22.1)

project("llama-android" LANGUAGES C CXX)

set(CMAKE_C_STANDARD 11)
set(CMAKE_C_STANDARD_REQUIRED ON)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_POSITION_INDEPENDENT_CODE ON)

# llama.cpp source is cloned into ./llama.cpp (see .github/workflows/build.yml).
set(LLAMA_DIR ${CMAKE_CURRENT_LIST_DIR}/llama.cpp)
if(NOT EXISTS ${LLAMA_DIR}/CMakeLists.txt)
    message(FATAL_ERROR "llama.cpp sources not found at ${LLAMA_DIR}. Clone them first:\n"
        "  git clone --depth 1 --branch b12020 https://github.com/ggml-org/llama.cpp ${LLAMA_DIR}")
endif()

# Inference must be fast even in debug builds: always optimise native code.
set(CMAKE_BUILD_TYPE Release CACHE STRING "" FORCE)
set(CMAKE_C_FLAGS_RELEASE   "-O3 -DNDEBUG" CACHE STRING "" FORCE)
set(CMAKE_CXX_FLAGS_RELEASE "-O3 -DNDEBUG" CACHE STRING "" FORCE)
set(CMAKE_C_FLAGS_DEBUG   "-O3 -DNDEBUG" CACHE STRING "" FORCE)
set(CMAKE_CXX_FLAGS_DEBUG "-O3 -DNDEBUG" CACHE STRING "" FORCE)

# Build only the core library: no tools, tests, examples, server, curl/openssl.
set(BUILD_SHARED_LIBS OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_COMMON   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TESTS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_TOOLS    OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_EXAMPLES OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_SERVER   OFF CACHE BOOL "" FORCE)
set(LLAMA_BUILD_APP      OFF CACHE BOOL "" FORCE)
set(LLAMA_OPENSSL        OFF CACHE BOOL "" FORCE)
set(GGML_OPENMP          OFF CACHE BOOL "" FORCE)
set(GGML_NATIVE          OFF CACHE BOOL "" FORCE)

if(ANDROID_ABI STREQUAL "arm64-v8a")
    # ARMv8.2 + dot-product: ~2-3x faster quantised matmul on phones from 2019 onwards.
    set(GGML_CPU_ARM_ARCH "armv8.2-a+dotprod" CACHE STRING "" FORCE)
endif()

# v1.4: optional GPU offload through ggml's Vulkan backend (off by default; Gradle passes
# -DVIBE_VULKAN=ON when built with -PvibeVulkan=true). The NDK ships the Vulkan C headers, libvulkan and
# glslc (shader-tools/<host>/glslc); vulkan.hpp and SPIRV-Headers are not in the NDK, so the Vulkan CI job
# clones Khronos Vulkan-Headers / SPIRV-Headers and passes their locations (see build-apk.yml).
option(VIBE_VULKAN "Build the ggml Vulkan backend for GPU offload" OFF)
set(VIBE_VULKAN_HEADERS "$ENV{VIBE_VULKAN_HEADERS}" CACHE PATH "Khronos Vulkan-Headers checkout (has include/vulkan/vulkan.hpp)")
set(VIBE_SPIRV_HEADERS_DIR "$ENV{VIBE_SPIRV_HEADERS_DIR}" CACHE PATH "Directory containing SPIRV-HeadersConfig.cmake")
if(VIBE_VULKAN)
    message(STATUS "VibeCoder: Vulkan GPU backend ON")
    set(GGML_VULKAN ON CACHE BOOL "" FORCE)
    if(NOT Vulkan_GLSLC_EXECUTABLE)
        file(GLOB _vibe_glslc "${ANDROID_NDK}/shader-tools/*/glslc")
        if(_vibe_glslc)
            list(GET _vibe_glslc 0 _vibe_glslc0)
            set(Vulkan_GLSLC_EXECUTABLE "${_vibe_glslc0}" CACHE FILEPATH "glslc from the NDK" FORCE)
            message(STATUS "VibeCoder: glslc = ${_vibe_glslc0}")
        endif()
    endif()
    if(VIBE_VULKAN_HEADERS AND EXISTS "${VIBE_VULKAN_HEADERS}/include/vulkan/vulkan.hpp")
        # Put the Khronos headers first so vulkan.hpp and vulkan_core.h come from the same version.
        include_directories(BEFORE SYSTEM "${VIBE_VULKAN_HEADERS}/include")
    else()
        message(WARNING "VibeCoder: VIBE_VULKAN_HEADERS not set; the NDK has no vulkan.hpp, the Vulkan build will likely fail.")
    endif()
    if(VIBE_SPIRV_HEADERS_DIR)
        set(SPIRV-Headers_DIR "${VIBE_SPIRV_HEADERS_DIR}" CACHE PATH "" FORCE)
    endif()
else()
    set(GGML_VULKAN OFF CACHE BOOL "" FORCE)
endif()

# v1.7.3: libmtmd (image input for vision models, e.g. Qwen3-VL). Library only: no CLI tools, no video/ffmpeg.
set(LLAMA_BUILD_MTMD ON CACHE BOOL "" FORCE)
set(LLAMA_SUBPROCESS OFF CACHE BOOL "" FORCE)
set(MTMD_VIDEO       OFF CACHE BOOL "" FORCE)

add_subdirectory(${LLAMA_DIR} build-llama EXCLUDE_FROM_ALL)

add_library(llama-android SHARED llama_jni.cpp)

target_include_directories(llama-android PRIVATE
    ${LLAMA_DIR}/include
    ${LLAMA_DIR}/ggml/include
    ${LLAMA_DIR}/tools/mtmd)

find_library(log-lib log)
target_link_libraries(llama-android PRIVATE llama mtmd ${log-lib})

# Android 15+ devices use 16 KB pages.
target_link_options(llama-android PRIVATE -Wl,-z,max-page-size=16384)
