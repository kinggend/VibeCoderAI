// v1.9.29: pure helpers for the detailed Speed test (no dependencies, unit tested on the host).
#pragma once

#include <algorithm>
#include <cmath>
#include <cstddef>
#include <vector>

namespace vibe {

// Nearest-rank percentile of per-step latencies (p in 0..100). Empty input gives 0.
inline double percentile(std::vector<double> v, double p) {
    if (v.empty()) return 0.0;
    std::sort(v.begin(), v.end());
    if (p <= 0.0) return v.front();
    if (p >= 100.0) return v.back();
    const double rank = std::ceil(p / 100.0 * static_cast<double>(v.size()));
    const size_t idx = static_cast<size_t>(std::max(1.0, rank)) - 1;
    return v[std::min(idx, v.size() - 1)];
}

inline double sum(const std::vector<double> &v) {
    double s = 0.0;
    for (double x : v) s += x;
    return s;
}

// Tokens per second for `tokens` produced in `ms` milliseconds; 0 when nothing was measured.
inline double tokens_per_second(size_t tokens, double ms) {
    return (tokens == 0 || ms <= 0.0) ? 0.0 : static_cast<double>(tokens) * 1000.0 / ms;
}

// Generation speed from per-step decode latencies. The first generated token comes from the prompt's own
// logits (no decode call), so n generated tokens have n-1 measured steps.
inline double decode_tokens_per_second(const std::vector<double> &step_ms) {
    return tokens_per_second(step_ms.size(), sum(step_ms));
}

}  // namespace vibe
