// v1.9.38: what the phone's storage can do on the model file itself, measured with plain reads, no llama.cpp involved.
//
// Why: a 30B mixture-of-experts model that streams from storage read about 16 GB per generated token on one phone, and the speed then
// depends on how the storage answers many small reads versus fewer large ones. A test with the kernel's read-ahead switched off made
// reads 4 KB each and the model finished no token in 2554 s, so what matters is the cost per read, not only MB/s. This probe reports
// reads per second for 4 KB and MB/s for 1 MB reads, with 1 and with 8 threads (queue depth), at random positions in the file.
//
// The reads bypass the page cache (O_DIRECT) when the file system allows it; otherwise the cache is dropped for the file first and the
// text says the cache was not bypassed, because a cached read measures RAM. Nothing here writes, and the model is not touched.
#pragma once

#include <fcntl.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <atomic>
#include <cerrno>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <thread>
#include <vector>

#ifndef O_DIRECT
#define O_DIRECT 0
#endif
#ifndef O_CLOEXEC
#define O_CLOEXEC 0
#endif

namespace vibe {

struct ProbeReads {
    long long reads = 0;
    long long bytes = 0;
    double secs = 0.0;
    bool failed = false;
    int err = 0;
};

inline uint64_t probe_next(uint64_t &s) {  // xorshift64: a cheap, deterministic position generator
    s ^= s << 13;
    s ^= s >> 7;
    s ^= s << 17;
    return s;
}

/** Positions are 4 KB aligned and every read of [len] bytes lies inside the file. Returns -1 when the file is too small for [len]. */
inline long long probe_slots(long long file_size, size_t len) {
    if (len == 0 || file_size < static_cast<long long>(len) + 4096) return -1;
    return (file_size - static_cast<long long>(len)) / 4096;
}

/** Random reads of [len] bytes for about [seconds] with [threads] threads. The last read of each thread may end a little after the time. */
inline ProbeReads probe_reads(int fd, long long file_size, size_t len, int threads, double seconds, uint64_t seed) {
    ProbeReads total;
    const long long slots = probe_slots(file_size, len);
    if (slots < 1 || threads < 1 || threads > 64 || seconds <= 0.0) {
        total.failed = true;
        total.err = EINVAL;
        return total;
    }
    using clock = std::chrono::steady_clock;
    std::vector<ProbeReads> per(static_cast<size_t>(threads));
    std::vector<std::thread> pool;
    const auto t0 = clock::now();
    const auto end = t0 + std::chrono::milliseconds(static_cast<long long>(seconds * 1000.0));
    for (int t = 0; t < threads; ++t) {
        pool.emplace_back([&, t]() {
            ProbeReads &r = per[static_cast<size_t>(t)];
            void *buf = nullptr;
            if (posix_memalign(&buf, 4096, len) != 0) {
                r.failed = true;
                r.err = ENOMEM;
                return;
            }
            uint64_t s = seed + 0x9E3779B97F4A7C15ULL * static_cast<uint64_t>(t + 1);
            if (s == 0) s = 1;
            while (clock::now() < end) {
                const long long off = static_cast<long long>(probe_next(s) % static_cast<uint64_t>(slots)) * 4096LL;
                const ssize_t got = pread(fd, buf, len, static_cast<off_t>(off));
                if (got <= 0) {
                    r.failed = true;
                    r.err = got < 0 ? errno : EIO;
                    break;
                }
                ++r.reads;
                r.bytes += got;
            }
            free(buf);
        });
    }
    for (auto &th : pool) th.join();
    total.secs = std::chrono::duration<double>(clock::now() - t0).count();
    for (const auto &r : per) {
        total.reads += r.reads;
        total.bytes += r.bytes;
        if (r.failed) {
            total.failed = true;
            total.err = r.err;
        }
    }
    return total;
}

inline double probe_per_sec(long long n, double secs) { return secs > 0.0 ? static_cast<double>(n) / secs : 0.0; }
inline double probe_mb_per_sec(long long bytes, double secs) { return secs > 0.0 ? static_cast<double>(bytes) / 1048576.0 / secs : 0.0; }

/** One report (several lines) for the file at [path]; each of the four tests runs for budget/4 seconds (1 to 5). Never throws. */
inline std::string storage_probe_text(const std::string &path, int budget_sec) {
    if (path.empty()) return "Storage probe: no model file.";
    const double each = static_cast<double>(std::max(1, std::min(5, budget_sec / 4)));
    int fd = open(path.c_str(), O_RDONLY | O_CLOEXEC | O_DIRECT);
    bool bypass = O_DIRECT != 0 && fd >= 0;
    if (bypass) {
        // Some file systems accept O_DIRECT on open and refuse it at the first read.
        void *buf = nullptr;
        if (posix_memalign(&buf, 4096, 4096) == 0) {
            if (pread(fd, buf, 4096, 0) < 0) {
                close(fd);
                fd = -1;
                bypass = false;
            }
            free(buf);
        }
    }
    if (fd < 0) {
        fd = open(path.c_str(), O_RDONLY | O_CLOEXEC);
        bypass = false;
    }
    if (fd < 0) {
        char b[160];
        std::snprintf(b, sizeof(b), "Storage probe: the model file could not be opened (error %d).", errno);
        return b;
    }
    struct stat st {};
    if (fstat(fd, &st) != 0 || st.st_size < (64LL << 20)) {
        close(fd);
        return "Storage probe: the model file is smaller than 64 MB, nothing to probe.";
    }
    if (!bypass) posix_fadvise(fd, 0, 0, POSIX_FADV_DONTNEED);
    const long long size = static_cast<long long>(st.st_size);
    const ProbeReads a1 = probe_reads(fd, size, 4096, 1, each, 1);
    const ProbeReads a8 = probe_reads(fd, size, 4096, 8, each, 2);
    const ProbeReads b1 = probe_reads(fd, size, 1u << 20, 1, each, 3);
    const ProbeReads b8 = probe_reads(fd, size, 1u << 20, 8, each, 4);
    close(fd);
    if (a1.failed || a8.failed || b1.failed || b8.failed) {
        const int err = a1.failed ? a1.err : a8.failed ? a8.err : b1.failed ? b1.err : b8.err;
        char b[200];
        std::snprintf(b, sizeof(b), "Storage probe: a read failed (error %d), no numbers.", err);
        return b;
    }
    char out[640];
    std::snprintf(out, sizeof(out),
                  "Storage probe (random reads on the model file, %s, %.0f s each):\n"
                  "  4 KB reads: 1 thread %.0f reads/s (%.1f MB/s), 8 threads %.0f reads/s (%.1f MB/s)\n"
                  "  1 MB reads: 1 thread %.0f MB/s, 8 threads %.0f MB/s",
                  bypass ? "page cache bypassed" : "page cache NOT bypassed, some reads may come from RAM", each,
                  probe_per_sec(a1.reads, a1.secs), probe_mb_per_sec(a1.bytes, a1.secs),
                  probe_per_sec(a8.reads, a8.secs), probe_mb_per_sec(a8.bytes, a8.secs),
                  probe_mb_per_sec(b1.bytes, b1.secs), probe_mb_per_sec(b8.bytes, b8.secs));
    return out;
}

}  // namespace vibe
