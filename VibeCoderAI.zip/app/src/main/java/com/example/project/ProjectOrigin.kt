package com.example.project

import java.io.File
import java.net.URI
import java.net.URLDecoder
import java.security.MessageDigest

/**
 * v1.9.14: every project previews on its own web origin, https://p<hash>.vibecoder.test/, which the app answers itself
 * (ProjectWebGuard.Client.shouldInterceptRequest). With file:// every project shared one origin, so a page generated for
 * project A could read project B's localStorage. Now storage is per project, the page is a secure context (fetch of its own
 * files and `type="module"` scripts work), and the preview needs no file:// access at all.
 * Pure Kotlin (no Android classes), unit-tested.
 */
object ProjectOrigin {
  const val DOMAIN = "vibecoder.test"

  sealed class Target {
    class Ok(val file: File) : Target()
    object Forbidden : Target()
    object NotFound : Target()
  }

  /** Stable host name for a project folder: the same project always gets the same origin, so saved game data survives restarts. */
  fun host(root: File): String {
    val path = runCatching { root.canonicalPath }.getOrDefault(root.absolutePath)
    val d = MessageDigest.getInstance("SHA-256").digest(path.toByteArray(Charsets.UTF_8))
    return "p" + d.take(6).joinToString("") { "%02x".format(it) } + "." + DOMAIN
  }

  fun url(root: File, rel: String = "index.html"): String = "https://${host(root)}/${rel.trimStart('/')}"

  fun owns(root: File, url: String): Boolean {
    val u = runCatching { URI(url.trim()) }.getOrNull() ?: return false
    return u.scheme.equals("https", ignoreCase = true) && u.host.equals(host(root), ignoreCase = true)
  }

  /** Which file of [root] a request for [url] means. Dot folders (.vibecoder backups, .history, .git) and anything outside the project are Forbidden. */
  fun resolve(root: File, url: String): Target {
    val raw = runCatching { URI(url.trim()).rawPath }.getOrNull() ?: return Target.Forbidden
    val path = runCatching { URLDecoder.decode((raw ?: "").replace("+", "%2B"), "UTF-8") }.getOrNull() ?: return Target.Forbidden
    if (path.contains('\u0000') || path.contains('\\')) return Target.Forbidden
    val parts = path.split('/').filter { it.isNotEmpty() }
    if (parts.any { it == ".." || it == "." || it.startsWith(".") }) return Target.Forbidden
    var f = if (parts.isEmpty()) root else File(root, parts.joinToString("/"))
    if (!FileOps.inside(root, f)) return Target.Forbidden
    if (f.isDirectory) f = File(f, "index.html")
    if (!f.isFile) return Target.NotFound
    // A symlink inside the project must not lead out of it.
    return if (FileOps.inside(root, f)) Target.Ok(f) else Target.Forbidden
  }

  fun mime(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
    "html", "htm" -> "text/html"
    "css" -> "text/css"
    "js", "mjs" -> "text/javascript"
    "json", "map" -> "application/json"
    "svg" -> "image/svg+xml"
    "png" -> "image/png"
    "jpg", "jpeg" -> "image/jpeg"
    "gif" -> "image/gif"
    "webp" -> "image/webp"
    "ico" -> "image/x-icon"
    "woff" -> "font/woff"
    "woff2" -> "font/woff2"
    "ttf" -> "font/ttf"
    "otf" -> "font/otf"
    "txt", "md" -> "text/plain"
    "xml" -> "application/xml"
    "wasm" -> "application/wasm"
    "mp3" -> "audio/mpeg"
    "wav" -> "audio/wav"
    "ogg" -> "audio/ogg"
    "mp4" -> "video/mp4"
    "webm" -> "video/webm"
    else -> "application/octet-stream"
  }

  /** Text types are sent as UTF-8; binary types carry no charset. */
  fun isText(mime: String): Boolean = mime.startsWith("text/") || mime in setOf("application/json", "application/xml", "image/svg+xml")
}
