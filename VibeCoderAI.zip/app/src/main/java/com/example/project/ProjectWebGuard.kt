package com.example.project

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

/**
 * v1.6 security: WebViews that run project code (Preview, headless check) may read only that project's
 * files. Generated code can no longer read the app's private files (settings, chats, other projects)
 * through file:// URLs, and no JavaScript bridge is exposed.
 */
object ProjectWebGuard {
  /** Pure rule (unit tested): a file:// URL is allowed only when it resolves inside [root]. Other schemes are not files. */
  fun isAllowedFileUrl(root: File, url: String): Boolean {
    if (!url.startsWith("file:", ignoreCase = true)) return true
    val path = runCatching { java.net.URI(url.substringBefore('#').substringBefore('?')).path }.getOrNull() ?: return false
    if (path.isEmpty()) return false
    return FileOps.inside(root, File(path))
  }

  /** [fileAccess] = false for pages served from the project's own origin (ProjectOrigin): they need no file:// access at all. */
  fun harden(settings: WebSettings, fileAccess: Boolean = true) {
    settings.allowFileAccess = fileAccess
    settings.allowContentAccess = false
    @Suppress("DEPRECATION") settings.allowFileAccessFromFileURLs = false
    @Suppress("DEPRECATION") settings.allowUniversalAccessFromFileURLs = false
    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    settings.setGeolocationEnabled(false)
    settings.javaScriptCanOpenWindowsAutomatically = false
    settings.setSupportMultipleWindows(false)
  }

  /** Client that blocks file loads outside [root] and keeps navigation inside the project. */
  open class Client(
    private val root: File,
    private val onBlocked: (String) -> Unit = {},
    private val onRenderGone: (crashed: Boolean) -> Unit = {}
  ) : WebViewClient() {
    /**
     * v1.9.8: without this override Android kills the WHOLE APP when the WebView's renderer process dies (out of memory or a crashing page),
     * which looked like "Preview sends me to the home screen". Returning true keeps the app alive; the screen shows a reload button.
     */
    @android.annotation.TargetApi(26)
    override fun onRenderProcessGone(view: WebView?, detail: android.webkit.RenderProcessGoneDetail?): Boolean {
      onRenderGone(detail?.didCrash() ?: false)
      return true
    }

    private fun empty(code: Int, reason: String) =
      WebResourceResponse("text/plain", "utf-8", code, reason, emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))

    /** Answers a request for the project's own origin from its folder. */
    private fun serve(url: String): WebResourceResponse = when (val t = ProjectOrigin.resolve(root, url)) {
      is ProjectOrigin.Target.Ok -> {
        val mime = ProjectOrigin.mime(t.file.name)
        WebResourceResponse(
          mime, if (ProjectOrigin.isText(mime)) "utf-8" else null, 200, "OK",
          mapOf("Cache-Control" to "no-store"), java.io.FileInputStream(t.file)
        )
      }
      ProjectOrigin.Target.Forbidden -> { onBlocked(url); empty(403, "Forbidden") }
      // Browsers ask for /favicon.ico on their own; answering "no content" keeps a missing icon from showing up as a page error.
      ProjectOrigin.Target.NotFound ->
        if (url.substringBefore('?').endsWith("/favicon.ico", ignoreCase = true)) empty(204, "No Content") else empty(404, "Not Found")
    }

    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
      val url = request?.url?.toString() ?: return null
      if (ProjectOrigin.owns(root, url)) return serve(url)
      if (!isAllowedFileUrl(root, url)) {
        onBlocked(url)
        return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
      }
      return null
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
      val url = request?.url?.toString() ?: return true
      if (url.startsWith("file:", true)) {
        if (!isAllowedFileUrl(root, url)) { onBlocked(url); return true }
        return false
      }
      if (ProjectOrigin.owns(root, url)) return false // links between the project's own pages stay in the preview
      if (url.startsWith("about:", true) || url.startsWith("data:", true) || url.startsWith("blob:", true)) return false
      // Web links leave the preview only when the user tapped them, and then in the real browser.
      if ((url.startsWith("http://", true) || url.startsWith("https://", true)) && request.hasGesture() && view != null) {
        runCatching {
          view.context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        }
      }
      return true
    }
  }
}
