package com.example.project

import java.io.File

/**
 * v1.9.14: removes clutter the app itself left in project folders, and nothing else.
 *  - Files the old built-in self-test wrote into the user's project (v1.2 to v1.9.4): only when the content is exactly what the test wrote.
 *  - `.vibecoder_backups`: per-file .bak copies. Nothing in the app reads them (the Undo button uses the run snapshots in
 *    `.vibecoder/backups`), so they only pile up; the newest [KEEP_BACKUPS] are kept.
 * Anything the user wrote or edited is never touched.
 */
object ProjectJunk {
  const val KEEP_BACKUPS = 10

  private val TEST_LEFTOVERS: Map<String, Set<String>> = mapOf(
    "test_integration.txt" to setOf("VibeCoderAI Integration 123"),
    "patch_target.txt" to setOf("line1\nTARGET_CHUNK\nline3", "line1\nREPLACED_SURGICAL\nline3")
  )

  /** Keeps the newest [keep] backup files of [root]. Returns how many were deleted. */
  fun pruneBackups(root: File, keep: Int = KEEP_BACKUPS): Int {
    val dir = File(root, ".vibecoder_backups")
    val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".bak") } ?: return 0
    var n = 0
    files.sortedByDescending { it.lastModified() }.drop(keep).forEach { if (it.delete()) n++ }
    return n
  }

  /** Deletes the self-test leftovers in [root] and trims its backups. Returns the number of files deleted. */
  fun clean(root: File): Int {
    if (!root.isDirectory) return 0
    var n = 0
    for ((name, contents) in TEST_LEFTOVERS) {
      val f = File(root, name)
      if (f.isFile && f.length() < 200 && runCatching { f.readText().trim() in contents }.getOrDefault(false) && f.delete()) n++
    }
    return n + pruneBackups(root)
  }

  /** Cleans every project folder under [projectsDir]. */
  fun cleanAll(projectsDir: File): Int =
    projectsDir.listFiles { f -> f.isDirectory }?.sumOf { clean(it) } ?: 0
}
