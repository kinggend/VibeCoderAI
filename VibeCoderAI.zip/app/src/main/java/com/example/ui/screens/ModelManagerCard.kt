package com.example.ui.screens

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.filled.Check
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import com.example.ui.components.IconButton
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.llama.LlamaBridge
import com.example.data.downloader.Mmproj
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException

private fun listGguf(dir: File): List<File> =
  dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) }
    ?.sortedBy { it.name.lowercase() }
    ?: emptyList()

/** Chat models only: the image helper (mmproj) files belong to a vision model and are not models themselves. */
private fun listModels(dir: File): List<File> = listGguf(dir).filter { !Mmproj.isMmproj(it.name) }

private fun importModel(context: Context, uri: Uri, dir: File): Result<File> = runCatching {
  val resolver = context.contentResolver
  var name = "model.gguf"
  var size = -1L
  resolver.query(uri, null, null, null, null)?.use { c ->
    val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
    val si = c.getColumnIndex(OpenableColumns.SIZE)
    if (c.moveToFirst()) {
      if (ni >= 0) name = c.getString(ni) ?: name
      if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
    }
  }
  name = name.replace(Regex("[^A-Za-z0-9._-]"), "_")
  if (!name.endsWith(".gguf", ignoreCase = true)) {
    throw IllegalArgumentException("Please pick a .gguf model file.")
  }
  dir.mkdirs()
  if (size > 0 && dir.usableSpace < size + 64L * 1024 * 1024) {
    throw IllegalStateException("Not enough free storage for this model.")
  }

  val tmp = File(dir, "$name.part")
  val dest = File(dir, name)
  try {
    val input = resolver.openInputStream(uri) ?: throw IOException("Cannot open the selected file.")
    input.use { ins -> FileOutputStream(tmp).use { out -> ins.copyTo(out, 1 shl 20) } }

    val magic = ByteArray(4)
    tmp.inputStream().use { it.read(magic) }
    if (String(magic, Charsets.US_ASCII) != "GGUF") {
      throw IllegalArgumentException("This file is not a valid GGUF model.")
    }
    if (dest.exists()) dest.delete()
    if (!tmp.renameTo(dest)) throw IOException("Could not save the model file.")
  } finally {
    if (tmp.exists()) tmp.delete()
  }
  dest
}

private fun formatSize(bytes: Long): String =
  if (bytes >= 1_000_000_000L) "%.2f GB".format(bytes / 1_000_000_000.0) else "${bytes / 1_000_000} MB"

@Composable
fun ModelManagerCard(
  modelsDir: File,
  currentPath: String?,
  modelLoaded: Boolean,
  modelStatus: String?,
  onSelectModel: (String?) -> Unit,
  refreshKey: Int = 0,
  onUnload: () -> Unit = {},
  onBenchmark: () -> String = { "" },
  memory: com.example.llama.ModelMemory? = null,
  contextLength: Int = 0
) {
  val context = LocalContext.current
  val deviceRam = remember {
    val mi = android.app.ActivityManager.MemoryInfo()
    (context.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager).getMemoryInfo(mi)
    mi.totalMem.coerceAtLeast(1L).toDouble()
  }
  val scope = rememberCoroutineScope()
  var files by remember(refreshKey) { mutableStateOf(listModels(modelsDir)) }
  var importing by remember { mutableStateOf(false) }
  var message by remember { mutableStateOf<String?>(null) }
  var confirmDelete by remember { mutableStateOf<File?>(null) }
  var benchText by remember { mutableStateOf<String?>(null) }
  var benching by remember { mutableStateOf(false) }

  val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
    if (uri != null) {
      importing = true
      message = "Importing model... this can take a minute for large files."
      scope.launch {
        val result = withContext(Dispatchers.IO) { importModel(context, uri, modelsDir) }
        importing = false
        files = listModels(modelsDir)
        result
          .onSuccess { f ->
            message = "Imported ${f.name}"
            onSelectModel(f.absolutePath)
          }
          .onFailure { e -> message = e.message ?: "Import failed" }
      }
    }
  }

  val engineOk = LlamaBridge.isNativeLoaded
  val loading = engineOk && !modelLoaded && currentPath != null && modelStatus?.startsWith("Loading") == true
  val statusColor = when {
    !engineOk -> CyberCoralError
    modelLoaded -> CyberGreenSuccess
    loading -> CyberAmberWarning
    else -> TextMuted
  }
  val statusText = when {
    !engineOk -> "Engine error"
    modelLoaded -> "Ready"
    loading -> "Loading"
    currentPath != null -> modelStatus ?: "Not loaded"
    else -> "No model selected"
  }
  val active = files.firstOrNull { it.absolutePath == currentPath }

  // llama.cpp reports no load progress, so the bar is an estimate from the file size and elapsed time
  // (asymptotic, capped at 95 %) and jumps to done as soon as the model is ready.
  var loadFraction by remember { mutableStateOf(0f) }
  androidx.compose.runtime.LaunchedEffect(loading, currentPath) {
    if (!loading) {
      loadFraction = 0f
      return@LaunchedEffect
    }
    val bytes = currentPath?.let { File(it).length() } ?: 0L
    val expectedMs = (bytes / (350.0 * 1024 * 1024) * 1000.0).coerceAtLeast(1500.0)
    val start = System.currentTimeMillis()
    while (true) {
      val elapsed = (System.currentTimeMillis() - start).toDouble()
      loadFraction = (1.0 - kotlin.math.exp(-elapsed / expectedMs)).toFloat().coerceAtMost(0.95f)
      kotlinx.coroutines.delay(120)
    }
  }

  val ramNeedMb = memory?.let { it.neededBytes(maxOf(contextLength, it.minContext)) / 1048576 } ?: 0L
  val ramFreeMb = memory?.let { it.freeBytes / 1048576 } ?: 0L
  val ramShort = active != null && memory != null && memory.freeBytes > 0 && ramNeedMb > ramFreeMb
  val warn = !engineOk || ramShort
  val heroState = when {
    warn -> HeroState.WARN
    modelLoaded -> HeroState.READY
    loading -> HeroState.LOADING
    else -> HeroState.IDLE
  }

  Column(verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(20.dp)) {
    // Hero: glowing when loaded and the RAM fits, red rail when it does not.
    HeroModelCard(heroState) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        VibeStatus(statusText, color = statusColor, pulsing = loading)
        Spacer(Modifier.weight(1f))
        if (modelLoaded) VibeTextAction("Unload", CyberCoralError, onUnload)
      }
      Spacer(Modifier.height(10.dp))
      Text(
        active?.name?.removeSuffix(".gguf") ?: "Choose a model below",
        color = TextPrimary, fontSize = 20.sp, lineHeight = 25.sp, fontWeight = FontWeight.Bold, maxLines = 2
      )
      if (warn) {
        Text(
          if (!engineOk) "ERR_ENGINE  ${LlamaBridge.nativeLoadError ?: "inference engine could not start"}"
          else "ERR_OOM  need $ramNeedMb MB > free $ramFreeMb MB\n> lower the context or close other apps",
          color = CyberCoralError, fontFamily = Mono, fontSize = 12.sp, lineHeight = 18.sp,
          modifier = Modifier.padding(top = 10.dp)
        )
      } else if (loading) {
        Text(
          "> loading into memory, large models can take a minute",
          color = TextSecondary, fontFamily = Mono, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 8.dp)
        )
      }
      if (active != null) {
        Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 10.dp)) {
          modelTags(active.name).forEach { VibeChip(it) }
        }
        val ratio = (active.length().toDouble() / deviceRam).toFloat().coerceIn(0f, 1f)
        val ratioColor = if (ratio > 0.5f) CyberCoralError else if (ratio > 0.3f) CyberAmberWarning else androidx.compose.material3.MaterialTheme.colorScheme.primary
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(20.dp)) {
          VibeSpec("Size", formatSize(active.length()))
          VibeSpec("RAM", "${(ratio * 100).toInt()}%", color = ratioColor)
          if (contextLength > 0) VibeSpec("Context", "$contextLength ctx", color = androidx.compose.material3.MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape).background(TextPrimary.copy(alpha = 0.12f))) {
          Box(Modifier.fillMaxWidth(ratio.coerceAtLeast(0.04f)).height(6.dp).clip(CircleShape).background(ratioColor))
        }
      }
      if (loading) {
        PercentProgressBar(
          fraction = loadFraction,
          color = androidx.compose.material3.MaterialTheme.colorScheme.primary,
          modifier = Modifier.padding(top = 14.dp),
          label = "${(loadFraction * 100).toInt()}%"
        )
        Text(
          "estimated from file size",
          color = TextMuted, fontFamily = Mono, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp)
        )
      }
      Spacer(Modifier.height(16.dp))
      Row(horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
        VibeButton(
          when {
            importing -> "Importing..."
            modelLoaded -> "Import GGUF"
            else -> "Import GGUF model"
          },
          onClick = { picker.launch(arrayOf("*/*")) },
          modifier = Modifier.weight(1f), primary = true, enabled = !importing
        )
        if (modelLoaded) {
          VibeButton(
            if (benching) "Testing..." else "Speed test",
            onClick = {
              benching = true
              benchText = "Running..."
              scope.launch {
                benchText = withContext(Dispatchers.IO) { onBenchmark() }
                benching = false
              }
            },
            modifier = Modifier.weight(1f), enabled = !benching
          )
        }
      }
      benchText?.let {
        Text(it, color = TextSecondary, fontSize = 12.sp, fontFamily = Mono, modifier = Modifier.padding(top = 10.dp))
      }
      message?.let { Text(it, color = TextSecondary, fontFamily = Mono, fontSize = 11.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 10.dp)) }
    }

    // Installed models: flat list, hairline dividers, gradient pill on the selected row.
    ModelSection("Your models", "Tip: 1.5B to 3B models at Q4 give the fastest replies on most phones.") {
      if (files.isEmpty()) {
        Text(
          "NO MODELS YET\nDownload one below, or import a .gguf file. Recommended: Qwen2.5-Coder 1.5B or 3B Instruct, Q4.",
          color = TextSecondary, fontFamily = Mono, fontSize = 12.sp, lineHeight = 18.sp
        )
      }
      val allGguf = remember(files) { listGguf(modelsDir) }
      Column(Modifier.fillMaxWidth(), verticalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(10.dp)) {
        files.forEach { f ->
          val isSelected = f.absolutePath == currentPath
          val ratio = f.length().toDouble() / deviceRam
          val (fit, fitTint) = when {
            ratio > 0.5 -> "Too big" to CyberCoralError
            ratio > 0.3 -> "Heavy" to CyberAmberWarning
            ratio < 0.2 -> "Fast" to CyberGreenSuccess
            else -> "Good fit" to CyberGreenSuccess
          }
          VibeModelRow(
            selected = isSelected,
            onClick = { onSelectModel(f.absolutePath) },
            trailing = { VibeIconAction("Delete ${f.name}", CyberCoralError) { confirmDelete = f } }
          ) {
            Text(
              f.name.removeSuffix(".gguf"),
              color = TextPrimary, fontSize = 14.sp, lineHeight = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 2
            )
            Row(
              horizontalArrangement = androidx.compose.foundation.layout.Arrangement.spacedBy(6.dp),
              modifier = Modifier.padding(top = 8.dp).horizontalScroll(androidx.compose.foundation.rememberScrollState())
            ) {
              VibeChip(formatSize(f.length()), TextSecondary)
              modelTags(f.name).forEach { VibeChip(it) }
              VibeChip(fit, fitTint)
              val helper = Mmproj.pair(f.name, allGguf.map { it.name })
              if (helper != null) VibeChip("Vision ready")
              else if (com.example.data.downloader.ModelCategory.VISION in com.example.data.downloader.ModelCategories.tagsFor(f.name))
                VibeChip("No image helper", CyberAmberWarning)
            }
          }
        }
      }
    }
  }

  confirmDelete?.let { f ->
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { confirmDelete = null },
      title = { Text("Delete model?") },
      text = { Text("${f.name} (${formatSize(f.length())}) will be removed from this phone.") },
      confirmButton = {
        com.example.ui.components.TextButton(onClick = {
          val wasSelected = f.absolutePath == currentPath
          val helper = Mmproj.pair(f.name, listGguf(modelsDir).map { it.name })
          f.delete()
          // Remove the image helper too unless another model still uses it.
          if (helper != null && listModels(modelsDir).none { Mmproj.pair(it.name, listOf(helper)) != null }) File(modelsDir, helper).delete()
          files = listModels(modelsDir)
          if (wasSelected) onSelectModel(null)
          confirmDelete = null
        }) { Text("Delete", color = CyberCoralError) }
      },
      dismissButton = { com.example.ui.components.TextButton(onClick = { confirmDelete = null }) { Text("Cancel") } }
    )
  }
}
