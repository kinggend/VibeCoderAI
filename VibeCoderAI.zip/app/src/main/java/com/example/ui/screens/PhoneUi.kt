package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.phone.PhoneAgent
import com.example.phone.PhoneAgentService
import com.example.phone.PhoneHistory
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

private val Danger = Color(0xFFE5484D)

/**
 * v1.7.0: Phone agent settings: what it does (disclosure), the Accessibility switch, honest limits,
 * the model warning and every past phone task. Nothing here changes the coding agent.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
internal fun PhoneAgentSheet(settings: SettingsState, onDismiss: () -> Unit) {
  val context = LocalContext.current
  val agent = remember { PhoneAgent.get(context) }
  val on by agent.enabledFlow.collectAsState()
  val serviceOn by PhoneAgentService.connected.collectAsState()
  var history by remember { mutableStateOf(PhoneHistory.read(context)) }
  val remote = settings.backendMode == "remote"
  val vision = remote && com.example.chat.VisionSupport.check(settings.backendMode, settings.remoteModel) is com.example.chat.VisionSupport.Verdict.Ok

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true),
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    Column(
      Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding()
    ) {
      Text("Phone agent", fontSize = 20.sp, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(6.dp))
      Text(
        "When on, messages you send become phone tasks: the agent reads the screen and taps, types and scrolls in other apps until the task is done. When off, chat works exactly as before.",
        color = TextSecondary, fontSize = 13.5.sp, lineHeight = 19.sp
      )
      Spacer(Modifier.height(12.dp))
      Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
          .toggleable(value = on, role = Role.Switch) { agent.enabled = it }
          .heightIn(min = 52.dp).padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(Modifier.weight(1f)) {
          Text("Use Phone agent for my messages", fontSize = 15.sp, fontWeight = FontWeight.Medium)
          Text(if (on) "On: messages control the phone" else "Off: normal chat", color = TextMuted, fontSize = 12.sp)
        }
        Switch(checked = on, onCheckedChange = null, colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White))
      }
      Spacer(Modifier.height(8.dp))
      Box14 {
        Text(if (serviceOn) "Accessibility access: on" else "Accessibility access: off", fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        Text(
          "It reads what is on screen (text, buttons, fields) and performs taps, typing, scrolling and Back/Home only while a task you started runs. " +
            "Screen content goes to the model you picked" + (if (remote) " on ${com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl).label}." else ", on this phone.") +
            " It never confirms payments, purchases, sends, deletes, and never types passwords or OTPs: it stops and asks you. Banking and payment apps are not controlled.",
          color = TextSecondary, fontSize = 12.5.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 4.dp)
        )
        TextButton(onClick = { context.startActivity(PhoneAgentService.settingsIntent()) }, modifier = Modifier.heightIn(min = 48.dp)) {
          Text(if (serviceOn) "Open Accessibility settings" else "Turn on in Accessibility settings", color = CyberCyanPrimary)
        }
      }
      Spacer(Modifier.height(10.dp))
      if (!remote) Warn("On-device models are small; phone tasks may fail or loop. A remote vision model works best.")
      else if (!vision) Warn("Your remote model can't see images. It works from screen text only; apps that draw their own UI (games, video editors) need a vision model.")
      Text(
        "Limits: complex apps like CapCut are best effort. App layouts change, so a step can miss. Only for sideloaded installs (Play Store restricts this kind of access).",
        color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp, modifier = Modifier.padding(vertical = 8.dp)
      )
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Past phone tasks", fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (history.isNotEmpty()) TextButton(onClick = { PhoneHistory.clear(context); history = emptyList() }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Clear", color = TextSecondary) }
      }
      if (history.isEmpty()) Text("No phone tasks yet. Turn the agent on and send something like \"YouTube lo Telugu songs play cheyyi\".", color = TextMuted, fontSize = 12.5.sp)
      history.take(20).forEach { e -> HistoryItem(e) }
    }
  }
}

@Composable
private fun Box14(content: @Composable () -> Unit) {
  Column(
    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ObsidianSurfaceVariant)
      .border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp)).padding(start = 14.dp, end = 8.dp, top = 12.dp, bottom = 4.dp)
  ) { content() }
}

@Composable
private fun Warn(text: String) {
  Text(text, color = Color(0xFFF5A524), fontSize = 12.5.sp, lineHeight = 17.sp, modifier = Modifier.padding(bottom = 4.dp))
}

@Composable
private fun HistoryItem(e: PhoneHistory.Entry) {
  var open by remember { mutableStateOf(false) }
  val time = remember(e.time) { java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.SHORT, java.text.DateFormat.SHORT).format(java.util.Date(e.time)) }
  Column(
    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable(onClickLabel = if (open) "Hide steps" else "Show steps") { open = !open }
      .heightIn(min = 48.dp).padding(vertical = 8.dp)
  ) {
    Text(e.task, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
    Text("$time · ${if (e.remote) "Remote" else "On-device"} · ${e.steps.size} steps · ${e.result}", color = TextMuted, fontSize = 12.sp, maxLines = if (open) 6 else 1, overflow = TextOverflow.Ellipsis)
    if (open) e.steps.forEachIndexed { i, s -> Text("${i + 1}. $s", color = TextSecondary, fontSize = 12.5.sp, modifier = Modifier.padding(top = 2.dp)) }
  }
}

/** v1.7.0: live steps of the running phone task, with Stop. Shown above the composer while Phone agent is on. */
@Composable
internal fun PhoneRunCard(state: PhoneAgent.State, onStop: () -> Unit, onDismiss: () -> Unit) {
  Column(
    Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp).clip(RoundedCornerShape(18.dp))
      .background(ObsidianSurfaceVariant).border(1.dp, ObsidianBorder, RoundedCornerShape(18.dp)).padding(14.dp)
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Text(if (state.running) "Phone task running" else "Phone task finished", fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
      TextButton(onClick = if (state.running) onStop else onDismiss, modifier = Modifier.heightIn(min = 48.dp)) {
        Text(if (state.running) "Stop" else "Close", color = if (state.running) Danger else TextSecondary, fontWeight = FontWeight.SemiBold)
      }
    }
    Text(state.task, color = TextSecondary, fontSize = 13.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    Column(Modifier.padding(top = 6.dp).semantics { liveRegion = LiveRegionMode.Polite }, verticalArrangement = Arrangement.spacedBy(2.dp)) {
      state.steps.takeLast(4).forEach { s -> Text((if (s.ok) "• " else "✕ ") + s.text, color = if (s.ok) TextPrimary else Danger, fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis) }
      state.result?.takeIf { !state.running }?.let { Text(it, color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 4.dp)) }
    }
  }
}

/** v1.7.0: one-time notice before the first phone task on a remote model. */
@Composable
internal fun PhoneRemoteNoticeDialog(host: String, onContinue: () -> Unit, onCancel: () -> Unit) {
  AlertDialog(
    onDismissRequest = onCancel,
    title = { Text("Screen content goes to $host") },
    text = { Text("During phone tasks the text on your screen (and a screenshot when the screen can't be read as text) is sent to $host each step. Password fields are never read or typed.") },
    confirmButton = { TextButton(onClick = onContinue) { Text("Continue") } },
    dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
  )
}
