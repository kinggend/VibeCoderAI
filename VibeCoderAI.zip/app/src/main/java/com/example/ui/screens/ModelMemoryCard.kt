package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.llama.MemoryEstimator
import com.example.llama.ModelMemory
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

/**
 * Hardware dashboard (v1.9): weights + KV cache + overhead against free RAM as one gauge, and the context window as a
 * sliding segmented control. A context that does not fit is shown on the gauge for a moment (red pulse) and then
 * lowered to the largest size that fits, so a load never fails for a setting the user can see.
 */
@Composable
internal fun ModelMemoryCard(
  memory: ModelMemory?,
  contextLength: Int,
  onContextChange: (Int) -> Unit
) {
  var notice by remember { mutableStateOf<String?>(null) }
  // The size the user just tapped while it still does not fit: drawn for ~1.1 s, then replaced by the safe size.
  var attempted by remember { mutableStateOf<Int?>(null) }
  val scope = rememberCoroutineScope()

  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .background(ObsidianSurfaceSolid)
      .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(16.dp))
      .padding(16.dp)
  ) {
    if (memory == null) {
      Text("NO MODEL SELECTED", color = TextSecondary, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 1.sp)
      Text(
        "Select a downloaded model to profile its memory.",
        color = TextMuted, fontFamily = Mono, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 6.dp)
      )
      return@Column
    }

    fun requiredMb(ctx: Int) = MemoryEstimator.neededBytes(memory.fileBytes, maxOf(ctx, memory.minContext)) / 1048576
    val freeMb = memory.freeBytes / 1048576
    // Vision models cannot go below their minimum context, so "lower it" is no help when even that does not fit.
    val floor = maxOf(1024, memory.minContext)
    val neverFits = requiredMb(floor) > freeMb
    fun lowerMsg(ctx: Int, usedCtx: Int, neededMb: Long): String =
      if (neverFits) "Even the smallest context ($floor tokens) needs about ${requiredMb(floor)} MB but only $freeMb MB is free. Close other apps or choose a smaller model."
      else "A $ctx-token context needs about $neededMb MB but only $freeMb MB is free. Using $usedCtx instead."

    // Opened with a context that is already too big: lower it now and say so.
    LaunchedEffect(memory.fileBytes, memory.freeBytes, contextLength) {
      val g = MemoryEstimator.guard(memory.fileBytes, maxOf(contextLength, memory.minContext), memory.freeBytes)
      if (g.lowered && g.contextTokens < contextLength) {
        notice = lowerMsg(contextLength, g.contextTokens, g.neededBytes / 1048576)
        onContextChange(g.contextTokens)
      }
    }

    val shownCtx = attempted ?: maxOf(contextLength, memory.minContext)
    val weightsMb = memory.fileBytes * 12 / 10 / 1048576
    val kvMb = shownCtx.toLong() * MemoryEstimator.kvBytesPerToken(memory.fileBytes) / 1048576
    val overheadMb = MemoryEstimator.OVERHEAD_BYTES / 1048576
    val needMb = weightsMb + kvMb + overheadMb
    val over = freeMb > 0 && needMb > freeMb
    val tight = freeMb > 0 && needMb * 10 > freeMb * 8

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      VibeSpec("Required", "$needMb MB", color = fitColor(over, tight))
      VibeSpec("Free", "$freeMb MB")
      VibeSpec("Context", "$shownCtx ctx", color = VibeCyan)
    }
    Spacer(Modifier.height(14.dp))
    HardwareGauge(weightsMb, kvMb, overheadMb, freeMb)
    Spacer(Modifier.height(8.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      GaugeLegend(VibePurple, "WEIGHTS", "$weightsMb")
      GaugeLegend(VibeCyan, "KV", "$kvMb")
      GaugeLegend(TextMuted, "RT", "$overheadMb")
    }
    Spacer(Modifier.height(18.dp))
    Text("CONTEXT WINDOW", color = TextMuted, fontFamily = Mono, fontSize = 9.sp, letterSpacing = 1.sp)
    Spacer(Modifier.height(8.dp))
    VibeSegmented(
      options = listOf(1024, 2048, 4096, 8192),
      selected = shownCtx,
      isEnabled = { it >= memory.minContext },
      onSelect = { ctx ->
        val g = MemoryEstimator.guard(memory.fileBytes, maxOf(ctx, memory.minContext), memory.freeBytes)
        if (g.lowered) {
          notice = lowerMsg(ctx, g.contextTokens, g.neededBytes / 1048576)
          attempted = ctx
          scope.launch {
            delay(1100)
            attempted = null
            onContextChange(g.contextTokens)
          }
        } else {
          notice = null
          attempted = null
          onContextChange(ctx)
        }
      }
    )
    notice?.let {
      Spacer(Modifier.height(12.dp))
      Text(
        "WARN  $it",
        color = if (neverFits || over) CyberCoralError else CyberAmberWarning,
        fontFamily = Mono, fontSize = 11.sp, lineHeight = 16.sp
      )
    }
    if (memory.minContext > 0) {
      Spacer(Modifier.height(8.dp))
      Text(
        "Vision models keep at least ${memory.minContext} tokens for image data.",
        color = TextMuted, fontFamily = Mono, fontSize = 10.sp, lineHeight = 15.sp
      )
    }
  }
}
