@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.ui.screens

import com.example.ui.components.AccentSwitch
import android.os.Debug
import androidx.compose.runtime.collectAsState
import kotlinx.coroutines.launch
import androidx.compose.animation.togetherWith
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Extension
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Icon
import com.example.ui.components.liquidGlass
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import com.example.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.ui.components.GroupedSection
import com.example.ui.components.LargeTitle
import com.example.data.model.withLevel
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.roundToInt

@Composable
private fun SliderRow(
  label: String,
  valueText: String,
  hint: String?,
  value: Float,
  range: ClosedFloatingPointRange<Float>,
  steps: Int = 0,
  /** v1.5: shows a 48dp "?" that opens the setting's info sheet. */
  onInfo: (() -> Unit)? = null,
  /** v1.5: extra line under the slider (e.g. the output estimate). */
  below: (@Composable () -> Unit)? = null,
  onChange: (Float) -> Unit
) {
  val haptics = rememberHaptics()
  var first by remember { mutableStateOf(true) }
  LaunchedEffect(valueText) {
    if (first) first = false else haptics.tick()
  }
  Column(modifier = Modifier.padding(vertical = 6.dp)) {
    Row(modifier = Modifier.fillMaxWidth().heightIn(min = if (onInfo != null) 48.dp else 0.dp), verticalAlignment = Alignment.CenterVertically) {
      Text(label, color = TextPrimary, fontSize = 16.sp)
      if (onInfo != null) InfoButton(label, onInfo)
      Spacer(Modifier.weight(1f))
      Text(valueText, color = TextSecondary, fontSize = 16.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
    }
    Slider(
      value = value.coerceIn(range),
      onValueChange = onChange,
      valueRange = range,
      steps = steps,
      thumb = {
        Box(
          modifier = Modifier
            .size(28.dp)
            .shadow(4.dp, CircleShape)
            .background(Color.White, CircleShape)
        )
      },
      colors = SliderDefaults.colors(
        activeTrackColor = CyberCyanPrimary,
        inactiveTrackColor = ObsidianSurfaceVariant,
        activeTickColor = Color.White.copy(alpha = 0.55f),
        inactiveTickColor = TextMuted.copy(alpha = 0.5f)
      )
    )
    if (hint != null) Text(hint, color = TextMuted, fontSize = 13.sp, lineHeight = 17.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
    below?.invoke()
  }
}

@Composable
private fun ToggleRow(label: String, hint: String, checked: Boolean, enabled: Boolean = true, managedBy: String? = null, onChange: (Boolean) -> Unit) {
  val haptics = rememberHaptics()
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Column(modifier = Modifier.weight(1f).padding(end = 12.dp)) {
      Text(label, color = if (enabled) TextPrimary else TextPrimary.copy(alpha = 0.5f), fontSize = 16.sp)
      Text(hint, color = if (enabled) TextMuted else TextMuted.copy(alpha = 0.6f), fontSize = 13.sp, lineHeight = 17.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
      // v1.5: why a switch is locked (Strict Security).
      if (managedBy != null) Text(managedBy, color = com.example.ui.theme.CyberAmberWarning, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 2.dp))
    }
    AccentSwitch(
      checked = checked,
      enabled = enabled,
      onCheckedChange = {
        haptics.tick()
        onChange(it)
      })
  }
}

@Composable
private fun PillButton(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
  TextButton(
    onClick = onClick,
    modifier = modifier,
    shape = CircleShape
  ) {
    Box(
      modifier = Modifier
        .clip(CircleShape)
        .background(color.copy(alpha = 0.14f))
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Text(text, color = color, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}

@Composable
fun SettingsScreen(
  settings: SettingsState,
  onUpdateSettings: (SettingsState) -> Unit,
  onOpenTestRunner: () -> Unit,
  onClearChat: () -> Unit = {},
  bottomInset: androidx.compose.ui.unit.Dp = 0.dp,
  modifier: Modifier = Modifier
) {
  val maxThreads = Runtime.getRuntime().availableProcessors().coerceIn(2, 12)
  val rt = Runtime.getRuntime()
  var heapUsedMb by remember { mutableStateOf((rt.totalMemory() - rt.freeMemory()) / 1048576) }
  var nativeMb by remember { mutableStateOf(Debug.getNativeHeapAllocatedSize() / 1048576) }
  val heapMaxMb = rt.maxMemory() / 1048576

  var page by remember { mutableStateOf<String?>(null) }
  // v1.2: quick-details bottom sheet opened by tapping a row's value.
  var sheet by remember { mutableStateOf<String?>(null) }
  // v1.5: "?" info sheet and price editor.
  var info by remember { mutableStateOf<String?>(null) }
  var priceFor by remember { mutableStateOf<String?>(null) }
  androidx.activity.compose.BackHandler(enabled = page != null) { page = null }
  val level = com.example.data.model.OutputLevel.from(settings.outputLevel)
  val skillsOn = com.example.agent.Skills.version.let { com.example.agent.Skills.all().count { com.example.agent.Skills.isEnabled(it) } }
  val themeLabel = when (settings.themeMode) { "light" -> "Light"; "dark" -> "Dark (OLED)"; else -> "System" }
  val context = androidx.compose.ui.platform.LocalContext.current
  val appVersion = remember {
    val name = runCatching {
      @Suppress("DEPRECATION")
      context.packageManager.getPackageInfo(context.packageName, 0).versionName
    }.getOrNull()
    "VibeCoder v${name?.takeIf { it.isNotBlank() } ?: "1.2"}"
  }

  androidx.compose.animation.AnimatedContent(
    targetState = page,
    modifier = modifier.fillMaxSize(),
    transitionSpec = {
      val forward = targetState != null
      (androidx.compose.animation.slideInHorizontally(androidx.compose.animation.core.tween(280)) { if (forward) it / 4 else -it / 4 } +
        androidx.compose.animation.fadeIn(androidx.compose.animation.core.tween(220))) togetherWith
        (androidx.compose.animation.slideOutHorizontally(androidx.compose.animation.core.tween(240)) { if (forward) -it / 5 else it / 4 } +
          androidx.compose.animation.fadeOut(androidx.compose.animation.core.tween(140)))
    },
    label = "settingsPage"
  ) { p ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
      if (p == null) {
        LargeTitle("Settings")
        SettingsGroup {
          NavRow(Icons.Default.Palette, Color(0xFF5E5CE6), "Appearance", themeLabel, onValueClick = { sheet = "appearance" }) { page = "appearance" }
          NavRow(Icons.Default.Tune, Color(0xFF0A84FF), "Output and generation", "${com.example.data.model.OutputPresets.label(settings)} · ${settings.contextLength} ctx", last = true, onValueClick = { sheet = "output" }) { page = "output" }
        }
        SettingsGroup {
          NavRow(Icons.Default.SmartToy, Color(0xFF30D158), "Agent", (if (settings.autonomous) "Autonomous" else "Manual") + if (settings.strictSecurity) " · Strict" else "", onValueClick = { sheet = "agent" }) { page = "agent" }
          NavRow(Icons.Default.Extension, Color(0xFFFF9F0A), "Agent skills", "$skillsOn on", last = true, onValueClick = { sheet = "skills" }) { page = "skills" }
        }
        SettingsGroup {
          NavRow(Icons.Default.Memory, Color(0xFFFF453A), "Memory", "$heapUsedMb MB", onValueClick = { sheet = "memory" }) { page = "memory" }
          NavRow(Icons.Default.Storage, Color(0xFF8E8E93), "Data and diagnostics", appVersion.removePrefix("VibeCoder "), onValueClick = { sheet = "data" }) { page = "data" }
          // v1.6: what is stored where, network use, export / clear.
          NavRow(Icons.Default.Lock, Color(0xFF30B0C7), "Privacy & transparency", "No tracking", last = true) { page = "privacy" }
        }
        Text(
          appVersion,
          color = TextMuted,
          fontSize = 13.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center,
          modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
        )
      } else {
        Row(
          modifier = Modifier
            .clip(CircleShape)
            .clickable { page = null }
            .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
            .padding(end = 12.dp, top = 4.dp, bottom = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = CyberCyanPrimary, modifier = Modifier.size(22.dp))
          Text("Settings", color = CyberCyanPrimary, fontSize = 16.sp)
        }
        LargeTitle(when (p) {
          "appearance" -> "Appearance"; "output" -> "Output"; "agent" -> "Agent"; "skills" -> "Skills"; "memory" -> "Memory"; "privacy" -> "Privacy"; else -> "Data"
        })
        when (p) {
          "appearance" -> {
    GroupedSection("Appearance", footer = "Light, Dark (OLED pure black), or follow the phone setting.") {
      val modes = listOf("system" to "System", "light" to "Light", "dark" to "Dark (OLED)")
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(CircleShape)
          .background(ObsidianSurfaceVariant)
          .padding(3.dp)
      ) {
        modes.forEach { (key, label) ->
          val selected = settings.themeMode == key
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(CircleShape)
              .background(if (selected) CyberCyanPrimary else Color.Transparent)
              .clickable {
                onUpdateSettings(settings.copy(themeMode = key))
              }
              .padding(vertical = 9.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              label,
              color = if (selected) Color.White else TextPrimary,
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold
            )
          }
        }
      }
    }

    // v1.5: accent colour. Only buttons, active tabs, sliders, switches and focus rings follow it.
    GroupedSection("Accent colour", footer = "Recolours buttons, active tabs, sliders and focus rings. The background stays pure black, and error and success colours never change.") {
      AccentPicker(settings.accent) { onUpdateSettings(settings.copy(accent = it)) }
    }

    GroupedSection(
      "Performance",
      footer = if (canBlur) "Frosted glass is on by default. A larger radius looks softer but costs a little more GPU work."
      else "Frosted glass is on by default. Turn it off only if the app feels slow on this phone."
    ) {
      ToggleRow(
        "Real glass blur", "Frosted blur behind the dock and sheets (Android 12+).",
        settings.glassBlur
      ) { onUpdateSettings(settings.copy(glassBlur = it)) }
      // v1.5: radius slider with live preview, Android 12+ only (older phones keep the on/off switch).
      if (canBlur && settings.glassBlur) {
        SliderRow(
          "Blur radius", "${settings.blurRadiusDp} dp", null,
          settings.blurRadiusDp.toFloat(), 10f..40f, steps = 5,
          below = { Spacer(Modifier.height(6.dp)); BlurPreview(settings.blurRadiusDp) }
        ) { onUpdateSettings(settings.copy(blurRadiusDp = ((it / 5f).roundToInt() * 5).coerceIn(10, 40))) }
      }
    }

          }
          "output" -> {
    GroupedSection("Output level", footer = com.example.data.model.OutputLevel.from(settings.outputLevel).blurb) {
      val levels = com.example.data.model.OutputLevel.values()
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(CircleShape)
          .background(ObsidianSurfaceVariant)
          .padding(3.dp)
      ) {
        levels.forEach { level ->
          val selected = settings.outputLevel == level.id
          Box(
            modifier = Modifier
              .weight(1f)
              .clip(CircleShape)
              .background(if (selected) CyberCyanPrimary else Color.Transparent)
              .clickable {
                onUpdateSettings(settings.withLevel(level))
              }
              .padding(vertical = 9.dp),
            contentAlignment = Alignment.Center
          ) {
            Text(
              if (level == com.example.data.model.OutputLevel.ULTRA) "Ultra" else level.label,
              color = if (selected) Color.White else TextPrimary,
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              maxLines = 1
            )
          }
        }
      }
    }

    // v1.5: presets replace the three sampling sliders; the sliders live on under "Advanced".
    GroupedSection("Preset", footer = "Coding is steady and exact, Balanced mixes in some variety, Creative is the most varied. Fast also lowers the context to 2048 and max output to 512 (never raises them).") {
      PresetChips(settings, onUpdateSettings)
    }

    GroupedSection(
      "Generation",
      footer = "Context changes reload the model on the next message."
    ) {
      SliderRow(
        "CPU threads", "${settings.cpuThreads}",
        "This phone reports $maxThreads cores. Speed is usually best near the number of fast cores (often 4).",
        settings.cpuThreads.toFloat(), 1f..maxThreads.toFloat(), steps = maxThreads - 2,
        onInfo = { info = "CPU threads" }
      ) { onUpdateSettings(settings.copy(cpuThreads = it.roundToInt())) }
      SliderRow(
        "Context window", "${settings.contextLength}", null,
        settings.contextLength.toFloat(), 1024f..8192f, steps = 6,
        onInfo = { info = "Context window" }
      ) { onUpdateSettings(settings.copy(contextLength = (it / 1024f).roundToInt() * 1024)) }
      SliderRow(
        "Max output tokens", "${settings.maxOutputTokens}",
        "A complete small web app needs about 1500.",
        settings.maxOutputTokens.toFloat(), 256f..4096f, steps = 14,
        below = { OutputEstimate(settings) { priceFor = it } }
      ) { onUpdateSettings(settings.copy(maxOutputTokens = (it / 256f).roundToInt() * 256)) }
      SliderRow(
        "Repetition penalty", "%.2f".format(settings.repetitionPenalty),
        "1.00 is off. Keep it off for code.",
        settings.repetitionPenalty, 1f..1.5f,
        onInfo = { info = "Repetition penalty" }
      ) { onUpdateSettings(settings.copy(repetitionPenalty = (it * 20).roundToInt() / 20f)) }
      AdvancedSection {
        SliderRow(
          "Temperature", "%.2f".format(settings.temperature),
          "Lower gives more predictable code. 0 is greedy.",
          settings.temperature, 0f..1.5f,
          onInfo = { info = "Temperature" }
        ) { onUpdateSettings(settings.copy(temperature = (it * 20).roundToInt() / 20f)) }
        SliderRow(
          "Top-P", "%.2f".format(settings.topP), null,
          settings.topP, 0.1f..1f,
          onInfo = { info = "Top-P" }
        ) { onUpdateSettings(settings.copy(topP = (it * 20).roundToInt() / 20f)) }
        SliderRow(
          "Top-K", "${settings.topK}", null,
          settings.topK.toFloat(), 1f..100f,
          onInfo = { info = "Top-K" }
        ) { onUpdateSettings(settings.copy(topK = it.roundToInt())) }
      }
    }

    PriceTableSection(settings) { priceFor = it }

    // v1.4: optional GPU offload. Only a build made with -PvibeVulkan=true has a GPU backend.
    val gpuAvailable = remember { com.example.llama.LlamaBridge.instance.hasGpu() }
    GroupedSection(
      "GPU offload (Vulkan)",
      footer = if (gpuAvailable) "Applies on the next model load. If the GPU load fails, the model loads on the CPU automatically."
      else "This build has no Vulkan GPU backend, so models run on the CPU. GPU offload needs the Vulkan variant APK."
    ) {
      ToggleRow(
        "GPU offload (Vulkan)",
        if (gpuAvailable) "Runs model layers on the phone's GPU." else "Not available in this build.",
        settings.gpuOffload && gpuAvailable,
        enabled = gpuAvailable
      ) { if (gpuAvailable) onUpdateSettings(settings.copy(gpuOffload = it)) }
      if (gpuAvailable && settings.gpuOffload) {
        SliderRow(
          "GPU layers", if (settings.gpuLayers >= 99) "All" else "${settings.gpuLayers}",
          "Fewer layers use less GPU memory.",
          settings.gpuLayers.coerceIn(1, 99).toFloat(), 1f..99f
        ) { onUpdateSettings(settings.copy(gpuLayers = it.roundToInt().coerceIn(1, 99))) }
      }
    }

    // v1.9.31: experimental, off by default. The loaded model decides whether it can run at all.
    val lookupBlock = remember(settings.lookupDecoding, settings.customModelPath) { com.example.llama.LlamaBridge.instance.lookupInfo()?.block ?: 0 }
    GroupedSection(
      "Lookup decoding (experimental)",
      footer = "Guesses the next tokens from text already in the conversation (a code edit repeats most of the file) and checks them in one batch. " +
        "Every token still comes from the normal sampler, so the reply is the same text, but speed is NOT guaranteed: a wrong guess costs time, and the app stops guessing when it is not faster. " +
        "A batch and a single token can round floats differently, so a near-tie can very rarely flip. Never used for models that stream from storage. " +
        "Measure it on your phone: Models > Lookup test."
    ) {
      ToggleRow(
        "Lookup decoding",
        if (lookupBlock != 0) "Not used with the loaded model: ${com.example.llama.LookupBench.reason(lookupBlock)}." else "Off by default. Try it for code edits, then run the Lookup test.",
        settings.lookupDecoding
      ) { onUpdateSettings(settings.copy(lookupDecoding = it)) }
    }

    // v1.9.34: experimental, off by default, only for a model that streams its experts from storage (the STREAMS tag on Models).
    GroupedSection(
      "Streaming read pattern (experimental)",
      footer = "On one phone a 30B model that streams from storage read about 16 GB per generated token, while the experts one token uses are about 1.2 GB (an estimate from the model's architecture, not measured). " +
        "This setting tells the kernel not to read ahead around each page fault while tokens are generated (reading the prompt keeps the normal read-ahead), so the reads are smaller and more numerous. " +
        "That may be faster or slower: it is NOT known. Measure it: Models > Speed test shows the MB read per generated token and the seconds per token, and ends at a time limit if it is much slower. " +
        "If replies become much slower, turn it off. It does not change what the model writes, and it does nothing for a model that fits in RAM."
    ) {
      ToggleRow(
        "No read-ahead while generating (streamed models)",
        "Off by default. Run the Speed test with it off and on, and compare MB read per token and seconds per token.",
        settings.streamReadRandom
      ) { onUpdateSettings(settings.copy(streamReadRandom = it)) }
    }

          }
          "agent" -> {
    GroupedSection("Agent") {
      ToggleRow(
        "Autonomous mode", "Plans the app in steps, builds each step, then runs it and fixes errors by itself.",
        settings.autonomous
      ) { onUpdateSettings(settings.copy(autonomous = it)) }
      // v1.4: replaces "Approve file overwrites". Deletes, agent commands and repair patches always ask.
      // v1.5: Strict Security forces both auto-approve switches off (enforced in ApprovalPolicy too).
      ToggleRow(
        "Strict Security", "Every new file, edit, delete and command waits for your approval.",
        settings.strictSecurity
      ) { on ->
        onUpdateSettings(
          if (on) settings.copy(strictSecurity = true, autoApproveNewFiles = false, autoApproveSafeEdits = false)
          else settings.copy(strictSecurity = false)
        )
      }
      val strictNote = if (settings.strictSecurity) "Managed by Strict Mode" else null
      ToggleRow(
        "Auto-approve new files", "New files the agent creates are written without asking.",
        settings.autoApproveNewFiles && !settings.strictSecurity,
        enabled = !settings.strictSecurity,
        managedBy = strictNote
      ) { if (!settings.strictSecurity) onUpdateSettings(settings.copy(autoApproveNewFiles = it)) }
      ToggleRow(
        "Auto-approve safe edits", "Edits to existing files skip the approval dialog. Deletes and commands always ask.",
        settings.autoApproveSafeEdits && !settings.strictSecurity,
        enabled = !settings.strictSecurity,
        managedBy = strictNote
      ) { if (!settings.strictSecurity) onUpdateSettings(settings.copy(autoApproveSafeEdits = it)) }
      ToggleRow(
        "Rebuild after a fix", "Verifies the project after an approved patch.",
        settings.autoRebuildAfterPatch
      ) { onUpdateSettings(settings.copy(autoRebuildAfterPatch = it)) }
      SliderRow(
        "Max repair attempts", "${settings.maxRepairRetries}", null,
        settings.maxRepairRetries.toFloat(), 1f..5f, steps = 3
      ) { onUpdateSettings(settings.copy(maxRepairRetries = it.roundToInt())) }
    }

    // v1.9.19: background behaviour and the agent browser. Both optional features are off until you turn them on.
    GroupedSection(
      "Background and web",
      footer = "Project check runs without a model or network and never changes a file. The agent browser only reads: it never types, clicks or submits, and every site asks you first."
    ) {
      ToggleRow(
        "Run alerts", "A notification when a run finishes or fails while the app is not on screen.",
        settings.runAlerts
      ) { onUpdateSettings(settings.copy(runAlerts = it)) }
      ToggleRow(
        "Project check", "Every 12 hours (battery not low) looks for missing or cut-off files in your projects and tells you once.",
        settings.projectWatch
      ) {
        onUpdateSettings(settings.copy(projectWatch = it))
        if (it) com.example.agent.ProjectWatchWorker.enable(context) else com.example.agent.ProjectWatchWorker.apply(context, false)
      }
      ToggleRow(
        "Agent browser", "Lets the Debugger, Reviewer and Designer agents read a website. Page text goes to the model you use.",
        settings.agentBrowser
      ) { onUpdateSettings(settings.copy(agentBrowser = it)) }
    }

    // v1.6: terminal timeout (Terminal screen and agent commands). "No limit" keeps a visible Stop button.
    GroupedSection(
      "Terminal",
      footer = "Commands that run longer than this are stopped. With No limit, use Stop on the Terminal screen (or Stop in chat for agent commands)."
    ) {
      TimeoutChips(settings.terminalTimeoutSec) { onUpdateSettings(settings.copy(terminalTimeoutSec = it)) }
    }

    GroupedSection("Editor and feedback") {
      ToggleRow(
        "Editor suggestions", "Keywords and names already in the file appear above the editor. Tap one or press Tab.",
        settings.editorAutocomplete
      ) { onUpdateSettings(settings.copy(editorAutocomplete = it)) }
      ToggleRow(
        "Haptic feedback", "Vibrates when a reply starts and finishes and when a command ends (success and error feel different). Follows the phone's touch feedback setting.",
        settings.haptics
      ) { onUpdateSettings(settings.copy(haptics = it)) }
    }

          }
          "skills" -> SkillsSection()
          "privacy" -> PrivacyPage(onChatsCleared = onClearChat)
          "memory" -> {
    GroupedSection("Memory", footer = "Model weights are memory-mapped by llama.cpp and are not counted here.") {
      val fraction = (heapUsedMb.toFloat() / heapMaxMb.coerceAtLeast(1)).coerceIn(0f, 1f)
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Column {
          Text("JVM heap", color = TextPrimary, fontSize = 16.sp)
          Text("$heapUsedMb of $heapMaxMb MB, native $nativeMb MB", color = TextMuted, fontSize = 13.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
        }
        PillButton("Free RAM", CyberCyanPrimary, onClick = {
          System.gc()
          heapUsedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576
          nativeMb = Debug.getNativeHeapAllocatedSize() / 1048576
        })
      }
      Spacer(modifier = Modifier.height(8.dp))
      LinearProgressIndicator(
        progress = { fraction },
        modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
        color = if (fraction > 0.8f) CyberCoralError else CyberCyanPrimary,
        trackColor = ObsidianSurfaceVariant
      )
    }

          }
          else -> {
    GroupedSection("Data & diagnostics") {
      Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        PillButton("Clear chat", CyberCoralError, onClick = {
          onClearChat()
        })
        PillButton("Reset defaults", TextSecondary, onClick = {
          // v1.5: a reset never silently turns Strict Security off.
          onUpdateSettings(SettingsState(customModelPath = settings.customModelPath, themeMode = settings.themeMode, strictSecurity = settings.strictSecurity))
        })
        PillButton("Self tests", CyberCyanPrimary, onClick = {
          onOpenTestRunner()
        })
      }
    }
    // Export settings: preferences + agent skills as JSON. API keys are never written.
    val exportScope = androidx.compose.runtime.rememberCoroutineScope()
    val settingsExporter = androidx.activity.compose.rememberLauncherForActivityResult(
      androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
      if (uri == null) return@rememberLauncherForActivityResult
      exportScope.launch {
        val msg = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
          runCatching {
            val skills = com.example.agent.Skills.all().map {
              com.example.data.ExportSkill(it.id, it.name, it.description, if (it.builtIn) null else it.prompt, it.builtIn, com.example.agent.Skills.isEnabled(it))
            }
            val stamp = java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            val json = com.example.data.SettingsExport.toJson(settings, skills, appVersion, stamp)
            context.contentResolver.openOutputStream(uri)?.use { it.write(json.toByteArray()) } ?: error("Could not open the file.")
          }.fold({ "Settings exported. API keys were not included." }, { "Export failed: ${it.message}" })
        }
        android.widget.Toast.makeText(context, msg, android.widget.Toast.LENGTH_LONG).show()
      }
    }
    GroupedSection("Export settings", footer = "Saves your preferences and agent skills as a JSON file. API keys and tokens are never included.") {
      PillButton("Export settings (JSON)", CyberCyanPrimary, onClick = { settingsExporter.launch("vibecoder-settings.json") })
    }

    // v1.4: token usage logged per generation in Room.
    val usageRepo = remember { com.example.data.repository.ChatRepository.get(context) }
    val totals by usageRepo.usageTotals.collectAsState(initial = null)
    val usageScope = androidx.compose.runtime.rememberCoroutineScope()
    GroupedSection(
      "Token usage",
      footer = "Local prompt counts are exact (llama.cpp tokenizer); remote counts are estimates (≈)."
    ) {
      val t = totals
      if (t == null || t.runs == 0) {
        Text("No generations logged yet.", color = TextMuted, fontSize = 14.sp)
      } else {
        UsageLine("Generations", "${t.runs}")
        UsageLine("Prompt tokens", (if (t.estimatedRuns > 0) "≈ " else "") + "%,d".format(t.promptTokens))
        UsageLine("Output tokens", "%,d".format(t.outputTokens))
        UsageLine("Reused from cache", "%,d".format(t.cachedTokens))
        UsageLine("Average speed", "%.1f tok/s".format(t.avgTokensPerSecond))
        Spacer(modifier = Modifier.height(6.dp))
        PillButton("Clear usage", TextSecondary, onClick = { usageScope.launch { runCatching { usageRepo.clearUsage() } } })
      }
    }

    // v1.9.30: speed measured on this phone from real requests and Speed tests (numbers only, kept in one small file).
    val speedStore = remember { com.example.data.SpeedHistoryStore.get(context.filesDir) }
    var speedRecords by remember { mutableStateOf<List<com.example.data.SpeedRecord>>(emptyList()) }
    val speedScope = androidx.compose.runtime.rememberCoroutineScope()
    androidx.compose.runtime.LaunchedEffect(Unit) {
      speedRecords = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { speedStore.all() }
    }
    GroupedSection(
      "Speed history",
      footer = "Measured on this phone from your real requests and Speed tests. Numbers only: no prompts, file paths or keys are stored. A remote number includes your network. Prompt reuse is counted by the app's own prompt cache for on-phone replies only; remote servers do not report it, so no remote figure is shown."
    ) {
      if (speedRecords.isEmpty()) {
        Text("No speed data yet. It appears after your next reply or Speed test.", color = TextMuted, fontSize = 14.sp)
      } else {
        for ((backend, title) in listOf("local" to "On this phone", "remote" to "Remote")) {
          val sum = com.example.data.SpeedHistory.summary(speedRecords, backend) ?: continue
          UsageLine(title, "${sum.runs} replies")
          sum.medianDecodeTps?.let { UsageLine("  Generation (median)", "%.1f tok/s".format(java.util.Locale.US, it)) }
          sum.medianTtftMs?.let { UsageLine("  First token (median)", "%.1f s".format(java.util.Locale.US, it / 1000.0)) }
          sum.medianPrefillTps?.let { UsageLine("  Prompt speed (approx., median)", "%.0f tok/s".format(java.util.Locale.US, it)) }
          sum.cacheReusePct?.let { UsageLine("  Prompt tokens reused", "$it%") }
          if (sum.lookupRuns > 0) UsageLine("  Lookup replies (not in the medians)", "${sum.lookupRuns}")
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text("Recent", color = TextSecondary, fontSize = 13.sp)
        speedRecords.takeLast(6).asReversed().forEach {
          Text(com.example.data.SpeedHistory.line(it), color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 3.dp))
        }
        Spacer(modifier = Modifier.height(6.dp))
        PillButton("Clear speed history", TextSecondary, onClick = {
          speedScope.launch {
            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) { speedStore.clear() }
            speedRecords = emptyList()
          }
        })
      }
    }

    GroupedSection("About") {
      Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("Version", color = TextPrimary, fontSize = 16.sp)
        Text(appVersion, color = TextSecondary, fontSize = com.example.ui.theme.UiTokens.RowValueSize, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
      }
    }

          }
        }
      }
      Spacer(modifier = Modifier.height(24.dp + bottomInset))
    }
  }

  info?.let { InfoSheet(it) { info = null } }
  priceFor?.let { PriceDialog(it) { priceFor = null } }

  sheet?.let { key ->
    SettingsQuickSheet(
      key = key,
      settings = settings,
      appVersion = appVersion,
      onOpenFull = { page = it },
      onDismiss = {
        sheet = null
        // Keep the Memory row's value current after the sheet freed RAM.
        heapUsedMb = (rt.totalMemory() - rt.freeMemory()) / 1048576
      }
    )
  }
}

/** iOS-style rounded group holding navigation rows. */
@Composable
private fun SettingsGroup(content: @Composable androidx.compose.foundation.layout.ColumnScope.() -> Unit) {
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .liquidGlass(com.example.ui.theme.UiTokens.CardShape, 8.dp)
      .padding(vertical = 4.dp),
    content = content
  )
}

@Composable
private fun NavRow(
  icon: androidx.compose.ui.graphics.vector.ImageVector,
  tint: Color,
  title: String,
  summary: String,
  last: Boolean = false,
  onValueClick: (() -> Unit)? = null,
  onClick: () -> Unit
) {
  Column {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clickable(onClick = onClick)
        .heightIn(min = 52.dp)
        .padding(horizontal = 14.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier.size(30.dp).clip(RoundedCornerShape(8.dp)).background(tint),
        contentAlignment = Alignment.Center
      ) { Icon(icon, contentDescription = null, tint = Color.White, modifier = Modifier.size(18.dp)) }
      Text(title, color = TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 12.dp))
      if (summary.isNotEmpty()) Text(
        summary,
        color = TextSecondary,
        fontSize = com.example.ui.theme.UiTokens.RowValueSize,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
        maxLines = 1,
        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        // v1.2: the value is its own tap target (quick-details sheet). Its clickable consumes the tap, so
        // the row's navigation does not fire as well.
        modifier = Modifier
          .padding(start = 8.dp)
          .widthIn(max = 170.dp)
          .then(
            if (onValueClick != null) Modifier
              .clip(RoundedCornerShape(10.dp))
              .clickable(onClickLabel = "Show details", onClick = onValueClick)
              .background(ObsidianSurfaceVariant.copy(alpha = 0.55f))
              .padding(horizontal = 8.dp, vertical = 5.dp)
            else Modifier
          )
      )
      Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted, modifier = Modifier.size(22.dp))
    }
    if (!last) Box(Modifier.fillMaxWidth().padding(start = 56.dp).height(0.5.dp).background(ObsidianBorder))
  }
}

@Composable
private fun UsageLine(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp),
    horizontalArrangement = Arrangement.SpaceBetween
  ) {
    Text(label, color = TextPrimary, fontSize = 15.sp)
    Text(value, color = TextMuted, fontSize = 15.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
  }
}
