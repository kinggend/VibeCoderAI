package com.example.ui.components

import android.provider.Settings
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.DotsState
import com.example.agent.RunDots
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

/**
 * v1.9.19: three dots that show what the agent is doing. A wave while it works, a slow shared pulse when it waits for
 * you, solid green / red when it finished or failed. Honors the system's "remove animations" setting.
 */
@Composable
fun AgentDots(state: DotsState, modifier: Modifier = Modifier, dotSize: Dp = 6.dp) {
  val context = LocalContext.current
  val reduceMotion = remember {
    Settings.Global.getFloat(context.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
  }
  val color by animateColorAsState(
    when (state) {
      DotsState.WORKING -> MaterialTheme.colorScheme.primary
      DotsState.NEEDS_YOU -> CyberAmberWarning
      DotsState.DONE -> CyberGreenSuccess
      DotsState.FAILED -> CyberCoralError
      DotsState.IDLE -> TextMuted
    },
    tween(300), label = "dotsColor"
  )
  val transition = rememberInfiniteTransition(label = "agentDots")
  val phase by transition.animateFloat(
    0f, 1f,
    infiniteRepeatable(tween(if (state == DotsState.NEEDS_YOU) 1800 else 1100, easing = LinearEasing)),
    label = "dotsPhase"
  )
  val moving = !reduceMotion && (state == DotsState.WORKING || state == DotsState.NEEDS_YOU)
  Row(
    modifier.semantics { contentDescription = "Agent ${RunDots.label(state, "").ifBlank { "idle" }}" },
    horizontalArrangement = Arrangement.spacedBy(4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    repeat(3) { i ->
      Box(
        Modifier
          .size(dotSize)
          .graphicsLayer {
            val level = if (moving) RunDots.level(state, phase, i) else if (state == DotsState.IDLE) 0.4f else 1f
            alpha = 0.35f + 0.65f * level
            val s = 0.75f + 0.25f * level
            scaleX = s
            scaleY = s
            if (state == DotsState.WORKING && moving) translationY = -3.dp.toPx() * level
          }
          .clip(CircleShape)
          .background(color)
      )
    }
  }
}

/** The dots plus one short line, as a small pill (live step label, "Waiting for you", ...). */
@Composable
fun AgentPresence(state: DotsState, text: String, modifier: Modifier = Modifier) {
  Row(
    modifier.widthIn(max = 320.dp).clip(CircleShape).background(ObsidianSurfaceVariant).padding(horizontal = 12.dp, vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    AgentDots(state)
    Spacer(Modifier.width(8.dp))
    AnimatedContent(
      targetState = text,
      transitionSpec = { (fadeIn(tween(180)) + slideInVertically(tween(180)) { it / 3 }) togetherWith fadeOut(tween(100)) },
      label = "presenceText"
    ) { t ->
      Text(t, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
  }
}
