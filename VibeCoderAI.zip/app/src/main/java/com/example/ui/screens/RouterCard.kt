package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.downloader.Mmproj
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary
import java.io.File

/**
 * v1.9.5: picks the small model that understands phone tasks ("youtube lo ... play cheyyi"). Off = the main model does it.
 * Only models up to 2.2 GB are offered: a router must be small to stay fast and to fit beside the main model.
 */
@Composable
internal fun RouterCard(modelsDir: File, selectedPath: String?, onSelect: (String?) -> Unit) {
  val accent = MaterialTheme.colorScheme.primary
  val files = modelsDir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", true) && !Mmproj.isMmproj(f.name) && f.length() <= 2_200_000_000L }
    ?.sortedBy { it.name.lowercase() } ?: emptyList()
  val chosen = files.firstOrNull { it.absolutePath == selectedPath }
  Column(
    Modifier.fillMaxWidth().clip(VibeShape).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)).padding(20.dp),
    verticalArrangement = Arrangement.spacedBy(12.dp)
  ) {
    Text(
      if (chosen != null) "ROUTER ON  ${chosen.name.removeSuffix(".gguf")}" else "ROUTER OFF  main model routes tasks",
      color = if (chosen != null) accent else TextSecondary, fontFamily = Mono, fontSize = 11.sp, letterSpacing = 0.5.sp
    )
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      RouterPill("Off", selectedPath == null || chosen == null) { onSelect(null) }
      files.forEach { f -> RouterPill(f.name.removeSuffix(".gguf"), f.absolutePath == selectedPath) { onSelect(f.absolutePath) } }
    }
    Text(
      "Import your tuned router .gguf with Import GGUF, then pick it here. It loads beside the main model only when free RAM allows; otherwise the main model is used.",
      color = TextMuted, fontFamily = Mono, fontSize = 10.sp, lineHeight = 15.sp
    )
  }
}

@Composable
private fun RouterPill(label: String, selected: Boolean, onClick: () -> Unit) {
  val accent = MaterialTheme.colorScheme.primary
  Box(
    Modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .pressable(onClick = onClick)
      .clip(VibePill)
      .background(if (selected) accent else accent.copy(alpha = 0.12f))
      .padding(horizontal = 16.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(label, color = if (selected) MaterialTheme.colorScheme.onPrimary else accent, fontFamily = Mono, fontSize = 12.sp, maxLines = 1)
  }
}
