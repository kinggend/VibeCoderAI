package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.ui.theme.TextPrimary

/*
 * v1.9.7 motion kit. Everything animates through graphicsLayer (scale, alpha, translation) so the state is read in the
 * draw phase and a running animation never recomposes the screen.
 */

/**
 * Spring press feedback: scales to [pressedScale] while a finger is down and bounces back, with the Material ripple.
 * A long press (when [onLongClick] is set) fires a stronger haptic before it runs. Use it on cards and custom buttons;
 * the stock [Button] wrappers already do the same through their own press source.
 */
@OptIn(ExperimentalFoundationApi::class)
fun Modifier.bounceClick(
  enabled: Boolean = true,
  pressedScale: Float = 0.95f,
  onLongClick: (() -> Unit)? = null,
  onClick: () -> Unit
): Modifier = composed {
  val source = remember { MutableInteractionSource() }
  val pressed by source.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (pressed && enabled) pressedScale else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "bounceClick"
  )
  val haptics = LocalHapticFeedback.current
  this
    .graphicsLayer { scaleX = scale; scaleY = scale }
    .combinedClickable(
      interactionSource = source,
      indication = androidx.compose.material3.ripple(),
      enabled = enabled,
      onLongClick = onLongClick?.let { run -> { haptics.performHapticFeedback(HapticFeedbackType.LongPress); run() } },
      onClick = onClick
    )
}

/**
 * Entrance for the content of a bottom sheet: it rises 36 dp and fades in on a low-bounce, low-stiffness spring, so the
 * sheet content settles softly after the sheet itself has slid up. (The sheet's own slide uses Material's internal
 * animation, which has no public spring setting.)
 */
fun Modifier.springEntrance(rise: Dp = 36.dp): Modifier = composed {
  val progress = remember { Animatable(0f) }
  LaunchedEffect(Unit) {
    progress.animateTo(1f, spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessLow))
  }
  this.graphicsLayer {
    translationY = (1f - progress.value) * rise.toPx()
    alpha = progress.value.coerceIn(0f, 1f)
  }
}

/** Three dots that rise and fade in turn: the "model is working" state before the first token arrives. */
@Composable
fun ThinkingDots(modifier: Modifier = Modifier, color: Color = MaterialTheme.colorScheme.primary, dotSize: Dp = 7.dp) {
  val transition = rememberInfiniteTransition(label = "thinkingDots")
  Row(modifier, horizontalArrangement = Arrangement.spacedBy(5.dp), verticalAlignment = Alignment.CenterVertically) {
    repeat(3) { i ->
      val level by transition.animateFloat(
        initialValue = 0.25f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
          animation = tween(520, easing = FastOutSlowInEasing),
          repeatMode = RepeatMode.Reverse,
          initialStartOffset = StartOffset(i * 170)
        ),
        label = "dot$i"
      )
      Box(
        Modifier
          .size(dotSize)
          .graphicsLayer {
            alpha = level
            val s = 0.7f + 0.3f * level
            scaleX = s
            scaleY = s
            translationY = -3.dp.toPx() * level
          }
          .clip(CircleShape)
          .background(color)
      )
    }
  }
}

/**
 * Toggle whose track colour fades between grey and the accent and whose thumb glides on a spring and stretches while
 * pressed. Callers add their own haptic tick. [onCheckedChange] = null makes it a pure indicator (the row around it handles the tap).
 */
@Composable
fun AccentSwitch(
  checked: Boolean,
  onCheckedChange: ((Boolean) -> Unit)?,
  modifier: Modifier = Modifier,
  enabled: Boolean = true
) {
  val accent = MaterialTheme.colorScheme.primary
  val off = TextPrimary.copy(alpha = 0.22f)
  val track by animateColorAsState(if (checked) accent else off, tween(220), label = "switchTrack")
  val source = remember { MutableInteractionSource() }
  val pressed by source.collectIsPressedAsState()
  val thumbX by animateDpAsState(if (checked) 24.dp else 4.dp, spring(dampingRatio = 0.7f, stiffness = Spring.StiffnessMedium), label = "switchThumb")
  val stretch by animateFloatAsState(if (pressed) 1.15f else 1f, spring(stiffness = Spring.StiffnessMedium), label = "switchStretch")
  val base = modifier
    .size(width = 52.dp, height = 48.dp)
    .graphicsLayer { alpha = if (enabled) 1f else 0.45f }
  val interactive = if (onCheckedChange != null) {
    base.toggleable(
      value = checked, enabled = enabled, role = Role.Switch, interactionSource = source, indication = null,
      onValueChange = onCheckedChange
    )
  } else base
  Box(interactive, contentAlignment = Alignment.Center) {
    Box(Modifier.size(width = 52.dp, height = 30.dp).clip(CircleShape).background(track)) {
      Box(
        Modifier
          .align(Alignment.CenterStart)
          .offset { IntOffset(thumbX.roundToPx(), 0) }
          .graphicsLayer { scaleX = stretch; scaleY = 1f }
          .size(22.dp)
          .clip(CircleShape)
          .background(Color.White)
      )
    }
  }
}
