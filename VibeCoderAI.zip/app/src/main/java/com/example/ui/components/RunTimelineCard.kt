package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.RunTimeline
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.UiTokens

/** The technical side of a run, shown only when the person expands "Details" (never repeated per step). */
data class TimelineDetails(
  /** "On-device" or "Remote: api.groq.com". */
  val environment: String,
  val remote: Boolean,
  /** "≈1310 tokens", or null. */
  val context: String?,
  val onShowContext: (() -> Unit)?,
  /** The raw step log (tool calls, exit codes). */
  val log: List<String>
)

/**
 * v1.9.21: one card per agent run. Replaces the scattered progress notes, per-step chips, the "Last run" bar and the file card with
 * a single timeline: a header with the one status of the run, a progress bar, the steps with their files, the test result, the
 * actions that fit the state, and an expandable "Details" for the technical side.
 *
 * Actions by state: running shows Stop; done shows (only if needed) Apply / Undo; failed shows Retry and the error details;
 * stopped shows Retry. Preview is not here on purpose: the header has the one primary Preview action.
 */
@Composable
fun RunTimelineCard(
  model: RunTimeline.Model,
  /** The text of a written file (for the code preview), or null when it is no longer kept. */
  fileContent: (String) -> String?,
  defaultOpen: Boolean,
  details: TimelineDetails?,
  onStop: (() -> Unit)?,
  onRetry: (() -> Unit)?,
  onUndo: (() -> Unit)?,
  onApplyPending: (() -> Unit)?,
  onDiscardPending: (() -> Unit)?,
  /** The "undo this file's change" action for a path, or null when none is available. */
  fileUndo: (String) -> (() -> Unit)?,
  modifier: Modifier = Modifier
) {
  val reduced = rememberReducedMotion()
  var userOpen by remember { mutableStateOf<Boolean?>(null) }
  val open = userOpen ?: (defaultOpen || model.state == RunTimeline.State.RUNNING)
  var showDetails by remember { mutableStateOf(false) }
  val shape = RoundedCornerShape(16.dp)
  val live = model.state == RunTimeline.State.RUNNING
  val hasPending = model.rows.any { r -> r.files.any { it.state == RunTimeline.FileState.PENDING } }

  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(shape)
      .background(ObsidianSurfaceSolid)
      .border(0.5.dp, ObsidianBorder, shape)
      .then(if (reduced) Modifier else Modifier.animateContentSize(tween(200, easing = FastOutSlowInEasing)))
  ) {
    // Header: the single status of this run.
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clickable(onClickLabel = if (open) "Collapse run" else "Expand run", role = Role.Button) { userOpen = !open }
        .heightIn(min = UiTokens.MinTouchTarget)
        .padding(horizontal = 16.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      StatusDot(headerStatus(model.state), 20)
      Spacer(Modifier.width(12.dp))
      Column(Modifier.weight(1f)) {
        if (live) {
          ShimmerText(
            model.current ?: "Working…", active = !reduced, color = TextPrimary, fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
          )
        } else {
          Text(headerTitle(model), color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        val sub = headerSubtitle(model)
        if (sub.isNotEmpty()) Text(sub, color = TextMuted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
      }
      if (model.total > 0) {
        Text("${model.done}/${model.total}", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(8.dp))
      }
      Text(if (open) "▴" else "▾", color = TextMuted, fontSize = 14.sp)
    }
    ProgressBar(model)

    if (open) {
      Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        val hidden = (model.rows.size - MAX_ROWS).coerceAtLeast(0)
        if (hidden > 0) Text("$hidden earlier steps", color = TextMuted, fontSize = 12.sp)
        model.rows.drop(hidden).forEach { row -> TimelineRow(row, fileContent, fileUndo) }
        if (model.rows.isEmpty()) Text("Starting…", color = TextMuted, fontSize = 13.sp)
      }

      // Actions that fit the state. Never a Stop button on a finished run, never a Retry on a running one.
      Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        when {
          live && onStop != null -> ActionPill("■  Stop agent", CyberCoralError, filled = false, onClick = onStop)
          hasPending && onApplyPending != null -> {
            ActionPill("Apply", CyberCyanPrimary, filled = true, onClick = onApplyPending)
            if (onDiscardPending != null) ActionPill("Discard", TextSecondary, filled = false, onClick = onDiscardPending)
          }
          !live -> {
            if ((model.state == RunTimeline.State.FAILED || model.state == RunTimeline.State.STOPPED) && onRetry != null) {
              ActionPill("Retry", CyberCyanPrimary, filled = true, onClick = onRetry)
            }
            if (onUndo != null) ActionPill("Undo changes", CyberAmberWarning, filled = false, onClick = onUndo)
          }
        }
      }
    }

    if (details != null) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clickable(onClickLabel = if (showDetails) "Hide details" else "Show details", role = Role.Button) { showDetails = !showDetails }
          .heightIn(min = 44.dp)
          .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Details", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.width(8.dp))
        Text(
          details.environment,
          color = if (details.remote) CyberAmberWarning else CyberGreenSuccess,
          fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        Text(if (showDetails) "▴" else "▾", color = TextMuted, fontSize = 12.sp)
      }
      if (showDetails) DetailsBody(model, details)
    }
  }
}

private const val MAX_ROWS = 14

private fun headerStatus(s: RunTimeline.State): RunTimeline.Status = when (s) {
  RunTimeline.State.RUNNING -> RunTimeline.Status.RUNNING
  RunTimeline.State.DONE -> RunTimeline.Status.DONE
  RunTimeline.State.FAILED -> RunTimeline.Status.FAILED
  RunTimeline.State.STOPPED -> RunTimeline.Status.STOPPED
}

private fun headerTitle(m: RunTimeline.Model): String {
  val who = m.agent?.let { "$it agent · " }.orEmpty()
  return who + when (m.state) {
    RunTimeline.State.RUNNING -> "Working"
    RunTimeline.State.DONE -> "Done"
    RunTimeline.State.FAILED -> "Needs attention"
    RunTimeline.State.STOPPED -> "Stopped"
  }
}

private fun headerSubtitle(m: RunTimeline.Model): String {
  val parts = ArrayList<String>()
  if (m.modifiedFiles > 0) parts.add(if (m.modifiedFiles == 1) "1 file" else "${m.modifiedFiles} files")
  val check = m.rows.lastOrNull { it.kind == RunTimeline.Kind.CHECK }
  if (m.state != RunTimeline.State.RUNNING && check != null) parts.add(if (check.status == RunTimeline.Status.DONE) "tested, no errors" else "test failed")
  if (m.state == RunTimeline.State.RUNNING && m.total > 0) parts.add("step ${(m.done + 1).coerceAtMost(m.total)} of ${m.total}")
  if (m.state == RunTimeline.State.RUNNING && m.agent != null) parts.add(0, "${m.agent} agent")
  return parts.joinToString(" · ")
}

@Composable
private fun ProgressBar(m: RunTimeline.Model) {
  val target = when (m.state) {
    RunTimeline.State.DONE -> 1f
    else -> m.fraction ?: 0f
  }
  val shown by animateFloatAsState(target, tween(300), label = "runProgress")
  val color = when (m.state) {
    RunTimeline.State.FAILED -> CyberCoralError
    RunTimeline.State.DONE -> CyberGreenSuccess
    else -> CyberCyanPrimary
  }
  if (m.fraction == null && m.state != RunTimeline.State.DONE) return
  Box(Modifier.fillMaxWidth().height(2.dp).background(ObsidianBorder)) {
    Box(Modifier.fillMaxWidth(shown.coerceIn(0f, 1f)).fillMaxHeight().background(color))
  }
}

@Composable
private fun StatusDot(status: RunTimeline.Status, sizeDp: Int) {
  val (fill, mark, desc) = when (status) {
    RunTimeline.Status.DONE -> Triple(CyberGreenSuccess, "✓", "Done")
    RunTimeline.Status.FAILED -> Triple(CyberCoralError, "!", "Failed")
    RunTimeline.Status.STOPPED -> Triple(TextMuted, "■", "Stopped")
    RunTimeline.Status.RUNNING -> Triple(CyberCyanPrimary, "", "Running")
    RunTimeline.Status.PENDING -> Triple(Color.Transparent, "", "Waiting")
  }
  val base = Modifier.size(sizeDp.dp).semantics { contentDescription = desc }.clip(CircleShape)
  Box(
    modifier = when (status) {
      RunTimeline.Status.PENDING -> base.border(1.5.dp, ObsidianBorder, CircleShape)
      RunTimeline.Status.RUNNING -> base
      else -> base.background(fill)
    },
    contentAlignment = Alignment.Center
  ) {
    if (status == RunTimeline.Status.RUNNING) SparkleSpinner(size = (sizeDp - 6).dp, color = fill)
    else if (mark.isNotEmpty()) Text(mark, color = Color.White, fontSize = (sizeDp * 0.55f).sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
private fun TimelineRow(row: RunTimeline.Row, fileContent: (String) -> String?, fileUndo: (String) -> (() -> Unit)?) {
  Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
    Row(verticalAlignment = Alignment.Top, modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp)) {
      Box(Modifier.padding(top = 1.dp)) { StatusDot(row.status, 16) }
      Spacer(Modifier.width(12.dp))
      Column(Modifier.weight(1f)) {
        Text(
          row.label,
          color = when {
            row.status == RunTimeline.Status.FAILED -> CyberCoralError
            row.status == RunTimeline.Status.PENDING -> TextMuted
            row.kind == RunTimeline.Kind.INFO -> TextSecondary
            else -> TextPrimary
          },
          fontSize = 13.sp, lineHeight = 18.sp, maxLines = 3, overflow = TextOverflow.Ellipsis
        )
        row.detail?.let {
          Text(it, color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 6, overflow = TextOverflow.Ellipsis)
        }
      }
    }
    row.files.forEach { f -> FileLine(f, fileContent, fileUndo) }
  }
}

@Composable
private fun FileLine(f: RunTimeline.FileRow, fileContent: (String) -> String?, fileUndo: (String) -> (() -> Unit)?) {
  var open by remember { mutableStateOf(false) }
  val (label, color) = when (f.state) {
    RunTimeline.FileState.APPLIED -> "${f.lines} lines" to CyberGreenSuccess
    RunTimeline.FileState.FAILED -> (f.error ?: "failed") to CyberCoralError
    RunTimeline.FileState.DISCARDED -> "discarded" to TextMuted
    RunTimeline.FileState.PENDING -> "waiting for you" to CyberAmberWarning
  }
  Column(Modifier.padding(start = 28.dp)) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(10.dp))
        .clickable(onClickLabel = if (open) "Hide ${f.path}" else "Show ${f.path}", role = Role.Button) { open = !open }
        .heightIn(min = 40.dp)
        .padding(horizontal = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        f.path, color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace,
        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
      )
      Spacer(Modifier.width(8.dp))
      Text(label, color = color, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 150.dp))
      Spacer(Modifier.width(6.dp))
      Text(if (open) "▴" else "▾", color = TextMuted, fontSize = 12.sp)
    }
    if (open) {
      CodePreview(f.path, fileContent(f.path))
      fileUndo(f.path)?.let { undo ->
        Text(
          "Undo this change",
          color = CyberAmberWarning, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
          modifier = Modifier.padding(start = 4.dp, bottom = 6.dp).heightIn(min = 32.dp).clickable(role = Role.Button, onClick = undo)
        )
      }
    }
  }
}

@Composable
private fun CodePreview(path: String, content: String?) {
  if (content.isNullOrEmpty()) {
    Text("The text of $path is no longer kept. Open it in Projects.", color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 6.dp))
    return
  }
  val lines = content.lines()
  val shown = lines.take(PREVIEW_LINES).joinToString("\n")
  val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(bottom = 6.dp)
      .clip(RoundedCornerShape(12.dp))
      .background(ObsidianSurfaceVariant)
      .padding(12.dp)
  ) {
    Box(Modifier.horizontalScroll(rememberScrollState())) {
      Text(shown, color = TextSecondary, fontSize = 11.sp, lineHeight = 15.sp, fontFamily = FontFamily.Monospace, softWrap = false)
    }
    if (lines.size > PREVIEW_LINES) Text("… ${lines.size - PREVIEW_LINES} more lines", color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    Text(
      "Copy file",
      color = CyberCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
      modifier = Modifier
        .padding(top = 6.dp)
        .heightIn(min = 32.dp)
        .clickable(role = Role.Button) { clipboard.setText(AnnotatedString(content)) }
    )
  }
}

private const val PREVIEW_LINES = 24

@Composable
private fun ActionPill(label: String, color: Color, filled: Boolean, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .clip(CircleShape)
      .then(if (filled) Modifier.background(color) else Modifier.border(1.dp, color.copy(alpha = 0.55f), CircleShape))
      .clickable(onClickLabel = label, role = Role.Button, onClick = onClick)
      .heightIn(min = 44.dp)
      .padding(horizontal = 18.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(label, color = if (filled) Color.White else color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
  }
}

@Composable
private fun DetailsBody(model: RunTimeline.Model, d: TimelineDetails) {
  Column(
    modifier = Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 12.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    Text(
      if (d.remote) "${d.environment}. The prompt and the project text it needs were sent there." else "${d.environment}. Nothing left this phone.",
      color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp
    )
    d.context?.let { c ->
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text("Context $c", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
        if (d.onShowContext != null) {
          Text(
            "What the AI sees", color = CyberCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clickable(role = Role.Button, onClick = d.onShowContext).heightIn(min = 32.dp).padding(start = 8.dp)
          )
        }
      }
    }
    if (model.state == RunTimeline.State.FAILED && !model.failure.isNullOrBlank()) {
      Text("Error details", color = CyberCoralError, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      Text(model.failure.orEmpty(), color = TextMuted, fontSize = 12.sp, lineHeight = 16.sp, fontFamily = FontFamily.Monospace)
    }
    if (d.log.isNotEmpty()) {
      Text("Step log", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      Column(Modifier.heightIn(max = 200.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(2.dp)) {
        d.log.forEach { line ->
          Text(
            line,
            color = if (line.startsWith("exit ") && !line.startsWith("exit 0")) CyberCoralError else TextMuted,
            fontSize = 11.sp, lineHeight = 15.sp, fontFamily = FontFamily.Monospace
          )
        }
      }
    }
  }
}
