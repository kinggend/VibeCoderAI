package com.example.ui.screens

import android.annotation.SuppressLint
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.filled.Fullscreen
import androidx.compose.material.icons.filled.FullscreenExit
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import com.example.ui.components.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import com.example.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.build.ApkPackager
import com.example.data.model.Project
import com.example.ui.theme.CyberCoralContainer
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private sealed interface ApkUi {
  object Idle : ApkUi
  object Working : ApkUi
  class Done(val file: File) : ApkUi
  class Failed(val message: String) : ApkUi
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun WebPreviewScreen(
  project: Project,
  onBack: () -> Unit,
  onFixErrors: (String) -> Unit
) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val errors = remember { mutableStateListOf<String>() }
  val logs = remember { mutableStateListOf<String>() }
  var showConsole by remember { mutableStateOf(false) }
  var webView by remember { mutableStateOf<WebView?>(null) }
  var gone by remember { mutableStateOf(false) }
  // v1.9.20: set when the page loaded without errors but shows nothing (see PageProbe).
  var pageNote by remember { mutableStateOf<String?>(null) }
  var viewKey by remember { mutableStateOf(0) }
  // v1.9.23: full-screen preview (the toolbar hides, a small exit button floats) and a thin loading bar.
  var fullscreen by remember { mutableStateOf(false) }
  var progress by remember { mutableStateOf(0) }
  androidx.activity.compose.BackHandler(enabled = fullscreen) { fullscreen = false }
  var apk by remember { mutableStateOf<ApkUi>(ApkUi.Idle) }
  val indexFile = File(project.rootDir, "index.html")

  DisposableEffect(Unit) {
    onDispose { webView?.destroy() }
  }

  Box(Modifier.fillMaxSize()) {
  Column(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
    if (!fullscreen) Row(
      modifier = Modifier.fillMaxWidth().background(ObsidianSurface).padding(horizontal = 4.dp, vertical = 2.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      IconButton(onClick = onBack) {
        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
      }
      // The project name is not repeated here (the screen was opened from it); the room goes to the icons.
      androidx.compose.foundation.layout.Spacer(Modifier.weight(1f))
      TextButton(onClick = { showConsole = true }) {
        Text("Console${if (logs.isNotEmpty()) " (${logs.size})" else ""}", fontSize = 13.sp, color = TextSecondary)
      }
      IconButton(onClick = {
        errors.clear()
        logs.clear()
        pageNote = null
        progress = 0
        if (gone) { gone = false; viewKey++ } else webView?.reload()
      }) { Icon(Icons.Default.Refresh, contentDescription = "Reload the preview", tint = TextSecondary) }
      IconButton(onClick = { fullscreen = true }) {
        Icon(Icons.Default.Fullscreen, contentDescription = "Full screen", tint = TextSecondary)
      }
      Button(
        onClick = {
          apk = ApkUi.Working
          scope.launch {
            apk = withContext(Dispatchers.IO) {
              runCatching { ApkPackager.build(context, project.rootDir, project.name) }
                .fold({ ApkUi.Done(it) }, { ApkUi.Failed(it.message ?: it.javaClass.simpleName) })
            }
          }
        },
        enabled = apk !is ApkUi.Working && indexFile.isFile,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
      ) { Text("Build APK", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
    }

    if (progress in 1..99 && !gone) {
      androidx.compose.material3.LinearProgressIndicator(
        progress = progress / 100f,
        modifier = Modifier.fillMaxWidth().height(2.dp),
        color = CyberCyanPrimary,
        trackColor = Color.Transparent
      )
    }

    if (errors.isNotEmpty()) {
      Row(
        modifier = Modifier.fillMaxWidth().background(CyberCoralContainer).padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "${errors.size} JS error(s): ${errors.last()}",
          color = CyberCoralError,
          fontSize = 12.sp,
          maxLines = 2,
          modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { onFixErrors(errors.take(5).joinToString("\n")) }) {
          Text("Fix with AI", fontSize = 12.sp, color = CyberCoralError, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    pageNote?.takeIf { errors.isEmpty() }?.let { note ->
      Row(
        modifier = Modifier.fillMaxWidth().background(CyberCoralContainer).padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = note,
          color = CyberCoralError,
          fontSize = 12.sp,
          maxLines = 4,
          modifier = Modifier.weight(1f)
        )
        TextButton(onClick = { onFixErrors(note) }) {
          Text("Fix with AI", fontSize = 12.sp, color = CyberCoralError, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    if (!indexFile.isFile) {
      // v1.6 honest limitation: say why there is nothing to preview instead of a blank screen.
      val root = project.rootDir
      val pkg = File(root, "package.json").takeIf { it.isFile }?.let { runCatching { it.readText() }.getOrDefault("") }.orEmpty()
      val why = when {
        pkg.contains("react-native") || pkg.contains("\"expo\"") ->
          "This is a React Native / Expo project. Live preview here runs web apps (index.html + CSS + JS) only, so it cannot show React Native screens. Build it on a computer with Expo or Android Studio."
        File(root, "build.gradle.kts").isFile || File(root, "build.gradle").isFile ->
          "This is an Android (Gradle) project. Live preview runs web apps only; Android projects need a Gradle build on a computer or CI."
        File(root, "main.py").isFile || root.listFiles()?.any { it.extension == "py" } == true ->
          "This is a Python project. Live preview runs web apps only; run Python files from the Terminal if a Python runtime is installed."
        else -> "No index.html in this project yet. Ask the agent to build a web app, or create index.html in Projects."
      }
      Text(why, color = TextSecondary, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(16.dp))
    } else {
      if (gone) {
        androidx.compose.foundation.layout.Column(
          Modifier.weight(1f).fillMaxWidth().padding(24.dp),
          verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center,
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Text(
            "The preview stopped: the phone ran low on memory or the page crashed. Your files are safe.",
            color = TextSecondary, fontSize = 14.sp, lineHeight = 20.sp
          )
          androidx.compose.foundation.layout.Spacer(Modifier.height(12.dp))
          TextButton(onClick = { gone = false; viewKey++ }) { Text("Reload preview") }
        }
      } else androidx.compose.runtime.key(viewKey) { AndroidView(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        factory = { ctx ->
          com.example.agent.PreviewFixer.prepare(project.rootDir)
          WebView(ctx).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            // v1.6: project files only (no reading app data via file://), no mixed content, no JS bridge.
            com.example.project.ProjectWebGuard.harden(settings, fileAccess = false)
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            webViewClient = object : com.example.project.ProjectWebGuard.Client(
              project.rootDir,
              onBlocked = { url ->
                if (logs.size < 200) logs.add("[blocked] $url is outside this project, so the preview did not load it.")
              },
              onRenderGone = { crashed ->
                logs.add("[error] The preview process ${if (crashed) "crashed" else "was stopped by Android (low memory)"}.")
                webView?.destroy()
                webView = null
                gone = true
              }
            ) {
              // v1.9.20: a page with no JavaScript errors can still show nothing. Look at what is on screen a moment after it loads.
              override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                val v = view ?: return
                v.postDelayed({
                  runCatching {
                    v.evaluateJavascript(com.example.agent.PageProbe.JS) { raw ->
                      pageNote = com.example.agent.PageProbe.parse(raw).firstOrNull()
                    }
                  }
                }, 2500)
              }
            }
            webChromeClient = object : WebChromeClient() {
              override fun onProgressChanged(view: WebView?, newProgress: Int) { progress = newProgress }
              override fun onConsoleMessage(m: ConsoleMessage): Boolean {
                if (logs.size < 200) logs.add("[${m.messageLevel().name.lowercase()}] ${m.message()} (line ${m.lineNumber()})")
                if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) {
                  errors.add("${m.message()} (line ${m.lineNumber()})")
                }
                return true
              }
            }
            loadUrl(com.example.project.ProjectOrigin.url(project.rootDir))
            webView = this
          }
        }
      ) }
    }
  }
  if (fullscreen) {
    Box(
      modifier = Modifier
        .align(Alignment.TopEnd)
        .padding(8.dp)
        .size(com.example.ui.theme.UiTokens.MinTouchTarget)
        .clip(CircleShape)
        .background(Color.Black.copy(alpha = 0.55f))
        .clickable(onClickLabel = "Exit full screen") { fullscreen = false },
      contentAlignment = Alignment.Center
    ) { Icon(Icons.Default.FullscreenExit, contentDescription = "Exit full screen", tint = Color.White) }
  }
  }

  if (showConsole) {
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { showConsole = false },
      title = { Text("Console") },
      text = {
        Text(
          if (logs.isEmpty()) "No messages." else logs.takeLast(40).joinToString("\n"),
          fontFamily = FontFamily.Monospace,
          fontSize = 11.sp,
          modifier = Modifier.verticalScroll(androidx.compose.foundation.rememberScrollState())
        )
      },
      confirmButton = { TextButton(onClick = { showConsole = false }) { Text("Close") } },
      dismissButton = { TextButton(onClick = { logs.clear(); errors.clear() }) { Text("Clear") } }
    )
  }

  when (val state = apk) {
    ApkUi.Idle -> Unit
    ApkUi.Working -> com.example.ui.components.GlassAlertDialog(
      onDismissRequest = {},
      title = { Text("Building APK") },
      text = { Text("Packaging and signing on this phone...") },
      confirmButton = {}
    )
    is ApkUi.Done -> com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { apk = ApkUi.Idle },
      title = { Text("APK ready") },
      text = { Text("${state.file.name} (${state.file.length() / 1024} KB). Installing replaces the previous app built from VibeCoderAI.") },
      confirmButton = {
        TextButton(onClick = {
          ApkPackager.install(context, state.file)
          apk = ApkUi.Idle
        }) { Text("Install") }
      },
      dismissButton = {
        TextButton(onClick = {
          ApkPackager.share(context, state.file)
          apk = ApkUi.Idle
        }) { Text("Share") }
      }
    )
    is ApkUi.Failed -> com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { apk = ApkUi.Idle },
      title = { Text("Build failed") },
      text = { Text(state.message) },
      confirmButton = { TextButton(onClick = { apk = ApkUi.Idle }) { Text("OK") } }
    )
  }
}
