package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.hypot
import kotlin.math.sin

/*
 * VibeKit: the custom design system for the Models screen (v1.9). No Card, Switch or stock buttons.
 * Everything here is plain foundation + Canvas so it can be restyled in one place.
 */

/** Corner radius used by every card on the Models screen. */
internal val VibeRadius = 24.dp
internal val VibeShape = RoundedCornerShape(VibeRadius)
internal val VibePill = RoundedCornerShape(50)

/**
 * Technical-value typeface. JetBrains Mono is not bundled yet (SIL OFL, add jetbrains_mono_regular/medium/bold.ttf
 * to res/font and replace this line with FontFamily(Font(R.font.jetbrains_mono_regular, FontWeight.Normal), ...)).
 */
internal val Mono: FontFamily = FontFamily.Monospace

// ---------------------------------------------------------------- interaction

/** Spring scale-down while pressed, a light tick on click, no ripple. */
internal fun Modifier.pressable(
  enabled: Boolean = true,
  scaleTo: Float = 0.95f,
  haptic: Boolean = true,
  onClick: () -> Unit
): Modifier = composed {
  val source = remember { MutableInteractionSource() }
  val pressed by source.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (pressed && enabled) scaleTo else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "pressScale"
  )
  val feedback = LocalHapticFeedback.current
  this
    .graphicsLayer { scaleX = scale; scaleY = scale }
    .clickable(interactionSource = source, indication = null, enabled = enabled) {
      if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      onClick()
    }
}

// ---------------------------------------------------------------- atoms

@Composable
internal fun VibeDivider(modifier: Modifier = Modifier) {
  Box(modifier.fillMaxWidth().height(0.5.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

/** Pill tag with a soft tint and no border. [color] defaults to the accent, so sizes and quants follow Appearance. */
@Composable
internal fun VibeChip(text: String, color: Color = Color.Unspecified) {
  val c = if (color == Color.Unspecified) MaterialTheme.colorScheme.primary else color
  Text(
    text.uppercase(),
    color = c, fontFamily = Mono, fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.6.sp, maxLines = 1,
    modifier = Modifier
      .clip(VibePill)
      .background(c.copy(alpha = 0.14f))
      .padding(horizontal = 10.dp, vertical = 4.dp)
  )
}

@Composable
internal fun VibeButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  primary: Boolean = false,
  enabled: Boolean = true
) {
  val accent = MaterialTheme.colorScheme.primary
  Box(
    modifier = modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .alpha(if (enabled) 1f else 0.45f)
      .pressable(enabled = enabled, onClick = onClick)
      .clip(VibePill)
      .background(if (primary) accent else accent.copy(alpha = 0.12f))
      .padding(horizontal = 20.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text,
      color = if (primary) MaterialTheme.colorScheme.onPrimary else accent,
      fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1
    )
  }
}

/** Text-only action (UNLOAD): scales on press, 48 dp target. */
@Composable
internal fun VibeTextAction(text: String, color: Color, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .pressable(onClick = onClick)
      .padding(horizontal = 10.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(text.uppercase(), color = color, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp)
  }
}

@Composable
internal fun VibeIconAction(contentDescription: String, tint: Color, onClick: () -> Unit) {
  Box(
    modifier = Modifier.size(48.dp).pressable(scaleTo = 0.85f, onClick = onClick),
    contentAlignment = Alignment.Center
  ) { Icon(Icons.Default.Delete, contentDescription, tint = tint, modifier = Modifier.size(20.dp)) }
}

/** Status dot with a soft breathing halo while [pulsing]. */
@Composable
internal fun VibeStatus(text: String, color: Color, pulsing: Boolean) {
  val transition = rememberInfiniteTransition(label = "vibeStatus")
  val halo by transition.animateFloat(
    initialValue = 0.15f, targetValue = if (pulsing) 0.55f else 0.15f,
    animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "halo"
  )
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier.size(14.dp).drawBehind { drawCircle(color.copy(alpha = halo), radius = size.minDimension / 2f) },
      contentAlignment = Alignment.Center
    ) { Box(Modifier.size(6.dp).clip(CircleShape).background(color)) }
    Spacer(Modifier.width(6.dp))
    Text(text.uppercase(), color = color, fontFamily = Mono, fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp)
  }
}

/** Label over value, both monospaced: SIZE / 2.50 GB. */
@Composable
internal fun VibeSpec(label: String, value: String, color: Color = TextPrimary, modifier: Modifier = Modifier) {
  Column(modifier) {
    Text(label.uppercase(), color = TextMuted, fontFamily = Mono, fontSize = 10.sp, letterSpacing = 1.sp)
    Text(value, color = color, fontFamily = Mono, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
  }
}

// ---------------------------------------------------------------- hero card

internal enum class HeroState { READY, WARN, LOADING, IDLE }

/**
 * One soft rounded card in three tints, all from the theme: READY accent-tinted with an accent rim, WARN red-tinted with a
 * red rim (the only non-accent colour, because it is a warning), LOADING/IDLE a quiet neutral surface.
 */
@Composable
internal fun HeroModelCard(state: HeroState, content: @Composable ColumnScope.() -> Unit) {
  val accent = MaterialTheme.colorScheme.primary
  val (bg, rim) = when (state) {
    HeroState.WARN -> CyberCoralError.copy(alpha = 0.12f) to CyberCoralError.copy(alpha = 0.45f)
    HeroState.READY -> accent.copy(alpha = 0.10f) to accent.copy(alpha = 0.45f)
    HeroState.LOADING -> accent.copy(alpha = 0.06f) to accent.copy(alpha = 0.22f)
    HeroState.IDLE -> MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f) to Color.Transparent
  }
  val bgAnim by animateColorAsState(bg, tween(300), label = "heroBg")
  val rimAnim by animateColorAsState(rim, tween(300), label = "heroRim")
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .clip(VibeShape)
      .background(bgAnim)
      .border(1.dp, rimAnim, VibeShape)
      .padding(20.dp),
    content = content
  )
}

// ---------------------------------------------------------------- model list

/** Soft rounded row. Selected: accent-tinted background and a rounded accent rim. No left bar, no dividers. */
@Composable
internal fun VibeModelRow(
  selected: Boolean,
  onClick: () -> Unit,
  trailing: @Composable () -> Unit,
  content: @Composable ColumnScope.() -> Unit
) {
  val accent = MaterialTheme.colorScheme.primary
  val neutral = MaterialTheme.colorScheme.onSurface
  val bg by animateColorAsState(if (selected) accent.copy(alpha = 0.10f) else neutral.copy(alpha = 0.04f), tween(250), label = "rowBg")
  val rim by animateColorAsState(if (selected) accent.copy(alpha = 0.5f) else Color.Transparent, tween(250), label = "rowRim")
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .pressable(scaleTo = 0.985f, onClick = onClick)
      .clip(VibeShape)
      .background(bg)
      .border(1.dp, rim, VibeShape)
      .padding(start = 18.dp, end = 6.dp, top = 14.dp, bottom = 14.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Column(Modifier.weight(1f), content = content)
    trailing()
  }
}

// ---------------------------------------------------------------- hardware gauge

/**
 * One rounded bar: accent fill for the memory this model needs, neutral grey track for the rest. If it needs more than
 * is free the fill turns red, a tick marks where free RAM ends, and a red halo pulses behind the bar.
 */
@Composable
internal fun HardwareGauge(requiredMb: Long, freeMb: Long, modifier: Modifier = Modifier) {
  val over = freeMb > 0 && requiredMb > freeMb
  val scale = maxOf(requiredMb, freeMb, 1L).toFloat()
  val spec = tween<Float>(450, easing = FastOutSlowInEasing)
  val fill by animateFloatAsState(requiredMb / scale, spec, label = "gaugeFill")
  val freeAt by animateFloatAsState(if (freeMb > 0) freeMb / scale else 1f, spec, label = "gaugeFree")
  val overAmount by animateFloatAsState(if (over) 1f else 0f, tween(250), label = "gaugeOver")
  val pulse by rememberInfiniteTransition(label = "gaugePulse").animateFloat(
    initialValue = 0.05f, targetValue = 0.35f,
    animationSpec = infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
  )
  val accent = MaterialTheme.colorScheme.primary
  val track = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
  val tick = MaterialTheme.colorScheme.onSurface
  val red = CyberCoralError
  Canvas(
    modifier = modifier
      .fillMaxWidth()
      .height(24.dp)
      .drawBehind {
        if (overAmount > 0.01f) {
          drawRoundRect(
            red.copy(alpha = pulse * overAmount),
            topLeft = Offset(-6.dp.toPx(), 0f),
            size = Size(size.width + 12.dp.toPx(), size.height),
            cornerRadius = CornerRadius(size.height / 2f)
          )
        }
      }
  ) {
    val thick = 10.dp.toPx()
    val r = thick / 2f
    val y = size.height / 2f
    drawLine(track, Offset(r, y), Offset(size.width - r, y), strokeWidth = thick, cap = StrokeCap.Round)
    val end = (fill * size.width - r).coerceIn(r, size.width - r)
    drawLine(if (over) red else accent, Offset(r, y), Offset(end, y), strokeWidth = thick, cap = StrokeCap.Round)
    if (over) {
      val mx = (freeAt * size.width).coerceIn(r, size.width - r)
      drawLine(tick, Offset(mx, y - 8.dp.toPx()), Offset(mx, y + 8.dp.toPx()), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
    }
  }
}

/** Plain mono caption under the gauge. */
@Composable
internal fun GaugeLegend(label: String, value: String) {
  Text("$label $value", color = TextSecondary, fontFamily = Mono, fontSize = 10.sp, maxLines = 1)
}

// ---------------------------------------------------------------- segmented control

/**
 * Pill segmented control. One accent thumb slides between segments on a spring; each change ticks the haptics.
 * [onBlocked] fires for a tap on a disabled segment.
 */
@Composable
internal fun VibeSegmented(
  options: List<Int>,
  selected: Int,
  isEnabled: (Int) -> Boolean,
  onSelect: (Int) -> Unit,
  onBlocked: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val index = options.indexOf(selected).coerceAtLeast(0)
  val feedback = LocalHapticFeedback.current
  val accent = MaterialTheme.colorScheme.primary
  val onAccent = MaterialTheme.colorScheme.onPrimary
  BoxWithConstraints(
    modifier = modifier
      .fillMaxWidth()
      .height(46.dp)
      .clip(VibePill)
      .background(MaterialTheme.colorScheme.onSurface.copy(alpha = 0.07f))
      .padding(4.dp)
  ) {
    val segment = maxWidth / options.size
    val thumbX by animateDpAsState(segment * index, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow), label = "thumb")
    Box(
      Modifier
        .offset(x = thumbX)
        .width(segment)
        .fillMaxHeight()
        .clip(VibePill)
        .background(accent)
    )
    Row(Modifier.fillMaxWidth().fillMaxHeight()) {
      options.forEach { option ->
        val on = option == selected
        val allowed = isEnabled(option)
        val textColor by animateColorAsState(if (on) onAccent else TextSecondary, tween(200), label = "segText")
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
              if (!allowed) {
                feedback.performHapticFeedback(HapticFeedbackType.LongPress)
                onBlocked()
              } else if (!on) {
                feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onSelect(option)
              }
            },
          contentAlignment = Alignment.Center
        ) {
          Text(
            "$option", color = textColor, fontFamily = Mono, fontSize = 13.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.alpha(if (allowed) 1f else 0.35f)
          )
        }
      }
    }
  }
}

/** Semantic only: red when it does not fit, orange when tight, otherwise normal text. */
internal fun fitColor(over: Boolean, tight: Boolean): Color = when {
  over -> CyberCoralError
  tight -> CyberAmberWarning
  else -> TextPrimary
}
