package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlin.math.hypot
import kotlin.math.sin

/*
 * VibeKit: the custom design system for the Models screen (v1.9). No Card, Switch or stock buttons.
 * Everything here is plain foundation + Canvas so it can be restyled in one place.
 */

internal val VibePurple = Color(0xFFA855F7)
internal val VibeCyan = Color(0xFF22D3EE)
internal val VibeViolet = Color(0xFF7C3AED)

/**
 * Technical-value typeface. JetBrains Mono is not bundled yet (SIL OFL, add jetbrains_mono_regular/medium/bold.ttf
 * to res/font and replace this line with FontFamily(Font(R.font.jetbrains_mono_regular, FontWeight.Normal), ...)).
 */
internal val Mono: FontFamily = FontFamily.Monospace

// ---------------------------------------------------------------- interaction

/** Spring scale-down while pressed, a light tick on click, no ripple. */
internal fun Modifier.pressable(
  enabled: Boolean = true,
  scaleTo: Float = 0.95f,
  haptic: Boolean = true,
  onClick: () -> Unit
): Modifier = composed {
  val source = remember { MutableInteractionSource() }
  val pressed by source.collectIsPressedAsState()
  val scale by animateFloatAsState(
    targetValue = if (pressed && enabled) scaleTo else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "pressScale"
  )
  val feedback = LocalHapticFeedback.current
  this
    .graphicsLayer { scaleX = scale; scaleY = scale }
    .clickable(interactionSource = source, indication = null, enabled = enabled) {
      if (haptic) feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
      onClick()
    }
}

/**
 * Rotating sweep-gradient border with a breathing outer glow. The content must paint its own opaque background
 * inset by the border width, so only the rim of the gradient stays visible.
 */
internal fun Modifier.glowBorder(radius: Dp, colors: List<Color>, glow: Boolean = true): Modifier = composed {
  val transition = rememberInfiniteTransition(label = "glowBorder")
  val angle by transition.animateFloat(
    initialValue = 0f, targetValue = 360f,
    animationSpec = infiniteRepeatable(tween(5000, easing = LinearEasing)), label = "angle"
  )
  val pulse by transition.animateFloat(
    initialValue = 0.25f, targetValue = 0.6f,
    animationSpec = infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
  )
  this.drawBehind {
    val r = radius.toPx()
    val path = Path().apply { addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r))) }
    if (glow) {
      val mix = lerp(colors.first(), colors.last(), (sin(Math.toRadians(angle.toDouble())).toFloat() + 1f) / 2f)
      for (i in 1..4) {
        drawPath(path, mix.copy(alpha = pulse * 0.10f * (5 - i)), style = Stroke(width = (i * 3).dp.toPx()))
      }
    }
    clipPath(path) {
      rotate(angle, center) {
        drawCircle(
          brush = Brush.sweepGradient(colors + colors.first(), center),
          radius = hypot(size.width, size.height) / 2f,
          center = center
        )
      }
    }
  }
}

// ---------------------------------------------------------------- atoms

@Composable
internal fun VibeDivider(modifier: Modifier = Modifier) {
  Box(modifier.fillMaxWidth().height(0.5.dp).background(MaterialTheme.colorScheme.outlineVariant))
}

/** Small, uppercase, 6 dp radius tag: cyan for sizes (4B), purple for quants (Q4_K_M), tinted for status. */
@Composable
internal fun VibeChip(text: String, color: Color) {
  Text(
    text.uppercase(),
    color = color, fontFamily = Mono, fontSize = 10.sp, fontWeight = FontWeight.Medium, letterSpacing = 0.6.sp, maxLines = 1,
    modifier = Modifier
      .clip(RoundedCornerShape(6.dp))
      .background(color.copy(alpha = 0.10f))
      .border(0.5.dp, color.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
      .padding(horizontal = 7.dp, vertical = 3.dp)
  )
}

/** Colour rule for a tag from [modelTags]: sizes cyan, everything else (quant) purple. */
internal fun vibeTagColor(tag: String): Color =
  if (Regex("""^\d+(\.\d+)?B$""").matches(tag)) VibeCyan else VibePurple

@Composable
internal fun VibeButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  primary: Boolean = false,
  enabled: Boolean = true
) {
  val shape = RoundedCornerShape(10.dp)
  val look = if (primary) {
    Modifier.background(Brush.horizontalGradient(listOf(VibePurple, VibeViolet)), shape)
  } else {
    Modifier
      .background(TextPrimary.copy(alpha = 0.05f), shape)
      .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, shape)
  }
  Box(
    modifier = modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .alpha(if (enabled) 1f else 0.45f)
      .pressable(enabled = enabled, onClick = onClick)
      .clip(shape)
      .then(look)
      .padding(horizontal = 16.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text,
      color = if (primary) Color.White else TextPrimary,
      fontFamily = Mono, fontSize = 13.sp, fontWeight = FontWeight.Medium, maxLines = 1
    )
  }
}

/** Text-only action (UNLOAD): scales on press, 48 dp target. */
@Composable
internal fun VibeTextAction(text: String, color: Color, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .pressable(onClick = onClick)
      .padding(horizontal = 10.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(text.uppercase(), color = color, fontFamily = Mono, fontSize = 12.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp)
  }
}

@Composable
internal fun VibeIconAction(contentDescription: String, tint: Color, onClick: () -> Unit) {
  Box(
    modifier = Modifier.size(48.dp).pressable(scaleTo = 0.85f, onClick = onClick),
    contentAlignment = Alignment.Center
  ) { Icon(Icons.Default.Delete, contentDescription, tint = tint, modifier = Modifier.size(20.dp)) }
}

/** Status dot with a soft breathing halo while [pulsing]. */
@Composable
internal fun VibeStatus(text: String, color: Color, pulsing: Boolean) {
  val transition = rememberInfiniteTransition(label = "vibeStatus")
  val halo by transition.animateFloat(
    initialValue = 0.15f, targetValue = if (pulsing) 0.55f else 0.15f,
    animationSpec = infiniteRepeatable(tween(900, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "halo"
  )
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(
      modifier = Modifier.size(14.dp).drawBehind { drawCircle(color.copy(alpha = halo), radius = size.minDimension / 2f) },
      contentAlignment = Alignment.Center
    ) { Box(Modifier.size(6.dp).clip(CircleShape).background(color)) }
    Spacer(Modifier.width(6.dp))
    Text(text.uppercase(), color = color, fontFamily = Mono, fontSize = 11.sp, fontWeight = FontWeight.Medium, letterSpacing = 1.sp)
  }
}

/** Label over value, both monospaced: SIZE / 2.50 GB. */
@Composable
internal fun VibeSpec(label: String, value: String, color: Color = TextPrimary, modifier: Modifier = Modifier) {
  Column(modifier) {
    Text(label.uppercase(), color = TextMuted, fontFamily = Mono, fontSize = 9.sp, letterSpacing = 1.sp)
    Text(value, color = color, fontFamily = Mono, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
  }
}

// ---------------------------------------------------------------- hero card

internal enum class HeroState { READY, WARN, LOADING, IDLE }

/**
 * READY: rotating purple-to-cyan border with glow. WARN: dark translucent red, square-ish corners and a sharp red
 * left rail. LOADING/IDLE: quiet hairline panel.
 */
@Composable
internal fun HeroModelCard(state: HeroState, content: @Composable ColumnScope.() -> Unit) {
  val outline = MaterialTheme.colorScheme.outlineVariant
  when (state) {
    HeroState.WARN -> Row(
      modifier = Modifier
        .fillMaxWidth()
        .height(IntrinsicSize.Min)
        .clip(RoundedCornerShape(6.dp))
        .background(CyberCoralError.copy(alpha = 0.12f))
    ) {
      Box(Modifier.width(3.dp).fillMaxHeight().background(CyberCoralError))
      Column(Modifier.weight(1f).padding(16.dp), content = content)
    }
    HeroState.READY -> Box(
      modifier = Modifier.fillMaxWidth().glowBorder(16.dp, listOf(VibePurple, VibeCyan, VibePurple))
    ) {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(1.5.dp)
          .clip(RoundedCornerShape(14.5.dp))
          .background(ObsidianSurfaceSolid)
          .padding(16.dp),
        content = content
      )
    }
    else -> Column(
      modifier = Modifier
        .fillMaxWidth()
        .clip(RoundedCornerShape(16.dp))
        .background(ObsidianSurfaceSolid)
        .border(0.5.dp, outline, RoundedCornerShape(16.dp))
        .padding(16.dp),
      content = content
    )
  }
}

// ---------------------------------------------------------------- model list

/** Flat list row: lighter tint plus a gradient pill on the left edge that grows in when selected. */
@Composable
internal fun VibeModelRow(
  selected: Boolean,
  onClick: () -> Unit,
  trailing: @Composable () -> Unit,
  content: @Composable ColumnScope.() -> Unit
) {
  val tint by animateColorAsState(if (selected) VibePurple.copy(alpha = 0.08f) else Color.Transparent, tween(250), label = "rowTint")
  val pill by animateDpAsState(if (selected) 30.dp else 0.dp, spring(dampingRatio = 0.6f, stiffness = Spring.StiffnessMedium), label = "rowPill")
  Box(Modifier.fillMaxWidth().background(tint).pressable(scaleTo = 0.985f, onClick = onClick)) {
    Box(
      Modifier
        .align(Alignment.CenterStart)
        .width(3.dp)
        .height(pill)
        .clip(RoundedCornerShape(topEnd = 3.dp, bottomEnd = 3.dp))
        .background(Brush.verticalGradient(listOf(VibeCyan, VibePurple)))
    )
    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 4.dp, top = 12.dp, bottom = 12.dp), verticalAlignment = Alignment.CenterVertically) {
      Column(Modifier.weight(1f), content = content)
      trailing()
    }
  }
}

// ---------------------------------------------------------------- hardware gauge

/**
 * Multi-layer memory bar: weights, KV cache (grows with the context window) and runtime overhead stacked left to
 * right on one track, with a marker at free RAM. Anything past the marker is painted red, and while the request
 * does not fit a red halo pulses behind the bar.
 */
@Composable
internal fun HardwareGauge(weightsMb: Long, kvMb: Long, overheadMb: Long, freeMb: Long, modifier: Modifier = Modifier) {
  val required = weightsMb + kvMb + overheadMb
  val over = freeMb > 0 && required > freeMb
  val scale = maxOf(required, freeMb, 1L).toFloat()
  val spec = tween<Float>(450, easing = FastOutSlowInEasing)
  val fw by animateFloatAsState(weightsMb / scale, spec, label = "gw")
  val fk by animateFloatAsState(kvMb / scale, spec, label = "gk")
  val fo by animateFloatAsState(overheadMb / scale, spec, label = "go")
  val ff by animateFloatAsState(if (freeMb > 0) freeMb / scale else 1f, spec, label = "gf")
  val overAmount by animateFloatAsState(if (over) 1f else 0f, tween(250), label = "gover")
  val transition = rememberInfiniteTransition(label = "gaugePulse")
  val pulse by transition.animateFloat(
    initialValue = 0.05f, targetValue = 0.38f,
    animationSpec = infiniteRepeatable(tween(650, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "pulse"
  )
  val track = MaterialTheme.colorScheme.outlineVariant
  val overhead = TextMuted
  val red = CyberCoralError
  val marker = TextPrimary
  Canvas(
    modifier = modifier
      .fillMaxWidth()
      .height(28.dp)
      .drawBehind {
        if (overAmount > 0.01f) {
          drawRoundRect(
            red.copy(alpha = pulse * overAmount),
            topLeft = Offset(-6.dp.toPx(), 1.dp.toPx()),
            size = Size(size.width + 12.dp.toPx(), size.height - 2.dp.toPx()),
            cornerRadius = CornerRadius(10.dp.toPx())
          )
        }
      }
  ) {
    val barTop = 7.dp.toPx()
    val barH = 14.dp.toPx()
    val corner = CornerRadius(5.dp.toPx())
    val gap = 2.dp.toPx()
    val bar = Path().apply { addRoundRect(RoundRect(0f, barTop, size.width, barTop + barH, corner)) }
    drawRoundRect(track.copy(alpha = 0.55f), Offset(0f, barTop), Size(size.width, barH), corner)
    clipPath(bar) {
      var x = 0f
      listOf(fw to VibePurple, fk to VibeCyan, fo to overhead.copy(alpha = 0.8f)).forEach { (f, c) ->
        val w = f * size.width
        if (w > 0.5f) drawRect(c, Offset(x, barTop), Size((w - gap).coerceAtLeast(0.5f), barH))
        x += w
      }
      // The part of the stack that sticks out past free RAM.
      val freeX = ff * size.width
      if (over && x > freeX) drawRect(red.copy(alpha = 0.55f * overAmount), Offset(freeX, barTop), Size(x - freeX, barH))
    }
    val mx = (ff * size.width).coerceIn(1.dp.toPx(), size.width - 1.dp.toPx())
    drawLine(marker, Offset(mx, barTop - 5.dp.toPx()), Offset(mx, barTop + barH + 5.dp.toPx()), strokeWidth = 2.dp.toPx())
  }
}

/** Colour square + mono caption, used under the gauge. */
@Composable
internal fun GaugeLegend(color: Color, label: String, value: String) {
  Row(verticalAlignment = Alignment.CenterVertically) {
    Box(Modifier.size(7.dp).clip(RoundedCornerShape(2.dp)).background(color))
    Spacer(Modifier.width(5.dp))
    Text("$label $value", color = TextSecondary, fontFamily = Mono, fontSize = 10.sp, maxLines = 1)
  }
}

// ---------------------------------------------------------------- segmented control

/**
 * Pill segmented control. One gradient thumb slides between segments on a spring; each change ticks the haptics.
 * [onBlocked] fires for a tap on a disabled segment.
 */
@Composable
internal fun VibeSegmented(
  options: List<Int>,
  selected: Int,
  isEnabled: (Int) -> Boolean,
  onSelect: (Int) -> Unit,
  onBlocked: () -> Unit = {},
  modifier: Modifier = Modifier
) {
  val index = options.indexOf(selected).coerceAtLeast(0)
  val feedback = LocalHapticFeedback.current
  BoxWithConstraints(
    modifier = modifier
      .fillMaxWidth()
      .height(42.dp)
      .clip(RoundedCornerShape(14.dp))
      .background(TextPrimary.copy(alpha = 0.05f))
      .border(0.5.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(14.dp))
      .padding(3.dp)
  ) {
    val segment = maxWidth / options.size
    val thumbX by animateDpAsState(segment * index, spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMediumLow), label = "thumb")
    Box(
      Modifier
        .offset(x = thumbX)
        .width(segment)
        .fillMaxHeight()
        .clip(RoundedCornerShape(11.dp))
        .background(Brush.horizontalGradient(listOf(VibeViolet, VibePurple)))
    )
    Row(Modifier.fillMaxWidth().fillMaxHeight()) {
      options.forEach { option ->
        val on = option == selected
        val allowed = isEnabled(option)
        val textColor by animateColorAsState(if (on) Color.White else TextSecondary, tween(200), label = "segText")
        Box(
          modifier = Modifier
            .weight(1f)
            .fillMaxHeight()
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {
              if (!allowed) {
                feedback.performHapticFeedback(HapticFeedbackType.LongPress)
                onBlocked()
              } else if (!on) {
                feedback.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onSelect(option)
              }
            },
          contentAlignment = Alignment.Center
        ) {
          Text(
            "$option", color = textColor, fontFamily = Mono, fontSize = 13.sp,
            fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
            modifier = Modifier.alpha(if (allowed) 1f else 0.35f)
          )
        }
      }
    }
  }
}

internal fun fitColor(over: Boolean, tight: Boolean): Color = when {
  over -> CyberCoralError
  tight -> CyberAmberWarning
  else -> CyberGreenSuccess
}
