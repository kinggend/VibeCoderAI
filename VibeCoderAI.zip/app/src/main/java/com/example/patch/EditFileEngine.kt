package com.example.patch

/** Outcome of a pure text edit: the new text, or why the edit was refused. */
sealed class EditResult {
  data class Ok(val text: String, val line: Int) : EditResult()
  data class Fail(val reason: String) : EditResult()
}

/**
 * v1.4 EditFile: exact find/replace. Refuses when [find] is empty, missing, or matches more than once,
 * so an edit can never land somewhere the model did not mean. Pure: no I/O, unit tested.
 */
object EditFileEngine {

  /** Non-overlapping occurrences of [needle] in [hay]. */
  fun countOccurrences(hay: String, needle: String): Int {
    if (needle.isEmpty()) return 0
    var count = 0
    var from = 0
    while (true) {
      val i = hay.indexOf(needle, from)
      if (i < 0) return count
      count++
      from = i + needle.length
    }
  }

  fun apply(original: String, find: String, replace: String): EditResult {
    if (find.isEmpty()) return EditResult.Fail("EditFile needs non-empty <find> text.")
    var f = find
    var r = replace
    var n = countOccurrences(original, f)
    // Files saved with CRLF: the model writes LF. Retry with CRLF line endings.
    if (n == 0 && original.contains("\r\n") && f.contains('\n') && !f.contains("\r\n")) {
      f = f.replace("\n", "\r\n")
      r = r.replace("\r\n", "\n").replace("\n", "\r\n")
      n = countOccurrences(original, f)
    }
    return when {
      n == 0 -> EditResult.Fail("Find text not found. Read the file and copy the exact text.")
      n > 1 -> EditResult.Fail("Find text matches $n places. Include more surrounding lines so it is unique.")
      else -> {
        val idx = original.indexOf(f)
        val line = original.substring(0, idx).count { it == '\n' } + 1
        EditResult.Ok(original.substring(0, idx) + r + original.substring(idx + f.length), line)
      }
    }
  }

  /**
   * v1.8.4: a find text that matches several places (typically a duplicated declaration, which is
   * identical text by nature) is widened with the lines above it until it is unique, choosing the
   * occurrence nearest [hintLine] (1-based, from the error message). Returns null when it cannot.
   */
  fun disambiguate(original: String, find: String, hintLine: Int?): String? {
    if (find.isEmpty() || hintLine == null) return null
    if (countOccurrences(original, find) < 2) return null
    val starts = mutableListOf<Int>()
    var from = 0
    while (true) {
      val i = original.indexOf(find, from)
      if (i < 0) break
      starts += i
      from = i + find.length
    }
    fun lineOf(idx: Int) = original.substring(0, idx).count { it == '\n' } + 1
    val target = starts.minByOrNull { kotlin.math.abs(lineOf(it) - hintLine) } ?: return null
    // Widen upward by whole lines.
    var begin = target
    repeat(6) {
      val prev = original.lastIndexOf('\n', begin - 2)
      begin = if (prev < 0) 0 else prev + 1
      val wide = original.substring(begin, target + find.length)
      if (countOccurrences(original, wide) == 1) return wide
      if (begin == 0) return null
    }
    return null
  }

  /** First "line N" / ":N" number in a JS error message, or null. */
  fun hintLineFrom(errors: List<String>): Int? {
    val re = Regex("""line\s+(\d+)""", RegexOption.IGNORE_CASE)
    return errors.firstNotNullOfOrNull { re.find(it)?.groupValues?.get(1)?.toIntOrNull() }
  }
}
