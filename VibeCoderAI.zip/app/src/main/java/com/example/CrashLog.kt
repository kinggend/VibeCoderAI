package com.example

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import java.io.File

/**
 * v1.9.9: saves the stack trace of an uncaught exception to a file before the process dies, and shows it on the next
 * launch with a Copy button, so "the app went to the home screen" comes with the exact line that crashed.
 */
object CrashLog {
  private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

  @Volatile private var installed = false

  fun install(ctx: Context) {
    if (installed) return // the activity is recreated on rotation; chaining a handler each time would write the trace repeatedly
    installed = true
    val app = ctx.applicationContext
    val previous = Thread.getDefaultUncaughtExceptionHandler()
    Thread.setDefaultUncaughtExceptionHandler { t, e ->
      runCatching {
        val text = buildString {
          append("thread: ").append(t.name).append('\n')
          append(com.example.transparency.Redact.text(android.util.Log.getStackTraceString(e).take(6000)))
        }
        file(app).writeText(text)
      }
      previous?.uncaughtException(t, e)
    }
  }

  /** Shows and clears the saved trace; returns true when a dialog was shown. */
  fun showIfAny(activity: Activity): Boolean {
    val f = file(activity)
    if (!f.exists()) return false
    val text = runCatching { f.readText() }.getOrNull().orEmpty()
    f.delete()
    if (text.isBlank()) return false
    runCatching {
      val tv = android.widget.TextView(activity).apply {
        this.text = text
        textSize = 10f
        typeface = android.graphics.Typeface.MONOSPACE
        setTextIsSelectable(true)
        setPadding(40, 20, 40, 20)
      }
      val scroll = android.widget.ScrollView(activity).apply { addView(tv) }
      android.app.AlertDialog.Builder(activity)
        .setTitle("The app crashed last time")
        .setView(scroll)
        .setPositiveButton("Copy") { _, _ ->
          val cm = activity.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
          cm.setPrimaryClip(ClipData.newPlainText("crash", text))
        }
        .setNegativeButton("Close", null)
        .show()
    }
    return true
  }
}
