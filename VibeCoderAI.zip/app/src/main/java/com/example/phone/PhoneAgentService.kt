package com.example.phone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * v1.7.0: the Phone agent's eyes and hands. The user turns it on in Android's Accessibility settings
 * after the in-app disclosure. It only reads or acts while a phone task the user started is running
 * (PhoneAgent calls it); it does nothing with events on its own.
 */
class PhoneAgentService : AccessibilityService() {

  /** Screen read for one step. [nodes] maps element ids to live nodes for acting on them. */
  class Snapshot(val pkg: String, val root: List<UiNode>, val nodes: Map<Int, AccessibilityNodeInfo>, val width: Int, val height: Int)

  private var overlay: LinearLayout? = null
  private var overlayTitle: TextView? = null
  private var overlayDetail: TextView? = null
  private var overlayButtons: LinearLayout? = null

  override fun onServiceConnected() {
    instance = this
    _connected.value = true
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
  override fun onInterrupt() = Unit

  override fun onDestroy() {
    hideOverlay()
    if (instance === this) instance = null
    _connected.value = false
    super.onDestroy()
  }

  // ---- Reading the screen ----

  /** Package of the app on screen right now (cheap: no tree walk), or null when unknown. */
  fun foregroundPkg(): String? = runCatching {
    rootInActiveWindow?.packageName?.toString()
      ?: windows.firstOrNull { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION }?.root?.packageName?.toString()
  }.getOrNull()

  fun snapshot(): Snapshot? {
    // Active window first, then other app windows (some apps keep focus on a small window or dialog).
    val active = rootInActiveWindow
    val appRoots = runCatching {
      windows.filter { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION }.mapNotNull { it.root }
    }.getOrDefault(emptyList())
    val roots = (listOfNotNull(active) + appRoots.filter { r -> active == null || r != active }).distinct()
    val root = roots.firstOrNull() ?: return null
    val pkg = root.packageName?.toString().orEmpty()
    val map = HashMap<Int, AccessibilityNodeInfo>()
    var next = 1
    val r = Rect()
    // shortcut: 400 nodes / depth 30 cap keeps a step cheap; raise if long lists lose items.
    fun read(n: AccessibilityNodeInfo, depth: Int): UiNode? {
      if (depth > 30 || map.size >= 400 || !n.isVisibleToUser) return null
      n.getBoundsInScreen(r)
      val id = next++
      map[id] = n
      val kids = (0 until n.childCount).mapNotNull { i -> n.getChild(i)?.let { read(it, depth + 1) } }
      return UiNode(
        id = id, text = if (n.isPassword) null else n.text?.toString(), desc = n.contentDescription?.toString(),
        hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString() else null,
        resId = n.viewIdResourceName, cls = n.className?.toString(),
        left = r.left, top = r.top, right = r.right, bottom = r.bottom,
        clickable = n.isClickable, longClickable = n.isLongClickable, editable = n.isEditable,
        scrollable = n.isScrollable, password = n.isPassword,
        checked = if (n.isCheckable) n.isChecked else null, enabled = n.isEnabled, children = kids
      )
    }
    val tree = roots.filter { it.packageName?.toString() == pkg || it == root }.mapNotNull { read(it, 0) }
    val dm = resources.displayMetrics
    return Snapshot(pkg, tree, map, dm.widthPixels, dm.heightPixels)
  }

  /** JPEG data URL of the screen (API 30+), with the overlay hidden. Null when not possible or a secure window. */
  suspend fun screenshot(): String? {
    if (Build.VERSION.SDK_INT < 30) return null
    overlay?.visibility = View.INVISIBLE
    try {
      return suspendCancellableCoroutine { cont ->
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
          override fun onSuccess(result: ScreenshotResult) {
            val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
            result.hardwareBuffer.close()
            if (soft == null) { cont.resume(null); return }
            // 720 px wide: small toolbar icons in 3D and video apps stay readable.
            val scale = PhoneAgent.SHOT_W.toFloat() / soft.width
            val small = if (scale < 1f) Bitmap.createScaledBitmap(soft, PhoneAgent.SHOT_W, (soft.height * scale).toInt(), true) else soft
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 60, out)
            cont.resume("data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
          }
          override fun onFailure(errorCode: Int) { cont.resume(null) }
        })
      }
    } finally {
      overlay?.visibility = View.VISIBLE
    }
  }

  // ---- Acting ----

  private fun clickableAncestor(n: AccessibilityNodeInfo, long: Boolean): AccessibilityNodeInfo? {
    var cur: AccessibilityNodeInfo? = n
    var hops = 0
    while (cur != null && hops < 6) {
      if (if (long) cur.isLongClickable else cur.isClickable) return cur
      cur = cur.parent; hops++
    }
    return null
  }

  suspend fun tap(n: AccessibilityNodeInfo, long: Boolean = false): Boolean {
    val target = clickableAncestor(n, long)
    if (target?.performAction(if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK) == true) return true
    val r = Rect().also { n.getBoundsInScreen(it) }
    return gesture(r.exactCenterX(), r.exactCenterY(), r.exactCenterX(), r.exactCenterY(), if (long) 700 else 60)
  }

  fun type(n: AccessibilityNodeInfo?, text: String): Boolean {
    val field = n?.takeIf { it.isEditable } ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: return false
    field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    val args = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
    return field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
  }

  fun enter(): Boolean {
    if (Build.VERSION.SDK_INT < 30) return false
    val field = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
    return field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
  }

  suspend fun scroll(direction: String, n: AccessibilityNodeInfo?, w: Int, h: Int): Boolean {
    if (n != null && n.isScrollable) {
      val forward = direction == "down" || direction == "right"
      if (n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true
    }
    val cx = w / 2f; val cy = h / 2f
    return when (direction) {
      "up" -> gesture(cx, h * 0.3f, cx, h * 0.75f, 350)
      "left" -> gesture(w * 0.2f, cy, w * 0.8f, cy, 350)
      "right" -> gesture(w * 0.8f, cy, w * 0.2f, cy, 350)
      else -> gesture(cx, h * 0.75f, cx, h * 0.3f, 350)
    }
  }

  /** A tap or swipe on screen, with the overlay hidden so it never catches the touch. */
  suspend fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
    val path = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
    val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms.coerceAtLeast(1))).build()
    overlay?.visibility = View.INVISIBLE
    try {
      return suspendCancellableCoroutine { cont ->
        val sent = dispatchGesture(g, object : GestureResultCallback() {
          override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
          override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!sent && cont.isActive) cont.resume(false)
      }
    } finally {
      overlay?.visibility = View.VISIBLE
    }
  }

  fun global(action: Int): Boolean = performGlobalAction(action)

  fun launch(intent: Intent): Boolean = runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)

  fun installedApps(): List<InstalledApp> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return packageManager.queryIntentActivities(i, 0).map {
      InstalledApp(it.loadLabel(packageManager).toString(), it.activityInfo.packageName)
    }.distinctBy { it.pkg }
  }

  fun appLabel(pkg: String): String = runCatching {
    packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
  }.getOrDefault(pkg)

  // ---- Floating overlay: current step, STOP, and approval buttons ----

  /**
   * Shows or updates the overlay. [buttons] are (label, isDanger, onClick); STOP is always one of them.
   * TYPE_ACCESSIBILITY_OVERLAY needs no extra permission and stays above other apps.
   */
  fun showOverlay(title: String, detail: String, buttons: List<Triple<String, Boolean, () -> Unit>>) {
    val wm = getSystemService(WINDOW_SERVICE) as WindowManager
    val dp = resources.displayMetrics.density
    if (overlay == null) {
      val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding((16 * dp).toInt(), (12 * dp).toInt(), (16 * dp).toInt(), (12 * dp).toInt())
        background = GradientDrawable().apply { cornerRadius = 20 * dp; setColor(0xF0151821.toInt()); setStroke((1 * dp).toInt(), 0x33FFFFFF) }
        elevation = 8 * dp
      }
      overlayTitle = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD); maxLines = 2 }
      overlayDetail = TextView(this).apply { setTextColor(0xCCFFFFFF.toInt()); textSize = 13f; maxLines = 4 }
      overlayButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
      box.addView(overlayTitle); box.addView(overlayDetail); box.addView(overlayButtons)
      val lp = WindowManager.LayoutParams(
        (resources.displayMetrics.widthPixels - 24 * dp).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        android.graphics.PixelFormat.TRANSLUCENT
      ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (96 * dp).toInt() }
      runCatching { wm.addView(box, lp); overlay = box }
    }
    overlayTitle?.text = title
    overlayDetail?.text = detail
    overlayDetail?.visibility = if (detail.isBlank()) View.GONE else View.VISIBLE
    overlayButtons?.removeAllViews()
    for ((label, danger, onClick) in buttons) {
      overlayButtons?.addView(Button(this).apply {
        text = label
        isAllCaps = false
        minHeight = (48 * dp).toInt(); minimumHeight = (48 * dp).toInt()
        setTextColor(0xFFFFFFFF.toInt())
        background = GradientDrawable().apply { cornerRadius = 24 * dp; setColor(if (danger) 0xFFD93A3A.toInt() else 0xFF3A6FF7.toInt()) }
        contentDescription = label
        setOnClickListener { onClick() }
      }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (48 * dp).toInt()).apply { marginStart = (8 * dp).toInt(); topMargin = (8 * dp).toInt() })
    }
  }

  fun hideOverlay() {
    overlay?.let { v -> runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(v) } }
    overlay = null; overlayTitle = null; overlayDetail = null; overlayButtons = null
  }

  companion object {
    @Volatile var instance: PhoneAgentService? = null
      private set
    private val _connected = MutableStateFlow(false)
    /** True while the user has the service turned on in Accessibility settings. */
    val connected: StateFlow<Boolean> = _connected

    fun settingsIntent(): Intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  }
}
