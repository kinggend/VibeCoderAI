package com.example.phone

/** A short script that runs without a model call (fast); [next] returns null when the model should decide. */
interface ScriptedFlow {
  val gaveUp: Boolean
  fun next(screen: CompactScreen, pkg: String): PhoneAction?
}

/** "youtube open free fire video play" / "YouTube lo Telugu songs" -> the search words. Null when no search is asked. */
object YouTubeQuery {
  private val ASKS = Regex("\\b(play|search|watch|find|vinipinchu|chudu|vethuku|vedhuku)\\b", RegexOption.IGNORE_CASE)
  private val NOISE = Regex(
    "\\b(youtube|yt|open|play|search|watch|find|vinipinchu|chudu|vethuku|vedhuku|lo|on|in|and|the|ani|pettu|ivvu|chesi|cheyyi|cheyyu|cheyyandi|cheyandi|chey)\\b",
    RegexOption.IGNORE_CASE
  )

  fun extract(task: String): String? {
    if (!Regex("\\b(youtube|yt)\\b", RegexOption.IGNORE_CASE).containsMatchIn(task) || !ASKS.containsMatchIn(task)) return null
    val q = task.replace(NOISE, " ").replace(Regex("[\"“”]"), " ").replace(Regex("\\s+"), " ").trim().trimEnd('.', '!', '?')
    return q.ifBlank { null }
  }
}

/** "WhatsApp lo Ravi ki hello ani msg pettu", "send hi to Ravi on whatsapp" -> (contact, text). */
object MessageParse {
  private const val WA = "(?:whatsapp|whats app|wa)"
  private const val MSGW = "(?:msg|message|sms|text)"
  private val A = Regex("^$WA\\s*(?:lo|లో)?\\s+(.+?)\\s+ki\\s+(.+?)\\s+ani\\s+$MSGW\\b.*$", RegexOption.IGNORE_CASE)
  private val B = Regex("^$WA\\s*(?:lo|లో)?\\s+(.+?)\\s+ani\\s+(.+?)\\s+ki\\s+$MSGW\\b.*$", RegexOption.IGNORE_CASE)
  private val C = Regex("^(?:send|text|message)\\s+(.+?)\\s+to\\s+(.+?)\\s+(?:on|in|via)\\s+$WA\\s*$", RegexOption.IGNORE_CASE)
  private val D = Regex("^(?:send\\s+)?(?:a\\s+)?$MSGW\\s+to\\s+(.+?)\\s+(?:on|in|via)\\s+$WA\\s+(?:saying|that|:)\\s*(.+)$", RegexOption.IGNORE_CASE)
  private fun clean(x: String) = x.trim().trim('"', '\'', '“', '”').trim()

  /** (contact, text) or null. */
  fun parse(task: String): Pair<String, String>? {
    val t = task.trim().replace(Regex("\\s+"), " ")
    A.find(t)?.let { return clean(it.groupValues[1]) to clean(it.groupValues[2]) }
    B.find(t)?.let { return clean(it.groupValues[2]) to clean(it.groupValues[1]) }
    C.find(t)?.let { return clean(it.groupValues[2]) to clean(it.groupValues[1]) }
    D.find(t)?.let { return clean(it.groupValues[1]) to clean(it.groupValues[2]) }
    return null
  }
}

/**
 * YouTube: Search icon, type the query, Enter, open the first real result. A person's steps, no model call.
 * Gives up (null / gaveUp) when the screen is not what it expects, and the model takes over.
 */
class YouTubeFlow(private val query: String, private val play: Boolean) : ScriptedFlow {
  private var typed = false
  private var entered = false
  private var tapped = false
  private var title = ""
  private var waits = 0
  private var misses = 0

  override val gaveUp: Boolean get() = misses >= 3 || waits > 8

  override fun next(screen: CompactScreen, pkg: String): PhoneAction? {
    if (!pkg.startsWith("com.google.android.youtube")) return null
    val els = screen.elements
    if (tapped) return PhoneAction.Done("Playing \"${title.take(50)}\" on YouTube")
    if (els.size < 3) return PhoneAction.Wait(800)

    if (!typed) {
      els.firstOrNull { it.editable && !it.password }?.let { typed = true; return PhoneAction.Type(it.id, query) }
      els.firstOrNull { it.clickable && !it.editable && it.label.trim().lowercase().startsWith("search") }?.let { return PhoneAction.Tap(it.id) }
      misses++
      return null
    }
    if (!entered) { entered = true; return PhoneAction.Enter }

    // Results page: the first long, clickable label that is not YouTube's own chrome.
    val words = query.lowercase().split(' ').filter { it.length >= 3 }
    val result = els.firstOrNull { e ->
      e.clickable && !e.editable && e.full.length >= 12 && !CHROME.containsMatchIn(e.label) &&
        (words.isEmpty() || words.any { it in e.full.lowercase() })
    } ?: if (waits >= 2) els.firstOrNull { e -> e.clickable && !e.editable && e.full.length >= 20 && !CHROME.containsMatchIn(e.label) } else null
    if (result == null) { waits++; return PhoneAction.Wait(1000) }
    if (!play) return PhoneAction.Done("Searched YouTube for \"$query\"")
    tapped = true
    title = result.full.substringBefore(" - ").substringBefore(", ").substringBefore(" | ")
    return PhoneAction.Tap(result.id)
  }

  private companion object {
    val CHROME = Regex("^(search|voice search|cast|more options|home|shorts|subscriptions|you|library|create|notifications|all|filters?|back|navigate up)\\b", RegexOption.IGNORE_CASE)
  }
}

/**
 * WhatsApp: search the contact, open the chat, type the message, tap Send. The Send tap still goes through
 * RiskGuard, so the user approves it. A chat that is already open is left first (it may be the wrong person).
 */
class MessageFlow(val contact: String, val text: String) : ScriptedFlow {
  private var typedContact = false
  private var picked = false
  private var typedMsg = false
  private var sent = false
  private var waits = 0
  private var misses = 0
  private var backs = 0

  override val gaveUp: Boolean get() = misses >= 3 || waits > 10 || backs > 2

  override fun next(screen: CompactScreen, pkg: String): PhoneAction? {
    if (!pkg.startsWith("com.whatsapp")) return null
    val els = screen.elements
    if (sent) return PhoneAction.Done("Sent \"${text.take(40)}\" to $contact on WhatsApp")
    if (els.size < 3) return PhoneAction.Wait(800)

    val box = els.firstOrNull { it.editable && !it.password && it.label.lowercase().contains("message") }
    if (box != null) {
      if (!picked) { backs++; return PhoneAction.Back }
      if (!typedMsg) { typedMsg = true; return PhoneAction.Type(box.id, text) }
      els.firstOrNull { it.clickable && !it.editable && it.label.trim().lowercase().let { l -> l == "send" || l == "send message" } }
        ?.let { sent = true; return PhoneAction.Tap(it.id) }
      waits++
      return PhoneAction.Wait(500)
    }
    if (!typedContact) {
      els.firstOrNull { it.editable && !it.password }?.let { typedContact = true; return PhoneAction.Type(it.id, contact) }
      els.firstOrNull { it.clickable && !it.editable && it.label.lowercase().contains("search") }?.let { return PhoneAction.Tap(it.id) }
      misses++
      return null
    }
    if (!picked) {
      val c = contact.lowercase()
      val hit = els.firstOrNull { it.clickable && !it.editable && !it.label.lowercase().startsWith("search") && c in it.full.lowercase() }
      if (hit != null) { picked = true; return PhoneAction.Tap(hit.id) }
      waits++
      return PhoneAction.Wait(900)
    }
    waits++
    return PhoneAction.Wait(600)
  }
}
