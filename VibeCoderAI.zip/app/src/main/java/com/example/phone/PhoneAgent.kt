package com.example.phone

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.example.AppGraph
import com.example.data.model.SettingsState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.withContext

/**
 * v1.7.0: runs one phone task the user started: observe the screen, ask the model for one action,
 * check it is safe, do it, repeat. Off unless the user turns Phone agent on; nothing else in the app
 * uses it. Runs through the app's AgentRunManager, so the existing foreground notification and its
 * Stop button cover it.
 */
class PhoneAgent private constructor(private val app: Context) {

  data class Step(val text: String, val ok: Boolean = true)
  data class State(
    val running: Boolean = false,
    val task: String = "",
    val steps: List<Step> = emptyList(),
    val status: String = "",
    val result: String? = null
  )

  private val _state = MutableStateFlow(State())
  val state: StateFlow<State> = _state

  private val prefs = app.getSharedPreferences("phone_agent", Context.MODE_PRIVATE)
  private val graph get() = AppGraph.get(app)

  /** The user's switch in Chat options. Off by default; the rest of the app works as before. */
  var enabled: Boolean
    get() = prefs.getBoolean("enabled", false)
    set(v) { prefs.edit().putBoolean("enabled", v).apply(); _enabledFlow.value = v }
  private val _enabledFlow = MutableStateFlow(prefs.getBoolean("enabled", false))
  val enabledFlow: StateFlow<Boolean> = _enabledFlow

  fun remoteNoticeAcked(): Boolean = prefs.getBoolean("remoteScreenNotice", false)
  fun ackRemoteNotice() = prefs.edit().putBoolean("remoteScreenNotice", true).apply()

  private var approval: CompletableDeferred<Boolean>? = null

  private fun step(text: String, ok: Boolean = true) {
    _state.value = _state.value.copy(steps = (_state.value.steps + Step(text, ok)).takeLast(60), status = text)
    graph.orchestrator.runs.label(text)
  }

  /** Starts [task]; false when another run is going or the service is off. */
  fun start(task: String, settings: SettingsState): Boolean {
    if (PhoneAgentService.instance == null) {
      _state.value = State(task = task, status = "Turn on VibeCoder Phone agent in Accessibility settings first.", result = "Phone agent is off in Accessibility settings.")
      return false
    }
    _state.value = State(running = true, task = task, status = "Starting")
    val job = graph.orchestrator.runs.start(null) {
      var result = "Stopped"
      try {
        result = run(task, settings)
      } catch (e: kotlinx.coroutines.CancellationException) {
        result = "Stopped by you"
        throw e
      } catch (t: Throwable) {
        result = "Error: ${t.message ?: t.javaClass.simpleName}"
      } finally {
        withContext(kotlinx.coroutines.NonCancellable + Dispatchers.Main) { PhoneAgentService.instance?.hideOverlay() }
        notifications().cancel(NOTE_APPROVAL)
        approval?.cancel(); approval = null
        _state.value = _state.value.copy(running = false, result = result, status = result)
        PhoneHistory.append(app, task, _state.value.steps.map { it.text }, result, settings.backendMode == "remote")
      }
    }
    if (job == null) {
      _state.value = State(task = task, status = "Another run is going. Stop it first.", result = "Another run is going.")
      return false
    }
    return true
  }

  fun stop() {
    approval?.complete(false)
    graph.orchestrator.runs.cancel()
    // Abort a model that is still reading the prompt: cancelling the coroutine alone waits for the next callback.
    runCatching { graph.llamaEngine.stopNow() }
    if (_state.value.running) _state.value = _state.value.copy(status = "Stopping...")
    // Safety net: if the run has not ended in 3 s (something blocked), leave the running state anyway.
    CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
      delay(3000)
      if (_state.value.running) {
        withContext(Dispatchers.Main) { PhoneAgentService.instance?.hideOverlay() }
        _state.value = _state.value.copy(running = false, result = "Stopped by you", status = "Stopped by you")
      }
    }
  }

  /** True once another app (not VibeCoder) is on screen, polling up to [ms]. */
  private suspend fun leftThisApp(svc: () -> PhoneAgentService, ms: Long = 3500): Boolean {
    val end = System.currentTimeMillis() + ms
    while (System.currentTimeMillis() < end) {
      val p = withContext(Dispatchers.Main) { svc().foregroundPkg() }
      if (p != null && p != app.packageName) return true
      delay(300)
    }
    return false
  }

  private suspend fun overlay(title: String, detail: String = "", extra: List<Triple<String, Boolean, () -> Unit>> = emptyList()) =
    withContext(Dispatchers.Main) {
      PhoneAgentService.instance?.showOverlay(title, detail, extra + Triple("Stop", true) { stop() })
    }

  /**
   * Pauses until the user answers on the overlay (or the notification opens the app). Never times out
   * into a yes.
   */
  private suspend fun ask(title: String, detail: String, allowLabel: String): Boolean {
    val d = CompletableDeferred<Boolean>()
    approval = d
    overlay("Needs your approval: $title", detail, listOf(Triple(allowLabel, false) { d.complete(true) }))
    notify(title, detail)
    return try { d.await() } finally { notifications().cancel(NOTE_APPROVAL); approval = null }
  }

  private suspend fun run(task: String, settings: SettingsState): String {
    val svc = { PhoneAgentService.instance ?: throw IllegalStateException("Phone agent was turned off in Accessibility settings.") }
    val remote = settings.backendMode == "remote"
    // On this phone: load the model now (a vision model brings its image helper) to know whether screenshots can be read.
    if (!remote) overlay("Phone agent: $task", "Loading the model")
    val localVision = !remote && withContext(Dispatchers.Default) { graph.llamaEngine.initialize(settings) && graph.llamaEngine.hasVision }
    val vision = localVision || (remote && com.example.chat.VisionSupport.check(settings.backendMode, settings.remoteModel) is com.example.chat.VisionSupport.Verdict.Ok)
    // Screen text budget: small on-device contexts get ~1.2K chars; remote models ~3K.
    val ctxForBudget = if (localVision) maxOf(settings.contextLength, 4096) else settings.contextLength
    val budget = if (remote) 3000 else ((ctxForBudget - minOf(settings.maxOutputTokens, 256) - 350 - (if (localVision) 700 else 0)) * 3).coerceIn(800, 3000)
    val history = ArrayDeque<String>()
    var lastSig = 0
    var parseFails = 0
    var blind = 0
    var unchanged = 0
    var selfFg = 0
    var timeouts = 0
    // Hard limit so a stuck run always ends.
    val deadline = System.currentTimeMillis() + (if (vision) 20 else 8) * 60_000L
    // Vision runs (screenshots) are longer: video editing or 3D work takes many taps.
    val maxSteps = if (vision) VISION_MAX_STEPS else MAX_STEPS

    overlay("Phone agent: $task", "Starting")
    val route = FastPaths.route(task)
    // YouTube runs as a visible script (home, open, search, type, play) with no model call.
    var flow: YouTubeFlow? = (route as? FastPaths.Route.YouTube)?.let { YouTubeFlow(it.query, FastPaths.wantsPlay(task)) }
    route?.let { r ->
      if (flow != null) {
        withContext(Dispatchers.Main) { svc().global(AccessibilityService.GLOBAL_ACTION_HOME) }
        step("Went to the home screen")
        delay(700)
      }
      var done = fastPath(if (flow != null) FastPaths.Route.App("YouTube") else r, svc())
      var opened = done != null && leftThisApp(svc)
      if (!opened && flow != null) {
        // The app would not open directly: use the search intent instead and let the model continue.
        flow = null
        done = fastPath(r, svc())
        opened = done != null && leftThisApp(svc)
      }
      if (opened && done != null) { history += done; step(done); delay(1500) }
      else step("The app did not open from here. Is it installed?", ok = false)
    }

    for (n in 1..maxSteps) {
      if (System.currentTimeMillis() > deadline) return "Stopped: this task took too long. Try a smaller task, or a faster model."
      val snap = withContext(Dispatchers.Main) { svc().snapshot() }
      if (snap == null) { delay(800); continue }
      // The task starts from this app's chat: go to the home screen instead of driving VibeCoder itself.
      if (snap.pkg == app.packageName) {
        if (++selfFg >= 3) return "Stopped: could not leave VibeCoder. The app may not be installed, or the home gesture was blocked."
        step("Leaving VibeCoder")
        withContext(Dispatchers.Main) { svc().global(AccessibilityService.GLOBAL_ACTION_HOME) }; delay(900); continue
      }
      selfFg = 0
      val label = svc().appLabel(snap.pkg)
      if (SensitiveApps.isSensitive(snap.pkg, label)) {
        return "Stopped: $label is a banking or payment app. Phone agent does not control those; please continue yourself."
      }
      val screen = ScreenCompactor.compact(label, snap.pkg, snap.root, budget)
      val sig = ScreenCompactor.signature(screen)
      if (n > 1 && sig == lastSig && history.isNotEmpty()) history[history.size - 1] = history.last() + " (screen did not change)"
      unchanged = if (n > 1 && sig == lastSig) unchanged + 1 else 0
      lastSig = sig
      // Image tokens are expensive: only when the tree is unreadable (games, video editors, Flutter apps).
      // Also when the same screen came back twice: taps on a canvas often change pixels the tree cannot see.
      // Local models get a smaller picture: image tokens cost prompt time on a phone.
      val shotMax = if (remote) SHOT_W else SHOT_W_LOCAL
      val image = if (vision && (screen.elements.size < 3 || unchanged >= 2)) svc().screenshot(shotMax) else null
      val shotW = minOf(shotMax, snap.width)
      val shotH = snap.height * shotW / snap.width
      val scale = if (image != null) snap.width.toFloat() / shotW else 1f
      // Unreadable screen and no vision: stop instead of spending tokens on guesses.
      // Apps can take a few seconds to draw after launch: wait without calling the model, then give up.
      if (screen.elements.size < 3 && image == null) {
        if (++blind >= 4) return "Stopped: $label shows no readable buttons or text (${screen.elements.size} found). Apps that draw their own screen, like games, 3D or video editors, need a vision model: in Models, download a vision model (for example Qwen3-VL 4B, it brings its image helper) or switch Run on to Remote server."
        step("Waiting for $label to load")
        delay(1500)
        continue
      } else blind = 0

      val scripted = flow?.takeIf { !it.gaveUp }?.next(screen, snap.pkg)
      var chosen: PhoneAction? = scripted
      if (chosen == null) {
        overlay("Step $n · $label", "Thinking…")
        val prompt = buildString {
          append("Task: ").append(task).append("\nStep ").append(n).append(" of ").append(maxSteps).append('\n')
          if (history.isNotEmpty()) append("Done so far:\n").append(history.joinToString("\n") { "- $it" }).append('\n')
          append(screen.text)
          if (image != null) append("\n(A screenshot ${shotW}x${shotH} px is attached. tap_xy, long_press_xy and swipe use coordinates in that image. Always give tap_xy a label.)")
        }
        // One model call must not hang the run: local reading + answering gets 3 min, remote 90 s.
        val reply = withTimeoutOrNull(if (remote) 90_000L else 180_000L) { generate(prompt, settings, image) }
        if (reply == null) {
          runCatching { graph.llamaEngine.stopNow() }
          step("The model took too long to answer", ok = false)
          if (++timeouts >= 2) return "Stopped: the model answered too slowly twice. Use a smaller context, a smaller model, or a remote model."
          continue
        }
        chosen = try { PhoneActionParser.parse(reply).also { parseFails = 0 } } catch (e: PhoneActionParser.ParseError) {
          step("Could not read the model's action: ${e.message}", ok = false)
          if (++parseFails >= 2) return "Stopped: the model did not reply with a valid action twice. A bigger or remote model works better."
          history += "Invalid reply: ${e.message}"
          continue
        }
      }
      val action: PhoneAction = chosen ?: continue
      val what = action.describe(screen)
      when (action) {
        is PhoneAction.Done -> { step(what); return action.summary }
        is PhoneAction.Ask -> { step(what); return "The agent needs you: ${action.question}" }
        else -> Unit
      }

      // Safety: risky taps wait for the user; secrets are never typed.
      val target = (action as? PhoneAction.Tap)?.id ?: (action as? PhoneAction.LongPress)?.id
      val el = target?.let { screen.element(it) }
      if (target != null && el == null) { history += "$what: no element #$target on this screen"; step("$what: element not on screen", ok = false); continue }
      val xyLabel = (action as? PhoneAction.TapXY)?.label ?: (action as? PhoneAction.LongPressXY)?.label
      RiskGuard.classify(el?.label ?: xyLabel)?.let { risk ->
        if (!ask(what, "This looks like ${risk.title} in $label. The agent never does this on its own.", "Allow this tap")) {
          step("$what: declined by you", ok = false)
          return "Stopped before ${risk.title}. You can finish it yourself."
        }
      }
      if (action is PhoneAction.Type) {
        val field = action.id?.let { screen.element(it) }
        if ((field != null && RiskGuard.isSecretField(field)) || RiskGuard.looksSecret(action.text)) {
          if (!ask("Type it yourself", "Passwords, PINs, OTPs and card numbers are never typed by the agent. Type it in $label, then tap Continue.", "Continue")) return "Stopped at a password or code field."
          history += "User typed a secret field themselves"
          step("You typed the secret field")
          continue
        }
      }

      step(what)
      overlay("Step $n · $label", what)
      val ok = execute(action, snap, svc(), scale)
      history += what + if (ok) "" else " (failed)"
      if (!ok) _state.value = _state.value.copy(steps = _state.value.steps.dropLast(1) + Step("$what (failed)", false))
      while (history.size > 4) history.removeFirst()
      delay(if (action is PhoneAction.Wait) action.ms else 1200)
    }
    return "Stopped after $maxSteps steps without finishing."
  }

  private suspend fun fastPath(r: FastPaths.Route, svc: PhoneAgentService): String? = when (r) {
    is FastPaths.Route.YouTube -> {
      val search = Intent(Intent.ACTION_SEARCH).setPackage(FastPaths.YOUTUBE_PKG).putExtra(android.app.SearchManager.QUERY, r.query)
      if (svc.launch(search) || svc.launch(Intent(Intent.ACTION_VIEW, Uri.parse(FastPaths.youtubeSearchUrl(r.query))))) "Searched YouTube for \"${r.query}\"" else null
    }
    is FastPaths.Route.Url -> if (svc.launch(Intent(Intent.ACTION_VIEW, Uri.parse(r.url)))) "Opened ${r.url}" else null
    is FastPaths.Route.App -> AppMatcher.matchLeading(r.name, svc.installedApps())?.let { a ->
      app.packageManager.getLaunchIntentForPackage(a.pkg)?.let { if (svc.launch(it)) "Opened ${a.label}" else null }
    }
  }

  private suspend fun execute(a: PhoneAction, snap: PhoneAgentService.Snapshot, svc: PhoneAgentService, scale: Float): Boolean = withContext(Dispatchers.Main) {
    when (a) {
      is PhoneAction.Tap -> snap.nodes[a.id]?.let { svc.tap(it) } ?: false
      is PhoneAction.LongPress -> snap.nodes[a.id]?.let { svc.tap(it, long = true) } ?: false
      is PhoneAction.Type -> svc.type(a.id?.let { snap.nodes[it] }, a.text)
      PhoneAction.Enter -> svc.enter()
      is PhoneAction.Scroll -> svc.scroll(a.direction, a.id?.let { snap.nodes[it] }, snap.width, snap.height)
      is PhoneAction.TapXY -> svc.gesture(a.x * scale, a.y * scale, a.x * scale, a.y * scale, 60)
      is PhoneAction.LongPressXY -> svc.gesture(a.x * scale, a.y * scale, a.x * scale, a.y * scale, 700)
      is PhoneAction.Swipe -> svc.gesture(a.x1 * scale, a.y1 * scale, a.x2 * scale, a.y2 * scale, 400)
      PhoneAction.Back -> svc.global(AccessibilityService.GLOBAL_ACTION_BACK)
      PhoneAction.Home -> svc.global(AccessibilityService.GLOBAL_ACTION_HOME)
      PhoneAction.Recents -> svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
      PhoneAction.Notifications -> svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
      is PhoneAction.OpenApp, is PhoneAction.OpenUrl, is PhoneAction.YouTubeSearch -> {
        val r = when (a) {
          is PhoneAction.OpenApp -> FastPaths.Route.App(a.name)
          is PhoneAction.OpenUrl -> FastPaths.Route.Url(a.url)
          else -> FastPaths.Route.YouTube((a as PhoneAction.YouTubeSearch).query)
        }
        fastPath(r, svc) != null
      }
      is PhoneAction.Wait -> true
      is PhoneAction.Done, is PhoneAction.Ask -> true
    }
  }

  private suspend fun generate(prompt: String, settings: SettingsState, image: String?): String {
    val out = StringBuilder()
    // chatOnly caps the reply at 1024 tokens; one JSON action needs far less. Thinking off saves tokens.
    graph.llamaEngine.generateCompletionStream(
      prompt = prompt, settings = settings.copy(thinking = false), onTelemetryUpdate = {},
      chatOnly = true, systemOverride = SYSTEM, images = listOfNotNull(image)
    ).takeWhile { chunk ->
      out.append(chunk)
      // Stop generating as soon as one complete JSON object is out: no tokens spent after the action.
      !ACTION_DONE.containsMatchIn(out)
    }.collect { }
    return out.toString()
  }

  private fun notifications(): NotificationManager = app.getSystemService(NotificationManager::class.java)

  private fun notify(title: String, text: String) {
    val nm = notifications()
    if (android.os.Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
      nm.createNotificationChannel(NotificationChannel(CHANNEL, "Phone agent approvals", NotificationManager.IMPORTANCE_HIGH))
    }
    val open = PendingIntent.getActivity(app, 7, Intent(app, com.example.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
    runCatching {
      nm.notify(NOTE_APPROVAL, NotificationCompat.Builder(app, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_dialog_alert)
        .setContentTitle("Needs your approval: $title")
        .setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
        .setContentIntent(open).setAutoCancel(true).build())
    }
  }

  companion object {
    const val MAX_STEPS = 25
    const val VISION_MAX_STEPS = 60
    const val SHOT_W = 720
    const val SHOT_W_LOCAL = 540
    private val ACTION_DONE = Regex("\\{[^{}]*\"action\"[^{}]*\\}")
    private const val CHANNEL = "phone_agent_approval"
    private const val NOTE_APPROVAL = 7107

    /** Kept short on purpose: it is sent with every step. */
    val SYSTEM = """You control an Android phone to finish the user's task. Each turn you see the current screen as numbered elements.
Reply with exactly ONE JSON object and nothing else. Actions:
${PhoneActionParser.TOOLS}
Rules: use ids from the current screen only. Prefer youtube_search/open_app over tapping through menus. When a screenshot is attached and no element fits, use tap_xy with a label. Look at the screenshot after each action to check it worked. After typing in a search box use enter. When the task is complete reply done. If you need information only the user has, reply ask. Never enter passwords, PINs, OTPs or card numbers."""

    @Volatile private var instance: PhoneAgent? = null
    fun get(context: Context): PhoneAgent =
      instance ?: synchronized(this) { instance ?: PhoneAgent(context.applicationContext).also { instance = it } }
  }
}

/** v1.7.0: every phone task with each step, kept on the phone (filesDir/phone_history.jsonl, last 50). */
object PhoneHistory {
  data class Entry(val time: Long, val task: String, val steps: List<String>, val result: String, val remote: Boolean)

  private fun file(ctx: Context) = java.io.File(ctx.filesDir, "phone_history.jsonl")

  fun append(ctx: Context, task: String, steps: List<String>, result: String, remote: Boolean) = runCatching {
    val line = com.example.agent.MiniJson.encode(listOf(
      "time" to System.currentTimeMillis(), "task" to task, "steps" to steps.joinToString("\n"), "result" to result, "remote" to remote
    ))
    val f = file(ctx)
    val lines = (if (f.isFile) f.readLines() else emptyList()) + line
    f.writeText(lines.takeLast(50).joinToString("\n") + "\n")
  }

  fun read(ctx: Context): List<Entry> = runCatching {
    file(ctx).takeIf { it.isFile }?.readLines().orEmpty().mapNotNull { l ->
      runCatching {
        val m = com.example.agent.MiniJson.parseObject(l)
        Entry((m["time"] as Number).toLong(), m["task"] as String, (m["steps"] as String).split("\n").filter { it.isNotBlank() }, m["result"] as String, m["remote"] == true)
      }.getOrNull()
    }.reversed()
  }.getOrDefault(emptyList())

  fun clear(ctx: Context) { file(ctx).delete() }
}
