package com.example.phone

import android.accessibilityservice.AccessibilityService
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.core.app.NotificationCompat
import com.example.AppGraph
import com.example.data.model.SettingsState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.takeWhile
import kotlinx.coroutines.withContext

/**
 * v1.7.0: runs one phone task the user started: observe the screen, ask the model for one action,
 * check it is safe, do it, repeat. Off unless the user turns Phone agent on; nothing else in the app
 * uses it. Runs through the app's AgentRunManager, so the existing foreground notification and its
 * Stop button cover it.
 */
class PhoneAgent private constructor(private val app: Context) {

  data class Step(val text: String, val ok: Boolean = true)
  data class State(
    val running: Boolean = false,
    val task: String = "",
    val steps: List<Step> = emptyList(),
    val status: String = "",
    val result: String? = null
  )

  private val _state = MutableStateFlow(State())
  val state: StateFlow<State> = _state

  private val prefs = app.getSharedPreferences("phone_agent", Context.MODE_PRIVATE)
  private val graph get() = AppGraph.get(app)

  /** The user's switch in Chat options. Off by default; the rest of the app works as before. */
  var enabled: Boolean
    get() = prefs.getBoolean("enabled", false)
    set(v) { prefs.edit().putBoolean("enabled", v).apply(); _enabledFlow.value = v }
  private val _enabledFlow = MutableStateFlow(prefs.getBoolean("enabled", false))
  val enabledFlow: StateFlow<Boolean> = _enabledFlow

  fun remoteNoticeAcked(): Boolean = prefs.getBoolean("remoteScreenNotice", false)
  fun ackRemoteNotice() = prefs.edit().putBoolean("remoteScreenNotice", true).apply()

  private var approval: CompletableDeferred<Boolean>? = null
  /** Messages the user typed on the overlay during a run; read at the start of each step. */
  private val notes = java.util.concurrent.ConcurrentLinkedQueue<String>()
  @Volatile private var composing = false

  private fun step(text: String, ok: Boolean = true) {
    _state.value = _state.value.copy(steps = (_state.value.steps + Step(text, ok)).takeLast(60), status = text)
    graph.orchestrator.runs.label(text)
  }

  /** Starts [task]; false when another run is going or the service is off. */
  fun start(task: String, settings: SettingsState): Boolean {
    if (PhoneAgentService.instance == null) {
      _state.value = State(task = task, status = "Turn on VibeCoder Phone agent in Accessibility settings first.", result = "Phone agent is off in Accessibility settings.")
      return false
    }
    _state.value = State(running = true, task = task, status = "Starting")
    notes.clear(); composing = false
    PhoneAgentService.instance?.let { sv ->
      sv.onUserMessage = { m -> notes.add(m); step("You: $m") }
      sv.onCompose = { composing = it }
    }
    val job = graph.orchestrator.runs.start(null) {
      var result = "Stopped"
      val logId = graph.runLog.begin(com.example.agent.RunKind.PHONE, task, FastPaths.route(task).let { r ->
        when (r) { is FastPaths.Route.App -> r.name; else -> "" }
      }, "Phone agent", settings.backendMode == "remote")
      try {
        result = run(task, settings)
      } catch (e: kotlinx.coroutines.CancellationException) {
        result = "Stopped by you"
        throw e
      } catch (t: Throwable) {
        result = "Error: ${t.message ?: t.javaClass.simpleName}"
      } finally {
        withContext(kotlinx.coroutines.NonCancellable + Dispatchers.Main) { PhoneAgentService.instance?.hideOverlay() }
        notifications().cancel(NOTE_APPROVAL)
        approval?.cancel(); approval = null
        composing = false
        PhoneAgentService.instance?.let { it.onUserMessage = null; it.onCompose = null }
        _state.value = _state.value.copy(running = false, result = result, status = result)
        PhoneHistory.append(app, task, _state.value.steps.map { it.text }, result, settings.backendMode == "remote")
        graph.runLog.end(logId, com.example.agent.RunBoard.phoneStatus(result), result, _state.value.steps.size)
      }
    }
    if (job == null) {
      _state.value = State(task = task, status = "Another run is going. Stop it first.", result = "Another run is going.")
      return false
    }
    return true
  }

  fun stop() {
    approval?.complete(false)
    graph.orchestrator.runs.cancel()
    // Abort a model that is still reading the prompt: cancelling the coroutine alone waits for the next callback.
    runCatching { graph.llamaEngine.stopNow() }
    if (_state.value.running) _state.value = _state.value.copy(status = "Stopping...")
    // Safety net: if the run has not ended in 3 s (something blocked), leave the running state anyway.
    CoroutineScope(SupervisorJob() + Dispatchers.Default).launch {
      delay(3000)
      if (_state.value.running) {
        withContext(Dispatchers.Main) { PhoneAgentService.instance?.hideOverlay() }
        _state.value = _state.value.copy(running = false, result = "Stopped by you", status = "Stopped by you")
      }
    }
  }

  /** Flattens a UI tree. */
  private fun flat(n: UiNode): Sequence<UiNode> = sequenceOf(n) + n.children.asSequence().flatMap { flat(it) }

  /**
   * Opens [name] like a person: look at this home page, swipe left or right through the home pages, and only
   * then try the app drawer (swipe up, search, scroll). The icon is tapped with the cursor. Returns a step text,
   * or null when it never worked.
   */
  private suspend fun openAppByUi(name: String, svc: () -> PhoneAgentService): String? {
    val target = AppMatcher.matchLeading(name, svc().installedApps()) ?: return null
    var pages = true            // true: swiping through home pages; false: app drawer fallback
    var dir = -1                // -1 swipes left (next page), +1 swipes right (previous page)
    var edges = 0               // how many page ends were reached
    var lastSig = 0
    var swipes = 0
    var drawerOpened = false
    var iconTaps = 0
    var searched = false
    var where = "the home screen"
    for (attempt in 0 until 26) {
      val snap = withContext(Dispatchers.Main) { svc().snapshot() }
      if (snap == null || snap.pkg == app.packageName) { delay(600); continue }
      val nodes = snap.root.asSequence().flatMap { flat(it) }.toList()
      val hit = nodes.firstOrNull { AppMatcher.labelMatches(it.text ?: it.desc, target.label) }
      val node = hit?.let { snap.nodes[it.id] }
      if (hit != null && node != null) {
        // Real touch first (launchers often ignore an accessibility click); the second try uses the click action.
        step("Tapping the ${target.label} icon")
        if (++iconTaps > 3) return null
        withContext(Dispatchers.Main) { if (iconTaps % 2 == 1) svc().touch(node) else svc().tap(node) }
        val end = System.currentTimeMillis() + 4000
        while (System.currentTimeMillis() < end) {
          if (withContext(Dispatchers.Main) { svc().foregroundPkg() } == target.pkg) return "Opened ${target.label} from $where"
          delay(300)
        }
        continue
      }
      val w = snap.width.toFloat(); val h = snap.height.toFloat()
      if (pages) {
        // Same labels after a swipe means this was the last page in that direction.
        val sig = nodes.mapNotNull { (it.text ?: it.desc)?.takeIf { t -> t.isNotBlank() } }.sorted().hashCode()
        if (swipes > 0 && sig == lastSig) {
          edges++; dir = -dir
          if (edges >= 2) { pages = false; continue }
        }
        lastSig = sig
        step("Swiping ${if (dir < 0) "left" else "right"} to look for ${target.label}")
        val y = h * 0.42f
        val (x1, x2) = if (dir < 0) w * 0.85f to w * 0.15f else w * 0.15f to w * 0.85f
        withContext(Dispatchers.Main) { svc().gesture(x1, y, x2, y, 320) }
        swipes++; where = "a home page"; delay(750)
        if (swipes >= 14) pages = false
        continue
      }
      where = "the app drawer"
      val field = nodes.firstOrNull { it.editable && !it.password }
      if (!drawerOpened) {
        step("Swiping up to open the app drawer")
        withContext(Dispatchers.Main) { svc().gesture(w * 0.5f, h * 0.78f, w * 0.5f, h * 0.28f, 350) }
        drawerOpened = true; delay(800)
      } else if (!searched && field != null) {
        step("Searching the drawer for ${target.label}")
        withContext(Dispatchers.Main) { svc().type(snap.nodes[field.id], target.label) }
        searched = true; delay(900)
      } else {
        step("Scrolling the app drawer")
        withContext(Dispatchers.Main) { svc().gesture(w * 0.5f, h * 0.75f, w * 0.5f, h * 0.3f, 350) }
        delay(700)
      }
    }
    return null
  }

  /** True once another app (not VibeCoder) is on screen, polling up to [ms]. */
  private suspend fun leftThisApp(svc: () -> PhoneAgentService, ms: Long = 3500): Boolean {
    val end = System.currentTimeMillis() + ms
    while (System.currentTimeMillis() < end) {
      val p = withContext(Dispatchers.Main) { svc().foregroundPkg() }
      if (p != null && p != app.packageName) return true
      delay(300)
    }
    return false
  }

  private suspend fun overlay(title: String, detail: String = "", extra: List<Triple<String, Boolean, () -> Unit>> = emptyList()) =
    withContext(Dispatchers.Main) {
      PhoneAgentService.instance?.showOverlay(title, detail, extra + Triple("Stop", true) { stop() })
    }

  /**
   * Pauses until the user answers on the overlay (or the notification opens the app). Never times out
   * into a yes.
   */
  private suspend fun ask(title: String, detail: String, allowLabel: String): Boolean {
    val d = CompletableDeferred<Boolean>()
    approval = d
    overlay("Needs your approval: $title", detail, listOf(Triple(allowLabel, false) { d.complete(true) }))
    notify(title, detail)
    return try { d.await() } finally { notifications().cancel(NOTE_APPROVAL); approval = null }
  }

  private suspend fun run(task: String, settings: SettingsState): String {
    val svc = { PhoneAgentService.instance ?: throw IllegalStateException("Phone agent was turned off in Accessibility settings.") }
    val remote = settings.backendMode == "remote"
    // On this phone: load the model now (a vision model brings its image helper) to know whether screenshots can be read.
    if (!remote) overlay("Phone agent: $task", "Loading the model")
    val modelLoaded = remote || withContext(Dispatchers.Default) { graph.llamaEngine.initialize(settings) }
    if (!modelLoaded) return "Stopped: the offline model did not load. ${graph.llamaEngine.statusMessage ?: "Open Models and select a model."}"
    val localVision = !remote && graph.llamaEngine.hasVision
    val vision = localVision || (remote && com.example.chat.VisionSupport.check(settings.backendMode, settings.remoteModel) is com.example.chat.VisionSupport.Verdict.Ok)
    // Screen text budget: small on-device contexts get ~1.2K chars; remote models ~3K.
    val ctxForBudget = if (localVision) maxOf(settings.contextLength, 4096) else settings.contextLength
    val budget = if (remote) 3000 else ((ctxForBudget - minOf(settings.maxOutputTokens, 256) - 350 - (if (localVision) 700 else 0)) * 3).coerceIn(800, 3000)
    val history = ArrayDeque<String>()
    var lastSig = 0
    var parseFails = 0
    var blind = 0
    var unchanged = 0
    var selfFg = 0
    var timeouts = 0
    // Hard limit so a stuck run always ends.
    var deadline = System.currentTimeMillis() + (if (vision) 20 else 8) * 60_000L
    // Vision runs (screenshots) are longer: video editing or 3D work takes many taps.
    val maxSteps = if (vision) VISION_MAX_STEPS else MAX_STEPS

    overlay("Phone agent: $task", "Starting")
    // One short model call understands the task in any language (like Google's Mobile Actions); the regex rules are only
    // the offline fallback when that call fails. "agent" from the model means the screen agent does the work.
    val routed = routeTask(task, settings)
    (routed as? FastPaths.Route.System)?.let { sys ->
      runSystem(sys.setting, svc)?.let { msg -> step(msg); return msg }
    }
    val route = routed.takeUnless { it is FastPaths.Route.System }
    // v1.8.1: common tasks (YouTube search/play, WhatsApp message) run as a short script with no model call per step,
    // which is much faster on a phone. Anything unusual, or a screen the script does not recognise, falls back to the model.
    var flow: ScriptedFlow? = when (route) {
      is FastPaths.Route.YouTube -> YouTubeFlow(route.query, route.play)
      is FastPaths.Route.Message -> MessageFlow(route.contact, route.text)
      else -> null
    }
    route?.let { r ->
      // Apps open the way a person does it: Home, swipe up for the app drawer, tap the icon.
      val openName = when (r) {
        is FastPaths.Route.App -> r.name
        is FastPaths.Route.YouTube -> "YouTube"
        is FastPaths.Route.Message -> r.app
        else -> null
      }
      var done: String? = null
      var opened = false
      if (openName != null) {
        withContext(Dispatchers.Main) { svc().global(AccessibilityService.GLOBAL_ACTION_HOME) }
        step("Went to the home screen")
        delay(700)
        done = openAppByUi(openName, svc)
        opened = done != null
        if (!opened) {
          // The icon could not be found or tapped: open it directly instead.
          done = fastPath(FastPaths.Route.App(openName), svc())
          opened = done != null && leftThisApp(svc)
          if (!opened && r is FastPaths.Route.YouTube) { flow = null; done = fastPath(r, svc()); opened = done != null && leftThisApp(svc) }
        }
      } else {
        done = fastPath(r, svc())
        opened = done != null && leftThisApp(svc)
      }
      if (opened && done != null) { history += done; step(done); delay(1500) }
      else step("The app did not open from here. Is it installed?", ok = false)
    }

    val userNotes = ArrayDeque<String>()
    for (n in 1..maxSteps) {
      // While the user types a message, wait (that time does not count against the limit).
      while (composing) { delay(250); deadline += 250 }
      while (true) {
        val m = notes.poll() ?: break
        userNotes += m; while (userNotes.size > 3) userNotes.removeFirst()
        flow = null   // a script gives way to what the user just said
        history += "User message: $m"
        unchanged = 0; blind = 0; timeouts = 0
      }
      if (System.currentTimeMillis() > deadline) return "Stopped: this task took too long. Try a smaller task, or a faster model."
      val snap = withContext(Dispatchers.Main) { svc().snapshot() }
      if (snap == null) { delay(800); continue }
      // The task starts from this app's chat: go to the home screen instead of driving VibeCoder itself.
      if (snap.pkg == app.packageName) {
        if (++selfFg >= 3) return "Stopped: could not leave VibeCoder. The app may not be installed, or the home gesture was blocked."
        step("Leaving VibeCoder")
        withContext(Dispatchers.Main) { svc().global(AccessibilityService.GLOBAL_ACTION_HOME) }; delay(900); continue
      }
      selfFg = 0
      val label = svc().appLabel(snap.pkg)
      if (SensitiveApps.isSensitive(snap.pkg, label)) {
        return "Stopped: $label is a banking or payment app. Phone agent does not control those; please continue yourself."
      }
      val screen = ScreenCompactor.compact(label, snap.pkg, snap.root, budget)
      val sig = ScreenCompactor.signature(screen)
      if (n > 1 && sig == lastSig && history.isNotEmpty()) history[history.size - 1] = history.last() + " (screen did not change)"
      unchanged = if (n > 1 && sig == lastSig) unchanged + 1 else 0
      lastSig = sig
      // Image tokens are expensive: only when the tree is unreadable (games, video editors, Flutter apps).
      // Also when the same screen came back twice: taps on a canvas often change pixels the tree cannot see.
      // Local models get a smaller picture: image tokens cost prompt time on a phone.
      val shotMax = if (remote) SHOT_W else SHOT_W_LOCAL
      // Remote vision models (Claude, GPT and similar) look at a fresh screenshot every step, like computer-use agents.
      // On-device models only get one when the tree is unreadable, because image tokens are slow on a phone.
      val image = if (vision && (remote || screen.elements.size < 3 || unchanged >= 2)) svc().screenshot(shotMax) else null
      val shotW = minOf(shotMax, snap.width)
      val shotH = snap.height * shotW / snap.width
      val scale = if (image != null) snap.width.toFloat() / shotW else 1f
      // Unreadable screen and no vision: stop instead of spending tokens on guesses.
      // Apps can take a few seconds to draw after launch: wait without calling the model, then give up.
      if (screen.elements.size < 3 && image == null) {
        if (++blind >= 4) return "Stopped: $label shows no readable buttons or text (${screen.elements.size} found). Apps that draw their own screen, like games, 3D or video editors, need a vision model: in Models, download a vision model (for example Qwen3-VL 4B, it brings its image helper) or switch Run on to Remote server." +
          (graph.llamaEngine.visionNotice?.let { " Reason: $it" } ?: if (!remote && !vision) " Reason: the loaded model has no image support (it is a text-only model)." else "")
        step("Waiting for $label to load")
        delay(1500)
        continue
      } else blind = 0

      var chosen: PhoneAction? = flow?.takeIf { !it.gaveUp }?.next(screen, snap.pkg)
      if (chosen == null) {
        overlay("Step $n · $label", "Thinking…")
        val prompt = buildString {
          append("Task: ").append(PhoneTips.cleanTask(task)).append("\nStep ").append(n).append(" of ").append(maxSteps).append('\n')
          if (userNotes.isNotEmpty()) append("The user added while you work (follow this, it overrides the plan):\n").append(userNotes.joinToString("\n") { "- $it" }).append('\n')
          if (history.isNotEmpty()) append("Done so far:\n").append(history.joinToString("\n") { "- $it" }).append('\n')
          PhoneTips.forTask(task)?.let { append(it).append('\n') }
          PhoneTips.planLine(n)?.let { append(it).append('\n') }
          if (n <= 2 || unchanged >= 2) append(PhoneTips.GENERAL).append('\n')
          PhoneTips.forApp(label, snap.pkg)?.let { append(it).append('\n') }
          PhoneTips.stuckHint(unchanged)?.let { append(it).append('\n') }
          append(screen.text)
          if (image != null) append("\n(A screenshot ${shotW}x${shotH} px is attached. tap_xy, long_press_xy and swipe use coordinates in that image. Always give tap_xy a label. Look at the picture first and act like a person: tap what you see, type, swipe.)")
        }
        // One model call must not hang the run: local reading + answering gets 3 min, remote 90 s.
        val reply = withTimeoutOrNull(if (remote) 90_000L else 180_000L) { generate(prompt, settings, image) }
        if (reply == null) {
          runCatching { graph.llamaEngine.stopNow() }
          step("The model took too long to answer", ok = false)
          if (++timeouts >= 2) return "Stopped: the model answered too slowly twice. Use a smaller context, a smaller model, or a remote model."
          continue
        }
        chosen = try { PhoneActionParser.parse(reply).also { parseFails = 0 } } catch (e: PhoneActionParser.ParseError) {
          step("Could not read the model's action: ${e.message}", ok = false)
          if (++parseFails >= 2) return "Stopped: the model did not reply with a valid action twice. A bigger or remote model works better."
          history += "Invalid reply: ${e.message}"
          continue
        }
      }
      val action: PhoneAction = chosen ?: continue
      val what = action.describe(screen)
      when (action) {
        is PhoneAction.Done -> { step(what); return action.summary }
        is PhoneAction.Ask -> { step(what); return "The agent needs you: ${action.question}" }
        else -> Unit
      }

      // Safety: risky taps wait for the user; secrets are never typed.
      val target = (action as? PhoneAction.Tap)?.id ?: (action as? PhoneAction.LongPress)?.id
      val el = target?.let { screen.element(it) }
      if (target != null && el == null) { history += "$what: no element #$target on this screen"; step("$what: element not on screen", ok = false); continue }
      val xyLabel = (action as? PhoneAction.TapXY)?.label ?: (action as? PhoneAction.LongPressXY)?.label
      RiskGuard.classify(el?.label ?: xyLabel)?.let { risk ->
        if (!ask(what, "This looks like ${risk.title} in $label. The agent never does this on its own.", "Allow this tap")) {
          step("$what: declined by you", ok = false)
          return "Stopped before ${risk.title}. You can finish it yourself."
        }
      }
      if (action is PhoneAction.Type) {
        val field = action.id?.let { screen.element(it) }
        if ((field != null && RiskGuard.isSecretField(field)) || RiskGuard.looksSecret(action.text)) {
          if (!ask("Type it yourself", "Passwords, PINs, OTPs and card numbers are never typed by the agent. Type it in $label, then tap Continue.", "Continue")) return "Stopped at a password or code field."
          history += "User typed a secret field themselves"
          step("You typed the secret field")
          continue
        }
      }

      // The user opened the message box or sent a note while the model was thinking: drop this action, re-plan.
      while (composing) { delay(250); deadline += 250 }
      if (notes.isNotEmpty()) continue
      step(what)
      overlay("Step $n · $label", what)
      val ok = execute(action, snap, svc(), scale)
      history += what + if (ok) "" else " (failed)"
      if (!ok) _state.value = _state.value.copy(steps = _state.value.steps.dropLast(1) + Step("$what (failed)", false))
      while (history.size > 4) history.removeFirst()
      delay(if (action is PhoneAction.Wait) action.ms else 1200)
    }
    return "Stopped after $maxSteps steps without finishing."
  }

  private suspend fun fastPath(r: FastPaths.Route, svc: PhoneAgentService): String? = when (r) {
    is FastPaths.Route.YouTube -> {
      val search = Intent(Intent.ACTION_SEARCH).setPackage(FastPaths.YOUTUBE_PKG).putExtra(android.app.SearchManager.QUERY, r.query)
      if (svc.launch(search) || svc.launch(Intent(Intent.ACTION_VIEW, Uri.parse(FastPaths.youtubeSearchUrl(r.query))))) "Searched YouTube for \"${r.query}\"" else null
    }
    is FastPaths.Route.Url -> if (!com.example.security.UrlPolicy.isWebUrl(r.url)) null else if (svc.launch(Intent(Intent.ACTION_VIEW, Uri.parse(r.url)))) "Opened ${r.url}" else null
    is FastPaths.Route.System -> null
    is FastPaths.Route.Message -> fastPath(FastPaths.Route.App(r.app), svc)
    is FastPaths.Route.App -> AppMatcher.matchLeading(r.name, svc.installedApps())?.let { a ->
      app.packageManager.getLaunchIntentForPackage(a.pkg)?.let { if (svc.launch(it)) "Opened ${a.label}" else null }
    }
  }

  private suspend fun execute(a: PhoneAction, snap: PhoneAgentService.Snapshot, svc: PhoneAgentService, scale: Float): Boolean = withContext(Dispatchers.Main) {
    when (a) {
      is PhoneAction.Tap -> snap.nodes[a.id]?.let { svc.tap(it) } ?: false
      is PhoneAction.LongPress -> snap.nodes[a.id]?.let { svc.tap(it, long = true) } ?: false
      is PhoneAction.Type -> svc.type(a.id?.let { snap.nodes[it] }, a.text)
      PhoneAction.Enter -> svc.enter()
      is PhoneAction.Scroll -> svc.scroll(a.direction, a.id?.let { snap.nodes[it] }, snap.width, snap.height)
      is PhoneAction.TapXY -> svc.gesture(a.x * scale, a.y * scale, a.x * scale, a.y * scale, 60)
      is PhoneAction.LongPressXY -> svc.gesture(a.x * scale, a.y * scale, a.x * scale, a.y * scale, 700)
      is PhoneAction.Swipe -> svc.gesture(a.x1 * scale, a.y1 * scale, a.x2 * scale, a.y2 * scale, 400)
      PhoneAction.Back -> svc.global(AccessibilityService.GLOBAL_ACTION_BACK)
      PhoneAction.Home -> svc.global(AccessibilityService.GLOBAL_ACTION_HOME)
      PhoneAction.Recents -> svc.global(AccessibilityService.GLOBAL_ACTION_RECENTS)
      PhoneAction.Notifications -> svc.global(AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
      PhoneAction.QuickSettings -> svc.global(if (android.os.Build.VERSION.SDK_INT >= 31) AccessibilityService.GLOBAL_ACTION_QUICK_SETTINGS else AccessibilityService.GLOBAL_ACTION_NOTIFICATIONS)
      is PhoneAction.OpenApp -> {
        // Like a person: home pages / app drawer, then the icon; the direct launch is only the fallback.
        openAppByUi(a.name) { svc } != null || fastPath(FastPaths.Route.App(a.name), svc) != null
      }
      is PhoneAction.OpenUrl, is PhoneAction.YouTubeSearch -> {
        val r = if (a is PhoneAction.OpenUrl) FastPaths.Route.Url(a.url) else FastPaths.Route.YouTube((a as PhoneAction.YouTubeSearch).query)
        fastPath(r, svc) != null
      }
      is PhoneAction.Wait -> true
      is PhoneAction.Done, is PhoneAction.Ask -> true
    }
  }

  /** Direct Android calls, no screen needed: torch, volume, settings pages. Null when it did not work (the agent then tries). */
  private suspend fun runSystem(setting: String, svc: () -> PhoneAgentService): String? = withContext(Dispatchers.Main) {
    runCatching {
      when (setting) {
        "flashlight_on", "flashlight_off" -> {
          val cm = app.getSystemService(Context.CAMERA_SERVICE) as android.hardware.camera2.CameraManager
          val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
          if (id == null) null else { cm.setTorchMode(id, setting == "flashlight_on"); if (setting == "flashlight_on") "Flashlight is on" else "Flashlight is off" }
        }
        "volume_up", "volume_down" -> {
          val am = app.getSystemService(Context.AUDIO_SERVICE) as android.media.AudioManager
          val dir = if (setting == "volume_up") android.media.AudioManager.ADJUST_RAISE else android.media.AudioManager.ADJUST_LOWER
          repeat(3) { am.adjustStreamVolume(android.media.AudioManager.STREAM_MUSIC, dir, if (it == 2) android.media.AudioManager.FLAG_SHOW_UI else 0) }
          if (setting == "volume_up") "Volume turned up" else "Volume turned down"
        }
        "wifi_settings" -> if (svc().launch(Intent(android.provider.Settings.ACTION_WIFI_SETTINGS))) "Opened Wi-Fi settings" else null
        "bluetooth_settings" -> if (svc().launch(Intent(android.provider.Settings.ACTION_BLUETOOTH_SETTINGS))) "Opened Bluetooth settings" else null
        else -> null
      }
    }.getOrNull()
  }

  private suspend fun routeTask(task: String, settings: SettingsState): FastPaths.Route? {
    val out = StringBuilder()
    val reply = withTimeoutOrNull(if (settings.backendMode == "remote") 20_000L else 45_000L) {
      graph.llamaEngine.generateCompletionStream(
        prompt = "Task: " + task.take(400), settings = settings.copy(thinking = false), onTelemetryUpdate = {},
        chatOnly = true, systemOverride = IntentRouter.SYSTEM, images = emptyList()
      ).takeWhile { chunk -> out.append(chunk); !Regex("\\{[^{}]*\"tool\"[^{}]*\\}").containsMatchIn(out) }.collect { }
      out.toString()
    }
    if (reply == null) { runCatching { graph.llamaEngine.stopNow() }; return FastPaths.route(task) }
    return if (Regex("\"tool\"").containsMatchIn(reply)) IntentRouter.parse(reply) else FastPaths.route(task)
  }

  private suspend fun generate(prompt: String, settings: SettingsState, image: String?): String {
    val out = StringBuilder()
    // chatOnly caps the reply at 1024 tokens; one JSON action needs far less. Thinking off saves tokens.
    graph.llamaEngine.generateCompletionStream(
      prompt = prompt, settings = settings.copy(thinking = false), onTelemetryUpdate = {},
      chatOnly = true, systemOverride = SYSTEM, images = listOfNotNull(image)
    ).takeWhile { chunk ->
      out.append(chunk)
      // Stop generating as soon as one complete JSON object is out: no tokens spent after the action.
      !ACTION_DONE.containsMatchIn(out)
    }.collect { }
    return out.toString()
  }

  private fun notifications(): NotificationManager = app.getSystemService(NotificationManager::class.java)

  private fun notify(title: String, text: String) {
    val nm = notifications()
    if (android.os.Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL) == null) {
      nm.createNotificationChannel(NotificationChannel(CHANNEL, "Phone agent approvals", NotificationManager.IMPORTANCE_HIGH))
    }
    val open = PendingIntent.getActivity(app, 7, Intent(app, com.example.MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
    runCatching {
      nm.notify(NOTE_APPROVAL, NotificationCompat.Builder(app, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_dialog_alert)
        .setContentTitle("Needs your approval: $title")
        .setContentText(text).setStyle(NotificationCompat.BigTextStyle().bigText(text))
        .setContentIntent(open).setAutoCancel(true).build())
    }
  }

  companion object {
    const val MAX_STEPS = 25
    const val VISION_MAX_STEPS = 60
    const val SHOT_W = 720
    const val SHOT_W_LOCAL = 540
    private val ACTION_DONE = Regex("\\{[^{}]*\"action\"[^{}]*\\}")
    private const val CHANNEL = "phone_agent_approval"
    private const val NOTE_APPROVAL = 7107

    /** Kept short on purpose: it is sent with every step. */
    val SYSTEM = """You control an Android phone to finish the user's task. Each turn you see the current screen as numbered elements.
Reply with exactly ONE JSON object and nothing else. Actions:
${PhoneActionParser.TOOLS}
Rules: use ids from the current screen only. Act like a person: use open_app for apps, quick_settings for flashlight, Wi-Fi, Bluetooth, brightness and similar switches, and tap what you see. When a screenshot is attached and no element fits, use tap_xy with a label. Look at the screenshot after each action to check it worked. After typing in a search box use enter. When the task is complete reply done. If you need information only the user has, reply ask. Never enter passwords, PINs, OTPs or card numbers."""

    @Volatile private var instance: PhoneAgent? = null
    fun get(context: Context): PhoneAgent =
      instance ?: synchronized(this) { instance ?: PhoneAgent(context.applicationContext).also { instance = it } }
  }
}

/** v1.7.0: every phone task with each step, kept on the phone (filesDir/phone_history.jsonl, last 50). */
object PhoneHistory {
  data class Entry(val time: Long, val task: String, val steps: List<String>, val result: String, val remote: Boolean)

  private fun file(ctx: Context) = java.io.File(ctx.filesDir, "phone_history.jsonl")

  fun append(ctx: Context, task: String, steps: List<String>, result: String, remote: Boolean) = runCatching {
    val line = com.example.agent.MiniJson.encode(listOf(
      "time" to System.currentTimeMillis(), "task" to task, "steps" to steps.joinToString("\n"), "result" to result, "remote" to remote
    ))
    val f = file(ctx)
    val lines = (if (f.isFile) f.readLines() else emptyList()) + line
    f.writeText(lines.takeLast(50).joinToString("\n") + "\n")
  }

  fun read(ctx: Context): List<Entry> = runCatching {
    file(ctx).takeIf { it.isFile }?.readLines().orEmpty().mapNotNull { l ->
      runCatching {
        val m = com.example.agent.MiniJson.parseObject(l)
        Entry((m["time"] as Number).toLong(), m["task"] as String, (m["steps"] as String).split("\n").filter { it.isNotBlank() }, m["result"] as String, m["remote"] == true)
      }.getOrNull()
    }.reversed()
  }.getOrDefault(emptyList())

  fun clear(ctx: Context) { file(ctx).delete() }
}
