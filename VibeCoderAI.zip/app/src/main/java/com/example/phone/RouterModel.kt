package com.example.phone

import com.example.data.downloader.Mmproj
import com.example.data.model.SettingsState
import com.example.llama.LlamaBridge
import com.example.llama.MemoryEstimator
import java.io.File

/**
 * v1.9.5: the fine-tuned phone-router model (Qwen3-1.7B LoRA, trained to map a task in any language to one JSON function).
 * It runs on its own llama handle beside the main model, with a tiny context, so routing takes a moment instead of
 * a full main-model call. The prompt is exactly the training format (system prompt, raw task, empty think block).
 * When it is not set, does not fit free RAM or fails, the caller falls back to the main model and then to the regex rules.
 */
object RouterModel {
  /** Must stay identical to the system prompt the model was fine-tuned with. */
  const val SYSTEM = "Map the phone task (any language) to ONE JSON function: open_app{app}, youtube{query,play}, " +
    "whatsapp{contact,text}, system{setting}, agent (needs screen work), none (chat/no phone action). Reply with JSON only."

  private const val CTX = 1024
  private val bridge by lazy { LlamaBridge.newInstance() }
  @Volatile private var loadedKey: String? = null

  /** Qwen3 ChatML with thinking off, as produced by the training chat template. */
  fun prompt(task: String): String =
    "<|im_start|>system\n$SYSTEM<|im_end|>\n<|im_start|>user\n$task<|im_end|>\n<|im_start|>assistant\n<think>\n\n</think>\n\n"

  /** The router file: the one chosen in Models, else any installed model whose name contains "router". */
  fun resolve(settings: SettingsState, modelsDir: File): File? {
    settings.routerModelPath?.let { p -> File(p).takeIf { it.isFile }?.let { return it } }
    return modelsDir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", true) && !Mmproj.isMmproj(f.name) && f.name.contains("router", true) }
      ?.minByOrNull { it.name }
  }

  /** Null when the router is loaded and ready, otherwise why it is not. */
  @Synchronized
  fun ensureLoaded(file: File, threads: Int, freeBytes: Long): String? {
    val key = "${file.absolutePath}|${file.length()}"
    if (loadedKey == key && bridge.isModelLoaded) return null
    unload()
    val need = MemoryEstimator.neededBytes(file.length(), CTX)
    if (freeBytes > 0 && need > freeBytes) return "Not enough free RAM for the router model (needs ${need / 1048576} MB, ${freeBytes / 1048576} MB free)."
    val ok = bridge.initModel(file.absolutePath, threads.coerceIn(1, 8), CTX, 0)
    if (!ok) return bridge.lastError ?: "The router model could not be loaded."
    loadedKey = key
    return null
  }

  /** The model's raw reply (stops at the first complete JSON object), or null on failure or after [timeoutMs]. */
  @Synchronized
  fun route(task: String, timeoutMs: Long): String? {
    if (!bridge.isModelLoaded) return null
    val deadline = System.currentTimeMillis() + timeoutMs
    val out = StringBuilder()
    val n = bridge.generate(
      prompt = prompt(task), maxTokens = 96, temperature = 0.1f, topP = 1f, topK = 1, repeatPenalty = 1f,
      onProgress = { _, _ -> System.currentTimeMillis() < deadline },
      onPiece = { piece ->
        out.append(piece)
        !out.contains('}') && System.currentTimeMillis() < deadline
      }
    )
    return if (n < 0 || out.isEmpty()) null else out.toString()
  }

  @Synchronized
  fun unload() {
    bridge.freeModel()
    loadedKey = null
  }
}
