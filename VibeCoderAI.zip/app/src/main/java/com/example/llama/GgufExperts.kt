package com.example.llama

import java.io.BufferedInputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.util.concurrent.ConcurrentHashMap

/** How a GGUF model file splits into routed-expert tensors and everything else. See [GgufExperts]. */
data class ExpertSplit(val totalBytes: Long, val expertBytes: Long, val expertCount: Int, val expertUsed: Int) {
  /** A mixture-of-experts model whose expert tensors could be recognised in the file. */
  val isMoe: Boolean get() = expertCount > 1 && expertBytes > 0 && expertBytes < totalBytes

  /** Attention, embeddings, shared experts and norms: needed for every token, so they have to stay in RAM. */
  val coreBytes: Long get() = totalBytes - expertBytes
}

/**
 * v1.9.26: reads only the header of a GGUF file (key/value metadata and the tensor list, a few MB at most) and adds up the
 * bytes of the routed-expert tensors (names containing "_exps"). A mixture-of-experts model uses a few experts per token, so
 * the experts can be read from storage on demand while the rest stays in RAM: that is how a model bigger than the free RAM
 * can still run. Dense models have no expert tensors and are reported as not MoE.
 *
 * Pure: [parse] works on any stream, so it is unit tested with a small synthetic file. Never throws; any problem gives null.
 */
object GgufExperts {
  private const val MAGIC = 0x46554747L // "GGUF" read as a little-endian 32-bit number
  private const val MAX_STRING = 1L shl 20
  private const val MAX_TENSORS = 100_000L
  private const val MAX_KV = 100_000L
  private const val MAX_ARRAY = 50_000_000L

  private class Reader(private val ins: InputStream) {
    var pos = 0L
    private val b = ByteArray(8)

    private fun fill(n: Int) {
      var off = 0
      while (off < n) {
        val r = ins.read(b, off, n - off)
        if (r < 0) throw EOFException()
        off += r
      }
      pos += n
    }

    fun u8(): Long { fill(1); return b[0].toLong() and 0xFF }
    fun u16(): Long { fill(2); return (b[0].toLong() and 0xFF) or ((b[1].toLong() and 0xFF) shl 8) }
    fun u32(): Long { fill(4); var v = 0L; for (i in 3 downTo 0) v = (v shl 8) or (b[i].toLong() and 0xFF); return v }
    fun u64(): Long { fill(8); var v = 0L; for (i in 7 downTo 0) v = (v shl 8) or (b[i].toLong() and 0xFF); return v }

    fun skip(n: Long) {
      if (n < 0) throw IOException("negative skip")
      var left = n
      while (left > 0) {
        val s = ins.skip(left)
        if (s > 0) { left -= s; pos += s } else {
          if (ins.read() < 0) throw EOFException()
          left -= 1; pos += 1
        }
      }
    }

    fun str(): String {
      val len = u64()
      if (len < 0 || len > MAX_STRING) throw IOException("bad string length")
      val buf = ByteArray(len.toInt())
      var off = 0
      while (off < buf.size) {
        val r = ins.read(buf, off, buf.size - off)
        if (r < 0) throw EOFException()
        off += r
      }
      pos += len
      return String(buf, Charsets.UTF_8)
    }

    fun skipString() {
      val len = u64()
      if (len < 0 || len > MAX_STRING) throw IOException("bad string length")
      skip(len)
    }
  }

  /** Size in bytes of a fixed-size GGUF value type, or -1 for strings and arrays. */
  private fun fixedSize(type: Int): Int = when (type) {
    0, 1, 7 -> 1
    2, 3 -> 2
    4, 5, 6 -> 4
    10, 11, 12 -> 8
    else -> -1
  }

  private fun readUInt(r: Reader, type: Int): Long = when (type) {
    0 -> r.u8()
    2 -> r.u16()
    4, 5 -> r.u32()
    10, 11 -> r.u64()
    else -> throw IOException("not an integer")
  }

  private fun skipValue(r: Reader, type: Int, depth: Int) {
    val fixed = fixedSize(type)
    when {
      fixed > 0 -> r.skip(fixed.toLong())
      type == 8 -> r.skipString()
      type == 9 -> {
        if (depth > 2) throw IOException("arrays nested too deep")
        val elem = r.u32().toInt()
        val n = r.u64()
        if (n < 0 || n > MAX_ARRAY) throw IOException("bad array length")
        val size = fixedSize(elem)
        if (size > 0) r.skip(n * size) else {
          var i = 0L
          while (i < n) { skipValue(r, elem, depth + 1); i++ }
        }
      }
      else -> throw IOException("unknown value type $type")
    }
  }

  /** [fileLength] is the size of the whole file (the tensor data after the header is not read). Null when it is not a GGUF v2/v3 file. */
  fun parse(input: InputStream, fileLength: Long): ExpertSplit? {
    try {
      val r = Reader(input)
      if (r.u32() != MAGIC) return null
      val version = r.u32()
      if (version < 2 || version > 3) return null
      val tensorCount = r.u64()
      val kvCount = r.u64()
      if (tensorCount < 0 || tensorCount > MAX_TENSORS || kvCount < 0 || kvCount > MAX_KV) return null

      var experts = 0L
      var used = 0L
      var alignment = 32L
      var i = 0L
      while (i < kvCount) {
        val key = r.str()
        val type = r.u32().toInt()
        when {
          key.endsWith(".expert_count") -> experts = readUInt(r, type)
          key.endsWith(".expert_used_count") -> used = readUInt(r, type)
          key == "general.alignment" -> alignment = readUInt(r, type)
          else -> skipValue(r, type, 0)
        }
        i++
      }

      val n = tensorCount.toInt()
      val offsets = LongArray(n)
      val isExpert = BooleanArray(n)
      for (t in 0 until n) {
        val name = r.str()
        val dims = r.u32()
        if (dims < 1 || dims > 8) return null
        r.skip(dims * 8)
        r.u32() // tensor type
        val offset = r.u64()
        if (offset < 0) return null
        offsets[t] = offset
        isExpert[t] = name.contains("_exps")
      }

      if (alignment <= 0 || alignment > (1L shl 20)) alignment = 32L
      val dataStart = (r.pos + alignment - 1) / alignment * alignment
      if (dataStart > fileLength) return null
      val dataLength = fileLength - dataStart

      // A tensor runs up to the start of the next one (the last one up to the end of the file).
      val order = (0 until n).sortedBy { offsets[it] }
      var expertBytes = 0L
      for (k in order.indices) {
        val t = order[k]
        val end = if (k + 1 < order.size) offsets[order[k + 1]] else dataLength
        val size = end - offsets[t]
        if (size < 0) return null
        if (isExpert[t]) expertBytes += size
      }
      return ExpertSplit(fileLength, expertBytes, experts.coerceIn(0, 100_000).toInt(), used.coerceIn(0, 100_000).toInt())
    } catch (e: Exception) {
      return null
    }
  }

  fun scan(file: File): ExpertSplit? = try {
    BufferedInputStream(FileInputStream(file), 1 shl 16).use { parse(it, file.length()) }
  } catch (e: Exception) {
    null
  }

  private class Scanned(val split: ExpertSplit?)

  private val cache = ConcurrentHashMap<String, Scanned>()

  /** [scan] once per file version: a few MB of header are read the first time only. */
  fun cached(file: File): ExpertSplit? {
    val key = "${file.absolutePath}|${file.length()}|${file.lastModified()}"
    return cache.getOrPut(key) { Scanned(scan(file)) }.split
  }
}
