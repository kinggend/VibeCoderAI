package com.example.llama

import java.util.Locale

/** Memory of this app as the OS counts it. File-backed pages are memory-mapped files (the model); the OS can drop them, so they are not heap use. */
data class MemSplit(val rssMb: Long, val anonMb: Long, val fileMb: Long, val byPss: Boolean)

data class DeviceSnapshot(
  val thermal: String? = null,
  val thermalLevel: Int? = null,
  val batteryTempC: Double? = null,
  val batteryPercent: Int? = null,
  val charging: Boolean? = null,
  val mem: MemSplit? = null
)

/**
 * v1.9.30: phone state around a run (thermal status, battery temperature, memory split). Pure parsing and wording, unit tested.
 * Readings are taken before and after a run. They are not peaks: nothing here samples during the run.
 */
object DeviceTelemetry {
  fun thermalLabel(status: Int?): String? = when (status) {
    0 -> "None"
    1 -> "Light"
    2 -> "Moderate"
    3 -> "Severe"
    4 -> "Critical"
    5 -> "Emergency"
    6 -> "Shutdown"
    else -> null
  }

  /** Moderate or worse: the phone is slowing itself down. */
  fun isThrottling(level: Int?): Boolean = level != null && level >= 2

  /** Parses /proc/self/smaps_rollup. Null when it cannot split anonymous from file-backed memory. */
  fun parseSmapsRollup(text: String): MemSplit? {
    val kb = HashMap<String, Long>()
    for (line in text.lineSequence()) {
      val c = line.indexOf(':')
      if (c <= 0) continue
      val num = line.substring(c + 1).trim().substringBefore(' ').toLongOrNull() ?: continue
      kb[line.substring(0, c).trim()] = num
    }
    val rss = kb["Rss"]
    val pssAnon = kb["Pss_Anon"]
    val pssFile = kb["Pss_File"]
    if (pssAnon != null && pssFile != null) return MemSplit((rss ?: (pssAnon + pssFile)) / 1024, pssAnon / 1024, pssFile / 1024, true)
    val anon = kb["Anonymous"]
    if (rss != null && anon != null) return MemSplit(rss / 1024, anon / 1024, (rss - anon).coerceAtLeast(0) / 1024, false)
    return null
  }

  private fun mb(v: Long): String = String.format(Locale.US, "%,d MB", v)

  /** Two or three plain lines for the Speed test result. */
  fun describe(before: DeviceSnapshot, after: DeviceSnapshot): String {
    val sb = StringBuilder()
    val tb = before.thermal
    val ta = after.thermal
    val thermal = when {
      ta == null -> "thermal status not available on this Android version"
      tb == null || tb == ta -> "thermal $ta" + if (tb != null) " (unchanged)" else ""
      else -> "thermal $tb → $ta"
    }
    val battery = ArrayList<String>()
    after.batteryTempC?.let { battery.add(String.format(Locale.US, "battery %.1f °C", it)) }
    after.batteryPercent?.let { battery.add("charge $it%" + if (after.charging == true) ", charging" else "") }
    sb.append("Device: ").append(thermal)
    if (battery.isNotEmpty()) sb.append(" · ").append(battery.joinToString(" · "))
    if (isThrottling(after.thermalLevel)) sb.append("\nThe phone is throttling, so speeds may be lower than normal. Let it cool and test again.")
    after.mem?.let {
      sb.append("\nMemory after the run (").append(if (it.byPss) "PSS" else "RSS").append("): anonymous ").append(mb(it.anonMb))
        .append(", file-backed ").append(mb(it.fileMb)).append(" (memory-mapped model pages the OS can drop; not heap use)")
    }
    return sb.toString()
  }

  /** Puts [extra] before the long "CPU:" line, or at the end when there is none. */
  fun insertBeforeCpu(text: String, extra: String): String {
    if (extra.isBlank()) return text
    val i = text.indexOf("\nCPU:")
    return if (i < 0) text + "\n" + extra else text.substring(0, i) + "\n" + extra + text.substring(i)
  }
}
