package com.example.llama

/**
 * v1.4: rough RAM need of a GGUF model before loading it: weights x 1.2 (runtime buffers on top of the
 * file) + KV cache for the context + a fixed compute/scratch overhead. The KV size per token is scaled
 * from the file size (about 32 KB per GB of weights, at least 12 KB: 0.5B models need ~12 KB/token,
 * 1B ~32 KB, 8B ~128 KB with f16 KV). Deliberately conservative. Pure, unit tested.
 *
 * v1.9.26: a mixture-of-experts model that does not fit as a whole can still run when only its core (attention,
 * embeddings, shared experts) has to stay in RAM and the routed experts are read from storage on demand: see [streamPlan].
 */
object MemoryEstimator {
  private const val MB = 1024L * 1024L
  private const val GB = 1024L * MB
  const val OVERHEAD_BYTES = 150L * MB

  /** Safe context to fall back to when the requested one does not fit. */
  const val SAFE_FALLBACK = 1024

  /**
   * The KV cache is sized from the file size, which is wrong for a mixture-of-experts file (most of it is experts, not attention).
   * For those it is sized from the core bytes times this factor (5/2), measured against a 30B-A3B model (about 52 KB per token).
   */
  private const val MOE_KV_NUM = 5L
  private const val MOE_KV_DEN = 2L

  /** The context the engine will really use and whether it had to be lowered to fit free RAM. */
  data class Guarded(val contextTokens: Int, val lowered: Boolean, val neededBytes: Long)

  /** A context that exceeds free RAM falls back to the largest standard size that fits, else [SAFE_FALLBACK]. */
  fun guard(fileBytes: Long, requested: Int, availableBytes: Long, kvBasisBytes: Long = fileBytes): Guarded {
    val need = neededBytes(fileBytes, requested, kvBasisBytes)
    if (availableBytes <= 0 || need <= availableBytes) return Guarded(requested, false, need)
    return Guarded(suggestContext(fileBytes, requested, availableBytes, kvBasisBytes) ?: SAFE_FALLBACK, true, need)
  }

  /**
   * How a model runs when it does not fit as a whole: [residentBytes] (the core) stay in RAM, [streamedBytes] of experts are read
   * from storage on demand, and about [cachedFraction] of those can stay cached in the RAM that is left.
   */
  data class StreamPlan(
    val residentBytes: Long,
    val kvBasisBytes: Long,
    val streamedBytes: Long,
    val neededBytes: Long,
    val cachedFraction: Double
  )

  /** [streams] is set when the model only fits because its experts stream from storage; [fits] is then true. */
  data class Verdict(
    val fits: Boolean,
    val neededBytes: Long,
    val availableBytes: Long,
    val suggestedContext: Int?,
    val streams: StreamPlan? = null
  )

  /** v1.9.1: the CPU engine stores the KV cache as q8_0 (34 bytes per 32 values instead of 64 for f16). */
  fun kvBytesPerToken(fileBytes: Long): Long =
    maxOf(12L * 1024, (32L * 1024 * fileBytes) / GB) * 17 / 32

  /** [kvBasisBytes] is the size the KV cache is scaled from: the file itself for a dense model. */
  fun neededBytes(fileBytes: Long, contextTokens: Int, kvBasisBytes: Long = fileBytes): Long =
    (fileBytes * 12) / 10 + contextTokens.toLong() * kvBytesPerToken(kvBasisBytes) + OVERHEAD_BYTES

  /** Largest standard context below [contextTokens] that fits [availableBytes], or null when none does. */
  fun suggestContext(fileBytes: Long, contextTokens: Int, availableBytes: Long, kvBasisBytes: Long = fileBytes): Int? =
    listOf(8192, 6144, 4096, 3072, 2048, 1024, 512)
      .filter { it < contextTokens }
      .firstOrNull { neededBytes(fileBytes, it, kvBasisBytes) <= availableBytes }

  /**
   * The streaming plan for a mixture-of-experts model, or null when [split] is not MoE, free memory is unknown, or even the core
   * (plus KV cache) does not fit. Only meant for a model that does not fit as a whole: [check] calls it after that test.
   */
  fun streamPlan(split: ExpertSplit?, contextTokens: Int, availableBytes: Long): StreamPlan? {
    if (split == null || !split.isMoe || availableBytes <= 0) return null
    val core = split.coreBytes
    val basis = core * MOE_KV_NUM / MOE_KV_DEN
    val need = neededBytes(core, contextTokens, basis)
    if (need > availableBytes) return null
    val cached = ((availableBytes - need).toDouble() / split.expertBytes).coerceIn(0.0, 1.0)
    return StreamPlan(core, basis, split.expertBytes, need, cached)
  }

  /** [split] describes the same file as [fileBytes]; pass null for a vision model (the image helper is not part of it) or a dense one. */
  fun check(fileBytes: Long, contextTokens: Int, availableBytes: Long, split: ExpertSplit? = null): Verdict {
    val need = neededBytes(fileBytes, contextTokens)
    val fits = availableBytes <= 0 || need <= availableBytes // unknown memory: do not block
    if (fits) return Verdict(true, need, availableBytes, null)
    val plan = streamPlan(split, contextTokens, availableBytes)
    if (plan != null) return Verdict(true, plan.neededBytes, availableBytes, null, plan)
    return Verdict(false, need, availableBytes, suggestContext(fileBytes, contextTokens, availableBytes))
  }
}

/**
 * What the Models screen needs to draw the RAM bar: model (+ image helper) size, free RAM and any forced minimum context.
 * v1.9.26: for a model that streams its experts, [fileBytes] is the core that stays in RAM, [kvBasisBytes] sizes the KV cache and
 * [streamedBytes] is what is read from storage on demand.
 */
data class ModelMemory(
  val fileBytes: Long,
  val freeBytes: Long,
  val minContext: Int = 0,
  val kvBasisBytes: Long = fileBytes,
  val streamedBytes: Long = 0L
) {
  fun neededBytes(contextTokens: Int): Long = MemoryEstimator.neededBytes(fileBytes, contextTokens, kvBasisBytes)

  fun guard(contextTokens: Int): MemoryEstimator.Guarded = MemoryEstimator.guard(fileBytes, contextTokens, freeBytes, kvBasisBytes)

  fun kvBytesPerToken(): Long = MemoryEstimator.kvBytesPerToken(kvBasisBytes)

  /** Share (0..1) of the streamed expert bytes that can stay cached in the RAM left after the model's own needs. */
  fun cachedFraction(contextTokens: Int): Double =
    if (streamedBytes <= 0) 1.0 else ((freeBytes - neededBytes(contextTokens)).toDouble() / streamedBytes).coerceIn(0.0, 1.0)
}
