package com.example.llama

import java.util.Locale

/**
 * v1.9.24: speed numbers for a remote model, worked out from the timing of its own reply stream. Pure, unit tested.
 * The test sends one short fixed prompt (nothing from the person's projects or chats) and stops reading early,
 * so it costs a few hundred tokens at most.
 */
object RemoteSpeed {
  /** Short, needs almost no thinking, and the answer is long enough to time (about 100 tokens). */
  const val PROMPT = "Count from 1 to 80, one number per line. Output only the numbers."
  const val MAX_TOKENS = 400

  /** The test stops reading after this many streamed chunks or this many milliseconds. */
  const val CHUNK_CAP = 120
  const val TIME_CAP_MS = 20_000L

  /** Fewer chunks than this cannot give a steady speed. */
  const val MIN_CHUNKS = 8

  /** A typical generated file, used to turn the speed into something concrete. */
  private const val FILE_TOKENS = 500

  /** Times in milliseconds on one clock. [firstMs] is null when no text chunk ever arrived. */
  data class Timing(val startMs: Long, val firstMs: Long?, val lastMs: Long, val chunks: Int)

  /** Chunks per second between the first and the last chunk (one chunk is about one token), or null when it cannot be told. */
  fun tokensPerSecond(t: Timing): Double? {
    val first = t.firstMs ?: return null
    if (t.chunks < MIN_CHUNKS) return null
    val span = t.lastMs - first
    if (span < 50) return null
    return (t.chunks - 1) * 1000.0 / span
  }

  private fun seconds(ms: Long): String = String.format(Locale.US, "%.1f", ms / 1000.0)

  fun summarize(t: Timing): String {
    val first = t.firstMs ?: return "No reply came back. Check the model name and the key, then try again."
    val head = "First token in ${seconds(first - t.startMs)} s."
    val rate = tokensPerSecond(t) ?: return "$head The reply was too short to measure the speed."
    val perFile = FILE_TOKENS / rate
    val speed = if (rate >= 10) rate.toInt().toString() else String.format(Locale.US, "%.1f", rate)
    return "$head About $speed tokens/s, so a $FILE_TOKENS-token file takes about ${seconds((perFile * 1000).toLong())} s. " +
      "Counted from ${t.chunks} streamed pieces; your network is included."
  }
}
