package com.example.llama

import java.util.Locale

/**
 * v1.9.24: speed numbers for a remote model, worked out from the timing of its own reply stream. Pure, unit tested.
 * The test sends one short fixed prompt (nothing from the person's projects or chats) and stops reading early,
 * so it costs about a thousand tokens at most.
 */
object RemoteSpeed {
  /** Short, needs almost no thinking, and the answer is long enough to time even a very fast model (hundreds of tokens). */
  const val PROMPT = "Count from 1 to 400, one number per line. Output only the numbers."
  const val MAX_TOKENS = 1000

  /** The test stops reading after this many streamed chunks or this many milliseconds, whatever comes first. */
  const val CHUNK_CAP = 600
  const val TIME_CAP_MS = 20_000L

  /**
   * v1.9.25: the first version stopped after 120 chunks, which a 500 tokens/s model delivers in 0.24 s: two runs of the same model
   * said 481 and 650. Now it reads for at least this long after the first chunk, and for at least [ENOUGH_CHUNKS] chunks
   * (a slow model needs more time, not more chunks).
   */
  const val MIN_WINDOW_MS = 1_500L
  const val ENOUGH_CHUNKS = 24

  /** Fewer chunks than this cannot give a steady speed. */
  const val MIN_CHUNKS = 8

  /** A typical generated file, used to turn the speed into something concrete. */
  private const val FILE_TOKENS = 500

  /** True while the test should keep reading. [chunks] have arrived so far; [firstMs] is null until the first one. */
  fun keepReading(chunks: Int, firstMs: Long?, startMs: Long, nowMs: Long): Boolean {
    if (nowMs - startMs >= TIME_CAP_MS || chunks >= CHUNK_CAP) return false
    val first = firstMs ?: return true
    return !(nowMs - first >= MIN_WINDOW_MS && chunks >= ENOUGH_CHUNKS)
  }

  /** Times in milliseconds on one clock. [firstMs] is null when no text chunk ever arrived. */
  data class Timing(val startMs: Long, val firstMs: Long?, val lastMs: Long, val chunks: Int)

  /** Chunks per second between the first and the last chunk (one chunk is about one token), or null when it cannot be told. */
  fun tokensPerSecond(t: Timing): Double? {
    val first = t.firstMs ?: return null
    if (t.chunks < MIN_CHUNKS) return null
    val span = t.lastMs - first
    if (span < 50) return null
    return (t.chunks - 1) * 1000.0 / span
  }

  private fun seconds(ms: Long): String = String.format(Locale.US, "%.1f", ms / 1000.0)

  fun summarize(t: Timing): String {
    val first = t.firstMs ?: return "No reply came back. Check the model name and the key, then try again."
    val head = "First token in ${seconds(first - t.startMs)} s."
    val rate = tokensPerSecond(t) ?: return "$head The reply was too short to measure the speed."
    val perFile = FILE_TOKENS / rate
    // No false precision: hundreds are rounded to tens, tens to whole numbers.
    val speed = when {
      rate >= 100 -> (Math.round(rate / 10.0) * 10).toString()
      rate >= 10 -> rate.toInt().toString()
      else -> String.format(Locale.US, "%.1f", rate)
    }
    return "$head About $speed tokens/s, so a $FILE_TOKENS-token file takes about ${seconds((perFile * 1000).toLong())} s. " +
      "Counted from ${t.chunks} streamed pieces; your network is included."
  }
}
