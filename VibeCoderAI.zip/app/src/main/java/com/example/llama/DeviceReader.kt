package com.example.llama

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import android.os.Build
import android.os.PowerManager
import java.io.File

/** v1.9.30: reads the phone state for [DeviceTelemetry]. Every reading is best effort: a value the platform hides stays null, and nothing throws. */
object DeviceReader {
  /** [includeMemory] reads /proc/self/smaps_rollup, which can take a moment when a lot is mapped: ask for it only after a run. */
  fun read(context: Context, includeMemory: Boolean): DeviceSnapshot {
    val level = thermalLevel(context)
    var temp: Double? = null
    var percent: Int? = null
    var charging: Boolean? = null
    runCatching {
      val i = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
      if (i != null) {
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        if (t != Int.MIN_VALUE) temp = t / 10.0
        val l = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val s = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        if (l >= 0 && s > 0) percent = l * 100 / s
        val st = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
        charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
      }
    }
    val mem = if (includeMemory) runCatching { DeviceTelemetry.parseSmapsRollup(File("/proc/self/smaps_rollup").readText()) }.getOrNull() else null
    return DeviceSnapshot(DeviceTelemetry.thermalLabel(level), level, temp, percent, charging, mem)
  }

  private fun thermalLevel(context: Context): Int? {
    if (Build.VERSION.SDK_INT < 29) return null
    return runCatching { (context.getSystemService(Context.POWER_SERVICE) as PowerManager).currentThermalStatus }.getOrNull()
  }
}
