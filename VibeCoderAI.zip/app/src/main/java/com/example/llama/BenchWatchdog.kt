package com.example.llama

import java.util.concurrent.ExecutionException
import java.util.concurrent.FutureTask
import java.util.concurrent.TimeUnit
import java.util.concurrent.TimeoutException
import java.util.concurrent.atomic.AtomicBoolean

/**
 * v1.9.38: gives control back to the screen when a Speed test does not end at its time limit.
 *
 * The native test checks its limit between the steps of ggml's computation. On one phone a 30B model that streams its experts from
 * storage ran 2628 s and 944 s against a limit of 480 s, because one step kept waiting on storage reads and a read cannot be interrupted.
 * The screen would stay on "Testing" for that whole time. This runs the measurement on its own thread and waits at most [run]'s
 * `waitMs`; after that the caller gets [Outcome.StillRunning] and can say so. The measurement itself is not killed (it cannot be);
 * it ends by itself, and while it runs a second test is refused ([Outcome.Busy]) instead of queueing behind it.
 */
class BenchWatchdog {
  sealed class Outcome {
    data class Done(val text: String) : Outcome()
    object StillRunning : Outcome()
    object Busy : Outcome()
  }

  private val busy = AtomicBoolean(false)

  /** True from the moment a measurement starts until its thread has finished, also after the caller stopped waiting. */
  val isBusy: Boolean get() = busy.get()

  fun run(waitMs: Long, block: () -> String): Outcome {
    if (!busy.compareAndSet(false, true)) return Outcome.Busy
    val task = FutureTask<String> {
      try {
        block()
      } finally {
        busy.set(false)
      }
    }
    Thread(task, "speed-test").apply { isDaemon = true }.start()
    return try {
      Outcome.Done(task.get(waitMs, TimeUnit.MILLISECONDS))
    } catch (e: TimeoutException) {
      Outcome.StillRunning
    } catch (e: ExecutionException) {
      Outcome.Done("Speed test failed: ${e.cause?.message ?: e.cause?.javaClass?.simpleName ?: "unknown error"}")
    } catch (e: InterruptedException) {
      Thread.currentThread().interrupt()
      Outcome.StillRunning
    }
  }
}
