package com.example.llama

import java.util.Locale

/** One Speed test at one thread count (the numbers the native benchmark reports). */
data class ThreadRun(
  val threads: Int,
  val decodeTps: Double?,
  val prefillTps: Double?,
  val medianMs: Double?,
  val p95Ms: Double?
)

/** One thread count, its runs averaged. [spread] = gap between its fastest and slowest decode run, as a share of the slowest. */
data class ThreadRow(
  val threads: Int,
  val decodeTps: Double,
  val prefillTps: Double?,
  val medianMs: Double?,
  val p95Ms: Double?,
  val spread: Double,
  val runs: Int
)

data class ThreadAnalysis(
  val rows: List<ThreadRow>,
  val bestDecode: Int?,
  val bestPrefill: Int?,
  /** The run-to-run noise the verdict is judged against (at least 5%, or the widest gap between two runs of one setting). */
  val noise: Double,
  /** Only set when a thread count is clearly faster for generation than the user's own setting. Never applied by itself. */
  val suggested: Int?,
  val verdict: String
)

data class ThreadTestResult(val text: String, val suggested: Int?)

/**
 * v1.9.32: thread-count A/B. The same detailed Speed test is run at 4 / 6 / 8 threads (and at the user's own setting), in the order
 * a b c c b a after one warm-up run, so a phone that warms up during the test does not favour one setting and the first run does not
 * pay for cold model pages. Pure: the engine runs the tests, this object plans them and judges the numbers.
 *
 * What it can say: which tested thread count generated fastest here and now, and whether the difference is larger than the test's own
 * run-to-run variation. What it cannot say: anything about a different model, a different moment (heat, battery saver, other apps) or
 * different prompt lengths. It never changes the setting by itself.
 */
object ThreadBench {
  const val TIME_LIMIT_SEC = 240
  const val MIN_NOISE = 0.05
  /** Skip the test at this thermal level (Severe) or worse: the phone already slows itself hard. */
  const val ABORT_THERMAL_LEVEL = 3

  /** 4, 6 and 8 (as far as the phone has cores) plus the user's own setting. At least two values. */
  fun candidates(cores: Int, current: Int): List<Int> {
    val c = cores.coerceAtLeast(1)
    val set = java.util.TreeSet<Int>()
    for (t in listOf(4, 6, 8)) if (t <= c) set.add(t)
    if (current in 1..c) set.add(current)
    if (set.size < 2) { set.add(c); set.add((c / 2).coerceAtLeast(1)) }
    return set.toList()
  }

  /** a b c c b a: every setting twice, once early and once late. */
  fun order(candidates: List<Int>): List<Int> = candidates + candidates.reversed()

  fun analyze(runs: List<ThreadRun>, current: Int): ThreadAnalysis {
    val groups = runs.filter { it.decodeTps != null && it.decodeTps > 0.0 }.groupBy { it.threads }
    val rows = groups.keys.sorted().map { t ->
      val g = groups.getValue(t)
      val d = g.map { it.decodeTps!! }
      fun avg(v: List<Double>): Double? = if (v.isEmpty()) null else v.sum() / v.size
      ThreadRow(
        threads = t, decodeTps = d.sum() / d.size, prefillTps = avg(g.mapNotNull { it.prefillTps }),
        medianMs = avg(g.mapNotNull { it.medianMs }), p95Ms = avg(g.mapNotNull { it.p95Ms }),
        spread = if (d.size >= 2 && d.min() > 0.0) (d.max() - d.min()) / d.min() else 0.0, runs = d.size
      )
    }
    if (rows.size < 2 || rows.any { it.runs < 2 }) {
      return ThreadAnalysis(rows, null, null, MIN_NOISE, null, "Not enough valid runs to compare.")
    }
    val noise = maxOf(MIN_NOISE, rows.maxOf { it.spread })
    val best = rows.maxByOrNull { it.decodeTps }!!
    val bestPrefill = rows.filter { it.prefillTps != null }.maxByOrNull { it.prefillTps!! }?.threads
    val cur = rows.firstOrNull { it.threads == current }
      ?: return ThreadAnalysis(rows, best.threads, bestPrefill, noise, null, "Your setting ($current) was not among the tested values, so there is nothing to compare it with.")
    val better = rows.filter { it.decodeTps > cur.decodeTps * (1.0 + noise) }
    if (better.isEmpty()) {
      val v = if (best.threads == current) {
        String.format(Locale.US, "Your setting (%d threads) generated fastest.", current)
      } else {
        String.format(Locale.US, "No clear difference for generation: %d threads (yours, %.1f tok/s) is within the ±%.0f%% these runs vary of the fastest (%d, %.1f tok/s). Keep it.", current, cur.decodeTps, noise * 100, best.threads, best.decodeTps)
      }
      return ThreadAnalysis(rows, best.threads, bestPrefill, noise, null, v)
    }
    val bestBetter = better.maxOf { it.decodeTps }
    // Among the clearly better ones, the fewest threads that are still within noise of the best: less heat, less battery, less jitter.
    val pick = better.filter { it.decodeTps >= bestBetter * (1.0 - noise) }.minByOrNull { it.threads }!!
    val gain = (pick.decodeTps / cur.decodeTps - 1.0) * 100
    val v = String.format(
      Locale.US, "%d threads generated %.0f%% faster than your %d (%.1f vs %.1f tok/s), more than the ±%.0f%% these runs vary.",
      pick.threads, gain, current, pick.decodeTps, cur.decodeTps, noise * 100
    )
    return ThreadAnalysis(rows, best.threads, bestPrefill, noise, pick.threads, v)
  }

  private fun f1(v: Double?): String = v?.let { String.format(Locale.US, "%.1f", it) } ?: "n/a"
  private fun f0(v: Double?): String = v?.let { String.format(Locale.US, "%.0f", it) } ?: "n/a"

  /**
   * [stoppedEarly]: the time limit ended the test. [abort]: why it was not (fully) run, in words (e.g. the phone was too hot).
   * [deviceLine]: the phone-state text of the Speed test (thermal, battery).
   */
  fun report(runs: List<ThreadRun>, current: Int, plan: List<Int>, stoppedEarly: Boolean, abort: String?, deviceLine: String): ThreadTestResult {
    val sb = StringBuilder()
    sb.append("Thread test (experimental): Speed test at ${plan.distinct().joinToString(" / ")} threads, order ${plan.joinToString(" ")} after one warm-up run\n")
    if (abort != null) {
      sb.append(abort).append('\n').append(deviceLine)
      return ThreadTestResult(sb.toString().trimEnd(), null)
    }
    if (stoppedEarly || runs.size < plan.size) {
      sb.append("Stopped at the $TIME_LIMIT_SEC s limit: not all runs finished, so there is no suggestion.\n").append(deviceLine)
      return ThreadTestResult(sb.toString().trimEnd(), null)
    }
    val a = analyze(runs, current)
    sb.append(String.format(Locale.US, "%-9s %-11s %-12s %-14s %s\n", "threads", "decode t/s", "prompt t/s", "median/P95 ms", "2 runs differ"))
    for (r in a.rows) {
      sb.append(
        String.format(
          Locale.US, "%-9s %-11s %-12s %-14s %.0f%%\n",
          if (r.threads == current) "${r.threads} (you)" else "${r.threads}", f1(r.decodeTps), f0(r.prefillTps),
          "${f0(r.medianMs)}/${f0(r.p95Ms)}", r.spread * 100
        )
      )
    }
    if (a.bestDecode != null && a.bestPrefill != null && a.bestDecode != a.bestPrefill) {
      sb.append("Fastest for generation: ${a.bestDecode} threads; for prompt processing: ${a.bestPrefill}. One setting covers both; generation is what a reply feels like.\n")
    }
    sb.append(a.verdict).append('\n')
    if (a.rows.any { it.spread > 0.10 }) {
      sb.append("Two runs of one setting differ by more than 10%: the phone may be heating or busy. Repeat when it is idle for a firmer answer.\n")
    }
    sb.append(deviceLine).append('\n')
    sb.append("One model, one moment, 128-token prompt: not a general result. Nothing was changed")
    sb.append(if (a.suggested != null) "; tap Use only if you agree." else ".")
    return ThreadTestResult(sb.toString(), a.suggested)
  }
}

/**
 * v1.9.33: how long the plain Speed test runs. A model that streams its experts from storage takes seconds per token (16 s on one
 * phone: 32 tokens took 8 minutes and took the phone from Moderate to Severe heat), so it generates fewer tokens, and it does not
 * start at all when the phone is already at Severe. Every other model is unchanged.
 */
object SpeedTestPlan {
  const val PROMPT_TOKENS = 128
  const val DECODE_TOKENS = 32
  const val STREAMING_DECODE_TOKENS = 8
  const val STREAMING_REFUSE_THERMAL_LEVEL = 3

  /** v1.9.35: the test ends at this limit and reports what it measured so far (a streamed model can need minutes per token). */
  const val STREAMING_LIMIT_SEC = 480
  const val LIMIT_SEC = 180

  fun timeLimitSec(streaming: Boolean): Int = if (streaming) STREAMING_LIMIT_SEC else LIMIT_SEC

  fun endedAtLimit(text: String): Boolean = text.startsWith("Speed test stopped at its time limit")

  fun decodeTokens(streaming: Boolean): Int = if (streaming) STREAMING_DECODE_TOKENS else DECODE_TOKENS

  fun refuseToStart(streaming: Boolean, thermalLevel: Int?): Boolean =
    streaming && (thermalLevel ?: 0) >= STREAMING_REFUSE_THERMAL_LEVEL

  fun refusal(thermalName: String?): String =
    "Speed test not started: the phone is at thermal status ${thermalName ?: "Severe or worse"} and this model reads its experts from storage for every token, " +
      "so the test would be slow and would heat it further. Let the phone cool and run it again."

  fun shortenedNote(): String =
    "Shortened for a model that streams from storage: $STREAMING_DECODE_TOKENS generated tokens instead of $DECODE_TOKENS " +
      "(median and P95 come from only ${STREAMING_DECODE_TOKENS - 1} steps)."

  /** v1.9.38: a streamed model's Speed test starts with a short storage probe (4 tests of this many seconds / 4 each). */
  const val STORAGE_PROBE_SEC = 12

  /** v1.9.38: how long the app waits past the limit before it stops waiting for the measurement (see [BenchWatchdog]). */
  const val WATCHDOG_GRACE_SEC = 60

  /** Milliseconds the screen waits for the whole test: the probe (streamed models), the limit, and the grace. */
  fun watchdogWaitMs(streaming: Boolean): Long =
    (timeLimitSec(streaming) + WATCHDOG_GRACE_SEC + (if (streaming) STORAGE_PROBE_SEC else 0)).toLong() * 1000L

  /** The probe's lines above the report, or the report alone when there is no probe text. */
  fun withProbe(probe: String?, report: String): String =
    if (probe.isNullOrBlank()) report else probe.trimEnd() + "\n" + report

  fun stillRunningText(limitSec: Int): String =
    "Speed test is still running after its $limitSec s limit: one step of the model is waiting on storage reads and cannot be interrupted. " +
      "It ends by itself when that read finishes, and nothing is recorded. Until then another test is refused and chat may wait for it. " +
      "If it does not end within a few minutes, close the app from the recent apps list."

  const val BUSY_TEXT =
    "A Speed test that started earlier is still finishing in the background (it passed its time limit while one step waited on storage). " +
      "Wait for it to end, or close the app from the recent apps list."
}
