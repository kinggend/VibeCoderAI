package com.example.llama

import com.example.data.SpeedHistoryStore
import com.example.data.SpeedMath
import com.example.data.SpeedRecord
import com.example.data.downloader.Mmproj
import android.app.ActivityManager
import android.content.Context
import android.os.Debug
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.buffer
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import kotlin.math.max

/**
 * High-level offline inference engine on top of llama.cpp.
 * Loads a GGUF model, applies the model's chat template and streams real generated tokens.
 */
class LlamaEngine(private val context: Context) : com.example.domain.ModelRuntime {

  private val bridge = LlamaBridge.instance

  private var loadedKey: String? = null

  /** v1.9.30: name (file name only, never the path) and context of the loaded model, for the speed history. */
  @Volatile private var loadedName: String = ""
  @Volatile private var loadedCtx: Int = 0

  /** v1.9.30: numbers-only history of real requests and Speed tests (see [SpeedHistoryStore]). */
  private val speedLog = SpeedHistoryStore.get(context.filesDir)

  /** Why the model is not usable right now (null when ready). */
  @Volatile
  override var statusMessage: String? = "No model loaded"
    private set

  override val isReady: Boolean get() = bridge.isModelLoaded

  fun modelsDir(): File = File(context.filesDir, "models").also { if (!it.exists()) it.mkdirs() }

  /** Resolves which .gguf file the current settings point at (may not exist). */
  fun resolveModelFile(settings: SettingsState): File {
    settings.customModelPath?.let { return File(it) }
    val preset = SettingsState.AVAILABLE_MODELS.firstOrNull { it.id == settings.activeModelId }
    return File(modelsDir(), preset?.fileName ?: "${settings.activeModelId}.gguf")
  }

  /**
   * Loads (or reloads) the model when the file / context length changed. Cheap no-op otherwise.
   * Blocking: call from a background thread.
   */
  /** v1.4: GPU fallback / memory notes for the UI (e.g. "GPU load failed, running on CPU"). */
  @Volatile
  var notice: String? = null
    private set

  /** v1.4: set when the last load was refused by the memory check (UI offers Load anyway / smaller context). */
  @Volatile
  var lastMemoryVerdict: MemoryEstimator.Verdict? = null
    private set

  /** Model+context the user chose to load despite the memory warning. */
  @Volatile
  private var memoryOverrideKey: String? = null

  /** v1.9.26: true when the loaded model streams its experts from storage (it did not fit free RAM as a whole). */
  @Volatile
  var streaming: Boolean = false
    private set

  /** True when the loaded model actually runs layers on the GPU. */
  @Volatile
  var gpuActive: Boolean = false
    private set

  private fun gpuLayersFor(settings: SettingsState): Int =
    if (settings.gpuOffload && bridge.hasGpu()) settings.gpuLayers.coerceIn(1, 999) else 0

  /** v1.7.3: the image-encoder file (mmproj) stored next to [file], or null for a text-only model. */
  fun mmprojFor(file: File): File? {
    val dir = file.parentFile ?: return null
    val all = dir.listFiles { f -> f.isFile && f.name.endsWith(".gguf", ignoreCase = true) } ?: return null
    val name = Mmproj.pair(file.name, all.map { it.name }) ?: return null
    return all.firstOrNull { it.name == name }
  }

  /** Images need room for image tokens: a vision model gets at least 4096 tokens of context. */
  private fun effectiveCtx(file: File, settings: SettingsState): Int =
    if (mmprojFor(file) != null) maxOf(settings.contextLength, VISION_MIN_CTX) else settings.contextLength

  /** True when the model the settings point at has an image helper (mmproj) next to it, loaded or not. */
  fun canReadImages(settings: SettingsState): Boolean = runCatching { resolveModelFile(settings).let { it.isFile && mmprojFor(it) != null } }.getOrDefault(false)

  /** True when the loaded model can read images. */
  val hasVision: Boolean get() = bridge.hasVision

  /** Set when an image helper exists but did not load (the model then runs text-only). */
  @Volatile
  var visionNotice: String? = null
    private set

  private fun loadVision(file: File, settings: SettingsState) {
    visionNotice = null
    val mm = mmprojFor(file)
    if (mm == null) {
      if (com.example.data.downloader.ModelCategory.VISION in com.example.data.downloader.ModelCategories.tagsFor(file.name)) {
        visionNotice = "This is a vision model but its image helper (mmproj) file is not in the models folder. Open Models, find the same Hugging Face repo and download the \"mmproj\" file."
      }
      return
    }
    val ok = runCatching { bridge.loadMmproj(mm.absolutePath, settings.cpuThreads, IMAGE_MAX_TOKENS) }.getOrDefault(false)
    if (!ok) visionNotice = "Image helper could not be loaded (${bridge.lastError ?: "unknown error"}). This model runs text-only."
  }

  private fun decodeDataUrl(url: String): ByteArray? = runCatching {
    android.util.Base64.decode(url.substringAfter("base64,", url), android.util.Base64.DEFAULT)
  }.getOrNull()?.takeIf { it.isNotEmpty() }

  private fun keyFor(file: File, settings: SettingsState): String {
    val mm = mmprojFor(file)
    return "${file.absolutePath}|${file.length()}|${effectiveCtx(file, settings)}|${gpuLayersFor(settings)}|${mm?.absolutePath}|${mm?.length()}"
  }

  private fun memKey(file: File, settings: SettingsState): String = "${file.absolutePath}|${file.length()}|${settings.contextLength}"

  /** Free RAM as Android reports it (ActivityManager.MemoryInfo.availMem); 0 when unknown. */
  fun availableMemoryBytes(): Long {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager ?: return 0L
    val mi = ActivityManager.MemoryInfo()
    am.getMemoryInfo(mi)
    return mi.availMem
  }

  /**
   * v1.9.26: the expert/core split of the model file, but only when it matters: the whole model does not fit free RAM, and it has no
   * image helper (a vision model is always loaded as a whole). The first call per file reads a few MB of header; later calls are cached.
   */
  private fun splitIfNeeded(file: File, totalBytes: Long, contextTokens: Int, freeBytes: Long): ExpertSplit? =
    if (freeBytes > 0 && MemoryEstimator.neededBytes(totalBytes, contextTokens) > freeBytes && mmprojFor(file) == null) GgufExperts.cached(file) else null

  /** v1.4: memory verdict for the model the settings point at (null when there is nothing to check). */
  fun memoryCheck(settings: SettingsState): MemoryEstimator.Verdict? {
    if (settings.backendMode == "remote") return null
    val file = resolveModelFile(settings)
    if (!file.isFile) return null
    if (bridge.isModelLoaded && keyFor(file, settings) == loadedKey) return null
    val total = file.length() + (mmprojFor(file)?.length() ?: 0L)
    val ctx = effectiveCtx(file, settings)
    val free = availableMemoryBytes()
    return MemoryEstimator.check(total, ctx, free, splitIfNeeded(file, total, ctx, free))
  }

  /** Sizes for the Models screen RAM bar; null for a remote backend or when no model file is selected. */
  fun modelMemory(settings: SettingsState): ModelMemory? {
    if (settings.backendMode == "remote") return null
    val file = resolveModelFile(settings)
    if (!file.isFile) return null
    val helper = mmprojFor(file)
    val total = file.length() + (helper?.length() ?: 0L)
    val free = availableMemoryBytes()
    val minCtx = if (helper != null) VISION_MIN_CTX else 0
    // A model that only fits because its experts stream from storage is shown by its core size (the part that stays in RAM).
    val ctx = maxOf(settings.contextLength, minCtx)
    val plan = MemoryEstimator.check(total, ctx, free, splitIfNeeded(file, total, ctx, free)).streams
    return if (plan != null) ModelMemory(plan.residentBytes, free, minCtx, plan.kvBasisBytes, plan.streamedBytes, plan.extraBytes) else ModelMemory(total, free, minCtx)
  }

  /**
   * Pre-flight for the agent: a verdict only when the model would NOT fit in free RAM right now, so a run can
   * stop before it starts. Null when it fits, is already loaded, is remote, or the user chose "Load anyway".
   */
  fun preflight(settings: SettingsState): MemoryEstimator.Verdict? {
    val v = memoryCheck(settings) ?: return null
    if (v.fits) return null
    return if (memKey(resolveModelFile(settings), settings) == memoryOverrideKey) null else v
  }

  /** "Load anyway": the next [initialize] for this model and context skips the memory check. */
  fun allowLowMemoryLoad(settings: SettingsState) {
    memoryOverrideKey = memKey(resolveModelFile(settings), settings)
  }

  /**
   * Loads (or reloads) the model when the file / context length / GPU layers changed. Cheap no-op
   * otherwise. v1.4: refuses (status message, no crash) when the memory estimate does not fit unless the
   * user chose "Load anyway"; retries on CPU when a GPU load fails. Blocking: call from a background thread.
   */
  @Synchronized
  override fun initialize(settings: SettingsState): Boolean {
    val file = resolveModelFile(settings)
    val key = keyFor(file, settings)

    if (bridge.isModelLoaded && key == loadedKey) {
      bridge.setCpuThreads(settings.cpuThreads)
      applyLookup(settings)
      return true
    }

    if (!file.isFile) {
      bridge.freeModel()
      loadedKey = null
      statusMessage = "No model file found. Open Settings and import a .gguf model."
      return false
    }

    lastMemoryVerdict = null
    var plan: MemoryEstimator.StreamPlan? = null
    run {
      val total = file.length() + (mmprojFor(file)?.length() ?: 0L)
      val ctx = effectiveCtx(file, settings)
      val free = availableMemoryBytes()
      val verdict = MemoryEstimator.check(total, ctx, free, splitIfNeeded(file, total, ctx, free))
      plan = verdict.streams
      if (memKey(file, settings) != memoryOverrideKey && !verdict.fits) {
        bridge.freeModel()
        loadedKey = null
        lastMemoryVerdict = verdict
        statusMessage = "Not enough free memory for this model: needs about ${verdict.neededBytes / 1048576} MB, " +
          "${verdict.availableBytes / 1048576} MB free." +
          (verdict.suggestedContext?.let { " Try a context of $it tokens." } ?: " Try a smaller model.")
        return false
      }
    }

    notice = null
    gpuActive = false
    streaming = false
    // v1.9.26: a mixture-of-experts model bigger than free RAM: keep the weights memory-mapped (no repacked copy in RAM), CPU only.
    val streamPlan = plan
    bridge.setStreamingLoad(streamPlan != null)
    if (streamPlan != null) {
      notice = "This model is bigger than the free RAM, so its experts stream from storage (about " +
        "${(streamPlan.cachedFraction * 100).toInt()}% stay cached). Replies are slower than a model that fits. Run Speed test for the real speed."
    }
    val layers = if (streamPlan != null) 0 else gpuLayersFor(settings)
    var ok = try {
      bridge.initModel(file.absolutePath, settings.cpuThreads, effectiveCtx(file, settings), layers)
    } catch (oom: OutOfMemoryError) {
      bridge.freeModel()
      false
    }
    if (ok && layers > 0) gpuActive = true
    if (!ok && layers > 0) {
      // v1.4: GPU (Vulkan) load failed: retry on the CPU automatically and tell the user.
      val gpuError = bridge.lastError
      ok = try {
        bridge.initModel(file.absolutePath, settings.cpuThreads, effectiveCtx(file, settings), 0)
      } catch (oom: OutOfMemoryError) {
        bridge.freeModel()
        false
      }
      if (ok) notice = "GPU offload failed (${gpuError ?: "unknown error"}). Running on the CPU instead."
    }
    loadedKey = if (ok) key else null
    loadedName = if (ok) file.name else ""
    loadedCtx = if (ok) effectiveCtx(file, settings) else 0
    streaming = ok && streamPlan != null
    if (ok) applyLookup(settings)
    if (ok) loadVision(file, settings) else visionNotice = null
    statusMessage = if (ok) null else friendlyLoadError(bridge.lastError)
    return ok
  }

  private fun friendlyLoadError(raw: String?): String {
    val r = raw ?: return "Failed to load model"
    return if (r.contains("memory", ignoreCase = true) || r.contains("OOM", ignoreCase = false))
      "Not enough memory to load this model. Close other apps, pick a smaller model, or lower the context length. ($r)"
    else r
  }

  /**
   * v1.6.2: why the last generation ended: "length" (output token limit or full context), "stop"
   * (the model finished), or the remote server's finish_reason; null when unknown.
   */
  @Volatile
  var lastFinishReason: String? = null
    private set

  /** Interrupts a running generation immediately (safe from any thread). */
  fun stopNow() = bridge.stop()

  /**
   * v1.9.32 (experimental): the Speed test at 4 / 6 / 8 threads and at [currentThreads], a b c c b a after a warm-up run. Blocking: call
   * from an IO dispatcher. Records nothing in the speed history, restores [currentThreads] at the end and never changes the setting itself:
   * the result only carries a suggestion. Not run for a streaming model (storage, not the CPU, limits it, and each run takes minutes).
   */
  fun threadBenchmark(currentThreads: Int): ThreadTestResult {
    if (!bridge.isModelLoaded) return ThreadTestResult("No model loaded.", null)
    if (streaming) {
      return ThreadTestResult("Thread test is not run for a model that streams its experts from storage: storage, not the CPU threads, sets its speed, and each run would take minutes.", null)
    }
    val cands = ThreadBench.candidates(Runtime.getRuntime().availableProcessors(), currentThreads)
    val plan = ThreadBench.order(cands)
    val before = DeviceReader.read(context, includeMemory = false)
    val t0 = System.nanoTime()
    val limitNs = ThreadBench.TIME_LIMIT_SEC * 1_000_000_000L
    val runs = ArrayList<ThreadRun>()
    var stopped = false
    var abort: String? = null
    try {
      for ((i, t) in (listOf(plan.first()) + plan).withIndex()) {
        val warmUp = i == 0
        if (System.nanoTime() - t0 > limitNs) { stopped = true; break }
        val state = DeviceReader.read(context, includeMemory = false)
        if ((state.thermalLevel ?: 0) >= ThreadBench.ABORT_THERMAL_LEVEL) {
          abort = "The phone is at thermal status ${state.thermal} and already slows itself hard, so the test would measure the heat, not the threads. Let it cool and run it again."
          break
        }
        bridge.setCpuThreads(t)
        val (nums, text) = com.example.data.BenchLine.split(bridge.benchmarkDetailed())
        if (nums == null) return ThreadTestResult("Thread test failed: $text", null)
        if (nums.threads != t) return ThreadTestResult("Thread test failed: asked for $t threads but the engine reports ${nums.threads}.", null)
        if (!warmUp) runs.add(ThreadRun(t, nums.decodeTps, nums.prefillTps, nums.medianMs, nums.p95Ms))
      }
    } finally {
      bridge.setCpuThreads(currentThreads)
    }
    val after = DeviceReader.read(context, includeMemory = false)
    return ThreadBench.report(runs, currentThreads, plan, stopped, abort, DeviceTelemetry.describe(before, after))
  }

  /** v1.9.31: the setting the user chose; the native side still refuses it for a streaming load or a memory that cannot roll back. */
  @Volatile private var lookupWanted = false

  private fun applyLookup(settings: SettingsState) {
    lookupWanted = settings.lookupDecoding
    bridge.setLookup(lookupWanted)
  }

  /**
   * v1.9.31 (experimental): code-edit A/B test of prompt-lookup decoding on the loaded model: off, on, on, off, same prompt, greedy,
   * cache dropped before each run. Reports tokens per second, how many guesses were accepted, whether the text was identical, and a
   * verdict that says "no clear difference" when the gap is within the test's own noise. Blocking: call from an IO dispatcher.
   * Never touches a streaming model (lookup is not used there).
   */
  fun lookupBenchmark(): String {
    if (!bridge.isModelLoaded) return "No model loaded."
    val info = bridge.lookupInfo() ?: return "This build cannot report lookup numbers, so the test cannot run."
    if (info.block != 0) {
      return "Lookup decoding is not used with this model: ${LookupBench.reason(info.block)}.\nNothing was measured and nothing changes in how this model runs."
    }
    val prompt = bridge.applyChatTemplate(listOf("system" to LookupBench.SYSTEM, "user" to LookupBench.WORKLOAD))
      ?: return "The model has no chat template the app can apply, so the test prompt cannot be built."
    val before = DeviceReader.read(context, includeMemory = false)
    val t0 = System.nanoTime()
    val limitNs = LookupBench.TIME_LIMIT_SEC * 1_000_000_000L
    val runs = ArrayList<LookupRun>()
    var stoppedEarly = false
    try {
      for (mode in LookupBench.ORDER) {
        if (System.nanoTime() - t0 > limitNs) { stoppedEarly = true; break }
        bridge.setLookup(mode)
        bridge.resetCache()
        val text = StringBuilder()
        var first = 0L
        var last = 0L
        val n = bridge.generate(prompt, LookupBench.MAX_TOKENS, 0f, 1f, 0, 1f) { piece ->
          val now = System.nanoTime()
          if (first == 0L) first = now
          last = now
          text.append(piece)
          if (now - t0 > limitNs) { stoppedEarly = true; false } else true
        }
        if (n < 0) return "Lookup test failed: ${bridge.lastError ?: "unknown error"}"
        if (stoppedEarly) break
        runs.add(LookupRun(mode, n, LookupBench.decodeTps(n, first, last), text.toString(), bridge.lookupInfo()))
      }
    } finally {
      bridge.setLookup(lookupWanted)
      bridge.resetCache()
    }
    val after = DeviceReader.read(context, includeMemory = false)
    return LookupBench.report(runs, stoppedEarly) + "\n" + DeviceTelemetry.describe(before, after)
  }

  fun benchmark(): String = bridge.benchmark()

  /** v1.9.29: the Speed test button: prompt speed and generation speed measured separately. */
  fun benchmarkDetailed(): String {
    val before = DeviceReader.read(context, includeMemory = false)
    val (nums, text) = com.example.data.BenchLine.split(bridge.benchmarkDetailed())
    if (nums == null) return text
    val after = DeviceReader.read(context, includeMemory = true)
    runCatching {
      speedLog.add(
        SpeedRecord(
          ts = System.currentTimeMillis(), source = "speedtest", backend = "local", model = loadedName,
          promptTokens = nums.promptTokens, outputTokens = nums.genTokens,
          ttftMs = nums.promptMs.toLong(), prefillTps = nums.prefillTps, decodeTps = nums.decodeTps,
          medianMs = nums.medianMs, p95Ms = nums.p95Ms, threads = nums.threads, streaming = nums.streaming,
          contextLength = loadedCtx.takeIf { it > 0 }, readMb = nums.readMb, majorFaults = nums.majorFaults, minorFaults = nums.minorFaults,
          thermalBefore = before.thermal, thermalAfter = after.thermal, batteryTempC = after.batteryTempC,
          anonMb = after.mem?.anonMb, fileMb = after.mem?.fileMb
        )
      )
    }
    return DeviceTelemetry.insertBeforeCpu(text, DeviceTelemetry.describe(before, after))
  }

  /** Frees the model's RAM. It reloads automatically on the next message. */
  @Synchronized
  override fun unload() {
    bridge.freeModel()
    loadedKey = null
    statusMessage = "Model unloaded (reloads on the next message)"
  }

  /** v1.4: exact count via llama_tokenize when a model is loaded, otherwise the ~4 chars/token estimate. */
  override fun countTokens(text: String): Int {
    if (text.isEmpty()) return 0
    return bridge.countTokensExact(text) ?: bridge.tokenize(text).size
  }

  private fun systemFor(chatOnly: Boolean, systemOverride: String?, levelHint: String, thinking: Boolean = false): String =
    (systemOverride ?: ((if (chatOnly) CHAT_PROMPT else SYSTEM_PROMPT) + com.example.agent.Skills.promptFor(chatOnly) + (if (!chatOnly && levelHint.isNotBlank()) "\n" + levelHint else ""))) + (if (thinking) com.example.agent.Thinking.HINT else "") +
      (if (PromptClock.inUserTail(systemOverride)) "" else PromptClock.systemLine()) + PromptClock.LANGUAGE_NOTE

  private fun buildPrompt(userPrompt: String, chatOnly: Boolean, history: List<Pair<String, String>>, systemOverride: String? = null, levelHint: String = "", thinking: Boolean = false): String {
    val system = systemFor(chatOnly, systemOverride, levelHint, thinking)
    val messages = listOf("system" to system) + history + ("user" to userPrompt)
    return bridge.applyChatTemplate(messages) ?: buildString {
      for ((role, content) in messages) append("<|im_start|>").append(role).append('\n').append(content).append("<|im_end|>\n")
      append("<|im_start|>assistant\n")
    }
  }

  private fun memoryInfo(): Pair<Long, Long> {
    val am = context.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
    val mi = ActivityManager.MemoryInfo()
    am?.getMemoryInfo(mi)
    val usedMb = (Debug.getNativeHeapAllocatedSize() + Runtime.getRuntime().let { it.totalMemory() - it.freeMemory() }) / (1024 * 1024)
    val totalMb = if (mi.totalMem > 0) mi.totalMem / (1024 * 1024) else Runtime.getRuntime().maxMemory() / (1024 * 1024)
    return usedMb to totalMb
  }

  /**
   * Streams real model output. Cancelling the collector stops native generation.
   * If no model is loaded, emits an explanatory message instead of fake output.
   */
  fun generateCompletionStream(
    prompt: String,
    settings: SettingsState,
    onTelemetryUpdate: (TelemetryData) -> Unit,
    chatOnly: Boolean = false,
    history: List<Pair<String, String>> = emptyList(),
    systemOverride: String? = null,
    /** v1.6: JPEG data URLs sent as image_url parts with the user message (remote OpenAI-compatible only). */
    images: List<String> = emptyList(),
    /** v1.6: the exact messages about to be sent and the exact prompt token count when known ("What the AI sees"). */
    onRequest: (List<Pair<String, String>>, Int?) -> Unit = { _, _ -> }
  ): Flow<String> = callbackFlow {
    lastFinishReason = null
    try {
      if (settings.backendMode == "remote") {
        val system = systemFor(chatOnly, systemOverride, com.example.data.model.OutputLevel.from(settings.outputLevel).hint, settings.thinking)
        // v1.9.29: for the standard system prompt the phone clock rides at the end of the user message (see PromptClock).
        val msgs = listOf("system" to system) + history + ("user" to (prompt + (if (PromptClock.inUserTail(systemOverride)) PromptClock.tail() else "")))
        onRequest(msgs, null)
        val start = System.currentTimeMillis()
        var pieces = 0
        var firstAt = 0L
        var lastAt = 0L
        val deviceBefore = DeviceReader.read(context, includeMemory = false)
        val host = runCatching { java.net.URL(settings.remoteUrl).host }.getOrDefault("server")
        // Remote: no tokenizer on the phone, so the prompt count is an estimate (shown with "≈").
        val estIn = (msgs.sumOf { it.first.length + it.second.length } / 4).coerceAtLeast(1)
        val remoteName = settings.remoteModel.ifBlank { host }
        onTelemetryUpdate(TelemetryData(inputTokens = estIn, activeBackend = "Remote: $host", promptExact = false, modelName = remoteName))
        kotlinx.coroutines.withContext(Dispatchers.IO) {
          lastFinishReason = RemoteClient.stream(settings, msgs, if (chatOnly) minOf(settings.maxOutputTokens, 1024) else settings.maxOutputTokens, images) { piece ->
            pieces++
            lastAt = System.currentTimeMillis()
            if (pieces == 1) firstAt = lastAt
            trySend(piece)
            if (pieces % 4 == 0) {
              val secs = max(0.05, (System.currentTimeMillis() - start) / 1000.0)
              onTelemetryUpdate(TelemetryData(inputTokens = estIn, outputTokens = pieces, tokensPerSecond = (pieces / secs).toFloat(), activeBackend = "Remote: $host", promptExact = false, modelName = remoteName))
            }
            isActive
          }
        }
        val secs = max(0.05, (System.currentTimeMillis() - start) / 1000.0)
        onTelemetryUpdate(TelemetryData(inputTokens = estIn, outputTokens = pieces, tokensPerSecond = (pieces / secs).toFloat(), latencyMs = System.currentTimeMillis() - start, activeBackend = "Remote: $host", promptExact = false, modelName = remoteName))
        // v1.9.30: numbers-only speed record of a normal request. A remote number includes the network; prompt speed is not derived (the prompt count is an estimate).
        if (PromptClock.inUserTail(systemOverride) && pieces > 0) {
          val outN = pieces
          val ctxLen = settings.contextLength
          val ttft = SpeedMath.ttftMs(start, firstAt)
          val decode = SpeedMath.decodeTps(outN, firstAt, lastAt)
          speedLog.addAsync {
            val after = DeviceReader.read(context, includeMemory = false)
            SpeedRecord(
              ts = System.currentTimeMillis(), source = "chat", backend = "remote", model = remoteName,
              promptTokens = estIn, outputTokens = outN, ttftMs = ttft, decodeTps = decode,
              contextLength = ctxLen, thermalBefore = deviceBefore.thermal, thermalAfter = after.thermal, batteryTempC = after.batteryTempC
            )
          }
        }
        close()
        return@callbackFlow
      }
      if (!initialize(settings)) {
        trySend(
          if (lastMemoryVerdict != null) "Offline model was not loaded: ${statusMessage}\n\nOpen Models to load it anyway or use a smaller context."
          else "Offline model is not ready: ${statusMessage ?: "unknown error"}\n\n" +
            "Go to Settings, tap \"Import GGUF model\" and pick a small coder model " +
            "(for example Qwen2.5-Coder 1.5B Q4_K_M)."
        )
        close()
        return@callbackFlow
      }

      // v1.7.3: with an image helper loaded, images go to the model (one marker per image in the prompt).
      val imageBytes = if (bridge.hasVision) images.mapNotNull { decodeDataUrl(it) } else emptyList()
      bridge.setImages(imageBytes)
      val userPrompt = (if (imageBytes.isEmpty()) prompt else (MEDIA_MARKER + "\n").repeat(imageBytes.size) + prompt) +
        (if (PromptClock.inUserTail(systemOverride)) PromptClock.tail() else "")
      val fullPrompt = buildPrompt(userPrompt, chatOnly, history, systemOverride, com.example.data.model.OutputLevel.from(settings.outputLevel).hint, settings.thinking)
      val start = System.currentTimeMillis()
      // v1.4: exact llama_tokenize count (same flags as generation).
      val exact = bridge.countTokensExact(fullPrompt)
      onRequest(listOf("system" to systemFor(chatOnly, systemOverride, com.example.data.model.OutputLevel.from(settings.outputLevel).hint, settings.thinking)) + history + ("user" to userPrompt), exact)
      var inputTokens = exact ?: countTokens(fullPrompt)
      var cached = 0
      val modelName = resolveModelFile(settings).name
      var outputTokens = 0
      var promptDone = 0
      var firstTokenAt = 0L
      var lastTokenAt = 0L
      val deviceBefore = DeviceReader.read(context, includeMemory = false)
      val totalMb = memoryInfo().second

      fun telemetry(): TelemetryData {
        val now = System.currentTimeMillis()
        val tps = if (outputTokens > 0 && firstTokenAt > 0) {
          outputTokens / max(0.05, (now - firstTokenAt) / 1000.0)
        } else if (promptDone > 0) {
          // prompt-processing speed while the model is still reading the prompt
          (promptDone - cached).coerceAtLeast(0) / max(0.05, (now - start) / 1000.0)
        } else 0.0
        return TelemetryData(
          inputTokens = if (outputTokens == 0 && promptDone > 0) promptDone else inputTokens,
          outputTokens = outputTokens,
          tokensPerSecond = tps.toFloat(),
          latencyMs = now - start,
          usedRamMb = memoryInfo().first,
          maxRamMb = totalMb,
          threadCount = settings.cpuThreads,
          activeBackend = if (gpuActive) "llama.cpp (offline, GPU)" else "llama.cpp (offline)",
          cachedTokens = cached,
          promptExact = exact != null,
          modelName = modelName
        )
      }
      onTelemetryUpdate(telemetry())

      // If the prompt never advances, show where the native side is stuck instead of waiting silently.
      // v1.9.28: a streaming model decodes its first batch (up to 1024 tokens, experts read from storage) before any progress shows.
      val watchdog = launch {
        delay(if (streaming) 300_000L else 25_000L)
        if (promptDone == 0 && outputTokens == 0) {
          trySend("\n\n[No progress after 25 s. Native log:]\n${bridge.debugLog()}")
        }
      }

      val stopFilter = StopFilter()
      val maxTokens = if (chatOnly) minOf(settings.maxOutputTokens, 1024) else settings.maxOutputTokens
      applyLookup(settings)
      val n = bridge.generate(
        prompt = fullPrompt,
        maxTokens = maxTokens,
        temperature = settings.temperature,
        topP = settings.topP,
        topK = settings.topK,
        repeatPenalty = settings.repetitionPenalty,
        onProgress = { done, total ->
          if (promptDone == 0) cached = bridge.cachedTokens()
          promptDone = done
          inputTokens = total
          onTelemetryUpdate(telemetry())
          isActive
        }
      ) { piece ->
        lastTokenAt = System.currentTimeMillis()
        if (outputTokens == 0) firstTokenAt = lastTokenAt
        outputTokens++
        // Stop at any chat-turn marker the model prints as text (wrong/unknown template).
        val out = stopFilter.feed(piece)
        if (out.isNotEmpty()) trySend(out)
        if (outputTokens % 4 == 0) onTelemetryUpdate(telemetry())
        isActive && !stopFilter.hit
      }
      if (!stopFilter.hit) stopFilter.flush().let { if (it.isNotEmpty()) trySend(it) }
      watchdog.cancel()
      cached = bridge.cachedTokens()
      onTelemetryUpdate(telemetry())

      // v1.9.30: numbers-only speed record of a normal request (the phone agent, router and internal tools bring their own system prompt and are not logged).
      if (n >= 0 && PromptClock.inUserTail(systemOverride) && outputTokens > 0) {
        // The prompt count and the reuse come from the native prompt cache itself (tokens actually processed, tokens kept from the KV
        // cache). If they cannot be read, the reuse stays unmeasured (null) rather than guessed.
        val stats = bridge.lastPromptStats()
        val inN = stats?.promptTokens ?: inputTokens
        val cachedN: Int? = stats?.reusedTokens
        val cutN: Int? = stats?.cutTokens
        val outN = outputTokens
        val ttft = SpeedMath.ttftMs(start, firstTokenAt)
        val decode = SpeedMath.decodeTps(outN, firstTokenAt, lastTokenAt)
        val prefill = cachedN?.let { SpeedMath.prefillTps(inN, it, ttft) }
        val streamingNow = streaming
        // Read now: the next generation overwrites these counts. True only when lookup really ran for this reply.
        val lookupRan = bridge.lookupInfo()?.active == true
        speedLog.addAsync {
          val after = DeviceReader.read(context, includeMemory = true)
          SpeedRecord(
            ts = System.currentTimeMillis(), source = "chat", backend = "local", model = modelName,
            promptTokens = inN, cachedTokens = cachedN, truncatedTokens = cutN, outputTokens = outN, ttftMs = ttft, prefillTps = prefill, decodeTps = decode,
            threads = settings.cpuThreads, streaming = streamingNow, contextLength = settings.contextLength,
            thermalBefore = deviceBefore.thermal, thermalAfter = after.thermal, batteryTempC = after.batteryTempC,
            anonMb = after.mem?.anonMb, fileMb = after.mem?.fileMb, lookup = lookupRan
          )
        }
      }

      if (n < 0) trySend("\n\n[Generation error: ${bridge.lastError ?: "unknown"}]")
      else lastFinishReason = if (!stopFilter.hit && (outputTokens >= maxTokens - 1 || inputTokens + outputTokens >= settings.contextLength - 4)) "length" else "stop"
    } catch (t: Throwable) {
      LlamaBridge.safeLog("generateCompletionStream failed", t)
      val unreachable = t is java.net.ConnectException || t is java.net.UnknownHostException || t is java.net.SocketTimeoutException
      trySend(
        if (unreachable) "Cannot reach the remote server (${t.message}).\n\nOpen Models and switch to \"On this phone\", or start your server and tap Test connection."
        else "\n\n[Engine error: ${t.javaClass.simpleName}: ${t.message}]"
      )
    }
    close()
    awaitClose { bridge.stop() }
  }.buffer(Channel.UNLIMITED).flowOn(Dispatchers.Default)

  companion object {
    /** mtmd's media marker: one per image in the user message. */
    private const val MEDIA_MARKER = "<__media__>"
    private const val VISION_MIN_CTX = 4096
    /** Upper limit of image tokens per picture (keeps prompt time and RAM in check on a phone). */
    private const val IMAGE_MAX_TOKENS = 640

    private const val CHAT_PROMPT =
      "You are VibeCoderAI, a friendly offline coding assistant. Reply naturally and briefly in the user's language. " +
        "Greetings and questions get a normal short answer. Only write code when the user asks for code, and then " +
        "use fenced markdown code blocks. Do not create project files unless the user asks you to build an app."

    // v1.4: shorter system prompt (same rules, fewer tokens on every request).
    private const val SYSTEM_PROMPT =
      "You are VibeCoderAI, an offline assistant that builds small web apps on a phone.\n" +
        "To create or change an app: one short plan sentence, then every changed file as\n" +
        "<file path=\"index.html\">\nFULL FILE CONTENT\n</file>\n" +
        "Rules: complete files only (no diffs, no placeholders), only files that change; vanilla HTML/CSS/JS, " +
        "no libraries or network (except the global THREE for 3D, added automatically); mobile-first, clean design; default files index.html, styles.css, app.js; " +
        "nothing after the last file. Answer questions briefly in plain text."
  }
}


/** Holds back text that could be the start of a chat-turn marker and stops once a full marker appears. */
internal class StopFilter {
  companion object {
    val MARKERS = listOf("<|im_end|>", "<|im_start|>", "<end_of_turn>", "<start_of_turn>", "<turn|>", "<|turn>",
      "<|eot_id|>", "<|start_header_id|>", "<|endoftext|>", "<|end|>", "<|user|>", "</s>")
  }
  private val buf = StringBuilder()
  var hit = false
    private set

  fun feed(piece: String): String {
    if (hit) return ""
    buf.append(piece)
    val text = buf.toString()
    val idx = MARKERS.map { text.indexOf(it) }.filter { it >= 0 }.minOrNull()
    if (idx != null) {
      hit = true
      buf.setLength(0)
      return text.substring(0, idx)
    }
    // keep a tail that might be the start of a marker
    var keep = 0
    for (m in MARKERS) for (k in minOf(m.length - 1, text.length) downTo 1) {
      if (text.endsWith(m.substring(0, k))) { if (k > keep) keep = k; break }
    }
    buf.setLength(0)
    buf.append(text.substring(text.length - keep))
    return text.substring(0, text.length - keep)
  }

  fun flush(): String { val t = buf.toString(); buf.setLength(0); return t }
}
