package com.example.llama

import java.util.Locale

/**
 * v1.9.31: what the native side counted during the last text generation (experimental prompt-lookup decoding).
 * Counts only: nothing is estimated. [block] is why lookup cannot be used with this load (0 = it can).
 */
data class LookupNumbers(
  val block: Int,
  val enabled: Boolean,
  val active: Boolean,
  val rounds: Long,
  val drafted: Long,
  val accepted: Long,
  val roundMs: Double,
  val roundTokens: Long,
  val singleSteps: Long,
  val singleMs: Double,
  val pauses: Long
) {
  /** Share of guessed tokens the sampler also picked, 0..100. Null when nothing was guessed. */
  val acceptPct: Double? get() = if (drafted > 0) accepted * 100.0 / drafted else null
  val tokensPerRound: Double? get() = if (rounds > 0) roundTokens.toDouble() / rounds else null
  /** v1.9.36: average milliseconds of one plain one-token step and of one guessed-token batch in this generation (measured, not estimated). */
  val singleStepMs: Double? get() = if (singleSteps > 0 && singleMs > 0.0) singleMs / singleSteps else null
  val roundAvgMs: Double? get() = if (rounds > 0 && roundMs > 0.0) roundMs / rounds else null
  /** How many plain steps one batch cost. Null unless both were measured in this generation. */
  val roundVsStep: Double? get() { val r = roundAvgMs; val s1 = singleStepMs; return if (r != null && s1 != null) r / s1 else null }

  companion object {
    /** Layout of nativeLookupInfo: block, enabled, active, rounds, drafted, accepted, roundMs, roundTokens, singleSteps, singleMs, pauses. */
    fun from(v: DoubleArray?): LookupNumbers? {
      if (v == null || v.size < 11) return null
      return LookupNumbers(
        block = v[0].toInt(), enabled = v[1] != 0.0, active = v[2] != 0.0,
        rounds = v[3].toLong(), drafted = v[4].toLong(), accepted = v[5].toLong(),
        roundMs = v[6], roundTokens = v[7].toLong(), singleSteps = v[8].toLong(), singleMs = v[9], pauses = v[10].toLong()
      )
    }
  }
}

/** v1.9.36: the cost of one decode of [tokens] tokens: median, fastest and slowest of the timed passes, in milliseconds. */
data class BatchCostRow(val tokens: Int, val medianMs: Double, val minMs: Double, val maxMs: Double)

/**
 * v1.9.36: what one decode of 1, 2, 4 and 9 tokens costs on this phone with the loaded model, at the context length the test left in the
 * cache. Measured by the native side (the same batch shape the lookup verify step uses, logits on every row). It answers the question
 * the A/B runs cannot: how much more than one token does a batch of guessed tokens cost? Guessing can only pay when a batch of n
 * tokens costs less than n plain steps, and even then only for the guesses that turn out right.
 */
data class BatchCost(val context: Int, val passes: Int, val rows: List<BatchCostRow>) {
  private val one: BatchCostRow? get() = rows.firstOrNull { it.tokens == 1 }

  /** Cost of this batch in plain one-token steps. Null without a measured one-token row. */
  fun ratio(r: BatchCostRow): Double? = one?.let { if (it.medianMs > 0.0) r.medianMs / it.medianMs else null }

  /** Most a batch of n tokens can speed generation up: every guess right, so n tokens are confirmed for [ratio] steps of time. */
  fun bestCase(r: BatchCostRow): Double? = ratio(r)?.let { if (it > 0.0) r.tokens / it else null }

  /** The size with the highest best case (batches of 2 tokens or more) and that best case. */
  fun bestOverall(): Pair<BatchCostRow, Double>? =
    rows.filter { it.tokens > 1 }.mapNotNull { r -> bestCase(r)?.let { r to it } }.maxByOrNull { it.second }

  /** True when no batch size, even with every guess right, gains more than 5%: lookup cannot help with this model on this phone. */
  fun cannotHelp(): Boolean = bestOverall()?.let { it.second <= 1.05 } ?: false

  fun describe(): String {
    val sb = StringBuilder(String.format(Locale.US, "Batch cost on this phone (loaded model, %d tokens of context, median of %d passes):\n", context, passes))
    for (r in rows) {
      val rt = ratio(r)
      val bc = bestCase(r)
      val label = if (r.tokens == 1) "1 token " else "${r.tokens} tokens"
      val ms = String.format(Locale.US, "%.0f ms", r.medianMs)
      val extra = if (r.tokens > 1 && rt != null && bc != null) String.format(Locale.US, " (%.1fx one token), best case %.1fx", rt, bc) else ""
      sb.append("  ").append(label).append(": ").append(ms).append(extra).append('\n')
    }
    sb.append("Best case = every guessed token is right, so a batch of n confirms n tokens. The real gain is lower: a wrong guess still pays for the whole batch.\n")
    val best = bestOverall()
    if (best != null) {
      if (cannotHelp()) {
        sb.append("Even with every guess right, no batch size gains more than 5% here: lookup cannot help with this model on this phone.\n")
      } else {
        sb.append(String.format(Locale.US, "At most %.1fx, at %d tokens per batch; the accepted share of guesses decides how much of that is real.\n", best.second, best.first.tokens))
      }
    }
    return sb.toString().trimEnd()
  }

  companion object {
    /** Batch sizes probed: one plain step, and the batches lookup builds (up to 1 + 8 guesses). */
    val SIZES = intArrayOf(1, 2, 4, 9)
    const val REPS = 5
    const val LIMIT_SEC = 60

    /** Layout of nativeBatchCost: context tokens, timed passes, then per size: median, min, max (ms). Null for anything that does not fit. */
    fun from(v: DoubleArray?, sizes: IntArray): BatchCost? {
      if (v == null || sizes.isEmpty() || v.size != 2 + 3 * sizes.size) return null
      val context = v[0].toInt()
      val passes = v[1].toInt()
      if (context <= 0 || passes < 1) return null
      val rows = ArrayList<BatchCostRow>()
      for (i in sizes.indices) {
        val med = v[2 + 3 * i]
        val lo = v[3 + 3 * i]
        val hi = v[4 + 3 * i]
        if (!(med > 0.0) || !(lo > 0.0) || !(hi >= lo) || med.isInfinite() || hi.isInfinite()) return null
        rows.add(BatchCostRow(sizes[i], med, lo, hi))
      }
      return BatchCost(context, passes, rows)
    }
  }
}

/** One generation of the code-edit test. */
data class LookupRun(
  val lookup: Boolean,
  val tokens: Int,
  val decodeTps: Double?,
  val text: String,
  val numbers: LookupNumbers?
)

/**
 * v1.9.31: the code-edit A/B test of prompt-lookup decoding. A fixed prompt (a small file plus a rename instruction, the kind of reply
 * that mostly copies its input), greedy sampling, the cache dropped before every run so each run does the same work. Runs go
 * off, on, on, off so a phone that warms up or cools down during the test does not favour one setting.
 * Pure: the engine runs the generations, this object only holds the workload and turns numbers into text.
 */
object LookupBench {
  /** Longest reply per run. Short on purpose: four runs have to fit a phone's patience. */
  const val MAX_TOKENS = 128
  /** Runs stop early (the report says so) when the whole test passes this many seconds. */
  const val TIME_LIMIT_SEC = 240
  /** Settings of the runs, in order: off, on, on, off. */
  val ORDER = listOf(false, true, true, false)

  const val SYSTEM = "You are a code editor. Reply with the complete updated file in one code block and nothing else."

  const val WORKLOAD = "Rename compute_total to calculate_total everywhere and add a one-line docstring to it.\n\n" +
    "```python\n" +
    "import json\n\n" +
    "def load_items(path):\n" +
    "    with open(path) as f:\n" +
    "        data = json.load(f)\n" +
    "    items = []\n" +
    "    for row in data:\n" +
    "        if row.get(\"active\"):\n" +
    "            items.append(row)\n" +
    "    return items\n\n" +
    "def compute_total(items, tax_rate):\n" +
    "    total = 0\n" +
    "    for item in items:\n" +
    "        price = item[\"price\"]\n" +
    "        qty = item[\"qty\"]\n" +
    "        total = total + price * qty\n" +
    "    return total + total * tax_rate\n\n" +
    "def format_report(items, tax_rate):\n" +
    "    lines = []\n" +
    "    for item in items:\n" +
    "        lines.append(item[\"name\"] + \": \" + str(item[\"price\"]))\n" +
    "    lines.append(\"Total: \" + str(compute_total(items, tax_rate)))\n" +
    "    return \"\\n\".join(lines)\n" +
    "```"

  /** The first token arrives with the prompt, so n tokens have n-1 intervals. Times in nanoseconds. */
  fun decodeTps(tokens: Int, firstNs: Long, lastNs: Long): Double? =
    if (tokens >= 2 && firstNs > 0 && lastNs > firstNs) (tokens - 1) * 1e9 / (lastNs - firstNs) else null

  data class Diff(val identical: Boolean, val index: Int, val a: String, val b: String)

  /** Same text, or where the two first differ (character index) with a short excerpt of each. */
  fun compare(a: String, b: String): Diff {
    if (a == b) return Diff(true, -1, "", "")
    val n = minOf(a.length, b.length)
    var i = 0
    while (i < n && a[i] == b[i]) i++
    fun cut(s: String): String = s.substring((i - 12).coerceAtLeast(0), (i + 24).coerceAtMost(s.length)).replace('\n', ' ')
    return Diff(false, i, cut(a), cut(b))
  }

  private fun mean(v: List<Double>): Double? = if (v.isEmpty()) null else v.sum() / v.size

  /** Largest relative gap between the two runs of one setting: the test's own run-to-run noise. */
  private fun spread(v: List<Double>): Double = if (v.size < 2 || v.min() <= 0.0) 0.0 else (v.max() - v.min()) / v.min()

  /**
   * "faster", "slower" or "no clear difference". A difference smaller than 5% or smaller than the gap between two runs of the SAME setting
   * is called no clear difference: a phone's run-to-run noise is about that size.
   */
  fun verdict(off: List<Double>, on: List<Double>): String {
    val o = mean(off)
    val n = mean(on)
    if (o == null || n == null || o <= 0.0) return "Not enough generated tokens to compare."
    val ratio = n / o
    val noise = maxOf(0.05, spread(off), spread(on))
    val pct = Math.abs(ratio - 1.0) * 100
    return when {
      Math.abs(ratio - 1.0) <= noise -> String.format(Locale.US, "No clear difference (%.0f%%, within the %.0f%% the runs themselves vary).", pct, noise * 100)
      ratio > 1.0 -> String.format(Locale.US, "Lookup was %.0f%% faster on this prompt, on this phone, in this test.", pct)
      else -> String.format(Locale.US, "Lookup was %.0f%% SLOWER on this prompt, on this phone. Leave it off.", pct)
    }
  }

  /** A fact that does not depend on a noise band: every run of one setting is ahead of every run of the other. Null when the runs overlap. */
  fun rankingLine(off: List<Double>, on: List<Double>): String? {
    if (off.isEmpty() || on.isEmpty()) return null
    return when {
      on.max() < off.min() -> "Every lookup run was slower than every plain run."
      on.min() > off.max() -> "Every lookup run beat every plain run."
      else -> null
    }
  }

  /** Two runs of the SAME setting should agree. When they differ this much, one run was disturbed and no comparison above is reliable. */
  fun unstableNote(off: List<Double>, on: List<Double>): String? {
    val worst = maxOf(spread(off), spread(on))
    if (worst <= UNSTABLE_SPREAD) return null
    return String.format(Locale.US, "Two runs of the same setting differ by %.0f%%: a run was disturbed (heat, background work), so the verdict above is not reliable. Run it again with the phone cool.", worst * 100)
  }

  /** Runs of one setting that differ by more than this much (relative to the slower one) make the test unreliable. */
  const val UNSTABLE_SPREAD = 0.25

  private fun runLine(r: LookupRun, idx: Int): String {
    val head = String.format(Locale.US, "  %-3s #%d  %d tokens  %s", if (r.lookup) "on" else "off", idx, r.tokens, r.decodeTps?.let { String.format(Locale.US, "%.1f tok/s", it) } ?: "n/a")
    val n = r.numbers
    if (!r.lookup || n == null) return head
    if (!n.active) return "$head  (lookup did not run)"
    val acc = n.acceptPct?.let { String.format(Locale.US, "%.0f%% of %d guesses accepted", it, n.drafted) } ?: "no guesses made"
    val per = n.tokensPerRound?.let { String.format(Locale.US, ", %.1f tokens per batch", it) } ?: ""
    val paused = if (n.pauses > 0) ", paused ${n.pauses}x (not faster)" else ""
    // v1.9.36: what the batches cost in this very run, next to the plain steps of the same run (both measured by the native side).
    val cost = n.roundVsStep?.let { ratio ->
      String.format(Locale.US, "\n          a batch took %.0f ms, a plain step %.0f ms (%.1fx)", n.roundAvgMs ?: 0.0, n.singleStepMs ?: 0.0, ratio)
    } ?: ""
    return "$head  $acc$per$paused$cost"
  }

  /** Why lookup cannot run on this load, in the user's words. */
  fun reason(block: Int): String = when (block) {
    1 -> "this model streams its experts from storage, where a batch of guessed tokens reads many more experts than one token does"
    2 -> "this model keeps a recurrent state that cannot drop its newest tokens"
    3 -> "this model uses sliding-window attention, where removing the newest tokens is not reliable"
    4 -> "the model's memory does not support removing its newest tokens"
    else -> "unknown reason"
  }

  /** [runs] in [ORDER]. [stoppedEarly] = the time limit ended the test before all four runs finished. */
  fun report(runs: List<LookupRun>, stoppedEarly: Boolean, cost: BatchCost? = null): String {
    val sb = StringBuilder("Lookup test (experimental): code edit, greedy, max $MAX_TOKENS tokens, order off / on / on / off\n")
    var offN = 0
    var onN = 0
    for (r in runs) sb.append(runLine(r, if (r.lookup) ++onN else ++offN)).append('\n')
    if (stoppedEarly || runs.size < ORDER.size) {
      sb.append("Stopped at the ${TIME_LIMIT_SEC} s limit: not all runs finished, so there is no verdict.\n")
      return sb.toString().trimEnd()
    }
    val off = runs.filter { !it.lookup }.mapNotNull { it.decodeTps }
    val on = runs.filter { it.lookup }.mapNotNull { it.decodeTps }
    if (runs.filter { it.lookup }.none { it.numbers?.active == true }) {
      sb.append("Lookup did not run in the \"on\" runs, so there is nothing to compare.")
      return sb.toString()
    }
    mean(off)?.let { o -> mean(on)?.let { n -> sb.append(String.format(Locale.US, "Mean generation: off %.1f tok/s, on %.1f tok/s\n", o, n)) } }
    // Same text in both pairs (off #1 with on #1, off #2 with on #2). Each run is compared with the run of the other setting that is the same prompt and state.
    val pairs = listOf(runs[0] to runs[1], runs[3] to runs[2])
    val diffs = pairs.map { compare(it.first.text, it.second.text) }
    if (diffs.all { it.identical }) {
      sb.append("Output: identical with lookup on and off in both pairs.\n")
    } else {
      diffs.forEachIndexed { i, d ->
        if (!d.identical) {
          sb.append("Output differed in pair ${i + 1}, first at character ${d.index}: off \"${d.a}\" / on \"${d.b}\".\n")
        }
      }
      sb.append("A batched decode and a one-token decode round floats slightly differently, so a choice between two nearly equal tokens can flip. This is reported, not hidden.\n")
    }
    if (cost != null) sb.append(cost.describe()).append('\n')
    sb.append(verdict(off, on)).append('\n')
    rankingLine(off, on)?.let { sb.append(it).append('\n') }
    unstableNote(off, on)?.let { sb.append(it).append('\n') }
    sb.append("One prompt, one phone, two runs per setting: this is not a general speed-up. Lookup stays off unless you turn it on in Settings.")
    return sb.toString()
  }
}
