package com.example.llama

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * The phone clock for the model, kept out of the system prompt's volatile part.
 *
 * v1.9.29: the local engine reuses the KV cache of the longest common token prefix between two requests, and remote providers
 * cache prompt prefixes the same way. A clock that changes every minute inside the system prompt made everything after it a cache
 * miss on almost every request, so the clock moved to the end of the user message.
 *
 * v1.9.33: that placement made a small model answer "hi" with the clock as JSON (it treated the bracketed line as the thing to
 * answer). Now the system prompt carries only the DATE (it changes once a day, so the cache is kept all day) and the full clock
 * with the time of day is added to the user message only when the message is about the date or time ([asksForClock]); every other
 * message is sent exactly as typed. Pure, unit tested.
 */
object PromptClock {
  /** Static (never changes): the language note that used to share a block with the clock. */
  const val LANGUAGE_NOTE =
    "\nThe user may write Telugu or Hindi in English letters (for example \"ipudu time entha\" = what is the time now). " +
      "Understand it and reply in the same style."

  fun line(nowMs: Long, zoneId: String): String {
    val zone = TimeZone.getTimeZone(zoneId)
    val f = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).apply { timeZone = zone }
    return "\n\n[Phone clock: ${f.format(Date(nowMs))} (${zone.id}). Use it only when asked about the date or time.]"
  }

  /** The date alone (no time of day): the same text all day, so the system prompt stays a reusable prefix. */
  fun dateLine(nowMs: Long = System.currentTimeMillis(), zoneId: String = TimeZone.getDefault().id): String {
    val zone = TimeZone.getTimeZone(zoneId)
    val f = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.ENGLISH).apply { timeZone = zone }
    return "\nToday's date on the user's phone: ${f.format(Date(nowMs))}."
  }

  // Word-boundary matches, so "update" does not match "date" and "sometimes" does not match "time". Matching too much only means
  // the clock is attached to a message that did not need it; matching too little means the model has no time of day to read.
  private val CLOCK_WORDS = Regex(
    "\\b(?:times?|clocks?|dates?|today|tonight|tomorrow|yesterday|now|current|currently|days?|weeks?|weekend|weekday|months?|years?|hours?|minutes?|" +
      "o'clock|morning|afternoon|evening|night|monday|tuesday|wednesday|thursday|friday|saturday|sunday|ago|" +
      "samayam|samay|waqt|gantalu|ganta|ghanta|baje|tarikh|tareekh|roju|rojulu|eroju|repu|ninna|ippudu|ipudu|ippatiki|aaj|kal|abhi|" +
      "subah|shaam|raat|dopahar|vaaram|masam|tithi)\\b|\\d\\s?[ap]m\\b",
    RegexOption.IGNORE_CASE
  )

  // Telugu and Hindi words in their own script (a word boundary is not reliable for them, so these are plain substring checks).
  private val CLOCK_NATIVE = listOf(
    "\u0C38\u0C2E\u0C2F\u0C02", "\u0C24\u0C47\u0C26\u0C40", "\u0C08\u0C30\u0C4B\u0C1C\u0C41", "\u0C07\u0C2A\u0C4D\u0C2A\u0C41\u0C21\u0C41", "\u0C30\u0C47\u0C2A\u0C41", "\u0C28\u0C3F\u0C28\u0C4D\u0C28", "\u0C17\u0C02\u0C1F",
    "\u0938\u092E\u092F", "\u0924\u093E\u0930\u0940\u0916", "\u0906\u091C", "\u0915\u0932", "\u0905\u092D\u0940", "\u092C\u091C\u0947", "\u0924\u093F\u0925\u093F"
  )

  /** True when the message is about the date or time (or mentions a day, a time of day, "now", "ago"...). */
  fun asksForClock(userText: String): Boolean =
    CLOCK_WORDS.containsMatchIn(userText) || CLOCK_NATIVE.any { userText.contains(it) }

  /** The tail appended to the final user message: the full clock when the message needs it, otherwise nothing. */
  fun tailFor(userText: String, nowMs: Long = System.currentTimeMillis(), zoneId: String = TimeZone.getDefault().id): String =
    if (asksForClock(userText)) line(nowMs, zoneId) else ""

  /**
   * The old placement, unchanged byte for byte: the clock inside the system prompt. Requests that bring their own system prompt
   * (the phone agent, the router, internal tools) keep it, because their user message has a strict format of its own.
   */
  fun systemLine(nowMs: Long = System.currentTimeMillis(), zoneId: String = TimeZone.getDefault().id): String {
    val zone = TimeZone.getTimeZone(zoneId)
    val f = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).apply { timeZone = zone }
    return "\nCurrent date and time on the user's phone: ${f.format(Date(nowMs))} (${zone.id}). Use it when asked about the date or time."
  }

  /** The date (system prompt) and the on-demand clock (user message) apply only when the request uses the standard system prompt. */
  fun inUserTail(systemOverride: String?): Boolean = systemOverride == null
}
