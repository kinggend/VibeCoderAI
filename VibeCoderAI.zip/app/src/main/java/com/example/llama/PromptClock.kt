package com.example.llama

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

/**
 * v1.9.29: the phone clock for the model, kept out of the system prompt.
 *
 * The local engine reuses the KV cache of the longest common token prefix between two requests, and remote providers cache
 * prompt prefixes the same way. A clock that changes every minute inside the system prompt made everything after it a cache
 * miss on almost every request. The clock now rides at the very end of the user message, which is new on every request anyway,
 * so the system prompt and the project files before it stay a stable, reusable prefix. The model still sees the date and time.
 * Pure, unit tested.
 */
object PromptClock {
  /** Static (never changes): the language note that used to share a block with the clock. */
  const val LANGUAGE_NOTE =
    "\nThe user may write Telugu or Hindi in English letters (for example \"ipudu time entha\" = what is the time now). " +
      "Understand it and reply in the same style."

  fun line(nowMs: Long, zoneId: String): String {
    val zone = TimeZone.getTimeZone(zoneId)
    val f = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).apply { timeZone = zone }
    return "\n\n[Phone clock: ${f.format(Date(nowMs))} (${zone.id}). Use it only when asked about the date or time.]"
  }

  /** The tail appended to the final user message of a normal chat or build request. */
  fun tail(nowMs: Long = System.currentTimeMillis(), zoneId: String = TimeZone.getDefault().id): String = line(nowMs, zoneId)

  /**
   * The old placement, unchanged byte for byte: the clock inside the system prompt. Requests that bring their own system prompt
   * (the phone agent, the router, internal tools) keep it, because their user message has a strict format of its own.
   */
  fun systemLine(nowMs: Long = System.currentTimeMillis(), zoneId: String = TimeZone.getDefault().id): String {
    val zone = TimeZone.getTimeZone(zoneId)
    val f = SimpleDateFormat("EEEE, d MMMM yyyy, h:mm a", Locale.ENGLISH).apply { timeZone = zone }
    return "\nCurrent date and time on the user's phone: ${f.format(Date(nowMs))} (${zone.id}). Use it when asked about the date or time."
  }

  /** The clock goes to the user message tail only when the request uses the standard system prompt. */
  fun inUserTail(systemOverride: String?): Boolean = systemOverride == null
}
