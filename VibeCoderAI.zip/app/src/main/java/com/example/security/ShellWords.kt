package com.example.security

/**
 * v1.9.16: reads a shell command line the way `sh` does (quotes, backslashes, heredocs), so the security checks look at
 * what the shell will really see. `cat /da""ta/x` and `cat /d\ata/x` are both the word `/data/x`; a plain text search for
 * "/data" missed them. Pure Kotlin, unit-tested.
 */
object ShellWords {
  /**
   * One piece of the command line. [text] has quotes and escapes removed. [op] is an unquoted ; & | ( ) < > or newline.
   * [dynamic] is true when the shell will compute the word (variables, $(...), backticks, brace lists), so it cannot be checked ahead of time.
   */
  class Tok(val text: String, val op: Boolean = false, val dynamic: Boolean = false, val quoted: Boolean = false)

  class Result(val tokens: List<Tok>, val error: String? = null)

  private const val OPERATORS = ";&|()<>"

  private fun startsExpansion(s: String, i: Int): Boolean {
    val nx = s.getOrNull(i + 1) ?: return false
    return nx == '(' || nx == '{' || nx == '_' || nx.isLetter()
  }

  fun parse(cmd: String): Result {
    val out = ArrayList<Tok>()
    val sb = StringBuilder()
    var have = false
    var dyn = false
    var quoted = false
    var brace = false
    var braceList = false
    fun flush() {
      if (have) out += Tok(sb.toString(), op = false, dynamic = dyn || braceList, quoted = quoted)
      sb.setLength(0); have = false; dyn = false; quoted = false; brace = false; braceList = false
    }
    val n = cmd.length
    var i = 0
    while (i < n) {
      val c = cmd[i]
      when {
        c == '\\' -> {
          if (i + 1 < n && cmd[i + 1] != '\n') { sb.append(cmd[i + 1]); have = true }
          i += 2
        }
        c == '\'' -> {
          val j = cmd.indexOf('\'', i + 1)
          if (j < 0) return Result(out, "A quote is never closed.")
          sb.append(cmd, i + 1, j); have = true; quoted = true; i = j + 1
        }
        c == '"' -> {
          have = true; quoted = true; i++
          while (true) {
            if (i >= n) return Result(out, "A quote is never closed.")
            val d = cmd[i]
            if (d == '"') { i++; break }
            if (d == '\\' && i + 1 < n && cmd[i + 1] in "\"\\$`\n") {
              if (cmd[i + 1] != '\n') sb.append(cmd[i + 1])
              i += 2
              continue
            }
            if (d == '`' || (d == '$' && startsExpansion(cmd, i))) dyn = true
            sb.append(d); i++
          }
        }
        c == '`' -> { dyn = true; sb.append(c); have = true; i++ }
        c == '$' -> { if (startsExpansion(cmd, i)) dyn = true; sb.append(c); have = true; i++ }
        c == '{' -> { brace = true; sb.append(c); have = true; i++ }
        c == ',' && brace -> { braceList = true; sb.append(c); have = true; i++ }
        c == '}' -> { brace = false; sb.append(c); have = true; i++ }
        c == '#' && !have -> { while (i < n && cmd[i] != '\n') i++ }
        c == '<' && cmd.startsWith("<<", i) && !cmd.startsWith("<<<", i) -> {
          flush()
          out += Tok("<<", op = true)
          i = heredoc(cmd, i + 2, out)
        }
        c == '\n' || c in OPERATORS -> { flush(); out += Tok(c.toString(), op = true); i++ }
        c == ' ' || c == '\t' || c == '\r' -> { flush(); i++ }
        else -> { sb.append(c); have = true; i++ }
      }
    }
    flush()
    return Result(out)
  }

  /**
   * `<<EOF ... EOF`: the body is text, not commands, so it is skipped. When the delimiter is not quoted the shell still expands
   * $(...) and variables inside it, so such a body adds a dynamic token. Returns the index after the terminator line.
   */
  private fun heredoc(cmd: String, from: Int, out: MutableList<Tok>): Int {
    var i = from
    if (i < cmd.length && cmd[i] == '-') i++
    while (i < cmd.length && (cmd[i] == ' ' || cmd[i] == '\t')) i++
    val delim = StringBuilder()
    var quotedDelim = false
    while (i < cmd.length && cmd[i] !in " \t\n;&|()<>") {
      val c = cmd[i]
      if (c == '\'' || c == '"') { quotedDelim = true; i++; continue }
      if (c == '\\') { quotedDelim = true; i++; continue }
      delim.append(c); i++
    }
    if (delim.isEmpty()) return i
    // The rest of the current line still holds ordinary command text (">file", "&& next"); the body starts on the next line.
    val lineEnd = cmd.indexOf('\n', i)
    if (lineEnd < 0) return i
    val rest = cmd.substring(i, lineEnd)
    val tail = parse(rest)
    out.addAll(tail.tokens)
    var p = lineEnd + 1
    val body = StringBuilder()
    while (p <= cmd.length) {
      val e = cmd.indexOf('\n', p).let { if (it < 0) cmd.length else it }
      val line = cmd.substring(p, e)
      if (line.trim() == delim.toString()) { p = minOf(e + 1, cmd.length); break }
      body.append(line).append('\n')
      if (e >= cmd.length) { p = cmd.length; break }
      p = e + 1
    }
    if (!quotedDelim && Regex("""\$[({A-Za-z_]|`""").containsMatchIn(body)) out += Tok(body.toString().take(40), dynamic = true)
    out += Tok("\n", op = true)
    return p
  }
}
