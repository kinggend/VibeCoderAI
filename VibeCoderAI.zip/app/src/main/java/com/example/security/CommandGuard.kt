package com.example.security

import java.io.File

/**
 * v1.9.16: checks a shell command by what the shell will really run (ShellWords), not by searching the raw text.
 *  - [blockReason]: hard refusals: paths that leave the project, system and app-data folders, `..`, `~` (agent only).
 *  - [warning]: what the approval dialog should say when a command runs code the dialog cannot show (scripts, interpreters,
 *    eval, wrappers, variables). Such code can do anything the app can, so the user is told before approving.
 * Pure Kotlin, unit-tested.
 */
object CommandGuard {
  private val SYSTEM_ROOTS = listOf("etc", "system", "proc", "sys", "dev", "root", "data", "storage", "sdcard", "mnt", "vendor", "product", "apex", "odm")
  private val FS_ROOTS = SYSTEM_ROOTS + listOf("bin", "sbin", "usr", "lib", "lib64", "tmp", "home", "var", "opt", "cache", "config", "acct", "metadata", "oem", "linkerconfig", "debug_ramdisk", "init", "d")
  private val GLOB = Regex("""[*?\[]""")

  private val SHELLS = setOf("sh", "bash", "zsh", "dash", "ash", "ksh", "mksh", "csh", "tcsh", "fish")
  private val INTERPRETERS = setOf("node", "nodejs", "deno", "bun", "python", "python2", "python3", "perl", "ruby", "php", "java", "kotlin", "kotlinc", "lua", "tclsh", "awk", "gawk")
  private val WRAPPERS = setOf("env", "nohup", "timeout", "xargs", "nice", "ionice", "setsid", "stdbuf", "time", "watch", "busybox", "toybox", "command", "exec", "su", "run-as", "chroot", "nsenter", "unshare", "script")
  private val PREFIX_KEYWORDS = setOf("if", "then", "else", "elif", "do", "while", "until", "!", "{", "}", "time")
  private val SKIP_KEYWORDS = setOf("for", "case", "select", "function", "fi", "done", "esac", "in")
  private val ASSIGNMENT = Regex("""^[A-Za-z_][A-Za-z0-9_]*=""")

  private fun canon(f: File) = runCatching { f.canonicalPath }.getOrDefault(f.absolutePath)

  private fun inside(root: File, path: String): Boolean {
    val r = canon(root)
    val c = canon(File(path))
    return c == r || c.startsWith(r + File.separator)
  }

  /** Candidate paths inside one word: the word itself, the value of `--opt=/path` or `NAME=/path`, and the parts of a `:` list (not URLs). */
  private fun candidates(w: String): List<String> {
    val out = mutableListOf(w)
    if (w.contains('=')) out += w.substringAfter('=')
    for (base in out.toList()) if (!base.contains("://") && base.contains(':')) out += base.split(':')
    return out.distinct()
  }

  /** Why [cmd] must not run, or null. [strict] (commands the agent proposes) also refuses `~` and any real absolute path outside [root]. */
  fun blockReason(cmd: String, root: File?, strict: Boolean): String? {
    val parsed = ShellWords.parse(cmd)
    for (t in parsed.tokens) {
      if (t.op) continue
      // A computed word ("{/etc/hosts,x}", "`echo /etc`/x") is checked piece by piece for anything that looks like a path.
      val words = if (t.dynamic) t.text.split('{', '}', ',', '`', '(', ')', ' ').filter { it.isNotEmpty() }.flatMap { candidates(it) }.distinct()
      else candidates(t.text)
      for (w in words) {
        if (w == ".." || w.startsWith("../") || w.contains("/../") || w.endsWith("/..") || w.startsWith("..\\") || w.contains("\\..")) {
          return "Execution blocked: Path traversal ('..') is not permitted in commands."
        }
        if (strict && w.startsWith("~")) return "Execution blocked: '~' is not available to agent commands. Use a path inside the project."
        if (!w.startsWith("/") || w == "/dev/null") continue
        if (root != null && inside(root, w)) continue
        val first = w.trimStart('/').substringBefore('/')
        if (first.isEmpty()) return "Execution blocked: The root folder '/' is outside the project."
        if (first in SYSTEM_ROOTS) return "Execution blocked: Access to system directory '/$first' is strictly forbidden."
        // "/e*c/passwd" and "/da?a" are patterns the shell expands to system folders.
        if (GLOB.containsMatchIn(first)) return "Execution blocked: Patterns that start from the root folder are not permitted."
        if (strict && (first in FS_ROOTS || File("/$first").exists())) return "Execution blocked: '$w' is outside the project."
      }
    }
    return null
  }

  private class Simple(val words: List<ShellWords.Tok>)

  /** The simple commands of a command line: split at ; & | ( ) and newlines, redirections and assignments removed. */
  private fun simpleCommands(tokens: List<ShellWords.Tok>): List<Simple> {
    val result = mutableListOf<Simple>()
    var cur = mutableListOf<ShellWords.Tok>()
    var skipNext = false
    fun end() { if (cur.isNotEmpty()) result += Simple(cur); cur = mutableListOf() }
    for (t in tokens) {
      if (t.op) {
        when (t.text) {
          "<", ">" -> skipNext = true
          "<<" -> skipNext = false
          else -> { skipNext = false; end() }
        }
        continue
      }
      if (skipNext) { skipNext = false; continue } // the target of a redirection
      cur += t
    }
    end()
    return result.mapNotNull { s ->
      var w = s.words
      while (w.isNotEmpty() && !w[0].quoted && ASSIGNMENT.containsMatchIn(w[0].text)) w = w.drop(1)
      while (w.isNotEmpty() && w[0].text in PREFIX_KEYWORDS && !w[0].quoted) w = w.drop(1)
      if (w.isEmpty() || (w[0].text in SKIP_KEYWORDS && !w[0].quoted)) null else Simple(w)
    }
  }

  private fun lineCount(root: File?, name: String): String {
    if (root == null || name.isEmpty() || name.startsWith("-")) return ""
    val f = File(root, name)
    if (!f.isFile || f.length() > 512 * 1024 || !inside(root, f.path)) return ""
    return runCatching { " (${f.readLines().size} lines)" }.getOrDefault("")
  }

  /**
   * What the approval dialog should warn about, or null for a command that only moves and reads files. The command text alone does
   * not show what a script or interpreter will do, so the warning names the file and its size.
   */
  fun warning(cmd: String, root: File?): String? {
    val parsed = ShellWords.parse(cmd)
    val notes = LinkedHashSet<String>()
    if (parsed.error != null) notes += "cannot be read safely (${parsed.error})"
    if (parsed.tokens.any { it.dynamic }) notes += "uses variables, \$(...), backticks or {a,b} lists, so the exact command is only known when it runs"
    for (s in simpleCommands(parsed.tokens)) {
      val name = s.words[0].text.substringAfterLast('/')
      val args = s.words.drop(1).map { it.text }
      val file = args.firstOrNull { !it.startsWith("-") }.orEmpty()
      when {
        s.words[0].text.contains('/') && name !in SHELLS && name !in INTERPRETERS && name !in WRAPPERS ->
          notes += "runs the program ${s.words[0].text}"
        name in SHELLS -> notes += when {
          args.contains("-c") -> "starts a shell with a command text"
          file.isNotEmpty() -> "runs the script $file${lineCount(root, file)}"
          else -> "starts a shell that runs whatever it is given"
        }
        name == "." || name == "source" -> notes += "runs the script $file${lineCount(root, file)}"
        name == "eval" -> notes += "runs text as a command (eval)"
        name in INTERPRETERS -> notes += when {
          args.any { it == "-e" || it == "-c" || it == "--eval" || it == "-p" || it == "-r" } -> "runs $name code written in the command"
          file.isNotEmpty() -> "runs $name code from $file${lineCount(root, file)}"
          else -> "starts $name"
        }
        name in WRAPPERS -> notes += "runs another program through $name"
        name == "find" && args.any { it == "-exec" || it == "-execdir" || it == "-ok" || it == "-okdir" } -> notes += "runs programs from find"
      }
    }
    if (notes.isEmpty()) return null
    return "This command " + notes.joinToString("; ") + ". Code like this can do anything this app can, including reading your other projects and chats. Check it before you approve."
  }
}
