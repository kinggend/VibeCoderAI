package com.example.agent

/**
 * v1.9.20: the "is anything actually visible?" check, shared by the agent's own test (HeadlessCheck) and the Preview screen.
 *
 * Until now both only listened for JavaScript errors. A page can load, run every script and still show nothing (a canvas inside a
 * container that has no height, setup code that never ran, a render loop that never started). That page has zero errors, so the
 * agent said "no errors" and Preview showed a blank screen. The probe looks at what is on screen: any visible text, image, canvas,
 * video or control. If there is none, it says why (the canvas and its container sizes) so the agent or the user can fix the real cause.
 *
 * The script is plain ES5 and has no dollar signs (this is a Kotlin raw string). It returns a JSON array of at most 3 short messages.
 */
object PageProbe {
  const val JS = """(function(){var o=[];var b=document.body;
if(!b)return JSON.stringify(['The page has no body.']);
function shown(e){var r=e.getBoundingClientRect();if(r.width<2||r.height<2)return false;var s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&parseFloat(s.opacity)!==0;}
function nm(e){return e.id?'#'+e.id:((typeof e.className==='string'&&e.className.trim())?'.'+e.className.trim().split(/\s+/)[0]:e.tagName.toLowerCase());}
function px(e){var r=e.getBoundingClientRect();return Math.round(r.width)+'x'+Math.round(r.height);}
var media=0,text=0,all=b.getElementsByTagName('*'),skip={SCRIPT:1,STYLE:1,NOSCRIPT:1,LINK:1,META:1};
for(var i=0;i<all.length&&i<4000;i++){var e=all[i],t=e.tagName;if(skip[t])continue;
if(t==='CANVAS'||t==='IMG'||t==='VIDEO'||t==='IFRAME'||t==='INPUT'||t==='TEXTAREA'||t==='SELECT'||t==='svg'){if(shown(e))media++;continue;}
if(!text){for(var n=e.firstChild;n;n=n.nextSibling){if(n.nodeType===3&&n.nodeValue.trim()&&shown(e)){text++;break;}}}}
var cs=b.getElementsByTagName('canvas');
function cm(c,lead){var p=c.parentElement;return lead+'the canvas is '+px(c)+' px on screen'+(p&&p!==b?' and its container '+nm(p)+' is '+px(p)+' px':'')+'. The container has no real height. Set html, body {height:100%} and a height such as 100vh on the container, and size the renderer from it.';}
if(!media&&!text){
if(cs.length){o.push(cm(cs[0],'Nothing is visible: '));}
else if(typeof THREE!=='undefined'){o.push('Nothing is visible: Three.js loaded but no canvas was added to the page. The setup code did not run, or it never appended renderer.domElement to the page.');}
else{o.push('Nothing is visible: the page has no visible text, image or canvas. The JavaScript did not add any content.');}}
if(!o.length){for(var k=0;k<cs.length;k++){var q=cs[k];if(q.getClientRects().length>0){var r=q.getBoundingClientRect();if(r.width<2||r.height<2){o.push(cm(q,'The page shows text, but '));break;}}}}
var els=document.querySelectorAll('[id],[class]');
for(var j=0;j<els.length&&o.length<3;j++){var d=els[j];var key=((d.id||'')+' '+(typeof d.className==='string'?d.className:'')).toLowerCase();
if(/(board|grid|stage|cells)/.test(key)&&d.offsetParent!==null&&d.children.length===0&&!d.textContent.trim())o.push('The element '+nm(d)+' is empty: JavaScript never drew anything inside it.');}
return JSON.stringify(o.slice(0,3));})()"""

  /** The messages from [JS] as returned by WebView.evaluateJavascript (a JSON string that holds a JSON array). Empty when fine or unreadable. */
  fun parse(raw: String?): List<String> = runCatching {
    val s = org.json.JSONTokener(raw ?: return emptyList()).nextValue() as? String ?: return emptyList()
    val arr = org.json.JSONArray(s)
    (0 until arr.length()).map { arr.getString(it) }
  }.getOrDefault(emptyList())
}
