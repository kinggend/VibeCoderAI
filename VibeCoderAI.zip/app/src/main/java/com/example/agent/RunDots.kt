package com.example.agent

import kotlin.math.PI
import kotlin.math.sin

/** v1.9.19: the state the animated dots show. Pure Kotlin, unit-tested. */
enum class DotsState { IDLE, WORKING, NEEDS_YOU, DONE, FAILED }

object RunDots {
  /** An open approval, question or patch always wins: the run is waiting for the user, not working. */
  fun of(running: Boolean, needsUser: Boolean): DotsState = when {
    needsUser -> DotsState.NEEDS_YOU
    running -> DotsState.WORKING
    else -> DotsState.IDLE
  }

  fun of(status: RunStatus): DotsState = when (status) {
    RunStatus.WORKING -> DotsState.WORKING
    RunStatus.DONE -> DotsState.DONE
    RunStatus.FAILED -> DotsState.FAILED
    RunStatus.STOPPED -> DotsState.IDLE
  }

  /** Short line next to the dots. [detail] is the live step label, if any. */
  fun label(state: DotsState, detail: String): String = when (state) {
    DotsState.NEEDS_YOU -> "Waiting for you"
    DotsState.WORKING -> detail.trim().ifBlank { "Working" }.lineSequence().first().take(60)
    DotsState.DONE -> "Done"
    DotsState.FAILED -> "Needs attention"
    DotsState.IDLE -> ""
  }

  /**
   * Brightness 0..1 of dot [index] (0..2) at [phase] 0..1. Working: a wave that passes along the three dots.
   * Needs you: all three breathe together, slower to read. Finished states hold still.
   */
  fun level(state: DotsState, phase: Float, index: Int): Float = when (state) {
    DotsState.WORKING -> ((sin(2.0 * PI * (phase - index * 0.18)) + 1.0) / 2.0).toFloat()
    DotsState.NEEDS_YOU -> ((sin(2.0 * PI * phase) + 1.0) / 2.0).toFloat()
    DotsState.DONE, DotsState.FAILED -> 1f
    DotsState.IDLE -> 0.4f
  }
}

/**
 * v1.9.19: a notification when a run finishes or fails while the app is not on screen. A run only counts when it was seen
 * WORKING first, so runs that were already finished when the app started never notify.
 */
object RunAlerts {
  fun newlyFinished(seen: MutableMap<String, RunStatus>, now: List<RunRecord>): List<RunRecord> {
    val out = ArrayList<RunRecord>()
    for (r in now) {
      val prev = seen[r.id]
      seen[r.id] = r.status
      if (prev == RunStatus.WORKING && (r.status == RunStatus.DONE || r.status == RunStatus.FAILED)) out.add(r)
    }
    val ids = now.mapTo(HashSet()) { it.id }
    seen.keys.retainAll(ids)
    return out
  }

  private fun what(r: RunRecord) = (r.tag.ifBlank { r.agent.ifBlank { r.kind.label } })

  fun title(r: RunRecord): String = when (r.status) {
    RunStatus.DONE -> "${what(r)} finished"
    RunStatus.FAILED -> "${what(r)} needs attention"
    else -> what(r)
  }

  fun text(r: RunRecord): String =
    r.result.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(140)?.ifBlank { null } ?: r.title.take(140)
}
