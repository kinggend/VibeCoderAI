package com.example.agent

/**
 * v1.9.21: turns one agent run (its progress notes and the files it wrote, in order) into a single timeline. Pure Kotlin,
 * unit-tested; the card that draws it is `RunTimelineCard`.
 *
 * Until now every note was its own list item with its own chips, and the files, the test result and the "Last run" bar lived
 * in different places, so a run read as scattered logs and could show contradictory signals. Here one run has exactly one
 * state (running, done, failed or stopped), one list of steps with their files, and one test result.
 *
 * The notes are the fixed English lines written by [AgentOrchestrator]; anything not recognised becomes a quiet info row,
 * so a new kind of note never breaks the card.
 */
object RunTimeline {
  enum class State { RUNNING, DONE, FAILED, STOPPED }
  enum class Status { PENDING, RUNNING, DONE, FAILED, STOPPED }
  enum class FileState { PENDING, APPLIED, FAILED, DISCARDED }
  enum class Kind { STEP, CHECK, FIX, TOOL, INFO }

  /** One thing that happened, in order. */
  sealed interface Item {
    data class Note(val text: String) : Item
    data class File(val path: String, val lines: Int, val state: FileState, val error: String? = null) : Item
  }

  data class FileRow(val path: String, val lines: Int, val state: FileState, val error: String?)
  data class Row(val kind: Kind, val label: String, val status: Status, val files: List<FileRow> = emptyList(), val detail: String? = null)

  data class Model(
    val state: State,
    /** The step being worked on now (RUNNING), else null. */
    val current: String?,
    /** "Debugger", "Reviewer"...: set for specialist runs, null for the Builder. */
    val agent: String?,
    val rows: List<Row>,
    /** Plan steps finished, and how many there are (0 = unknown). */
    val done: Int,
    val total: Int,
    /** What went wrong, for the failed state's details. */
    val failure: String?,
    val modifiedFiles: Int
  ) {
    /** 0..1, or null when the plan is unknown. */
    val fraction: Float? get() = if (total <= 0) null else (done.toFloat() / total).coerceIn(0f, 1f)
  }

  private class RowB(val kind: Kind, var label: String, var status: Status, var detail: String? = null) {
    val files = ArrayList<FileRow>()
    fun build() = Row(kind, label, status, files.toList(), detail)
  }

  private val PLAN_LINE = Regex("""^\s*\d+[.)]\s*(.+?)\s*$""")
  private val STEP = Regex("""^Step (\d+) of (\d+): (.*)$""", RegexOption.DOT_MATCHES_ALL)
  private val FOUND = Regex("""^Found (\d+) problem\(s\)\.""")
  private val ATTEMPT = Regex("""attempt (\d+) of (\d+)""")
  private val DECLINED_STEP = Regex("""^You declined the changes for step (\d+)""")
  private val STOPPED_AFTER = Regex("""^Stopped after (\d+) fix attempts""")
  private val STILL = Regex("""^Still (\d+) problem\(s\)""")
  private val COULD_NOT_WRITE = Regex("""^Could not write (.+?): (.*)$""", RegexOption.DOT_MATCHES_ALL)
  private val AGENT_WORKING = Regex("""^(.+) agent is working\.$""")
  private val AUTO_AGENT = Regex("""^Auto: (.+) agent\.$""")

  fun build(items: List<Item>, running: Boolean): Model {
    val rows = ArrayList<RowB>()
    val planRows = ArrayList<RowB>()
    var current: RowB? = null
    var checkRow: RowB? = null
    var done = false
    var failed = false
    var stopped = false
    var failure: String? = null
    var agent: String? = null
    var stepTotal = 0

    fun finishWorking() {
      for (r in rows) if (r.status == Status.RUNNING && r.kind != Kind.CHECK) r.status = Status.DONE
    }
    fun add(kind: Kind, label: String, status: Status, detail: String? = null): RowB =
      RowB(kind, label, status, detail).also { rows.add(it) }

    for (item in items) {
      when (item) {
        is Item.File -> {
          val holder = current ?: rows.lastOrNull { it.kind != Kind.CHECK } ?: add(Kind.STEP, "Files", Status.RUNNING).also { current = it }
          holder.files.add(FileRow(item.path, item.lines, item.state, item.error))
        }
        is Item.Note -> {
          val t = item.text.trim()
          val first = t.lineSequence().firstOrNull().orEmpty()
          when {
            t.startsWith("Working on it") -> Unit
            AUTO_AGENT.matches(first) -> agent = AUTO_AGENT.matchEntire(first)!!.groupValues[1]
            AGENT_WORKING.matches(first) -> agent = AGENT_WORKING.matchEntire(first)!!.groupValues[1]
            t.startsWith("Plan:") -> {
              planRows.clear()
              t.lineSequence().drop(1).mapNotNull { PLAN_LINE.matchEntire(it)?.groupValues?.get(1) }.forEach { label ->
                planRows.add(add(Kind.STEP, label, Status.PENDING))
              }
              stepTotal = planRows.size
              if (planRows.size == 1) { planRows[0].status = Status.RUNNING; current = planRows[0] }
            }
            STEP.matches(t) -> {
              val m = STEP.matchEntire(t)!!
              val i = m.groupValues[1].toInt()
              stepTotal = maxOf(stepTotal, m.groupValues[2].toInt())
              finishWorking()
              val row = planRows.getOrNull(i - 1) ?: add(Kind.STEP, m.groupValues[3].trim(), Status.RUNNING).also { planRows.add(it) }
              if (row.status != Status.FAILED) row.status = Status.RUNNING
              current = row
            }
            DECLINED_STEP.containsMatchIn(first) -> {
              val i = DECLINED_STEP.find(first)!!.groupValues[1].toInt()
              planRows.getOrNull(i - 1)?.let { it.status = Status.FAILED; it.detail = "You declined these changes" }
            }
            t.startsWith("Testing the app") || t.startsWith("Checking the app") -> {
              finishWorking()
              checkRow = add(Kind.CHECK, "Testing the app", Status.RUNNING)
              current = null
            }
            t.startsWith("Done. The app loaded with no errors") -> {
              finishWorking()
              (checkRow ?: add(Kind.CHECK, "", Status.DONE)).also { it.label = "Tested: loads with no errors"; it.status = Status.DONE }
              done = true
            }
            t.startsWith("Tested the app: no errors") -> {
              finishWorking()
              add(Kind.CHECK, "Tested: no errors", Status.DONE)
              done = true
            }
            FOUND.containsMatchIn(first) -> {
              val n = FOUND.find(first)!!.groupValues[1]
              finishWorking()
              (checkRow ?: add(Kind.CHECK, "", Status.FAILED)).also { it.label = "Test found $n problem(s)"; it.status = Status.FAILED }
              checkRow = null
              val attempt = ATTEMPT.find(first)?.let { "Fix attempt ${it.groupValues[1]} of ${it.groupValues[2]}" } ?: "Repairing the files"
              current = add(Kind.FIX, attempt, Status.RUNNING)
            }
            STILL.containsMatchIn(first) -> {
              finishWorking()
              val n = STILL.find(first)!!.groupValues[1]
              add(Kind.CHECK, "Still $n problem(s)", Status.FAILED, t.removePrefix(first).trim().ifEmpty { first.substringAfter(": ", "") }.ifEmpty { null })
              failed = true
              failure = t
            }
            STOPPED_AFTER.containsMatchIn(first) -> {
              finishWorking()
              val n = STOPPED_AFTER.find(first)!!.groupValues[1]
              (checkRow ?: add(Kind.CHECK, "", Status.FAILED)).also { it.label = "Stopped after $n fix attempts"; it.status = Status.FAILED; it.detail = t.lineSequence().drop(1).joinToString("\n").trim().ifEmpty { null } }
              checkRow = null
              failed = true
              failure = t
            }
            t.startsWith("Fix not applied because you declined") -> {
              finishWorking()
              add(Kind.INFO, "You declined the fix", Status.STOPPED)
              stopped = true
            }
            t.startsWith("Stopped: ") || t.startsWith("Not started") -> {
              finishWorking()
              add(Kind.INFO, first, Status.FAILED)
              failed = true
              failure = t
            }
            t.startsWith("Tool: ") -> {
              finishWorking()
              current = add(Kind.TOOL, t.removePrefix("Tool: ").take(120), Status.RUNNING)
            }
            COULD_NOT_WRITE.matches(t) -> {
              val m = COULD_NOT_WRITE.matchEntire(t)!!
              add(Kind.INFO, "Could not write ${m.groupValues[1]}", Status.FAILED, m.groupValues[2].trim().take(200))
            }
            t.isNotEmpty() -> add(Kind.INFO, first.take(160), Status.DONE, t.lineSequence().drop(1).joinToString("\n").trim().ifEmpty { null })
          }
        }
      }
    }

    val state = when {
      running -> State.RUNNING
      failed -> State.FAILED
      stopped -> State.STOPPED
      done -> State.DONE
      rows.any { it.status == Status.RUNNING } -> State.STOPPED
      else -> State.DONE
    }
    if (state != State.RUNNING) {
      for (r in rows) when {
        r.status == Status.RUNNING -> r.status = if (state == State.DONE) Status.DONE else Status.STOPPED
        r.status == Status.PENDING && state == State.DONE -> r.status = Status.DONE
      }
    }
    val files = rows.flatMap { it.files }.filter { it.state == FileState.APPLIED }.map { it.path }.distinct().size
    val currentLabel = if (state == State.RUNNING) rows.lastOrNull { it.status == Status.RUNNING }?.label else null
    val doneSteps = planRows.count { it.status == Status.DONE }
    return Model(
      state = state, current = currentLabel, agent = agent, rows = rows.map { it.build() },
      done = doneSteps, total = stepTotal, failure = failure, modifiedFiles = files
    )
  }
}

/**
 * v1.9.21: decides which chat messages are drawn as one run timeline. Pure Kotlin, unit-tested.
 *
 * A run is a stretch of consecutive agent progress notes and file-only agent messages (a message whose only content is files it
 * wrote). Everything else (the person's messages, replies with text, streaming replies) stays a normal chat item. A stretch with
 * no progress note is not a run, so a plain "here is your file" reply keeps looking like it always did.
 */
object RunGrouping {
  enum class Kind { USER, NOTE, FILES, OTHER }

  /** Messages [start]..[end] (inclusive) of the chat; [isRun] is false for a single normal message. */
  data class Span(val start: Int, val end: Int, val isRun: Boolean)

  fun group(kinds: List<Kind>): List<Span> {
    val out = ArrayList<Span>()
    var i = 0
    while (i < kinds.size) {
      if (kinds[i] != Kind.NOTE && kinds[i] != Kind.FILES) { out.add(Span(i, i, false)); i++; continue }
      var j = i
      while (j + 1 < kinds.size && (kinds[j + 1] == Kind.NOTE || kinds[j + 1] == Kind.FILES)) j++
      val hasNote = (i..j).any { kinds[it] == Kind.NOTE }
      if (hasNote) out.add(Span(i, j, true)) else for (k in i..j) out.add(Span(k, k, false))
      i = j + 1
    }
    return out
  }

  /** The run the person is looking at right now: the last run, if no message of theirs came after it. */
  fun latestRun(spans: List<Span>, kinds: List<Kind>): Span? {
    val last = spans.lastOrNull { it.isRun } ?: return null
    return if ((last.end + 1 until kinds.size).any { kinds[it] == Kind.USER }) null else last
  }
}
