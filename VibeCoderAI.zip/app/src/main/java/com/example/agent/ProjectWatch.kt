package com.example.agent

import java.io.File

/**
 * v1.9.19: deterministic health check of a project folder. No model, no WebView, no network, and it never changes a file
 * (unlike Preview, which repairs as it goes), so it is safe to run unattended. Pure Kotlin (java.io only), unit-tested.
 *
 * It looks for the two problems small models cause most: a file that index.html loads but that was never written, and a
 * script or stylesheet that was cut off in the middle (output limit reached), which leaves a bracket open.
 */
object ProjectWatch {
  data class Finding(val project: String, val problems: List<String>)

  private const val MAX_PROBLEMS = 6
  private const val MAX_FILE_BYTES = 400_000L

  private val SCRIPT_SRC = Regex("""<script\b[^>]*\bsrc\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
  private val LINK_TAG = Regex("""<link\b[^>]*>""", RegexOption.IGNORE_CASE)
  private val HREF = Regex("""\bhref\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
  private val REMOTE = Regex("""^(?:[a-z][a-z0-9+.-]*:|//|#)""", RegexOption.IGNORE_CASE)

  /** Problems in the folder [root], at most [MAX_PROBLEMS], each one short enough for a notification line. */
  fun staticProblems(root: File): List<String> {
    if (!root.isDirectory) return emptyList()
    val out = ArrayList<String>()
    val index = File(root, "index.html")
    val rootPath = runCatching { root.canonicalPath }.getOrNull() ?: return emptyList()
    if (!index.isFile) {
      if (File(root, "app.js").isFile || File(root, "styles.css").isFile) out.add("index.html is missing")
      return out
    }
    val html = runCatching { index.readText() }.getOrDefault("")
    // Only scripts and stylesheets: a missing favicon or icon is not a broken app.
    val styles = LINK_TAG.findAll(html).map { it.value }.filter { it.contains("stylesheet", ignoreCase = true) }.mapNotNull { HREF.find(it)?.groupValues?.get(1) }
    val refs = (SCRIPT_SRC.findAll(html).map { it.groupValues[1] } + styles).map { it.substringBefore('#').substringBefore('?').trim() }
      .filter { it.isNotEmpty() && !REMOTE.containsMatchIn(it) }
      .distinct().toList()
    for (ref in refs) {
      if (out.size >= MAX_PROBLEMS) break
      if (File(ref).name.lowercase().let { it == "three.min.js" || it == "three.js" }) continue // Preview supplies the bundled Three.js itself
      // The browser normalises "a/../app.js" to "app.js", so look at the canonical file, and never leave the project folder.
      val f = runCatching { File(root, ref).canonicalFile }.getOrNull() ?: continue
      if (!f.path.startsWith(rootPath + File.separator)) continue
      when {
        !f.isFile -> out.add("index.html loads $ref but it does not exist")
        f.length() == 0L -> out.add("$ref is empty")
        f.length() <= MAX_FILE_BYTES && (ref.endsWith(".js") || ref.endsWith(".css")) -> {
          val text = runCatching { f.readText() }.getOrDefault("")
          if (hasUnclosedBracket(text, css = ref.endsWith(".css"))) out.add("$ref looks cut off (a bracket is never closed)")
        }
      }
    }
    return out.take(MAX_PROBLEMS)
  }

  /** One line per notification: title and text. Null when nothing is wrong. */
  fun summary(findings: List<Finding>): Pair<String, String>? {
    if (findings.isEmpty()) return null
    val title = if (findings.size == 1) "1 project needs attention" else "${findings.size} projects need attention"
    val first = findings.first()
    val more = findings.sumOf { it.problems.size } - 1
    val text = "${first.project}: ${first.problems.first()}" + if (more > 0) " (+$more more)" else ""
    return title to text
  }

  /** Same findings, same signature: the same alert is never posted twice in a row. */
  fun signature(findings: List<Finding>): String =
    findings.sortedBy { it.project }.joinToString("|") { f -> f.project + ":" + f.problems.sorted().joinToString(";") }

  /**
   * True when a bracket opened in [src] is still open at the end, which is what a cut-off file looks like. Skips strings,
   * comments, template literals (with nested ${...}) and regex literals. A stray closing bracket is NOT reported:
   * the scanner is a heuristic and only the "never closed" direction is worth an alert.
   */
  fun hasUnclosedBracket(src: String, css: Boolean = false): Boolean {
    val st = ArrayList<Char>()
    val n = src.length
    var i = 0
    var prev = ' '
    var word = ""
    var inWord = false

    fun skipTemplate() { // i is just after a backtick, or after the } that ended a ${...}
      while (i < n) {
        val c = src[i]
        if (c == '\\') { i += 2; continue }
        if (c == '`') { i++; return }
        if (c == '$' && i + 1 < n && src[i + 1] == '{') { st.add('$'); i += 2; return }
        i++
      }
    }

    fun regexAllowed(): Boolean {
      if (prev in "(,=:[!&|?{};+-*%<>~^ ") return true
      return word in setOf("return", "typeof", "case", "in", "of", "delete", "void", "throw", "new", "else", "do")
    }

    while (i < n) {
      val c = src[i]
      val next = if (i + 1 < n) src[i + 1] else ' '
      when {
        c == '/' && next == '*' -> {
          val end = src.indexOf("*/", i + 2)
          if (end < 0) return true // a comment that never ends
          i = end + 2
        }
        c == '/' && next == '/' && !css -> {
          val end = src.indexOf('\n', i)
          i = if (end < 0) n else end + 1
        }
        c == '"' || c == '\'' -> {
          i++
          while (i < n && src[i] != c && src[i] != '\n') { if (src[i] == '\\') i++; i++ }
          i++
          prev = '"'; word = ""
        }
        c == '`' && !css -> { i++; skipTemplate(); prev = '`'; word = "" }
        c == '/' && !css && regexAllowed() -> {
          i++
          var inClass = false
          while (i < n && src[i] != '\n') {
            val r = src[i]
            if (r == '\\') { i += 2; continue }
            if (r == '[') inClass = true else if (r == ']') inClass = false
            else if (r == '/' && !inClass) break
            i++
          }
          i++
          prev = '/'; word = ""
        }
        c == '{' || c == '(' || c == '[' -> { st.add(c); i++; prev = c; word = "" }
        c == '}' && st.isNotEmpty() && st.last() == '$' -> { st.removeAt(st.size - 1); i++; skipTemplate(); prev = '`'; word = "" }
        c == '}' || c == ')' || c == ']' -> { if (st.isNotEmpty()) st.removeAt(st.size - 1); i++; prev = c; word = "" }
        c.isLetterOrDigit() || c == '_' || c == '$' -> { word = if (inWord) word + c else c.toString(); inWord = true; prev = 'w'; i++ }
        c.isWhitespace() -> { inWord = false; i++ }
        else -> { prev = c; word = ""; i++ }
      }
    }
    return st.isNotEmpty()
  }
}
