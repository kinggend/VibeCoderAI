package com.example.agent

import java.net.URI

/**
 * v1.9.19: which web addresses the agent browser may open. Pure Kotlin, unit-tested without Android.
 *
 * The browser exists so an agent can read a documentation page. It must never become a way into the phone's own network
 * (router pages, a LAN Ollama, other devices), so only public https websites pass: no IP addresses, no single-label or
 * local-looking host names, no credentials in the URL, no odd ports. [isPrivateAddress] is for the resolved addresses.
 */
object BrowsePolicy {
  sealed interface Verdict {
    /** [url] is normalised to https; [host] is lower case without a trailing dot. */
    data class Ok(val url: String, val host: String) : Verdict
    data class Blocked(val reason: String) : Verdict
  }

  const val MAX_URL = 2000

  private val LOCAL_SUFFIXES = listOf(
    ".local", ".localhost", ".internal", ".lan", ".home", ".corp", ".intranet", ".home.arpa", ".test", ".example", ".invalid", ".onion"
  )

  fun check(raw: String): Verdict {
    var text = raw.trim().trim('<', '>', '"', '\'', '`').trim()
    if (text.isEmpty()) return Verdict.Blocked("No address given.")
    if (text.length > MAX_URL) return Verdict.Blocked("The address is too long.")
    if (text.any { it.isWhitespace() || it.code < 32 }) return Verdict.Blocked("The address has spaces or control characters.")
    val scheme = text.substringBefore("://", "").lowercase()
    if (text.contains("://")) {
      if (scheme != "https" && scheme != "http") return Verdict.Blocked("Only https websites can be opened.")
      text = "https://" + text.substringAfter("://")
    } else {
      if (text.contains(':') && !text.substringBefore('/').contains('.')) return Verdict.Blocked("Only https websites can be opened.")
      text = "https://$text"
    }
    val uri = try { URI(text) } catch (e: Exception) { return Verdict.Blocked("That is not a valid address.") }
    if (uri.rawUserInfo != null || (uri.rawAuthority ?: "").contains('@')) return Verdict.Blocked("Addresses with a user name or password are not allowed.")
    if (uri.port != -1 && uri.port != 443) return Verdict.Blocked("Only the standard https port is allowed.")
    val host = (uri.host ?: "").lowercase().trimEnd('.')
    if (host.isEmpty()) return Verdict.Blocked("That is not a valid address.")
    if (host.contains(':') || host.startsWith("[")) return Verdict.Blocked("IP addresses are not allowed.")
    if (!host.all { it.isLetterOrDigit() || it == '-' || it == '.' }) return Verdict.Blocked("That host name is not allowed.")
    if (host.startsWith(".") || host.contains("..") || host.split('.').any { it.isEmpty() }) return Verdict.Blocked("That is not a valid address.")
    if (!host.contains('.')) return Verdict.Blocked("Use a full website address, not a local name.")
    // A browser reads a host whose last label is a number (or 0x...) as an IPv4 address in decimal, octal or hex form.
    val last = host.substringAfterLast('.')
    if (last.all { it.isDigit() } || (last.startsWith("0x") && last.drop(2).all { it.isDigit() || it in 'a'..'f' })) {
      return Verdict.Blocked("IP addresses are not allowed.")
    }
    if (host == "localhost" || LOCAL_SUFFIXES.any { host.endsWith(it) }) return Verdict.Blocked("Local and internal addresses are not allowed.")
    return Verdict.Ok(text, host)
  }

  /** True for loopback, private, link-local, carrier-grade NAT, multicast and reserved addresses (IPv4 or IPv6, as raw bytes). */
  fun isPrivateAddress(b: ByteArray): Boolean {
    if (b.size == 4) {
      val a = b[0].toInt() and 0xFF
      val c = b[1].toInt() and 0xFF
      val d = b[2].toInt() and 0xFF
      return when {
        a == 0 || a == 10 || a == 127 -> true
        a == 100 && c in 64..127 -> true
        a == 169 && c == 254 -> true
        a == 172 && c in 16..31 -> true
        a == 192 && c == 168 -> true
        a == 192 && c == 0 && d == 0 -> true
        a == 198 && (c == 18 || c == 19) -> true
        a >= 224 -> true
        else -> false
      }
    }
    if (b.size == 16) {
      val allZeroTo = { n: Int -> (0 until n).all { b[it].toInt() == 0 } }
      if (allZeroTo(15) && (b[15].toInt() == 0 || b[15].toInt() == 1)) return true // :: and ::1
      val first = b[0].toInt() and 0xFF
      val second = b[1].toInt() and 0xFF
      if (first == 0xFE && (second and 0xC0) == 0x80) return true // fe80::/10 link-local
      if ((first and 0xFE) == 0xFC) return true // fc00::/7 unique local
      if (first == 0xFF) return true // multicast
      // ::ffff:a.b.c.d (mapped) and 64:ff9b::a.b.c.d (NAT64) carry an IPv4 address in the last four bytes.
      val mapped = (0 until 10).all { b[it].toInt() == 0 } && (b[10].toInt() and 0xFF) == 0xFF && (b[11].toInt() and 0xFF) == 0xFF
      val nat64 = first == 0x00 && second == 0x64 && (b[2].toInt() and 0xFF) == 0xFF && (b[3].toInt() and 0xFF) == 0x9B && (4 until 12).all { b[it].toInt() == 0 }
      if (mapped || nat64) return isPrivateAddress(b.copyOfRange(12, 16))
      return false
    }
    return true // unknown shape: refuse
  }
}
