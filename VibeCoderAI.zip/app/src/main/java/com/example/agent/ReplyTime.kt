package com.example.agent

import java.util.Locale

/**
 * v1.9.37: "how long did this answer take", shown next to every reply and live while one is being written.
 * Pure text and arithmetic so the wording is tested; the clock itself is read by the caller.
 */
object ReplyTime {
  /** A reply that appears to have taken longer than this is a clock change, not a real duration. */
  const val MAX_MS = 24L * 60 * 60 * 1000

  /** Milliseconds from [startMs] to [endMs]; null when the phone clock moved backwards or the span is not believable. */
  fun since(startMs: Long, endMs: Long): Long? {
    val d = endMs - startMs
    return if (d in 0..MAX_MS) d else null
  }

  /**
   * 4.2 s, 34 s, 2 min 05 s, 1 h 02 min. Under ten seconds one decimal (so a quick reply is not "0 s"), above that whole seconds.
   * Null for a negative value, so the caller shows nothing instead of a wrong number.
   */
  fun format(ms: Long): String? {
    if (ms < 0) return null
    if (ms < 9_950) return String.format(Locale.US, "%.1f s", ms / 1000.0)
    val totalSec = (ms + 500) / 1000
    if (totalSec < 60) return "$totalSec s"
    val min = totalSec / 60
    if (min < 60) return "$min min ${two(totalSec % 60)} s"
    return "${min / 60} h ${two(min % 60)} min"
  }

  private fun two(n: Long): String = if (n < 10) "0$n" else n.toString()
}
