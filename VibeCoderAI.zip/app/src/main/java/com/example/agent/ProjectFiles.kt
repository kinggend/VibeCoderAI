package com.example.agent

import com.example.data.model.FileChange
import java.io.File

/** Sandboxed file helpers: nothing ever leaves the project folder. */
object ProjectFiles {
  private const val MAX_FILE_BYTES = 512 * 1024
  private const val UNRELATED_CAP = 3000L
  private val TEXT_EXT = setOf("html", "htm", "css", "js", "json", "md", "txt", "svg", "kt", "py", "xml")
  private val SKIP_DIRS = setOf("node_modules", "build", ".git")

  /** Resolves a model-supplied relative path inside [root], or null if it is unsafe. */
  fun resolve(root: File, relative: String): File? {
    val rel = relative.replace('\\', '/').trim().removePrefix("./")
    if (rel.isEmpty() || rel.length > 120 || rel.startsWith("/")) return null
    if (rel.split('/').any { it.isEmpty() || it == ".." || it.startsWith(".") }) return null
    val file = File(root, rel)
    return try {
      if (file.canonicalPath.startsWith(root.canonicalPath + File.separator)) file else null
    } catch (_: Exception) {
      null
    }
  }

  /** Agent-only writer. v1.5: every attempt lands in the project's History log. */
  fun write(root: File, change: FileChange): Result<Unit> = runCatching {
    val target = resolve(root, change.path) ?: throw IllegalArgumentException("Unsafe path: ${change.path}")
    if (change.content.toByteArray().size > MAX_FILE_BYTES) throw IllegalArgumentException("File too large")
    val existed = target.isFile
    target.parentFile?.mkdirs()
    target.writeText(change.content)
    existed
  }.fold(
    onSuccess = { existed ->
      ProjectHistory.record(root, if (existed) HistoryEntry.MODIFIED else HistoryEntry.CREATED, change.path, true)
      Result.success(Unit)
    },
    onFailure = { e ->
      ProjectHistory.record(root, if (change.isNew) HistoryEntry.CREATED else HistoryEntry.MODIFIED, change.path, false, e.message.orEmpty())
      Result.failure(e)
    }
  )

  /**
   * Compact project view for the prompt: file list, then full contents of small text files while the
   * character [budget] lasts. Keeps token use low and lets the model edit what already exists.
   */
  fun snapshot(root: File, budget: Int, task: String = ""): String {
    if (!root.isDirectory) return ""
    val files = root.walkTopDown()
      .onEnter { it.name !in SKIP_DIRS && !it.name.startsWith(".") || it == root }
      .filter { it.isFile && !it.name.startsWith(".") }
      .take(40)
      .toList()
      // v1.4: most relevant files first (named in the task, matching its subject), so the budget goes to them.
      .let { list ->
        val byRel = list.associateBy { it.relativeTo(root).invariantSeparatorsPath }
        com.example.context.RelevantFiles.rank(byRel.keys.toList(), task).mapNotNull { byRel[it] }
      }
    if (files.isEmpty()) return ""

    // Which files get their full text is still decided in relevance order (the budget goes to them first) ...
    class Entry(val rel: String, val modified: Long, val text: String)
    val entries = ArrayList<Entry>(files.size)
    var left = budget
    for (f in files) {
      val rel = f.relativeTo(root).invariantSeparatorsPath
      // v1.4: large files nothing in the task points at are listed by name only (ReadFile can fetch them).
      val unrelatedBig = task.isNotBlank() && f.length() > UNRELATED_CAP && com.example.context.RelevantFiles.score(rel, task) == 0
      if (f.extension.lowercase() !in TEXT_EXT || f.length() > left || unrelatedBig) {
        entries.add(Entry(rel, f.lastModified(), "- $rel (${f.length()} B, not shown)\n"))
        continue
      }
      val body = f.readText()
      left -= body.length
      entries.add(Entry(rel, f.lastModified(), "<file path=\"$rel\">\n${body.trimEnd()}\n</file>\n"))
    }
    // ... but they are written out in a stable order that does not depend on the task text: files untouched the longest first,
    // the ones just edited last. The local engine reuses the KV cache of the longest common prefix, so on the next request
    // (a repair after one file changed) everything before that file is not read again, and the files nearest the task are the fresh ones.
    val sb = StringBuilder()
    for (e in entries.sortedWith(compareBy<Entry>({ it.modified }, { it.rel }))) sb.append(e.text)
    return sb.toString()
  }
}
