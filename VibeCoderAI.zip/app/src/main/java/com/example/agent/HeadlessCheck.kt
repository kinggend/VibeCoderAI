package com.example.agent

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/** Opens index.html in an invisible WebView and reports JavaScript errors and missing files, so the agent can verify its own work. */
object HeadlessCheck {
  /** v1.5: each check is logged in the project's History as a pass/fail command. */
  suspend fun run(context: Context, root: File): List<String> = check(context, root).also { errs ->
    ProjectHistory.record(root, HistoryEntry.COMMAND, "Headless app check", errs.isEmpty(), if (errs.isEmpty()) "" else "${errs.size} problem(s): ${errs.first()}")
  }

  @SuppressLint("SetJavaScriptEnabled")
  private suspend fun check(context: Context, root: File): List<String> {
    val index = File(root, "index.html")
    PreviewFixer.prepare(root)
    if (!index.isFile) return listOf("index.html is missing. Create index.html, styles.css and app.js.")
    return withContext(Dispatchers.Main) {
      val errors = mutableListOf<String>()
      val loaded = CompletableDeferred<Unit>()
      val wv = WebView(context.applicationContext)
      try {
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        // v1.9.13: a WebView that was never laid out reports a 0x0 window, so canvas and Three.js games (sized from
        // window.innerWidth / innerHeight) looked blank and "zero size" and the repair loop then damaged working code.
        // Give it phone dimensions (360 x 780 css px at 3x).
        runCatching {
          wv.measure(android.view.View.MeasureSpec.makeMeasureSpec(1080, android.view.View.MeasureSpec.EXACTLY), android.view.View.MeasureSpec.makeMeasureSpec(2340, android.view.View.MeasureSpec.EXACTLY))
          wv.layout(0, 0, 1080, 2340)
        }
        com.example.project.ProjectWebGuard.harden(wv.settings, fileAccess = false) // v1.6: project files only; v1.9.14: served from the project's own origin
        wv.webChromeClient = object : WebChromeClient() {
          override fun onConsoleMessage(m: ConsoleMessage): Boolean {
            if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) errors.add("${m.message()} (line ${m.lineNumber()})")
            return true
          }
        }
        wv.webViewClient = object : com.example.project.ProjectWebGuard.Client(
          root,
          { url -> errors.add("Blocked a file outside the project: $url") },
          { crashed ->
            // v1.9.8: a dead renderer used to take the whole app with it. Report it as a page problem instead.
            errors.add(if (crashed) "The page crashed the preview renderer. Check for infinite loops or huge canvases." else "The preview renderer was stopped by Android (low memory).")
            if (!loaded.isCompleted) loaded.complete(Unit)
          }
        ) {
          override fun onPageFinished(view: WebView?, url: String?) {
            if (!loaded.isCompleted) loaded.complete(Unit)
          }

          override fun onReceivedHttpError(view: WebView?, request: WebResourceRequest?, errorResponse: android.webkit.WebResourceResponse?) {
            // A file the page asks for that is not in the project (the project origin answers 404 for it).
            if (errorResponse?.statusCode == 404 && request?.url?.lastPathSegment != "favicon.ico") {
              errors.add("Missing or unreadable file: ${request?.url?.lastPathSegment ?: "?"}")
            }
          }

          override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            errors.add("Missing or unreadable file: ${request?.url?.lastPathSegment ?: "?"}")
          }
        }
        wv.loadUrl(com.example.project.ProjectOrigin.url(root))
        withTimeoutOrNull(8000) { loaded.await() }
        delay(1500) // let timers and startup scripts run
        val probe = CompletableDeferred<String?>()
        wv.evaluateJavascript(PageProbe.JS) { probe.complete(it) }
        val raw = withTimeoutOrNull(3000) { probe.await() }
        errors.addAll(PageProbe.parse(raw))
      } finally {
        wv.destroy()
      }
      // WebGL cannot be verified without a window, so a missing context here is not a bug in the app.
      errors.filterNot { it.contains("WebGL", ignoreCase = true) }.distinct()
    }
  }
}
