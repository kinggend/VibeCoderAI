package com.example.agent

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * An agent skill is a short instruction pack added to the system prompt while it is switched on.
 * Built-in skills ship with the app; custom skills are written by the user and stored on the phone.
 * Only enabled skills cost tokens, and the total is capped so small models are not overloaded.
 */
data class Skill(
  val id: String,
  val name: String,
  val description: String,
  val prompt: String,
  val builtIn: Boolean,
  val defaultOn: Boolean = false,
  /** Also applied in plain chat (answers), not only when building. */
  val forChat: Boolean = false
)

object Skills {
  private var prefs: SharedPreferences? = null

  /** Bumped on every change so Compose screens re-read the list. */
  var version by mutableIntStateOf(0)
    private set

  private const val MAX_PROMPT_CHARS = 1500

  val builtIn: List<Skill> = listOf(
    Skill(
      "web-app", "Web app builder",
      "index.html + styles.css + app.js, correctly linked.",
      "Always create index.html, styles.css and app.js. index.html must contain <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">, " +
        "<link rel=\"stylesheet\" href=\"styles.css\"> and <script src=\"app.js\"></script> before </body>. " +
        "Every id or class used by app.js must exist in index.html. Code must run without errors. " +
        "app.js is plain browser JavaScript: no import, export or require, no Vue, React or createApp, declare every variable once, " +
        "and call your start function at the end.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "ui-polish", "Clean mobile UI",
      "Rounded cards, big tap targets, fits a 360 px screen.",
      "Design for a 360px wide phone: system-ui font, 16px padding, 14px rounded cards, buttons at least 44px tall, " +
        "flex or grid layout, no horizontal scroll, sizes in %, rem or vw (never fixed widths above 340px).",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "bug-fixer", "Bug fixer",
      "Fix errors by changing only what is broken.",
      "When fixing errors: read the error lines, change only what is broken, keep working code, and output the complete updated files.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "ponytail", "Minimal code (Ponytail)",
      "Smallest working solution: less code, fewer bugs.",
      "Write the smallest correct code. Before adding anything ask: does it need to exist, does the browser already do it " +
        "(button, input, details, dialog, form validation, CSS), can it be one line? No unused functions, no extra features or options. " +
        "Keep input validation, error handling and accessibility.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "js-safe", "Error-free JavaScript",
      "Checks that stop blank-page errors.",
      "Before you finish app.js check: every id used by getElementById exists in index.html, every function you call is defined, " +
        "each variable is declared once, JSON.parse and localStorage sit inside try/catch, and the script runs after the page loads.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "ui-ux-pro", "UI/UX Pro",
      "Palette, spacing, contrast, states (condensed UI/UX Pro Max).",
      "One accent colour on neutral surfaces, text contrast at least 4.5:1, spacing 8/16/24/32px, one font family with sizes 14/16/24, " +
        "the same corner radius everywhere, inline SVG icons (no emoji icons), visible :focus outline, a label on every input, " +
        "hover and active states with 150-250ms transitions, cursor:pointer on clickable items, and empty, loading and error states.",
      builtIn = true
    ),
    Skill(
      "forms-lists", "Forms and lists",
      "Native validation, one render function, empty state.",
      "Use <form> with <label>, required and native validation. Keep data in one array, draw it with one render() function and call render() " +
        "after every change. Ask before deleting and show a friendly empty state.",
      builtIn = true
    ),
    Skill(
      "code-review", "Code review (chat)",
      "Short, concrete review of pasted code.",
      "When asked to review code list at most 5 real problems, each with the line and the fix. No praise. Do not rewrite everything unless asked.",
      builtIn = true, forChat = true
    ),
    Skill(
      "oled-dark", "OLED dark theme",
      "Black background, white text, iOS blue accent.",
      "Use a dark OLED theme: body background #000000, text #ffffff, cards #1c1c1e, accent #0a84ff, subtle 1px borders #2a2a2c.",
      builtIn = true
    ),
    Skill(
      "games", "Games and 3D",
      "Canvas or CSS 3D games with touch controls.",
      "For games use a canvas or CSS grid sized with min(100vw, 100vh), a requestAnimationFrame loop, touch and keyboard controls, " +
        "a score display and a restart button. For 3D games use the global THREE (Three.js r128 is added automatically, never import it or load a CDN): one scene, PerspectiveCamera, WebGLRenderer appended to document.body, boxes and planes for shapes, and a render loop.",
      builtIn = true
    ),
    Skill(
      "indian-ui", "Telugu / Indian language UI",
      "Correct lang attribute and fonts for Telugu, Hindi.",
      "Write UI text in the language the user asks for. For Telugu use <html lang=\"te\"> and font-family 'Noto Sans Telugu', system-ui, sans-serif; " +
        "for Hindi use lang=\"hi\". Keep text short and large (at least 16px).",
      builtIn = true
    ),
    Skill(
      "storage", "Offline data storage",
      "Save data in localStorage, no network.",
      "Persist user data with localStorage (JSON.stringify / JSON.parse inside try/catch). Never call network APIs or CDNs.",
      builtIn = true
    ),
    Skill(
      "concise-chat", "Short answers",
      "Brief, direct chat replies.",
      "In chat answer briefly and directly, in the same language the user writes in.",
      builtIn = true, defaultOn = true, forChat = true
    )
  )

  fun init(context: Context) {
    if (prefs == null) prefs = context.applicationContext.getSharedPreferences("agent_skills", Context.MODE_PRIVATE)
  }

  private fun customArray(): JSONArray =
    runCatching { JSONArray(prefs?.getString("custom", "[]") ?: "[]") }.getOrDefault(JSONArray())

  fun custom(): List<Skill> = runCatching {
    val arr = customArray()
    (0 until arr.length()).map { i ->
      val o = arr.getJSONObject(i)
      Skill(
        id = o.getString("id"),
        name = o.getString("name"),
        // v1.5: custom skills keep their own description (older ones fall back to "Custom skill").
        description = o.optString("description").ifBlank { "Custom skill" },
        prompt = o.getString("prompt"),
        builtIn = false,
        defaultOn = true,
        forChat = false
      )
    }
  }.getOrDefault(emptyList())

  fun all(): List<Skill> = builtIn + custom()

  fun isEnabled(skill: Skill): Boolean = prefs?.getBoolean("on_${skill.id}", skill.defaultOn) ?: skill.defaultOn

  fun setEnabled(skill: Skill, on: Boolean) {
    prefs?.edit()?.putBoolean("on_${skill.id}", on)?.apply()
    version++
  }

  /** v1.5: why [name] cannot be used (empty, too long, or taken by a built-in or another custom skill), or null. */
  fun nameError(name: String, ignoreId: String? = null): String? =
    SkillCodec.validate(name, "", "x")
      ?: if (SkillCodec.collides(name, all().map { it.id to it.name }, ignoreId)) "A skill named \"${name.trim()}\" already exists." else null

  /**
   * v1.5: creates (or, with [editId], updates) a custom skill. Returns an error message, or null on success.
   * [enabled] = false is used for imports: an imported skill never switches itself on.
   */
  fun saveCustom(name: String, description: String, prompt: String, editId: String? = null, enabled: Boolean = true): String? {
    nameError(name, editId)?.let { return it }
    SkillCodec.validate(name, description, prompt)?.let { return it }
    val arr = customArray()
    val id = editId ?: ("c_" + UUID.randomUUID().toString().take(8))
    val o = JSONObject().put("id", id).put("name", name.trim()).put("description", description.trim()).put("prompt", prompt.trim())
    val out = JSONArray()
    var replaced = false
    for (i in 0 until arr.length()) {
      val cur = arr.getJSONObject(i)
      if (cur.getString("id") == id) { out.put(o); replaced = true } else out.put(cur)
    }
    if (!replaced) out.put(o)
    val e = prefs?.edit()?.putString("custom", out.toString())
    if (editId == null) e?.putBoolean("on_$id", enabled)
    e?.apply()
    version++
    return null
  }

  fun deleteCustom(id: String) {
    val arr = customArray()
    val kept = JSONArray()
    for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("id") != id) kept.put(arr.getJSONObject(i))
    prefs?.edit()?.putString("custom", kept.toString())?.remove("on_$id")?.apply()
    version++
  }

  /**
   * v1.6: names of the skills [promptFor] actually puts in the prompt, for "What the AI sees".
   * A skill cut by the size cap is marked, and one that does not fit at all is left out (it was not sent).
   */
  fun activeNames(chat: Boolean): List<String> {
    val active = all().filter { isEnabled(it) && (!chat || it.forChat) }
    var pos = "\nSkills:\n".length
    val out = mutableListOf<String>()
    for ((i, sk) in active.withIndex()) {
      if (pos >= MAX_PROMPT_CHARS) break
      val len = (if (i > 0) 1 else 0) + 2 + sk.prompt.length
      out += if (pos + len > MAX_PROMPT_CHARS) "${sk.name} (cut short by the ${MAX_PROMPT_CHARS}-character skill limit)" else sk.name
      pos += len
    }
    return out
  }

  /** Text appended to the system prompt: the enabled skills (chat mode only uses chat skills). */
  fun promptFor(chat: Boolean): String {
    val active = all().filter { isEnabled(it) && (!chat || it.forChat) }
    if (active.isEmpty()) return ""
    return ("\nSkills:\n" + active.joinToString("\n") { "- " + it.prompt }).take(MAX_PROMPT_CHARS)
  }
}
