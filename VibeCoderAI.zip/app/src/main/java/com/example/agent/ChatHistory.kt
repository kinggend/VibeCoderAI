package com.example.agent

import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender

/**
 * v1.9.32: markers the APP writes at the end of a reply ("[Stopped]", "[Error: ...]", "[The model returned no text.]"). The chat
 * screen shows them as a small caption; they are never model text. Sending them back as the assistant's earlier words taught small
 * models to copy them: after one Stop, "hi" was answered with "[Stopped]", which was then saved and sent again, and so on.
 */
object ReplyMarkers {
  private val PREFIXES = listOf("[Stopped", "[Error", "[The model", "[No progress", "[Generation error", "[Engine error")

  /** [text] without trailing app markers (a marker starts a line and the text ends with its closing bracket). */
  fun stripTrailing(text: String): String {
    var t = text.trimEnd()
    repeat(4) {
      if (!t.endsWith("]")) return t
      var cut = -1
      for (p in PREFIXES) {
        var i = t.lastIndexOf(p)
        while (i >= 0) {
          if (i == 0 || t[i - 1] == '\n') { if (i > cut) cut = i; break }
          i = if (i == 0) -1 else t.lastIndexOf(p, i - 1)
        }
      }
      if (cut < 0) return t
      t = t.substring(0, cut).trimEnd()
    }
    return t
  }
}

/** v1.9.32: the earlier turns a chat-mode request carries to the model. Pure, unit tested. */
object ChatHistory {
  const val MAX_MESSAGES = 4
  const val MAX_CHARS = 500

  /**
   * Earlier turns of this chat as (role, text), newest last, at most [MAX_MESSAGES]. Only words of the user and of the model are sent:
   *  - app notes, engine notices, and messages still streaming are left out;
   *  - app markers at the end of a reply are removed (a reply cut by Stop keeps the text it had);
   *  - a reply with nothing left (stopped at once, an error, no text) is dropped together with the question it did not answer, so
   *    roles still alternate and the model never sees an empty or marker-only answer to imitate.
   * The window is taken after this cleaning, so markers cannot fill it.
   */
  fun build(
    messages: List<ChatMessage>,
    isEngineNotice: (String) -> Boolean,
    display: (String) -> String,
    turnMarkers: List<String>
  ): List<Pair<String, String>> {
    val out = ArrayList<Pair<String, String>>()
    for (m in messages) {
      if (m.isStreaming || m.content.isBlank() || isEngineNotice(m.content)) continue
      if (m.sender != MessageSender.USER && m.sender != MessageSender.AGENT) continue
      if (m.sender == MessageSender.AGENT && m.thoughts == "note") continue
      val role = if (m.sender == MessageSender.USER) "user" else "assistant"
      var text = turnMarkers.fold(display(m.content)) { acc, mk -> acc.replace(mk, "") }
      if (role == "assistant") text = ReplyMarkers.stripTrailing(text)
      text = text.trim().take(MAX_CHARS)
      if (text.isBlank()) {
        // Nothing real was said. For a reply, also forget the question it never answered.
        if (role == "assistant" && out.isNotEmpty() && out.last().first == "user") out.removeAt(out.size - 1)
        continue
      }
      out.add(role to text)
    }
    return out.takeLast(MAX_MESSAGES)
  }
}
