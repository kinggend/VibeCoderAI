package com.example.agent

/**
 * v1.9.18: decides where a spoken task goes. Pure Kotlin, unit-tested.
 *
 * Typed messages already follow [TaskRouter] when the Agent chip is "Auto". Voice added one gap: with the Phone agent
 * switched off, "open YouTube" fell through to the coding pipeline and created a blank web project. Here a clear phone
 * command is routed to the Phone agent (only when its Accessibility service is on, checked by the caller), and everything
 * else keeps the same role pick as typing. The command form is deliberately stricter than [TaskRouter]'s phone regex,
 * because this path switches on phone control by itself; "how does the camera API work" must stay a question.
 */
object VoiceRoute {
  enum class Target { PHONE, PHONE_SWITCH, CODING, CHAT }

  /** [label] is shown under the orb so the user sees what the voice request was routed to. */
  data class Decision(val target: Target, val label: String)

  private val command = Regex(
    "^(please\\s+|can you\\s+|could you\\s+)?(open|launch|start|call|message|text|send|play|go to|go back|scroll|swipe|" +
      "turn (on|off)|switch (on|off)|take a (photo|picture|screenshot|selfie)|set (an )?alarm|set (the )?(volume|brightness))\\b"
  )

  fun looksLikePhoneCommand(text: String): Boolean {
    val t = text.trim().lowercase().trimEnd('.', '!', '?')
    return command.containsMatchIn(t) && TaskRouter.pick(t, false) == TaskRouter.Pick.PHONE
  }

  fun decide(text: String, roleId: String, phoneOn: Boolean, chatOnly: Boolean, hasApp: Boolean): Decision {
    val auto = roleId == AgentRoles.AUTO.id
    val pick = TaskRouter.pick(text, hasApp)
    if (phoneOn) {
      if (!auto || pick == TaskRouter.Pick.PHONE) return Decision(Target.PHONE, "Phone agent")
    } else if (auto && !chatOnly && looksLikePhoneCommand(text)) {
      return Decision(Target.PHONE_SWITCH, "Phone agent")
    }
    if (chatOnly) return Decision(Target.CHAT, "Chat")
    val role = if (auto) TaskRouter.role(pick) else AgentRoles.from(roleId)
    return Decision(Target.CODING, role.name)
  }
}
