package com.example.agent

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.example.AppGraph
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * v1.9.19: the opt-in project check. Every 12 hours (only when the battery is not low) it runs [ProjectWatch.staticProblems]
 * on the most recently changed projects. No model, no WebView, no network, no file is changed. It tells the user once per
 * set of problems, and stays silent while the app is on screen.
 */
class ProjectWatchWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
  override suspend fun doWork(): Result {
    val app = applicationContext
    val prefs = app.getSharedPreferences("vibecoder_settings", Context.MODE_PRIVATE)
    if (!prefs.getBoolean("projectWatch", false)) return Result.success()
    if (AppGraph.get(app).visibleFlow.value) return Result.success()
    val findings = withContext(Dispatchers.IO) {
      File(app.filesDir, "vibecoder_projects").listFiles { f -> f.isDirectory && !f.name.startsWith(".") }.orEmpty()
        .sortedByDescending { it.lastModified() }
        .take(MAX_PROJECTS)
        .mapNotNull { dir -> ProjectWatch.staticProblems(dir).takeIf { it.isNotEmpty() }?.let { ProjectWatch.Finding(dir.name, it) } }
    }
    val signature = ProjectWatch.signature(findings)
    if (signature == (prefs.getString(KEY_SIGNATURE, "") ?: "")) return Result.success()
    prefs.edit().putString(KEY_SIGNATURE, signature).apply()
    ProjectWatch.summary(findings)?.let { (title, text) -> AgentRunService.postWatch(app, title, text) }
    return Result.success()
  }

  companion object {
    private const val NAME = "project_watch"
    private const val KEY_SIGNATURE = "projectWatchSignature"
    private const val MAX_PROJECTS = 12

    /** Makes the schedule match the setting. Safe to call on every app start and every toggle. */
    fun apply(ctx: Context, enabled: Boolean) {
      val wm = runCatching { WorkManager.getInstance(ctx.applicationContext) }.getOrNull() ?: return
      if (enabled) {
        val request = PeriodicWorkRequestBuilder<ProjectWatchWorker>(12, TimeUnit.HOURS)
          .setConstraints(Constraints.Builder().setRequiresBatteryNotLow(true).build())
          .build()
        wm.enqueueUniquePeriodicWork(NAME, ExistingPeriodicWorkPolicy.KEEP, request)
      } else {
        wm.cancelUniqueWork(NAME)
        ctx.applicationContext.getSharedPreferences("vibecoder_settings", Context.MODE_PRIVATE).edit().remove(KEY_SIGNATURE).apply()
      }
    }
  }
}
