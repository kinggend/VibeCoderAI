package com.example.agent

import java.io.File

/**
 * Small models often forget to link their own files or to add a viewport. This makes index.html
 * runnable before it is previewed or packaged: doctype, charset, viewport, and any root-level
 * .css / .js file that exists but is not referenced.
 */
object PreviewFixer {
  private val TOP_DECL = Regex("""(?m)^(const|let)(\s+)([A-Za-z_$][\w$]*)""")

  /**
   * v1.9.2: small models redeclare the same top-level `const x` / `let x` (in one file or across the scripts of one page),
   * which is a SyntaxError that stops the whole script and leaves a blank preview. Every top-level declaration of a name
   * declared more than once becomes `var`, which may legally repeat; the later assignment wins. Pure: file name to text.
   */
  fun dedupeDeclarations(files: Map<String, String>): Map<String, String> {
    val counts = HashMap<String, Int>()
    files.values.forEach { t -> TOP_DECL.findAll(t).forEach { m -> counts.merge(m.groupValues[3], 1, Int::plus) } }
    val dup = counts.filterValues { it > 1 }.keys
    if (dup.isEmpty()) return files
    return files.mapValues { (_, t) ->
      TOP_DECL.replace(t) { m -> if (m.groupValues[3] in dup) "var" + m.groupValues[2] + m.groupValues[3] else m.value }
    }
  }

  private val IMPORT_FROM = Regex("""(?m)^[ \t]*import\s[^;\n]*?\sfrom\s*["'][^"'\n]+["'];?[ \t]*\r?$\n?""")
  private val IMPORT_BARE = Regex("""(?m)^[ \t]*import\s*["'][^"'\n]+["'];?[ \t]*\r?$\n?""")
  private val EXPORT_LIST = Regex("""(?m)^[ \t]*export\s*\{[^}\n]*}\s*(?:from\s*["'][^"'\n]+["'])?;?[ \t]*\r?$\n?""")
  private val EXPORT_DEFAULT = Regex("""(?m)^([ \t]*)export\s+default\s+""")
  private val EXPORT_DECL = Regex("""(?m)^([ \t]*)export\s+(?=(?:async\s+)?(?:const|let|var|function|class)\b)""")

  /**
   * v1.9.4: page scripts are classic scripts, so `import ... from` and `export` are SyntaxErrors that blank the page
   * (small models write them from habit). The statements are removed and `export` prefixes dropped. Pure.
   */
  fun stripModuleSyntax(js: String): String {
    if (!js.contains("import") && !js.contains("export")) return js
    return js
      .replace(IMPORT_FROM, "")
      .replace(IMPORT_BARE, "")
      .replace(EXPORT_LIST, "")
      .replace(EXPORT_DEFAULT) { it.groupValues[1] }
      .replace(EXPORT_DECL) { it.groupValues[1] }
  }

  private fun fixScripts(root: File) {
    val js = root.listFiles { f -> f.isFile && f.extension.lowercase() == "js" }?.sortedBy { it.name } ?: return
    if (js.isEmpty()) return
    val html = runCatching { File(root, "index.html").readText() }.getOrDefault("")
    // A page that really loads its script as a module keeps its import/export.
    val modules = Regex("""<script[^>]*type\s*=\s*["']module["'][^>]*>""", RegexOption.IGNORE_CASE).containsMatchIn(html)
    val raw = js.associate { it.name to it.readText() }
    val before = if (modules) raw else raw.mapValues { stripModuleSyntax(it.value) }
    val after = dedupeDeclarations(before)
    js.forEach { f -> if (after[f.name] != raw[f.name]) f.writeText(after.getValue(f.name)) }
  }

  fun prepare(root: File) {
    runCatching { fixScripts(root) }
    val index = File(root, "index.html")
    if (!index.isFile) {
      // The model wrote scripts or styles but forgot the page: create a minimal one so the app can run.
      val hasAssets = root.listFiles { f -> f.isFile && f.extension.lowercase() in setOf("js", "css") }?.isNotEmpty() == true
      if (!hasAssets) return
      runCatching {
        index.writeText("<!DOCTYPE html>\n<html lang=\"en\">\n<head></head>\n<body>\n<div id=\"app\"></div>\n</body>\n</html>\n")
      }
    }
    runCatching {
      val original = index.readText()
      var html = original

      if (!Regex("<html[\\s>]", RegexOption.IGNORE_CASE).containsMatchIn(html)) {
        html = "<html>\n<head></head>\n<body>\n$html\n</body>\n</html>"
      }
      if (!Regex("<!doctype", RegexOption.IGNORE_CASE).containsMatchIn(html)) html = "<!DOCTYPE html>\n$html"
      if (!html.contains("charset", ignoreCase = true)) html = inHead(html, "<meta charset=\"utf-8\">")
      if (!html.contains("name=\"viewport\"", ignoreCase = true) && !html.contains("name='viewport'", ignoreCase = true)) {
        html = inHead(html, "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">")
      }

      val files = root.listFiles { f -> f.isFile }?.sortedBy { it.name } ?: emptyList()
      for (f in files) {
        if (html.contains(f.name)) continue
        when (f.extension.lowercase()) {
          "css" -> html = inHead(html, "<link rel=\"stylesheet\" href=\"${f.name}\">")
          "js" -> html = beforeBodyEnd(html, "<script src=\"${f.name}\"></script>")
        }
      }

      if (html != original) index.writeText(html)
    }
  }

  private fun inHead(html: String, tag: String): String {
    val head = Regex("<head[^>]*>", RegexOption.IGNORE_CASE).find(html)
    if (head != null) return html.substring(0, head.range.last + 1) + "\n  " + tag + html.substring(head.range.last + 1)
    val root = Regex("<html[^>]*>", RegexOption.IGNORE_CASE).find(html)
    return if (root != null) {
      html.substring(0, root.range.last + 1) + "\n<head>\n  $tag\n</head>" + html.substring(root.range.last + 1)
    } else "$tag\n$html"
  }

  private fun beforeBodyEnd(html: String, tag: String): String {
    val i = html.lastIndexOf("</body>", ignoreCase = true)
    return if (i >= 0) html.substring(0, i) + "  " + tag + "\n" + html.substring(i) else "$html\n$tag\n"
  }
}
