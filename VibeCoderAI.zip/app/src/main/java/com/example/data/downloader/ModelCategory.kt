package com.example.data.downloader

/**
 * Browse categories for the "Get more models" list. [query] is the Hugging Face search a category chip runs;
 * [blurb] is the one-line "best for" text. Pure Kotlin (no Android/Compose) so it is unit-testable.
 */
enum class ModelCategory(val label: String, val query: String, val blurb: String) {
  CODING("Coding", "coder instruct", "Best for writing and fixing code"),
  REASONING("Reasoning", "deepseek r1 distill", "Best for step-by-step logic, math and planning"),
  VISION("Vision", "vl instruct", "Reads images. This app runs them text-only for now (no image input yet)"),
  LONG("Long session", "128k instruct", "Best for long chats and large files (big context window)"),
  LIGHT("Fast & light", "1.5b instruct", "Best for speed and low RAM on most phones"),
  GENERAL("General", "instruct", "Best for everyday chat and writing");
}

object ModelCategories {
  private fun has(id: String, vararg words: String) = words.any { id.contains(it) }
  private fun token(id: String, vararg words: String) =
    words.any { Regex("""(^|[^a-z0-9])${Regex.escape(it)}($|[^a-z0-9])""").containsMatchIn(id) }

  /** Parameter count in billions parsed from a name like "qwen2.5-coder-3b-instruct", or null. */
  fun paramsBillions(name: String): Double? =
    Regex("""(?<![a-z0-9])(\d+(?:\.\d+)?)b(?![a-z])""", RegexOption.IGNORE_CASE).find(name)?.groupValues?.get(1)?.toDoubleOrNull()

  /** Best-for categories inferred from a repo id / file name. Never empty: falls back to GENERAL. */
  fun tagsFor(name: String): List<ModelCategory> {
    val id = name.lowercase()
    val out = linkedSetOf<ModelCategory>()
    if (has(id, "coder", "codestral", "starcoder", "codellama", "devstral", "granite-code", "-code-", "opencoder")) out += ModelCategory.CODING
    if (token(id, "r1") || has(id, "reasoning", "qwq", "thinking", "magistral", "-think", "deepseek-r1")) out += ModelCategory.REASONING
    if (token(id, "vl") || has(id, "vision", "llava", "minicpm-v", "pixtral", "moondream", "smolvlm", "paligemma", "internvl", "-omni")) out += ModelCategory.VISION
    if (has(id, "128k", "256k", "512k", "1m-", "-1m", "longcontext", "long-context", "-long", "64k", "32k")) out += ModelCategory.LONG
    val p = paramsBillions(id)
    if (p != null && p <= 3.5) out += ModelCategory.LIGHT
    if (out.isEmpty()) out += ModelCategory.GENERAL
    return out.toList()
  }
}
