package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/** v1.4: chat history and token usage. Version 1 (first Room schema of the app). */
@Database(
  entities = [ChatSessionEntity::class, ChatMessageEntity::class, TokenUsageEntity::class],
  version = 3,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun chatDao(): ChatDao
  abstract fun tokenUsageDao(): TokenUsageDao

  companion object {
    @Volatile private var instance: AppDatabase? = null

    /** v1.6: message destination badge and attachments. Nullable columns, so old rows stay valid. */
    val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
      override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE chat_messages ADD COLUMN destination TEXT")
        db.execSQL("ALTER TABLE chat_messages ADD COLUMN attachments TEXT")
      }
    }

    /** v1.9.37: how long a reply took. One nullable column, so old rows stay valid (same form as the migration above). */
    val MIGRATION_2_3 = object : androidx.room.migration.Migration(2, 3) {
      override fun migrate(db: androidx.sqlite.db.SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE chat_messages ADD COLUMN elapsed_ms INTEGER")
      }
    }

    fun get(context: Context): AppDatabase =
      instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "vibecoder.db")
          .addMigrations(MIGRATION_1_2, MIGRATION_2_3)
          .build()
          .also { instance = it }
      }
  }
}
