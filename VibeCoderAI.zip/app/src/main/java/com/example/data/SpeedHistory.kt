package com.example.data

import com.example.agent.MiniJson
import java.io.File
import java.util.Locale
import java.util.concurrent.Executors

/**
 * v1.9.30: one measured generation or Speed test. Numbers and labels only: no prompt, no file path, no key.
 * Null means "not measured" (never 0 for unknown).
 */
data class SpeedRecord(
  val ts: Long,
  /** "chat" (a real request) or "speedtest" (the fixed benchmark). Never mixed in one summary. */
  val source: String,
  /** "local" or "remote". Kept apart: a network is part of a remote number. */
  val backend: String,
  /** Display name only: the model file name or the remote model id. */
  val model: String,
  /** Prompt tokens processed. For a local reply this is the count the native side actually used (after any cut). */
  val promptTokens: Int,
  /** Prompt tokens reused from the KV cache, counted by the app's own prompt cache. Null = not measured (remote replies, Speed tests, unreadable). */
  val cachedTokens: Int? = null,
  val outputTokens: Int,
  /** Oldest prompt tokens cut to fit the context (local only). Null = not measured. */
  val truncatedTokens: Int? = null,
  val ttftMs: Long? = null,
  val prefillTps: Double? = null,
  val decodeTps: Double? = null,
  val medianMs: Double? = null,
  val p95Ms: Double? = null,
  val threads: Int? = null,
  val streaming: Boolean = false,
  val contextLength: Int? = null,
  val readMb: Double? = null,
  val majorFaults: Long? = null,
  val minorFaults: Long? = null,
  val thermalBefore: String? = null,
  val thermalAfter: String? = null,
  val batteryTempC: Double? = null,
  val anonMb: Long? = null,
  val fileMb: Long? = null,
  /** v1.9.31: prompt-lookup decoding was active for this reply (experimental). Kept apart in the summary: it changes how tokens are produced. */
  val lookup: Boolean = false
)

data class SpeedSummary(
  val runs: Int,
  val medianDecodeTps: Double?,
  val medianTtftMs: Long?,
  val medianPrefillTps: Double?,
  /** Share of prompt tokens reused from the KV cache, 0..100. Only from local replies where the app counted it; null otherwise. */
  val cacheReusePct: Int?,
  /** Replies made with lookup decoding on. They are listed but not part of the medians above. */
  val lookupRuns: Int = 0
)

/** Pure calculations for one request, from timestamps and counts the engine already has. */
object SpeedMath {
  fun ttftMs(startMs: Long, firstTokenMs: Long): Long? =
    if (firstTokenMs > 0 && startMs > 0 && firstTokenMs >= startMs) firstTokenMs - startMs else null

  /** The first token comes with the prompt, so n tokens have n-1 intervals. */
  fun decodeTps(outputTokens: Int, firstTokenMs: Long, lastTokenMs: Long): Double? =
    if (outputTokens >= 2 && firstTokenMs > 0 && lastTokenMs > firstTokenMs) (outputTokens - 1) * 1000.0 / (lastTokenMs - firstTokenMs) else null

  /** Tokens actually processed (not served from the cache) per second of waiting for the first token. Approximate; null when too little was processed to mean anything. */
  fun prefillTps(promptTokens: Int, cachedTokens: Int, ttftMs: Long?): Double? {
    val processed = promptTokens - cachedTokens
    return if (ttftMs != null && ttftMs > 0 && processed >= MIN_PREFILL_TOKENS) processed * 1000.0 / ttftMs else null
  }

  const val MIN_PREFILL_TOKENS = 8
}

/** The numbers of one detailed Speed test, as the native side reports them on its first line. */
data class BenchNumbers(
  val promptTokens: Int,
  val promptMs: Double,
  val genTokens: Int,
  val steps: Int,
  val genMs: Double,
  val medianMs: Double,
  val p95Ms: Double,
  val readMb: Double?,
  val majorFaults: Long?,
  val minorFaults: Long?,
  val threads: Int,
  val streaming: Boolean,
  val batch: Int
) {
  val prefillTps: Double? get() = if (promptMs > 0 && promptTokens > 0) promptTokens * 1000.0 / promptMs else null
  val decodeTps: Double? get() = if (genMs > 0 && steps > 0) steps * 1000.0 / genMs else null
}

object BenchLine {
  private const val PREFIX = "@@bench "

  /** Splits the native result into its numbers (if the first line carries them) and the text to show. Never throws. */
  fun split(raw: String): Pair<BenchNumbers?, String> {
    if (!raw.startsWith(PREFIX)) return null to raw
    val nl = raw.indexOf('\n')
    val line = if (nl < 0) raw else raw.substring(0, nl)
    val text = if (nl < 0) "" else raw.substring(nl + 1)
    val nums = runCatching {
      val o = MiniJson.parseObject(line.removePrefix(PREFIX))
      fun d(k: String) = (o[k] as Number).toDouble()
      fun opt(k: String): Double? = (o[k] as? Number)?.toDouble()?.takeIf { it >= 0.0 }
      BenchNumbers(
        promptTokens = d("promptTokens").toInt(), promptMs = d("promptMs"),
        genTokens = d("genTokens").toInt(), steps = d("steps").toInt(), genMs = d("genMs"),
        medianMs = d("medianMs"), p95Ms = d("p95Ms"),
        readMb = opt("readMb"), majorFaults = opt("majFaults")?.toLong(), minorFaults = opt("minFaults")?.toLong(),
        threads = d("threads").toInt(), streaming = o["streaming"] as? Boolean ?: false, batch = d("batch").toInt()
      )
    }.getOrNull()
    return nums to text
  }
}

object SpeedHistory {
  const val MAX_RECORDS = 100

  fun toLine(r: SpeedRecord): String = MiniJson.encode(
    listOf(
      "ts" to r.ts, "source" to r.source, "backend" to r.backend, "model" to r.model.take(120),
      "promptTokens" to r.promptTokens, "cachedTokens" to r.cachedTokens, "outputTokens" to r.outputTokens, "truncatedTokens" to r.truncatedTokens,
      "ttftMs" to r.ttftMs, "prefillTps" to r.prefillTps, "decodeTps" to r.decodeTps,
      "medianMs" to r.medianMs, "p95Ms" to r.p95Ms, "threads" to r.threads, "streaming" to r.streaming,
      "contextLength" to r.contextLength, "readMb" to r.readMb, "majorFaults" to r.majorFaults, "minorFaults" to r.minorFaults,
      "thermalBefore" to r.thermalBefore, "thermalAfter" to r.thermalAfter, "batteryTempC" to r.batteryTempC,
      "anonMb" to r.anonMb, "fileMb" to r.fileMb, "lookup" to r.lookup
    )
  )

  /** One line back to a record; null for a blank or damaged line (a crash mid-write must not hide the rest). */
  fun fromLine(line: String): SpeedRecord? = runCatching {
    if (line.isBlank()) return null
    val o = MiniJson.parseObject(line)
    fun n(k: String) = o[k] as? Number
    SpeedRecord(
      ts = (o["ts"] as Number).toLong(),
      source = o["source"] as String,
      backend = o["backend"] as String,
      model = o["model"] as? String ?: "",
      promptTokens = n("promptTokens")?.toInt() ?: 0,
      cachedTokens = n("cachedTokens")?.toInt(),
      outputTokens = n("outputTokens")?.toInt() ?: 0,
      truncatedTokens = n("truncatedTokens")?.toInt(),
      ttftMs = n("ttftMs")?.toLong(), prefillTps = n("prefillTps")?.toDouble(), decodeTps = n("decodeTps")?.toDouble(),
      medianMs = n("medianMs")?.toDouble(), p95Ms = n("p95Ms")?.toDouble(), threads = n("threads")?.toInt(),
      streaming = o["streaming"] as? Boolean ?: false, contextLength = n("contextLength")?.toInt(),
      readMb = n("readMb")?.toDouble(), majorFaults = n("majorFaults")?.toLong(), minorFaults = n("minorFaults")?.toLong(),
      thermalBefore = o["thermalBefore"] as? String, thermalAfter = o["thermalAfter"] as? String,
      batteryTempC = n("batteryTempC")?.toDouble(), anonMb = n("anonMb")?.toLong(), fileMb = n("fileMb")?.toLong(),
      lookup = o["lookup"] as? Boolean ?: false
    )
  }.getOrNull()

  fun decode(text: String): List<SpeedRecord> = text.lineSequence().mapNotNull { fromLine(it) }.toList().takeLast(MAX_RECORDS)

  fun encode(list: List<SpeedRecord>): String = list.joinToString("\n", postfix = "\n") { toLine(it) }

  fun append(list: List<SpeedRecord>, r: SpeedRecord): List<SpeedRecord> = (list + r).takeLast(MAX_RECORDS)

  fun median(values: List<Double>): Double? {
    if (values.isEmpty()) return null
    val s = values.sorted()
    return if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2.0
  }

  /** Summary of real requests ("chat") for one backend. Speed tests are listed on their own, never averaged in. */
  fun summary(list: List<SpeedRecord>, backend: String): SpeedSummary? {
    val all = list.filter { it.source == "chat" && it.backend == backend }
    if (all.isEmpty()) return null
    // Replies made with lookup decoding are counted but kept out of the medians: it is a different way of producing tokens.
    val rows = all.filter { !it.lookup }
    val lookupRuns = all.size - rows.size
    if (rows.isEmpty()) return SpeedSummary(0, null, null, null, null, lookupRuns)
    // Only replies where the app counted the reuse itself; an unmeasured reply is left out, never counted as 0.
    val measured = rows.filter { it.cachedTokens != null && it.promptTokens > 0 }
    val reuse = if (backend == "local" && measured.isNotEmpty()) {
      (measured.sumOf { it.cachedTokens!!.toLong() } * 100 / measured.sumOf { it.promptTokens.toLong() }).toInt().coerceIn(0, 100)
    } else null
    return SpeedSummary(
      runs = rows.size,
      medianDecodeTps = median(rows.mapNotNull { it.decodeTps }),
      medianTtftMs = median(rows.mapNotNull { it.ttftMs?.toDouble() })?.toLong(),
      medianPrefillTps = median(rows.mapNotNull { it.prefillTps }),
      cacheReusePct = reuse,
      lookupRuns = lookupRuns
    )
  }

  /** One short line for the list of recent runs. */
  fun line(r: SpeedRecord): String {
    val parts = ArrayList<String>()
    parts.add(if (r.source == "speedtest") "Speed test" else if (r.backend == "remote") "Remote" else "Chat")
    parts.add(if (r.model.length > 26) r.model.take(25) + "…" else r.model)
    parts.add("${r.outputTokens} tokens")
    r.decodeTps?.let { parts.add(String.format(Locale.US, "%.1f tok/s", it)) }
    r.ttftMs?.let { parts.add(String.format(Locale.US, "first token %.1f s", it / 1000.0)) }
    val cached = r.cachedTokens
    if (r.backend == "local" && cached != null && r.promptTokens > 0) {
      parts.add("prompt reused ${(cached.toLong() * 100 / r.promptTokens).coerceIn(0, 100)}%")
    }
    r.truncatedTokens?.takeIf { it > 0 }?.let { parts.add("prompt cut by $it tokens") }
    if (r.lookup) parts.add("lookup on")
    return parts.filter { it.isNotBlank() }.joinToString(" · ")
  }
}

/** Reads and writes the history file. Never throws; the file is rewritten atomically and capped at [SpeedHistory.MAX_RECORDS] records. */
class SpeedHistoryStore(private val file: File) {
  private var cache: List<SpeedRecord>? = null

  @Synchronized fun all(): List<SpeedRecord> = load()

  @Synchronized fun add(r: SpeedRecord) {
    val next = SpeedHistory.append(load(), r)
    cache = next
    write(next)
  }

  @Synchronized fun clear() {
    cache = emptyList()
    runCatching { file.delete() }
    runCatching { File(file.parentFile, file.name + ".tmp").delete() }
  }

  /** Builds and stores a record on a low-priority background thread, so the request that produced it never waits. */
  fun addAsync(build: () -> SpeedRecord?) {
    runCatching { EXECUTOR.execute { runCatching { build()?.let { add(it) } } } }
  }

  private fun load(): List<SpeedRecord> {
    cache?.let { return it }
    val loaded = runCatching { if (file.isFile) SpeedHistory.decode(file.readText()) else emptyList() }.getOrDefault(emptyList())
    cache = loaded
    return loaded
  }

  private fun write(list: List<SpeedRecord>) {
    runCatching {
      file.parentFile?.mkdirs()
      val tmp = File(file.parentFile, file.name + ".tmp")
      tmp.writeText(SpeedHistory.encode(list))
      if (!tmp.renameTo(file)) {
        file.writeText(SpeedHistory.encode(list))
        tmp.delete()
      }
    }
  }

  companion object {
    const val FILE_NAME = "speed_history.jsonl"

    private val EXECUTOR by lazy {
      Executors.newSingleThreadExecutor { r -> Thread(r, "speed-history").apply { isDaemon = true; priority = Thread.MIN_PRIORITY } }
    }

    @Volatile private var instance: SpeedHistoryStore? = null

    /** The app-wide store, kept in [filesDir]. */
    fun get(filesDir: File): SpeedHistoryStore =
      instance ?: synchronized(this) { instance ?: SpeedHistoryStore(File(filesDir, FILE_NAME)).also { instance = it } }
  }
}
