#include "read_advice.h"

#include <fcntl.h>
#include <unistd.h>

#include <cstdio>
#include <cstdlib>
#include <cstring>

static int g_fail = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++g_fail; } } while (0)

// Does the mapping that starts at `start` carry the "rr" (random read) flag in /proc/self/smaps?
static int vm_flag_rr(uintptr_t start) {
    const std::string s = vibe::read_text_file("/proc/self/smaps");
    char head[64];
    std::snprintf(head, sizeof(head), "%lx-", static_cast<unsigned long>(start));
    size_t p = s.find(head);
    while (p != std::string::npos && p != 0 && s[p - 1] != '\n') p = s.find(head, p + 1);
    if (p == std::string::npos) return -1;
    const size_t f = s.find("VmFlags:", p);
    if (f == std::string::npos) return -1;
    const size_t e = s.find('\n', f);
    const std::string flags = s.substr(f, e - f);
    return flags.find(" rr") != std::string::npos ? 1 : 0;
}

int main() {
    using namespace vibe;
    // stems
    CHECK(model_stem("Qwen3-30B.gguf") == "Qwen3-30B");
    CHECK(model_stem("Qwen3-30B-00001-of-00003.gguf") == "Qwen3-30B");
    CHECK(model_stem("Qwen3-30B-00002-of-00003.gguf") == "Qwen3-30B");
    CHECK(model_stem("m-0001-of-0003.gguf") == "m-0001-of-0003");  // not a 5-digit shard suffix
    CHECK(model_stem("noext") == "noext");
    CHECK(path_base("/data/data/app/files/models/x.gguf") == "x.gguf");
    CHECK(path_base("x.gguf") == "x.gguf");

    // parse
    MapRegion r; std::string path;
    CHECK(parse_maps_line("7f1000000000-7f1100000000 r--s 00000000 fd:0f 1234   /data/data/com.example/files/models/a b.gguf", &r, &path));
    CHECK(r.start == 0x7f1000000000ULL && r.end == 0x7f1100000000ULL);
    CHECK(path == "/data/data/com.example/files/models/a b.gguf");
    CHECK(parse_maps_line("7f1000000000-7f1100000000 r--s 00000000 fd:0f 1234   /x/y.gguf (deleted)", &r, &path) && path == "/x/y.gguf");
    CHECK(parse_maps_line("7ffd0000-7ffd1000 rw-p 00000000 00:00 0 ", &r, &path) && path.empty());
    CHECK(parse_maps_line("7ffd0000-7ffd1000 rw-p 00000000 00:00 0 [stack]", &r, &path) && path == "[stack]");
    CHECK(!parse_maps_line("", &r, &path));
    CHECK(!parse_maps_line("garbage line", &r, &path));
    CHECK(!parse_maps_line("2000-1000 r--s 00000000 fd:0f 1 /a.gguf", &r, &path));

    // regions of one model, by name
    const std::string maps =
        "7f0000000000-7f0000001000 r-xp 00000000 fd:01 10 /system/lib64/libc.so\n"
        "7f1000000000-7f1100000000 r--s 00000000 fd:0f 99 /data/data/com.example/files/models/Big-00001-of-00002.gguf\n"
        "7f1200000000-7f1300000000 r--s 00000000 fd:0f 98 /data/data/com.example/files/models/Big-00002-of-00002.gguf\n"
        "7f1400000000-7f1400100000 r--s 00000000 fd:0f 97 /data/data/com.example/files/models/mmproj-Big.gguf\n"
        "7f1500000000-7f1500100000 r--s 00000000 fd:0f 96 /data/data/com.example/files/models/Other.gguf\n"
        "7f1600000000-7f1600100000 r--s 00000000 fd:0f 95 /data/data/com.example/files/models/Big-00001-of-00002.txt\n";
    auto sharded = regions_of_model(maps, "/data/user/0/com.example/files/models/Big-00001-of-00002.gguf");
    CHECK(sharded.size() == 2 && sharded[0].start == 0x7f1000000000ULL && sharded[1].start == 0x7f1200000000ULL);
    auto other = regions_of_model(maps, "/anywhere/Other.gguf");
    CHECK(other.size() == 1 && other[0].start == 0x7f1500000000ULL);
    CHECK(regions_of_model(maps, "/anywhere/Missing.gguf").empty());
    CHECK(regions_of_model(maps, "").empty());
    CHECK(regions_of_model("", "/a/b.gguf").empty());

    // the real thing: map a file named *.gguf, find it in the live /proc/self/maps, set and clear the hint, read the flag back
    char tmpl[] = "/tmp/advice_XXXXXX";
    int fd0 = mkstemp(tmpl);
    CHECK(fd0 >= 0);
    close(fd0);
    std::string file = std::string(tmpl) + ".gguf";
    CHECK(std::rename(tmpl, file.c_str()) == 0);
    const size_t len = 8u << 20;
    int fd = open(file.c_str(), O_RDWR);
    CHECK(fd >= 0 && ftruncate(fd, static_cast<off_t>(len)) == 0);
    void *m = mmap(nullptr, len, PROT_READ, MAP_SHARED, fd, 0);
    CHECK(m != MAP_FAILED);
    close(fd);
    auto live = regions_of_model(read_text_file("/proc/self/maps"), file);
    CHECK(live.size() == 1);
    if (live.size() == 1) {
        CHECK(live[0].start == reinterpret_cast<uintptr_t>(m) && live[0].end - live[0].start == len);
        CHECK(vm_flag_rr(live[0].start) == 0);
        CHECK(advise_regions(live, kAdviceRandom) == static_cast<long long>(len));
        CHECK(vm_flag_rr(live[0].start) == 1);
        CHECK(advise_regions(live, kAdviceDefault) == static_cast<long long>(len));
        CHECK(vm_flag_rr(live[0].start) == 0);
    }
    // a region that is not mapped: nothing accepts the hint
    std::vector<MapRegion> bogus(1);
    bogus[0].start = 0x1000; bogus[0].end = 0x2000;
    CHECK(advise_regions(bogus, kAdviceRandom) == -1);
    CHECK(advise_regions(std::vector<MapRegion>(), kAdviceRandom) == -1);
    munmap(m, len);
    unlink(file.c_str());

    std::printf(g_fail == 0 ? "advice_test: all passed\n" : "advice_test: %d FAILED\n", g_fail);
    return g_fail == 0 ? 0 : 1;
}
