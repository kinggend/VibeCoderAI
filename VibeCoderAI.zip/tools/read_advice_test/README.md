Host test for `app/src/main/cpp/read_advice.h` (v1.9.34). It parses /proc/self/maps lines, matches a model file (and its shards) by name,
maps a real file, applies MADV_RANDOM / MADV_NORMAL and reads the "rr" flag back from /proc/self/smaps.

    g++ -std=c++17 -O1 -Wall -Wextra -I app/src/main/cpp tools/read_advice_test/advice_test.cpp -o /tmp/advice_test && /tmp/advice_test
