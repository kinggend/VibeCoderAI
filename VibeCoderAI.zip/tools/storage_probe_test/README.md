Host test for `app/src/main/cpp/storage_probe.h` (v1.9.38). It checks the position generator (4 KB aligned, inside the file, spread),
real reads on a temporary 128 MB file with 1 and several threads (bytes add up, time is respected), the refusals (small file, bad
thread count, bad descriptor), and the text of the report. The millisecond and MB/s values on a host say nothing about a phone.

    g++ -std=c++17 -O1 -Wall -Wextra -pthread -I app/src/main/cpp tools/storage_probe_test/probe_test.cpp -o /tmp/probe_test && /tmp/probe_test
