// Host test for app/src/main/cpp/storage_probe.h (v1.9.38).
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <set>
#include <string>

#include "storage_probe.h"

static int fails = 0;
#define CHECK(cond, msg)                                              \
    do {                                                              \
        if (cond) std::printf("PASS %s\n", msg);                      \
        else { std::printf("FAIL %s\n", msg); ++fails; }              \
    } while (0)

static std::string make_file(long long bytes) {
    char path[] = "/tmp/probe_testXXXXXX";
    const int fd = mkstemp(path);
    if (fd < 0 || ftruncate(fd, static_cast<off_t>(bytes)) != 0) { std::printf("cannot make test file\n"); std::exit(2); }
    close(fd);
    return path;
}

int main() {
    // positions
    CHECK(vibe::probe_slots(100, 4096) == -1, "file smaller than a read -> no slots");
    CHECK(vibe::probe_slots(4096 + 4095, 4096) == -1, "file one page short of the read plus a page -> no slots");
    CHECK(vibe::probe_slots(8192, 4096) == 1, "8192-byte file, 4 KB read -> 1 slot");
    CHECK(vibe::probe_slots(1000, 0) == -1, "zero length -> no slots");
    {
        const long long size = 300LL << 20;
        const size_t len = 1u << 20;
        const long long slots = vibe::probe_slots(size, len);
        uint64_t s = 12345;
        bool ok = true;
        std::set<long long> seen;
        for (int i = 0; i < 100000; ++i) {
            const long long off = static_cast<long long>(vibe::probe_next(s) % static_cast<uint64_t>(slots)) * 4096LL;
            if (off % 4096 != 0 || off < 0 || off + static_cast<long long>(len) > size) ok = false;
            seen.insert(off);
        }
        CHECK(ok, "100000 positions: 4 KB aligned and every read lies inside the file");
        // 100000 uniform draws over `slots` positions give about slots*(1-exp(-100000/slots)) distinct ones (about 55800 for 76544 slots)
        CHECK(seen.size() > 50000 && seen.size() < 62000, "positions are spread like uniform random draws");
        uint64_t a = 7, b = 7;
        CHECK(vibe::probe_next(a) == vibe::probe_next(b), "same seed, same positions");
    }

    const std::string f = make_file(128LL << 20);
    // reads
    {
        const vibe::ProbeReads r = vibe::probe_reads(open(f.c_str(), O_RDONLY), 128LL << 20, 4096, 1, 0.3, 1);
        CHECK(!r.failed && r.reads > 0, "4 KB, 1 thread: reads happened");
        CHECK(r.bytes == r.reads * 4096, "4 KB, 1 thread: bytes = reads * 4096");
        CHECK(r.secs >= 0.29 && r.secs < 3.0, "4 KB, 1 thread: ran for about the asked time");
    }
    {
        const int fd = open(f.c_str(), O_RDONLY);
        const vibe::ProbeReads r = vibe::probe_reads(fd, 128LL << 20, 1u << 20, 4, 0.3, 2);
        close(fd);
        CHECK(!r.failed && r.reads > 0 && r.bytes == r.reads * (1LL << 20), "1 MB, 4 threads: reads happened, bytes add up");
    }
    {
        const int fd = open(f.c_str(), O_RDONLY);
        CHECK(vibe::probe_reads(fd, 1000, 4096, 1, 0.1, 1).failed, "too small file -> failed");
        CHECK(vibe::probe_reads(fd, 128LL << 20, 4096, 0, 0.1, 1).failed, "0 threads -> failed");
        CHECK(vibe::probe_reads(fd, 128LL << 20, 4096, 65, 0.1, 1).failed, "65 threads -> failed");
        CHECK(vibe::probe_reads(fd, 128LL << 20, 4096, 1, 0.0, 1).failed, "0 seconds -> failed");
        close(fd);
        CHECK(vibe::probe_reads(-1, 128LL << 20, 4096, 2, 0.1, 1).failed, "bad descriptor -> failed, no crash");
    }
    // the report
    {
        const std::string t = vibe::storage_probe_text(f, 4);
        std::printf("%s\n", t.c_str());
        CHECK(t.find("Storage probe (random reads on the model file,") == 0, "report starts with its title");
        CHECK(t.find("4 KB reads: 1 thread ") != std::string::npos && t.find("reads/s") != std::string::npos, "report has the 4 KB line");
        CHECK(t.find("1 MB reads: 1 thread ") != std::string::npos && t.find("8 threads") != std::string::npos, "report has the 1 MB line");
        CHECK(t.find("page cache bypassed") != std::string::npos || t.find("page cache NOT bypassed") != std::string::npos, "report says whether the cache was bypassed");
        CHECK(t.find("1 s each") != std::string::npos, "budget 4 s -> 1 s each");
    }
    {
        const std::string small = make_file(10LL << 20);
        CHECK(vibe::storage_probe_text(small, 12).find("smaller than 64 MB") != std::string::npos, "small file -> says so");
        unlink(small.c_str());
        const std::string missing = vibe::storage_probe_text("/nonexistent/model.gguf", 12);
        CHECK(missing.find("could not be opened (error 2)") != std::string::npos, "missing file -> error 2");
        CHECK(vibe::storage_probe_text("", 12) == "Storage probe: no model file.", "empty path -> no model file");
    }
    unlink(f.c_str());
    std::printf(fails == 0 ? "ALL PASS\n" : "%d FAILED\n", fails);
    return fails == 0 ? 0 : 1;
}
