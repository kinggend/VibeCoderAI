import re,sys,glob
Q=re.compile(r'\{\d+(?:,\d*)?\}')
def lit(s,i):
    # s[i] at quote; returns (value, end, templated)
    if s.startswith('"""',i):
        j=s.index('"""',i+3)
        while s.startswith('"',j+3): j+=1
        v=s[i+3:j]; return v,j+3,('$' in v and re.search(r'\$[\{A-Za-z_]',v) is not None)
    j=i+1; out=[]; t=False
    while s[j]!='"':
        if s[j]=='\\':
            n=s[j+1]; m={'n':'\n','t':'\t','r':'\r','"':'"','\\':'\\','$':'$',"'":"'"}.get(n)
            if n=='u': out.append(chr(int(s[j+2:j+6],16))); j+=6; continue
            out.append(m if m is not None else '\\'+n); j+=2; continue
        if s[j]=='$' and re.match(r'\$[\{A-Za-z_]',s[j:j+2]): t=True
        out.append(s[j]); j+=1
    return ''.join(out),j+1,t
def check(p):
    issues=[]; i=0; depth=0
    while i<len(p):
        c=p[i]
        if c=='\\':
            if depth and i+2<len(p) and p[i+1] in 'wsdWSD' and p[i+2]=='-' and i+3<len(p) and p[i+3]!=']':
                issues.append(f'class-escape range at {i}')
            i+=2; continue
        if depth:
            if c=='[': issues.append(f'nested [ at {i}'); 
            elif c==']': depth-=1
            elif c=='&' and p[i:i+2]=='&&': issues.append('&& in class')
        else:
            if c=='[':
                depth=1
                if p[i+1:i+2]=='^': i+=1
                if p[i+1:i+2]==']': i+=1
            elif c in '{}':
                m=Q.match(p,i) if c=='{' else None
                if m: i=m.end(); continue
                issues.append(f'bare {c} at {i}')
        i+=1
    if depth: issues.append('unclosed class')
    return issues
n=0;bad=0;skipped=0
for f in glob.glob('app/src/**/*.kt',recursive=True)+glob.glob('webshell/**/*.kt',recursive=True):
    s=open(f).read()
    for m in re.finditer(r'(?:Regex\(|toRegex\(|Pattern\.compile\()\s*(?=")',s):
        pass
    for m in re.finditer(r'Regex\(\s*(")',s):
        i=m.start(1); v,e,t=lit(s,i)
        while True:
            m2=re.match(r'\s*\+\s*(")',s[e:])
            if not m2: break
            v2,e2,t2=lit(s,e+m2.start(1)); v+=v2; t=t or t2; e=e2
        n+=1
        if t: skipped+=1; continue
        iss=check(v)
        if iss: bad+=1; print(f, repr(v[:100]), iss)
    for m in re.finditer(r'"((?:[^"\\\n]|\\.)*)"\.toRegex\(',s):
        v=m.group(1); n+=1
        iss=check(v)
        if iss: bad+=1; print(f,'toRegex',repr(v[:80]),iss)
print('checked',n,'skipped(templated)',skipped,'bad',bad)
