package com.example.llama;
public class LlamaBridge {
  public interface TokenCallback { boolean onPiece(byte[] b); boolean onProgress(int done, int total); }
  public native long nativeLoad(String modelPath, int threads, int ctxLength, int gpuLayers);
  public native void nativeSetStreamingLoad(boolean on);
  public native void nativeSetLookup(long h, boolean on);
  public native double[] nativeLookupInfo(long h);
  public native int nativeGenerate(long h, String prompt, int maxTokens, float temp, float topP, int topK, float repeatPenalty, TokenCallback cb);
  public native void nativeResetCache(long h);
  public native void nativeFree(long h);
  public native String nativeLastError();
  public native int[] nativeLastPrompt(long h);
  public native int nativeCachedTokens(long h);
}
