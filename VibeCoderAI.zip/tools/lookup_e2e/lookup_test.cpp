#include <cassert>
#include <cstdio>
#include <cstdint>
#include <functional>
#include <vector>
#include "ngram_lookup.h"

using vibe::LookupConfig; using vibe::LookupGate; using vibe::LookupStats;
using V = std::vector<int32_t>;
static int fails = 0;
#define CHECK(c) do { if (!(c)) { std::printf("FAIL line %d: %s\n", __LINE__, #c); ++fails; } } while (0)
static auto none = [](int32_t) { return false; };

static void draft_basics() {
    LookupConfig c; c.ngram_min = 3; c.ngram_max = 5; c.draft_max = 8;
    // x a b c d e f ... a b c  -> guess d e f ...
    V h = {9, 1, 2, 3, 4, 5, 6, 7, 8, 1, 2, 3};
    V d = vibe::lookup_draft(h, c, 8, none);
    CHECK((d == V{4, 5, 6, 7, 8, 1, 2, 3}));
    // cap by max_len and by draft_max
    CHECK((vibe::lookup_draft(h, c, 3, none) == V{4, 5, 6}));
    LookupConfig c2 = c; c2.draft_max = 2;
    CHECK((vibe::lookup_draft(h, c2, 8, none) == V{4, 5}));
    CHECK(vibe::lookup_draft(h, c, 0, none).empty());
    // no match
    CHECK(vibe::lookup_draft(V{1, 2, 3, 4, 5, 6}, c, 8, none).empty());
    // too short
    CHECK(vibe::lookup_draft(V{1, 2, 3}, c, 8, none).empty());
    CHECK(vibe::lookup_draft(V{}, c, 8, none).empty());
    // a run shorter than ngram_min never matches
    CHECK(vibe::lookup_draft(V{5, 6, 7, 5, 6}, c, 8, none).empty());
    // most recent occurrence wins
    V h2 = {1, 2, 3, 10, 0, 1, 2, 3, 20, 0, 1, 2, 3};
    CHECK((vibe::lookup_draft(h2, c, 2, none) == V{20, 0}));
    // longest run preferred: tail 7 1 2 3 matches the older place (7 1 2 3 -> 40), a shorter 1 2 3 would match the newer one (-> 50)
    V h3 = {7, 1, 2, 3, 40, 41, 8, 1, 2, 3, 50, 51, 7, 1, 2, 3};
    CHECK((vibe::lookup_draft(h3, c, 2, none) == V{40, 41}));
    // overlapping periodic text
    V h4 = {1, 2, 3, 1, 2, 3, 1, 2, 3};
    V d4 = vibe::lookup_draft(h4, c, 4, none);
    CHECK(!d4.empty() && d4[0] == 1);
    // stop token ends the guess and is never included
    V d5 = vibe::lookup_draft(h, c, 8, [](int32_t t) { return t == 6; });
    CHECK((d5 == V{4, 5}));
    // stop right after the run: nothing from that place, falls back to a shorter run elsewhere or nothing
    V h6 = {1, 2, 3, 99, 7, 1, 2, 3};
    CHECK(vibe::lookup_draft(h6, c, 8, [](int32_t t) { return t == 99; }).empty());
    // ngram_min 1 works and ngram_min < 1 is rejected
    LookupConfig c1; c1.ngram_min = 1; c1.ngram_max = 1;
    CHECK((vibe::lookup_draft(V{4, 5, 6, 4}, c1, 3, none) == V{5, 6, 4}));
    LookupConfig c0; c0.ngram_min = 0;
    CHECK(vibe::lookup_draft(V{4, 5, 6, 4}, c0, 3, none).empty());
    // the guess never reads past the end of the history
    V h7 = {1, 2, 3, 4, 1, 2, 3};
    CHECK((vibe::lookup_draft(h7, c, 8, none) == V{4, 1, 2, 3}));
}

static void verify_basics() {
    V draft = {5, 6, 7};
    std::vector<int> calls;
    // all match -> bonus row 3
    auto all = [&](int j) { calls.push_back(j); V t = {5, 6, 7, 8}; return t[j]; };
    auto r = vibe::verify_draft(draft, all);
    CHECK(r.accepted == 3 && r.next == 8 && calls == std::vector<int>({0, 1, 2, 3}));
    // mismatch at row 1: stops, row 1's token is the next token, rows after are never sampled
    calls.clear();
    auto mis = [&](int j) { calls.push_back(j); V t = {5, 99, 7, 8}; return t[j]; };
    r = vibe::verify_draft(draft, mis);
    CHECK(r.accepted == 1 && r.next == 99 && calls == std::vector<int>({0, 1}));
    // mismatch at row 0
    calls.clear();
    auto m0 = [&](int j) { calls.push_back(j); return 42; };
    r = vibe::verify_draft(draft, m0);
    CHECK(r.accepted == 0 && r.next == 42 && calls == std::vector<int>({0}));
    // empty draft: one sample (row 0)
    calls.clear();
    r = vibe::verify_draft(V{}, m0);
    CHECK(r.accepted == 0 && r.next == 42 && calls.size() == 1);
}

// ---- equivalence: lookup decoding picks the same tokens as plain decoding ----
struct Rng { uint64_t s; uint32_t next() { s = s * 6364136223846793005ULL + 1442695040888963407ULL; return static_cast<uint32_t>(s >> 33); } };

// Toy model: the distribution at a position depends only on the last two tokens; "temp" decides whether the sampler is
// greedy (always the likeliest) or random (the likeliest 75%, otherwise one of three others). One rng draw per sampled token.
static int32_t toy_sample(const V &ctx, Rng &rng, bool greedy, int period) {
    const size_t n = ctx.size();
    const int32_t a = n >= 1 ? ctx[n - 1] : 0, b = n >= 2 ? ctx[n - 2] : 0;
    int32_t likely = static_cast<int32_t>((a * 31 + b * 17 + 7) % period);
    if (greedy) return likely;
    uint32_t r = rng.next();
    return (r % 4 != 0) ? likely : static_cast<int32_t>((likely + 1 + (r >> 4) % 3) % period);
}

static V plain_decode(V prompt, int count, bool greedy, int period, uint64_t seed) {
    Rng rng{seed};
    V ctx = prompt, out;
    for (int i = 0; i < count; ++i) { int32_t t = toy_sample(ctx, rng, greedy, period); out.push_back(t); ctx.push_back(t); }
    return out;
}

// Same structure as the native loop: emit tok, guess after it, one batched check, keep the matching prefix, carry the sampler's token.
static V lookup_decode(V prompt, int count, bool greedy, int period, uint64_t seed, long *rounds, long *accepted, LookupConfig cfg = {}) {
    Rng rng{seed};
    V committed = prompt, out;       // committed = what the KV cache holds
    V hist = prompt;                 // committed + the token about to be decoded
    bool have_next = false; int32_t next_tok = 0;
    while (static_cast<int>(out.size()) < count) {
        int32_t tok;
        if (have_next) { tok = next_tok; have_next = false; } else tok = toy_sample(committed, rng, greedy, period);
        out.push_back(tok); hist.push_back(tok);
        int room = count - static_cast<int>(out.size());
        V draft = room > 0 ? vibe::lookup_draft(hist, cfg, room, none) : V{};
        if (draft.empty()) { committed.push_back(tok); continue; }
        ++*rounds;
        // rows: row j sees committed + tok + draft[0..j)
        auto sample = [&](int j) {
            V ctx = committed; ctx.push_back(tok);
            for (int k = 0; k < j; ++k) ctx.push_back(draft[k]);
            return toy_sample(ctx, rng, greedy, period);
        };
        auto vr = vibe::verify_draft(draft, sample);
        *accepted += vr.accepted;
        committed.push_back(tok);
        for (int j = 0; j < vr.accepted; ++j) { committed.push_back(draft[j]); out.push_back(draft[j]); hist.push_back(draft[j]); }
        next_tok = vr.next; have_next = true;
    }
    out.resize(count);
    return out;
}

static void equivalence() {
    long total_rounds = 0, total_acc = 0;
    for (int period : {3, 5, 7, 40}) {
        for (int greedy = 0; greedy < 2; ++greedy) {
            for (uint64_t seed = 1; seed <= 25; ++seed) {
                V prompt;
                Rng pr{seed * 977};
                int plen = 5 + static_cast<int>(pr.next() % 40);
                for (int i = 0; i < plen; ++i) prompt.push_back(static_cast<int32_t>(pr.next() % static_cast<uint32_t>(period)));
                int count = 150;
                V a = plain_decode(prompt, count, greedy != 0, period, seed);
                long r = 0, acc = 0;
                V b = lookup_decode(prompt, count, greedy != 0, period, seed, &r, &acc);
                if (a != b) { std::printf("MISMATCH period=%d greedy=%d seed=%llu\n", period, greedy, (unsigned long long)seed); ++fails; }
                total_rounds += r; total_acc += acc;
            }
        }
    }
    // the loop really exercised guessing and acceptance (otherwise the equality above proves little)
    CHECK(total_rounds > 500);
    CHECK(total_acc > 200);
    std::printf("equivalence: rounds=%ld accepted=%ld\n", total_rounds, total_acc);
}

static void gate_behavior() {
    LookupGate g;
    CHECK(!g.allow());                      // no plain measurements yet
    g.on_single(10); g.on_single(10);
    CHECK(!g.allow());                      // warm-up is 3
    g.on_single(10);
    CHECK(g.allow());
    // fast rounds (3 tokens in 14 ms vs 1 token per 10 ms) never pause
    for (int i = 0; i < 20; ++i) { g.on_round(14, 3); CHECK(g.allow()); }
    CHECK(g.pauses() == 0);

    // slow rounds (1 token in 25 ms): verdict only after min_rounds, then a pause
    LookupGate s;
    for (int i = 0; i < 3; ++i) s.on_single(10);
    s.on_round(25, 1); s.on_round(25, 1); s.on_round(25, 1);
    CHECK(s.allow() && s.pauses() == 0);    // 3 rounds < min_rounds 4
    s.on_round(25, 1);
    CHECK(!s.allow() && s.pauses() == 1 && s.paused_left() == 32);
    for (int i = 0; i < 31; ++i) { s.on_single(10); CHECK(!s.allow()); }
    s.on_single(10);
    CHECK(s.allow());                       // probes again
    // the probe starts with a clean window: one slow round is not enough for a second pause
    s.on_round(25, 1);
    CHECK(s.allow() && s.pauses() == 1);
    s.on_round(25, 1); s.on_round(25, 1); s.on_round(25, 1);
    CHECK(!s.allow() && s.pauses() == 2 && s.paused_left() == 64);   // repeated slow verdict: the pause doubles
    for (int i = 0; i < 64; ++i) s.on_single(10);
    for (int i = 0; i < 4; ++i) s.on_round(25, 1);
    CHECK(s.paused_left() == 128);
    // a good probe resets the pause to its base
    for (int i = 0; i < 128; ++i) s.on_single(10);
    for (int i = 0; i < 4; ++i) s.on_round(12, 4);
    CHECK(s.allow() && s.paused_left() == 0);
    for (int i = 0; i < 20 && s.allow(); ++i) s.on_round(25, 1);   // rounds only happen while allow() is true
    CHECK(s.paused_left() == 32);
    // the pause is capped
    LookupGate cap;
    for (int i = 0; i < 3; ++i) cap.on_single(10);
    int last = 0;
    for (int rep = 0; rep < 12; ++rep) {
        for (int i = 0; i < 4; ++i) cap.on_round(25, 1);
        last = cap.paused_left();
        for (int i = 0; i < last; ++i) cap.on_single(10);
    }
    CHECK(last == 512);

    // break-even: equal rate keeps going with margin 1.0 (>= comparison is strict <)
    LookupGate e;
    for (int i = 0; i < 3; ++i) e.on_single(10);
    for (int i = 0; i < 6; ++i) e.on_round(20, 2);
    CHECK(e.allow() && e.pauses() == 0);

    // a mixed window: 2 good rounds and 2 bad ones averaged by tokens/ms, not by round
    LookupGate m;
    for (int i = 0; i < 3; ++i) m.on_single(10);
    m.on_round(30, 6); m.on_round(30, 6); m.on_round(12, 1); m.on_round(12, 1);   // 14 tokens in 84 ms = 0.1667/ms > 0.1/ms
    CHECK(m.allow());

    // zero or tiny times never divide by zero
    LookupGate z;
    for (int i = 0; i < 3; ++i) z.on_single(0);
    for (int i = 0; i < 5; ++i) z.on_round(0, 1);
    CHECK(z.allow());
}

static void gate_in_a_cost_model() {
    // plain step 10 ms; a round costs 10 + 3 ms per guessed token (so a full draft of 8 costs 34 ms).
    // No acceptance: the gate must keep guessing to a small share of the steps. High acceptance: it must keep guessing.
    for (int accept_all = 0; accept_all < 2; ++accept_all) {
        LookupGate g; long rounds = 0, singles = 0; double ms = 0; long tokens = 0;
        while (tokens < 2000) {
            if (g.allow()) {
                int k = 8; int acc = accept_all ? 8 : 0;
                double t = 10 + 3.0 * k;
                g.on_round(t, 1 + acc); ms += t; tokens += 1 + acc; ++rounds;
            } else { g.on_single(10); ms += 10; tokens += 1; ++singles; }
        }
        double plain_ms = 10.0 * static_cast<double>(tokens);
        if (accept_all) { CHECK(g.pauses() == 0); CHECK(ms < plain_ms * 0.5); }
        else { CHECK(g.pauses() > 0); CHECK(ms < plain_ms * 1.06); CHECK(rounds < singles / 10); }
        std::printf("cost model accept_all=%d: %.0f ms vs plain %.0f ms (rounds=%ld singles=%ld pauses=%d)\n", accept_all, ms, plain_ms, rounds, singles, g.pauses());
    }
}

static void block_reasons() {
    using namespace vibe;
    CHECK(lookup_block_reason(false, false, false, 0, true) == kLookupOk);
    CHECK(lookup_block_reason(true, false, false, 0, true) == kLookupStreaming);
    CHECK(lookup_block_reason(true, true, true, 4096, false) == kLookupStreaming);   // streaming always wins
    CHECK(lookup_block_reason(false, true, false, 0, true) == kLookupRecurrent);
    CHECK(lookup_block_reason(false, false, true, 0, true) == kLookupRecurrent);
    CHECK(lookup_block_reason(false, false, false, 4096, true) == kLookupSwa);
    CHECK(lookup_block_reason(false, false, false, 0, false) == kLookupNoRollback);
    LookupStats s; CHECK(accept_percent(s) == 0.0);
    s.drafted = 8; s.accepted = 6; CHECK(accept_percent(s) == 75.0);
}

int main() {
    draft_basics(); verify_basics(); equivalence(); gate_behavior(); gate_in_a_cost_model(); block_reasons();
    if (fails == 0) std::printf("ALL OK\n"); else std::printf("%d FAILED\n", fails);
    return fails == 0 ? 0 : 1;
}
