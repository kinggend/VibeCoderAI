import sys, numpy as np
sys.path.insert(0, '../llama.cpp/gguf-py')
import gguf

seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
rng = np.random.default_rng(seed)
out = sys.argv[1]
W = float(sys.argv[3]) if len(sys.argv) > 3 else 0.15

# --- tiny SentencePiece-style vocab: specials, 256 byte tokens, some word pieces ---
tokens, scores, types = [], [], []
def add(t, s, ty):
    tokens.append(t.encode('utf-8')); scores.append(float(s)); types.append(int(ty))
add('<unk>', 0, 2); add('<s>', 0, 3); add('</s>', 0, 3)
for b in range(256): add('<0x%02X>' % b, 0, 6)
pieces = ['▁', 'e', 't', 'a', 'o', 'i', 'n', 's', 'r', 'h', 'l', 'd', 'c', 'u', 'm', 'f', 'p', 'g', 'w', 'y', 'b', 'v', 'k',
          '(', ')', '{', '}', ';', '=', '+', '-', '*', '/', ',', '.', '_', '0', '1', '2', '3',
          '▁the', '▁int', '▁return', '▁def', '▁if', '▁for', '▁value', '▁result', 'er', 'in', 'on', 'an', 're', 'st', 'at', 'en', 'or', 'it']
for i, p in enumerate(pieces): add(p, -1.0 - i * 0.01, 1)
n_vocab = len(tokens)

n_embd, n_head, n_head_kv, n_ff, n_layer, n_ctx = 128, 4, 2, 256, 2, 2048
head_dim = n_embd // n_head
kv_dim = head_dim * n_head_kv

w = gguf.GGUFWriter(out, 'llama')
w.add_name('tiny-random')
w.add_context_length(n_ctx); w.add_embedding_length(n_embd); w.add_block_count(n_layer)
w.add_feed_forward_length(n_ff); w.add_head_count(n_head); w.add_head_count_kv(n_head_kv)
w.add_layer_norm_rms_eps(1e-5); w.add_rope_dimension_count(head_dim); w.add_rope_freq_base(10000.0)
w.add_file_type(0)
w.add_tokenizer_model('llama'); w.add_token_list(tokens); w.add_token_scores(scores); w.add_token_types(types)
w.add_bos_token_id(1); w.add_eos_token_id(2); w.add_unk_token_id(0); w.add_add_bos_token(True)

def mat(rows, cols, scale):  # gguf shape is reversed by the writer: pass numpy (rows, cols) = ne[1], ne[0]
    return (rng.standard_normal((rows, cols)) * scale).astype(np.float32)

w.add_tensor('token_embd.weight', mat(n_vocab, n_embd, 1.0))
w.add_tensor('output_norm.weight', np.ones(n_embd, dtype=np.float32))
w.add_tensor('output.weight', mat(n_vocab, n_embd, 1.0))
for l in range(n_layer):
    w.add_tensor(f'blk.{l}.attn_norm.weight', np.ones(n_embd, dtype=np.float32))
    w.add_tensor(f'blk.{l}.attn_q.weight', mat(n_embd, n_embd, W))
    w.add_tensor(f'blk.{l}.attn_k.weight', mat(kv_dim, n_embd, W))
    w.add_tensor(f'blk.{l}.attn_v.weight', mat(kv_dim, n_embd, W))
    w.add_tensor(f'blk.{l}.attn_output.weight', mat(n_embd, n_embd, W))
    w.add_tensor(f'blk.{l}.ffn_norm.weight', np.ones(n_embd, dtype=np.float32))
    w.add_tensor(f'blk.{l}.ffn_gate.weight', mat(n_ff, n_embd, W))
    w.add_tensor(f'blk.{l}.ffn_up.weight', mat(n_ff, n_embd, W))
    w.add_tensor(f'blk.{l}.ffn_down.weight', mat(n_embd, n_ff, W))
w.write_header_to_file(); w.write_kv_data_to_file(); w.write_tensors_to_file(); w.close()
print('wrote', out, 'vocab', n_vocab)
