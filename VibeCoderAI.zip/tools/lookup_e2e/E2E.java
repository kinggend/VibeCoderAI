import com.example.llama.LlamaBridge;
import java.io.ByteArrayOutputStream;
import java.util.*;

public class E2E {
  static final LlamaBridge B = new LlamaBridge();
  static int fails = 0;
  static void check(boolean c, String m) { if (!c) { fails++; System.out.println("FAIL: " + m); } }

  static class Out { String text; int n; double[] info; }

  /** stopAfter < 0 = never stop from the callback. */
  static Out gen(long h, String prompt, int maxTokens, float repeat, int stopAfter) {
    ByteArrayOutputStream bo = new ByteArrayOutputStream();
    final int[] pieces = {0};
    int n = B.nativeGenerate(h, prompt, maxTokens, 0f, 1f, 0, repeat, new LlamaBridge.TokenCallback() {
      public boolean onPiece(byte[] b) { bo.write(b, 0, b.length); pieces[0]++; return stopAfter < 0 || pieces[0] < stopAfter; }
      public boolean onProgress(int d, int t) { return true; }
    });
    Out o = new Out(); o.n = n; o.text = new String(bo.toByteArray(), java.nio.charset.StandardCharsets.UTF_8); o.info = B.nativeLookupInfo(h);
    return o;
  }

  static final String BASE = "the int value = result ; return value ; for i in value : result = result + value ; return result ; def the value ( result ) : return value ; ";

  static String prompt(int seed) {
    Random r = new Random(seed);
    String[] words = {"the", "int", "value", "result", "return", "for", "def", "if", "(", ")", ";", "=", "+", "a", "b", "er", "in"};
    StringBuilder sb = new StringBuilder();
    int len = 20 + r.nextInt(60);
    for (int i = 0; i < len; i++) sb.append(words[r.nextInt(words.length)]).append(' ');
    // a repeated block so there is something to copy
    String block = sb.substring(0, Math.min(sb.length(), 60));
    return sb + BASE + block + block;
  }

  static long totalRounds = 0, totalAcc = 0, totalDrafted = 0;
  static int runsChecked = 0, identical = 0;

  static void compareSeq(long h, String label, List<String> prompts, int maxTokens, float repeat, int stopAfter) {
    // off sequence (no reset between turns: tests the prompt cache too)
    B.nativeResetCache(h); B.nativeSetLookup(h, false);
    List<Out> off = new ArrayList<>();
    for (String p : prompts) off.add(gen(h, p, maxTokens, repeat, stopAfter));
    B.nativeResetCache(h); B.nativeSetLookup(h, true);
    List<Out> on = new ArrayList<>();
    for (String p : prompts) on.add(gen(h, p, maxTokens, repeat, stopAfter));
    for (int i = 0; i < prompts.size(); i++) {
      runsChecked++;
      Out a = off.get(i), b = on.get(i);
      check(a.n >= 0 && b.n >= 0, label + " turn " + i + " generation failed: " + B.nativeLastError());
      check(a.info[2] == 0.0, label + " off run must not use lookup");
      boolean same = a.text.equals(b.text) && a.n == b.n;
      if (same) identical++; else {
        int k = 0; while (k < Math.min(a.text.length(), b.text.length()) && a.text.charAt(k) == b.text.charAt(k)) k++;
        System.out.println("DIFF " + label + " turn " + i + " first char " + k + " off.n=" + a.n + " on.n=" + b.n);
        fails++;
      }
      totalRounds += (long) b.info[3]; totalDrafted += (long) b.info[4]; totalAcc += (long) b.info[5];
    }
  }

  public static void main(String[] args) {
    System.load(args[0]);
    String[] models = Arrays.copyOfRange(args, 1, args.length);
    for (String model : models) {
      System.out.println("== model " + model);
      B.nativeSetStreamingLoad(false);
      long h = B.nativeLoad(model, 2, 2048, 0);
      check(h != 0, "load " + B.nativeLastError());
      if (h == 0) continue;
      double[] info0 = B.nativeLookupInfo(h);
      check(info0 != null && info0[0] == 0.0, "plain dense load must allow lookup, block=" + (info0 == null ? -1 : info0[0]));
      for (int seed = 1; seed <= 12; seed++) {
        String p1 = prompt(seed);
        for (float rep : new float[]{1.0f, 1.15f}) {
          int[] maxes = {1, 2, 3, 40, 200};
          for (int max : maxes) {
            // single turn
            compareSeq(h, "seed" + seed + " rep" + rep + " max" + max, List.of(p1), max, rep, -1);
          }
          // a stop request from the callback in the middle, then more turns on the same cache
          for (int stop : new int[]{1, 5, 17}) {
            B.nativeResetCache(h); B.nativeSetLookup(h, false);
            Out a1 = gen(h, p1, 120, rep, stop);
            String p2 = p1 + a1.text + " the value = result ; ";
            String p3 = p2 + " return value ; for i in value : ";
            compareSeq(h, "seed" + seed + " rep" + rep + " stop" + stop, List.of(p1, p2, p3), 120, rep, stop);
            compareSeq(h, "seed" + seed + " rep" + rep + " stop" + stop + " full", List.of(p1, p2, p3), 120, rep, -1);
          }
        }
      }
      // block reasons: streaming load is never allowed
      B.nativeFree(h);
      B.nativeSetStreamingLoad(true);
      long hs = B.nativeLoad(model, 2, 2048, 0);
      check(hs != 0, "streaming load");
      if (hs != 0) {
        double[] si = B.nativeLookupInfo(hs);
        check(si[0] == 1.0, "streaming load must report block=1, got " + si[0]);
        B.nativeSetLookup(hs, true);
        Out o1 = gen(hs, prompt(3), 80, 1.0f, -1);
        check(o1.info[2] == 0.0 && o1.info[3] == 0.0, "streaming load must not run lookup");
        B.nativeSetLookup(hs, false);
        B.nativeResetCache(hs);
        Out o2 = gen(hs, prompt(3), 80, 1.0f, -1);
        check(o1.text.equals(o2.text), "streaming output unchanged by the toggle");
        B.nativeFree(hs);
      }
      // a small context: generation is cut by the context, not by max tokens
      B.nativeSetStreamingLoad(false);
      long hc = B.nativeLoad(model, 2, 256, 0);
      check(hc != 0, "small ctx load " + B.nativeLastError());
      if (hc != 0) {
        for (int seed = 1; seed <= 8; seed++) compareSeq(hc, "ctx256 seed" + seed, List.of(prompt(seed).substring(0, Math.min(prompt(seed).length(), 380))), 400, 1.0f, -1);
        B.nativeFree(hc);
      }
    }
    System.out.println("runs compared=" + runsChecked + " identical=" + identical + " lookup rounds=" + totalRounds + " drafted=" + totalDrafted + " accepted=" + totalAcc);
    check(totalRounds > 100, "lookup must have really run (rounds=" + totalRounds + ")");
    check(totalAcc > 50, "some guesses must have been accepted (acc=" + totalAcc + ")");
    System.out.println(fails == 0 ? "E2E ALL OK" : (fails + " E2E FAILURES"));
    System.exit(fails == 0 ? 0 : 1);
  }
}
