# Lookup decoding checks (host, not part of the Android build)

1. `g++ -std=c++17 -I ../../app/src/main/cpp lookup_test.cpp -o lookup_test && ./lookup_test`
   Unit tests of `ngram_lookup.h`: guess search, verification, the speed gate, and a simulation that decodes with and without guessing and compares the tokens.

2. End to end with the real `llama_jni.cpp` on a PC, against tiny random-weight models:
   - Build llama.cpp (same tag as the app) with `-DCMAKE_POSITION_INDEPENDENT_CODE=ON -DBUILD_SHARED_LIBS=OFF -DLLAMA_BUILD_TOOLS=ON`, targets `llama` and `mtmd`.
   - Link `app/src/main/cpp/llama_jni.cpp` into `libllama-android.so` with those static libraries (a stub `android/log.h` is enough) and the JDK's `jni.h`.
   - `python3 gen_model.py tiny.gguf 1` (random model) and `python3 gen_model.py bi.gguf 4 0.01` (a model that repeats heavily); needs numpy and llama.cpp's `gguf-py` on the path.
   - Put `LlamaBridge.java` under `com/example/llama/`, compile it with `E2E.java`, run `java -cp . E2E /path/libllama-android.so tiny.gguf bi.gguf`.
   It compares the text of lookup off and on for many prompts and prints `E2E ALL OK` only when every pair is identical and lookup really ran.

These models say nothing about phone speed. Use Models > Lookup test on the phone for that.
