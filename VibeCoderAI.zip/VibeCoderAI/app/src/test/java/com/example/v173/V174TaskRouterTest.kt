package com.example.v173

import com.example.agent.TaskRouter
import com.example.agent.TaskRouter.Pick
import org.junit.Assert.assertEquals
import org.junit.Test

class V174TaskRouterTest {
  @Test fun picks() {
    assertEquals(Pick.PHONE, TaskRouter.pick("open youtube and search diwali videos", true))
    assertEquals(Pick.BUILDER, TaskRouter.pick("open index.html", true))
    assertEquals(Pick.BUILDER, TaskRouter.pick("create a todo app", false))
    assertEquals(Pick.BUILDER, TaskRouter.pick("build a calculator", true))
    assertEquals(Pick.DEBUGGER, TaskRouter.pick("fix the login bug", true))
    assertEquals(Pick.REVIEWER, TaskRouter.pick("review my code and list problems", true))
    assertEquals(Pick.DESIGNER, TaskRouter.pick("make the UI beautiful with animations", true))
  }
}
