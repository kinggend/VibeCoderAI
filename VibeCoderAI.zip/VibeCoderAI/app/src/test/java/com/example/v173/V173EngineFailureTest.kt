package com.example.v173

import com.example.agent.EngineFailure
import com.example.agent.EngineHalt
import com.example.ui.components.RamBarMath
import com.example.ui.components.RamLevel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V173EngineFailureTest {
  @Test fun engineNoticesHaltTheRepairLoop() {
    assertTrue(EngineFailure.isHalting("Offline model was not loaded: Not enough free memory for this model: needs about 6625 MB, 5838 MB free."))
    assertTrue(EngineFailure.isHalting("Offline model is not ready: No model file found."))
    assertTrue(EngineFailure.isHalting("Cannot reach the remote server (timeout)."))
    assertTrue(EngineFailure.isHalting("partial text\n\n[Error: OutOfMemoryError: Failed to allocate 512 MB]"))
  }

  @Test fun normalModelProseNeverHalts() {
    assertFalse(EngineFailure.isHalting("This function frees memory; an out of memory error is handled in the catch block."))
    assertFalse(EngineFailure.isHalting("<file path=\"index.html\"><h1>Not enough memory? Try again</h1></file>"))
  }

  @Test fun memoryHaltOffersContextOnlyWhenItFits() {
    val fits = EngineFailure.memory(6625L * 1048576, 5838L * 1048576, 1024)
    assertEquals("Insufficient RAM", fits.title)
    assertEquals(1024, fits.suggestedContext)
    assertTrue(fits.message.startsWith("Please reduce Context Window to 1024, or switch to a smaller model."))
    val never = EngineFailure.memory(6625L * 1048576, 5838L * 1048576, null)
    assertNull(never.suggestedContext)
    assertTrue(never.message.startsWith("Even a small context does not fit."))
    assertEquals(6625L, never.neededMb); assertEquals(5838L, never.availableMb)
  }

  @Test fun noticeBecomesMemoryDialogOnlyWithAVerdict() {
    val t = "Offline model was not loaded: Not enough free memory"
    assertEquals(EngineHalt.Kind.MEMORY, EngineFailure.fromNotice(t, Triple(7_000_000_000L, 5_000_000_000L, 1024)).kind)
    assertEquals(EngineHalt.Kind.ENGINE, EngineFailure.fromNotice("[Engine error: boom]", null).kind)
  }

  @Test fun noRetriesLeftWhenHalted() {
    assertEquals(0, EngineFailure.attemptsLeft(3, 0, halted = true))
    assertEquals(2, EngineFailure.attemptsLeft(3, 1, halted = false))
    assertEquals(0, EngineFailure.attemptsLeft(3, 5, halted = false))
  }

  @Test fun ramBarLevels() {
    assertEquals(RamLevel.TOO_BIG, RamBarMath.level(6625, 5838))
    assertEquals(RamLevel.TIGHT, RamBarMath.level(5200, 5838))
    assertEquals(RamLevel.FITS, RamBarMath.level(3000, 5838))
    assertEquals(RamLevel.UNKNOWN, RamBarMath.level(3000, 0))
    assertEquals(0f, RamBarMath.ratio(3000, 0), 0f)
  }
}
