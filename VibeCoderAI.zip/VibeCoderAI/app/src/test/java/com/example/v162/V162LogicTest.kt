package com.example.v162

import com.example.agent.AgentRunManager
import com.example.agent.PlanCheck
import com.example.agent.RemoteContext
import com.example.agent.Truncation
import com.example.agent.notificationText
import com.example.data.model.OutputLevel
import com.example.data.model.SettingsState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class V162LogicTest {
  @get:Rule val tmp = TemporaryFolder()

  // ---- plan completion ----

  @Test fun plannedFilesComeFromSteps() {
    val steps = listOf("index.html: page structure and board", "styles.css: layout, colours", "app.js: chess rules and 3D rendering")
    assertEquals(listOf("index.html", "styles.css", "app.js"), PlanCheck.plannedFiles(steps))
    assertEquals(listOf("js/game.js"), PlanCheck.plannedFiles(listOf("Write js/game.js with the loop", "Wire js/game.js")))
  }

  @Test fun missingFindsAbsentAndEmptyFiles() {
    val root = tmp.newFolder("p")
    java.io.File(root, "index.html").writeText("<html></html>")
    java.io.File(root, "styles.css").writeText("   \n")
    assertEquals(listOf("styles.css", "app.js"), PlanCheck.missing(root, listOf("index.html", "styles.css", "app.js")))
  }

  @Test fun expectedAddsFilesIndexHtmlLoads() {
    val root = tmp.newFolder("q")
    java.io.File(root, "index.html").writeText(
      """<link rel="stylesheet" href="styles.css"><script src="./app.js"></script>""" +
        """<script src="https://cdn.example.com/x.js"></script><img src="data:image/png;base64,AA">"""
    )
    assertEquals(listOf("index.html", "styles.css", "app.js"), PlanCheck.expected(root, listOf("index.html: structure")))
  }

  @Test fun missingFileErrorsAreParsed() {
    val errs = listOf("Missing or unreadable file: app.js", "Uncaught ReferenceError: x (line 3)", "Missing or unreadable file: ?")
    assertEquals(listOf("app.js"), PlanCheck.missingFromErrors(errs))
  }

  // ---- truncation ----

  @Test fun openFileBlockIsDetected() {
    val text = "Plan.\n<file path=\"index.html\">\n<html></html>\n</file>\n<file path=\"app.js\">\nconst a = 1;\nfunction f() {"
    val cut = Truncation.openFile(text)
    assertNotNull(cut)
    assertEquals("app.js", cut!!.path)
    assertEquals("const a = 1;\nfunction f() {", cut.partial)
    assertEquals(text.indexOf("<file path=\"app.js\">"), cut.start)
    assertTrue(Truncation.isCut(null, text))
  }

  @Test fun closedRepliesAreNotCut() {
    val text = "<file path=\"app.js\">\nlet x = 1;\n</file>"
    assertNull(Truncation.openFile(text))
    assertFalse(Truncation.isCut("stop", text))
    assertTrue(Truncation.isCut("length", text))
  }

  @Test fun unclosedFenceMapsToFile() {
    val cut = Truncation.openFile("Here:\n```css\nbody { margin: 0;")
    assertEquals("styles.css", cut?.path)
    assertEquals("body { margin: 0;", cut?.partial)
    assertNull(Truncation.openFile("```js\nlet a\n```"))
  }

  @Test fun continuationIsCleanedAndClosed() {
    val (body, closed) = Truncation.cleanContinuation("```js\n  return 2;\n}\n```\nDone!")
    assertEquals("  return 2;\n}\n", body)
    assertTrue(closed)
    val (b2, c2) = Truncation.cleanContinuation("<file path=\"app.js\">\n  y();\n}\n</file>\nextra")
    assertEquals("  y();\n}\n", b2)
    assertTrue(c2)
    val (b3, c3) = Truncation.cleanContinuation("  more();\n")
    assertEquals("  more();\n", b3)
    assertFalse(c3)
  }

  @Test fun mergeDropsRepeatedOverlap() {
    val a = "function f() {\n  const board = makeBoard();\n"
    assertEquals(a + "  draw(board);\n}\n", Truncation.merge(a, "  const board = makeBoard();\n  draw(board);\n}\n"))
    assertEquals("abc\ndef", Truncation.merge("abc\n", "def"))
    assertEquals("x", Truncation.merge("x", ""))
    // Repeated last line with different indentation is dropped once.
    assertEquals("let total = 0;\nnext();", Truncation.merge("let total = 0;", "  let total = 0;\nnext();"))
  }

  // ---- remote context ----

  @Test fun remoteContextUsesServerValueElseDefault() {
    assertEquals(131072, RemoteContext.resolve(131072))
    assertEquals(RemoteContext.DEFAULT_CTX, RemoteContext.resolve(null))
    assertEquals(RemoteContext.DEFAULT_CTX, RemoteContext.resolve(12))
  }

  @Test fun remoteMaxOutFollowsLevelAndContext() {
    assertEquals(16384, RemoteContext.maxOut(OutputLevel.MAX, 131072))
    assertEquals(4096, RemoteContext.maxOut(OutputLevel.MAX, 8192))
    assertEquals(1024, RemoteContext.maxOut(OutputLevel.LOW, 32768))
  }

  @Test fun effectiveSettingsIgnorePhoneContextForRemote() {
    val phone = SettingsState(backendMode = "remote", contextLength = 2048, maxOutputTokens = 4096, outputLevel = "max")
    val eff = RemoteContext.effective(phone, 131072)
    assertEquals(131072, eff.contextLength)
    assertEquals(16384, eff.maxOutputTokens)
    val local = SettingsState(backendMode = "local", contextLength = 2048, maxOutputTokens = 4096)
    assertEquals(local, RemoteContext.effective(local, 131072))
    assertEquals(1448, RemoteContext.localMaxOut(local))
    assertEquals(1536, RemoteContext.localMaxOut(SettingsState(contextLength = 4096, maxOutputTokens = 1536)))
  }

  // ---- run manager ----

  @Test fun runStateSurvivesObserverResubscription() = runBlocking {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    try {
      val mgr = AgentRunManager(scope)
      val gate = CompletableDeferred<Unit>()
      val job = mgr.start("chess") { gate.await() }
      assertNotNull(job)
      // First observer (Chat screen) sees the run, then goes away (tab switch).
      mgr.step(2, 3, "Writing styles.css")
      val first = withTimeout(2000) { mgr.state.first { it.step == 2 } }
      assertTrue(first.running)
      // A new observer (screen back) gets the live state, not a reset one.
      val again = withTimeout(2000) { mgr.state.first() }
      assertEquals(AgentRunManager.Progress(true, "chess", 2, 3, "Writing styles.css"), again)
      assertTrue(mgr.isRunning)
      // A second run is refused while one is going.
      assertNull(mgr.start("other") {})
      gate.complete(Unit)
      job!!.join()
      assertFalse(withTimeout(2000) { mgr.state.first { !it.running } }.running)
    } finally {
      scope.cancel()
    }
  }

  @Test fun cancelledRunGoesIdle() = runBlocking {
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    try {
      val mgr = AgentRunManager(scope)
      val job = mgr.start(null) { CompletableDeferred<Unit>().await() }!!
      mgr.cancel()
      job.join()
      assertFalse(mgr.isRunning)
      assertEquals(AgentRunManager.Progress(), withTimeout(2000) { mgr.state.first { !it.running } })
      assertNotNull(mgr.start(null) {}) // a new run can start
    } finally {
      scope.cancel()
    }
  }

  @Test fun notificationTextNamesProjectAndStep() {
    assertEquals(
      "VibeCoder is building chess" to "Step 2 of 3 · Writing styles.css",
      AgentRunManager.Progress(true, "chess", 2, 3, "Writing styles.css").notificationText()
    )
    assertEquals("VibeCoder is working" to "Starting", AgentRunManager.Progress(true).notificationText())
  }
}
