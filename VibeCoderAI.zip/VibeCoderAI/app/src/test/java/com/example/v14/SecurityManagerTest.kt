package com.example.v14

import com.example.security.SecurityManager
import com.example.security.ValidationResult
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class SecurityManagerTest {
  @get:Rule val tmp = TemporaryFolder()
  private val sm = SecurityManager()

  @Test fun insidePathIsSafe() {
    val root = tmp.newFolder("demo")
    assertTrue(sm.isPathSafe(File(root, "src/a.kt"), root))
    assertTrue(sm.isPathSafe(root, root))
  }

  @Test fun traversalIsBlocked() {
    val root = tmp.newFolder("demo")
    assertFalse(sm.isPathSafe(File(root, "../outside.txt"), root))
    assertFalse(sm.isPathSafe(File(root, "a/../../x"), root))
    assertFalse(sm.isPathSafe(File("/etc/passwd"), root))
  }

  @Test fun siblingWithSamePrefixIsBlocked() {
    val root = tmp.newFolder("demo")
    tmp.newFolder("demo2")
    assertFalse("demo2 must not count as inside demo", sm.isPathSafe(File(root.parentFile, "demo2/x.txt"), root))
  }

  @Test fun forbiddenCommandsAreBlocked() {
    for (c in listOf("rm -rf /", "mkfs.ext4 /dev/sda", "dd if=/dev/zero of=x", "reboot", "shutdown -h now", "cat /etc/passwd", "ls /system", "cat ../secret", "chmod 777 /")) {
      assertTrue("should block: $c", sm.validateCommand(c) is ValidationResult.Blocked)
    }
    assertTrue(sm.validateCommand("   ") is ValidationResult.Blocked)
  }

  @Test fun destructiveCommandsNeedApproval() {
    assertTrue(sm.validateCommand("rm notes.txt") is ValidationResult.RequiresUserApproval)
    assertTrue(sm.validateCommand("git clean -fd") is ValidationResult.RequiresUserApproval)
  }

  @Test fun harmlessCommandsPass() {
    for (c in listOf("ls -la", "pwd", "echo hi", "cat index.html")) {
      assertTrue("should pass: $c", sm.validateCommand(c) is ValidationResult.Approved)
    }
  }

  @Test fun fileOperationRules() {
    val root = tmp.newFolder("demo")
    val existing = File(root, "a.txt").apply { writeText("x") }
    assertTrue(sm.validateFileOperation(File(root, "new.txt"), root) is ValidationResult.Approved)
    assertTrue(sm.validateFileOperation(existing, root) is ValidationResult.RequiresUserApproval)
    assertTrue(sm.validateFileOperation(existing, root, isDelete = true) is ValidationResult.RequiresUserApproval)
    assertTrue(sm.validateFileOperation(File(root, "../x"), root) is ValidationResult.Blocked)
  }
}
