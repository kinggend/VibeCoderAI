package com.example.v173

import com.example.agent.RunBoard
import com.example.agent.RunKind
import com.example.agent.RunRecord
import com.example.agent.RunStatus
import com.example.phone.PhoneTips
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class V175RunBoardTest {
  private val now = 10L * RunBoard.DAY + 5000

  @Test fun sectionsSplitWorkingDoneArchived() {
    val r1 = RunRecord("1", RunKind.PHONE, "a", status = RunStatus.WORKING, startedAt = now - 1000)
    val r2 = RunRecord("2", RunKind.CODING, "b", status = RunStatus.DONE, startedAt = now - 3 * RunBoard.DAY)
    val r3 = RunRecord("3", RunKind.CHAT, "c", status = RunStatus.FAILED, startedAt = now - 2000, archived = true)
    val s = RunBoard.sections(listOf(r1, r2, r3))
    assertEquals(1, s.working.size); assertEquals(1, s.done.size); assertEquals(1, s.archived.size)
  }

  @Test fun timeAndJson() {
    assertEquals("3m ago", RunBoard.ago(now, now - 3 * 60_000))
    assertEquals("1m 5s", RunBoard.duration(65_000))
    val r = RunRecord("2", RunKind.CODING, "b", status = RunStatus.DONE, startedAt = 5L, endedAt = 9L)
    assertEquals(r, RunRecord.fromJson(r.toJson()))
    assertEquals(RunStatus.STOPPED, RunBoard.phoneStatus("Stopped by you"))
  }

  @Test fun phoneTips() {
    assertNotNull(PhoneTips.forApp("My Files", "com.sec.android.app.myfiles"))
    assertNull(PhoneTips.forApp("Calculator", "x"))
    assertNull(PhoneTips.stuckHint(0))
    assertNotNull(PhoneTips.stuckHint(4))
  }
}

class V176PhoneHintsTest {
  @Test fun systemSwitchesPointToQuickSettings() {
    assertNotNull(PhoneTips.forTask("Turn on the flashlight"))
    assertNotNull(PhoneTips.forTask("wifi off cheyyi"))
    assertNull(PhoneTips.forTask("Open YouTube"))
    assertNotNull(PhoneTips.forApp("System Home Screen", "com.miui.home"))
  }
  @Test fun quickSettingsActionParses() {
    assertEquals(com.example.phone.PhoneAction.QuickSettings, com.example.phone.PhoneActionParser.parse("{\"action\":\"quick_settings\"}"))
  }
}
