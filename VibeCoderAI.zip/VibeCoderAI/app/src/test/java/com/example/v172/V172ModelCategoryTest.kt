package com.example.v172

import com.example.data.downloader.ModelCategories
import com.example.data.downloader.ModelCategory
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V172ModelCategoryTest {
  private fun tags(n: String) = ModelCategories.tagsFor(n)

  @Test fun coderIsCodingAndLight() {
    val t = tags("Qwen/Qwen2.5-Coder-3B-Instruct-GGUF")
    assertTrue(ModelCategory.CODING in t)
    assertTrue(ModelCategory.LIGHT in t)
  }

  @Test fun r1IsReasoning() {
    assertTrue(ModelCategory.REASONING in tags("unsloth/DeepSeek-R1-Distill-Qwen-7B-GGUF"))
    assertTrue(ModelCategory.REASONING in tags("bartowski/QwQ-32B-GGUF"))
  }

  @Test fun vlIsVisionButNotFalsePositive() {
    assertTrue(ModelCategory.VISION in tags("unsloth/Qwen2.5-VL-3B-Instruct-GGUF"))
    assertFalse(ModelCategory.VISION in tags("someone/Bevl-7B-GGUF"))
  }

  @Test fun longContext() {
    assertTrue(ModelCategory.LONG in tags("unsloth/Qwen2.5-7B-Instruct-128K-GGUF"))
  }

  @Test fun unknownFallsBackToGeneral() {
    assertEquals(listOf(ModelCategory.GENERAL), tags("foo/Bar-70B-Instruct-GGUF"))
  }

  @Test fun paramsParsing() {
    assertEquals(1.5, ModelCategories.paramsBillions("qwen2.5-1.5b-instruct")!!, 0.0)
    assertEquals(null, ModelCategories.paramsBillions("gemma-instruct"))
  }
}
