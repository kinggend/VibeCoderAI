package com.example.v161

import com.example.chat.ChatOptionsLabels
import com.example.chat.SpeechText
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class V161LogicTest {
  private val note = SpeechText.CODE_NOTE

  @Test fun `code fence is replaced by the on-screen note`() {
    val out = SpeechText.forSpeech("Here you go:\n```js\nconst a = 1;\nconsole.log(a)\n```\nTap Preview.")
    assertEquals("Here you go: $note Tap Preview.", out)
    assertFalse(out.contains("const"))
  }

  @Test fun `unclosed fence while streaming still hides the code`() {
    val out = SpeechText.forSpeech("Writing it now\n```html\n<div>half")
    assertEquals("Writing it now. $note", out)
  }

  @Test fun `agent file blocks and tool tags are not read aloud`() {
    val out = SpeechText.forSpeech("Done.\n<file path=\"app.js\">let x = 2</file>\n<file path=\"index.html\"><p>hi</p></file>\n<tool name=\"RunCheck\"/>")
    assertEquals("Done. $note", out) // two blocks in a row collapse into one note
  }

  @Test fun `markdown emphasis headings lists links and inline code are cleaned`() {
    val md = "## Plan\n- **Add** a `Button`\n- Use *italic* and ~~old~~ text\n1. See [docs](https://x.dev/a)\n> quoted"
    assertEquals("Plan. Add a Button. Use italic and old text. See docs. quoted.", SpeechText.forSpeech(md))
  }

  @Test fun `snake_case identifiers keep their underscores, real emphasis loses them`() {
    assertEquals("Rename my_var_name now, it is important.", SpeechText.forSpeech("Rename my_var_name now, it is _important_."))
  }

  @Test fun `tables become comma separated rows and bare urls become link`() {
    val out = SpeechText.forSpeech("| Name | Size |\n|---|---:|\n| app.js | 2 KB |\nMore at https://example.com/x?y=1")
    assertEquals("Name, Size. app.js, 2 KB. More at link.", out)
  }

  @Test fun `think tags and html are dropped`() {
    assertEquals("Answer is 4.", SpeechText.forSpeech("<think>2+2 hmm</think>Answer is <b>4</b>."))
  }

  @Test fun `chunks respect the engine limit at sentence ends`() {
    val text = (1..50).joinToString(" ") { "Sentence number $it is here." }
    val parts = SpeechText.chunks(text, 100)
    assertTrue(parts.all { it.length <= 100 })
    assertEquals(text, parts.joinToString(" "))
    assertTrue(parts.all { it.endsWith(".") })
  }

  @Test fun `a sentence longer than the limit is cut at a space`() {
    val long = (1..40).joinToString(" ") { "word$it" }
    val parts = SpeechText.chunks(long, 50)
    assertTrue(parts.all { it.length <= 50 })
    assertEquals(long, parts.joinToString(" "))
  }

  @Test fun `empty reply speaks nothing`() {
    assertEquals("", SpeechText.forSpeech("   \n"))
    assertTrue(SpeechText.chunks("").isEmpty())
  }

  @Test fun `header line and chip come from the same state`() {
    assertEquals("Remote · Builder · Max", ChatOptionsLabels.headerLine(true, "Builder", "Max", false))
    assertEquals("Offline · Debugger · High · Think", ChatOptionsLabels.headerLine(false, "Debugger", "High", true))
    assertEquals("Builder · Max", ChatOptionsLabels.chip("Builder", "Max"))
    assertEquals("Debugger · Ultra", ChatOptionsLabels.chip("Debugger", "Ultra High"))
    assertEquals("Builder · High", ChatOptionsLabels.chip("Builder", "High"))
  }
}
