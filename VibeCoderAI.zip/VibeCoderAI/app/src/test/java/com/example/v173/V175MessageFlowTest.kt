package com.example.v173

import com.example.phone.FastPaths
import com.example.phone.MessageFlow
import com.example.phone.PhoneAction
import com.example.phone.CompactScreen
import com.example.phone.ScreenElement
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class V175MessageFlowTest {
  private fun el(id: Int, l: String, e: Boolean = false) = ScreenElement(id, "btn", l, true, e, false, false, 0, 0)
  private fun scr(vararg x: ScreenElement) = CompactScreen("", x.toList(), 0)

  @Test fun parsesTeluguAndEnglish() {
    assertEquals(FastPaths.Route.Message("WhatsApp", "Ravi", "hello"), FastPaths.route("WhatsApp lo Ravi ki hello ani msg pettu"))
    assertEquals(FastPaths.Route.Message("WhatsApp", "Ravi", "hello"), FastPaths.route("WhatsApp lo hello ani Ravi ki msg pettu"))
    assertEquals(FastPaths.Route.Message("WhatsApp", "Ravi", "hi bro"), FastPaths.route("send hi bro to Ravi on whatsapp"))
  }

  @Test fun scriptRunsSearchPickTypeSend() {
    val f = MessageFlow("Ravi", "hello"); val pk = "com.whatsapp"
    assertEquals(PhoneAction.Tap(1), f.next(scr(el(1, "Search"), el(2, "Chats"), el(3, "Camera")), pk))
    assertEquals(PhoneAction.Type(1, "Ravi"), f.next(scr(el(1, "Search", true), el(2, "x"), el(3, "y")), pk))
    assertEquals(PhoneAction.Tap(2), f.next(scr(el(1, "Search", true), el(2, "Ravi Kumar"), el(3, "other")), pk))
    assertEquals(PhoneAction.Type(1, "hello"), f.next(scr(el(1, "Message", true), el(2, "Voice message"), el(3, "Attach")), pk))
    assertEquals(PhoneAction.Tap(2), f.next(scr(el(1, "Message", true), el(2, "Send"), el(3, "Attach")), pk))
    assertTrue(f.next(scr(el(1, "Message", true), el(2, "Send"), el(3, "Attach")), pk) is PhoneAction.Done)
  }
}
