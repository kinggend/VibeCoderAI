package com.example.v14

import com.example.agent.ActionKind
import com.example.agent.ApprovalPolicy
import com.example.agent.ToolCalls
import com.example.build.ErrorAnalyzer
import com.example.data.model.SettingsState
import com.example.project.ZipImporter
import com.example.ui.components.friendlyModelName
import com.example.ui.components.middleEllipsize
import com.example.ui.components.splitFileExtension
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

class AnalyzeAndMiscTest {
  @get:Rule val tmp = TemporaryFolder()

  @Test fun analyzeKotlinJavacAndConsole() {
    val log = """
      e: /p/app/src/Main.kt:24:12: Unresolved reference: foo
      e: file:///p/app/src/B.kt:3:5 Unresolved reference 'bar'.
      /p/Foo.java:15: error: ';' expected
      src/a.ts(3,7): error TS1005: ',' expected.
      Uncaught ReferenceError: x is not defined (line 12)
      error: index.html:9: Missing file: app.js
      BUILD FAILED
    """.trimIndent()
    val errs = ErrorAnalyzer.parse(log)
    assertEquals(6, errs.size)
    assertEquals("/p/app/src/Main.kt", errs[0].filePath); assertEquals(24, errs[0].lineNumber); assertEquals(12, errs[0].columnNumber)
    assertEquals("/p/app/src/B.kt", errs[1].filePath); assertEquals(3, errs[1].lineNumber)
    assertEquals("/p/Foo.java", errs[2].filePath); assertEquals(15, errs[2].lineNumber)
    assertEquals("src/a.ts", errs[3].filePath)
    assertEquals(12, errs[4].lineNumber)
    assertEquals("index.html", errs[5].filePath); assertEquals("Missing file: app.js", errs[5].errorMessage)
    assertEquals("Main.kt:24:12: Unresolved reference: foo", ErrorAnalyzer.format(errs).lines().first())
  }

  @Test fun analyzeDeduplicatesAndHandlesClean() {
    val line = "e: /a/X.kt:1:1: boom"
    assertEquals(1, ErrorAnalyzer.parse("$line\n$line").size)
    assertTrue(ErrorAnalyzer.parse("BUILD SUCCESSFUL").isEmpty())
    assertEquals("No errors found in the log.", ErrorAnalyzer.format(emptyList()))
  }

  @Test fun friendlyNames() {
    assertEquals("Qwen 7B Coder", friendlyModelName("qwen2.5-coder-7b-instruct-q5_k_m"))
    assertEquals("Llama 8B Instruct", friendlyModelName("Meta-Llama-3.1-8B-Instruct-Q4_K_M.gguf"))
    assertEquals("DeepSeek 1.3B Coder", friendlyModelName("deepseek-coder-1.3b-instruct.Q8_0"))
    assertEquals("", friendlyModelName(null))
    assertEquals("", friendlyModelName("   "))
    assertEquals("My Custom Model", friendlyModelName("my-custom-model-q4_k_m"))
  }

  @Test fun middleEllipsisSplit() {
    assertEquals("build" to ".gradle.kts", splitFileExtension("build.gradle.kts"))
    assertEquals(".gitignore" to "", splitFileExtension(".gitignore"))
    assertEquals("Makefile" to "", splitFileExtension("Makefile"))
    assertEquals("index" to ".html", splitFileExtension("index.html"))
    assertEquals("Mai\u2026ty.kt", middleEllipsize("MainActivity", ".kt", 5))
    assertEquals("\u2026.kt", middleEllipsize("MainActivity", ".kt", 0))
    assertEquals("MainActivity".length, middleEllipsize("MainActivity", "", 99).length - 1)
  }

  @Test fun approvalPolicyDefaults() {
    val s = SettingsState()
    assertFalse(ApprovalPolicy.needsApproval(ActionKind.NEW_FILE, s))
    assertTrue(ApprovalPolicy.needsApproval(ActionKind.EDIT_FILE, s))
    assertTrue(ApprovalPolicy.needsApproval(ActionKind.COMMAND, s))
    val loose = s.copy(autoApproveSafeEdits = true, autoApproveNewFiles = false)
    assertFalse(ApprovalPolicy.needsApproval(ActionKind.EDIT_FILE, loose))
    assertTrue(ApprovalPolicy.needsApproval(ActionKind.NEW_FILE, loose))
    assertTrue("deletes always ask", ApprovalPolicy.needsApproval(ActionKind.DELETE_FILE, loose))
    assertTrue("commands always ask", ApprovalPolicy.needsApproval(ActionKind.COMMAND, loose))
    assertTrue("repair always asks", ApprovalPolicy.needsApproval(ActionKind.REPAIR_PATCH, loose))
  }

  @Test fun toolCallParsing() {
    val c = ToolCalls.parse("Plan.\n<tool name=\"EditFile\" path=\"app.js\"><find>a</find><replace>b</replace></tool>")!!
    assertEquals("editfile", c.name)
    assertEquals("app.js", c.attrs["path"])
    assertEquals("a", ToolCalls.section(c.arg, "find"))
    assertEquals("b", ToolCalls.section(c.arg, "replace"))
    val legacy = ToolCalls.parse("<tool name=\"read_file\">index.html</tool>")!!
    assertEquals("read_file", legacy.name)
    assertEquals("ReadFile", ToolCalls.canonical(legacy.name))
    assertEquals("RunCommand", ToolCalls.canonical("terminal_run"))
    assertEquals("SearchFiles", ToolCalls.canonical("search"))
    assertNull(ToolCalls.parse("no tools here"))
  }

  private fun zipOf(vararg entries: Pair<String, String>): File {
    val f = tmp.newFile("t${System.nanoTime()}.zip")
    ZipOutputStream(FileOutputStream(f)).use { z ->
      for ((n, body) in entries) { z.putNextEntry(ZipEntry(n)); z.write(body.toByteArray()); z.closeEntry() }
    }
    return f
  }

  @Test fun zipImportExtractsSafeEntries() {
    val target = File(tmp.root, "proj")
    val n = ZipImporter.extract(zipOf("index.html" to "<h1>", "js/app.js" to "1"), target)
    assertEquals(2, n)
    assertEquals("1", File(target, "js/app.js").readText())
  }

  @Test fun zipSlipIsRejectedAndNothingWritten() {
    val target = File(tmp.root, "proj2")
    try {
      ZipImporter.extract(zipOf("ok.txt" to "fine", "../../evil.txt" to "x"), target)
      fail("expected SecurityException")
    } catch (e: SecurityException) {
      assertTrue(e.message!!.contains("evil"))
    }
    assertFalse(File(target, "ok.txt").exists())
    assertFalse(File(tmp.root, "evil.txt").exists())
    assertNull(ZipImporter.resolveEntry(target, "/abs/path"))
    assertNull(ZipImporter.resolveEntry(target, "C:\\win.txt"))
    assertNull(ZipImporter.resolveEntry(target, "a/../../b"))
  }
}
