package com.example.v14

import com.example.agent.ApprovalGate
import com.example.agent.ApprovalItem
import com.example.agent.ActionKind
import com.example.agent.ApprovalRequest
import com.example.context.RelevantFiles
import com.example.llama.MemoryEstimator
import com.example.project.EditorBridge
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.yield
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder

class V14HelpersTest {
  @get:Rule val tmp = TemporaryFolder()
  private val MB = 1024L * 1024L

  @Test fun memoryEstimateFitsAndSuggests() {
    val file = 400 * MB
    val need4k = MemoryEstimator.neededBytes(file, 4096)
    assertTrue(need4k > file)
    assertTrue(MemoryEstimator.check(file, 4096, need4k + MB).fits)
    val v = MemoryEstimator.check(file, 8192, MemoryEstimator.neededBytes(file, 2048) + MB)
    assertFalse(v.fits)
    assertEquals(2048, v.suggestedContext)
    assertNull(MemoryEstimator.check(4096 * MB, 4096, 100 * MB).suggestedContext)
    assertTrue("unknown memory never blocks", MemoryEstimator.check(file, 4096, 0).fits)
  }

  @Test fun editorInsertAtCursorAndEnd() {
    assertEquals("ab\nX\ncd" to 4, EditorBridge.insertAt("abcd", 2, "X"))
    assertEquals("abc\nX" to 5, EditorBridge.insertAt("abc", null, "X"))
    assertEquals("X\n" to 2, EditorBridge.insertAt("", 99, "X\n"))
  }

  @Test fun editorFileNames() {
    assertEquals("Snippet.kt", EditorBridge.suggestFileName("kotlin"))
    assertEquals("snippet.js", EditorBridge.suggestFileName("JavaScript"))
    assertEquals("snippet.txt", EditorBridge.suggestFileName(""))
    val dir = tmp.newFolder("p")
    java.io.File(dir, "a.js").writeText("1")
    java.io.File(dir, "a-1.js").writeText("1")
    assertEquals("a-2.js", EditorBridge.uniqueName(dir, "a.js"))
    assertEquals("b.js", EditorBridge.uniqueName(dir, "b.js"))
  }

  @Test fun relevantFilesRanking() {
    val files = listOf("README.md", "app.js", "index.html", "styles.css", "lib/chart.js")
    assertEquals("lib/chart.js", RelevantFiles.rank(files, "fix the bug in chart.js").first())
    assertEquals("styles.css", RelevantFiles.rank(files, "change the colour theme").first())
    assertEquals(0, RelevantFiles.score("README.md", "make the button work"))
  }

  @Test fun approvalGateApproveRejectAndCancel() = runBlocking {
    val gate = ApprovalGate()
    val req = ApprovalRequest(title = "t", reason = "r", items = listOf(ApprovalItem(ActionKind.COMMAND, command = "ls")), messageId = "m1")
    val answer = async { gate.request(req) }
    while (gate.pending.value == null) yield()
    assertFalse("wrong id is ignored", gate.resolve("other", true))
    assertTrue(gate.resolveForMessage("m1", true))
    assertTrue(withTimeout(2000) { answer.await() })
    assertNull(gate.pending.value)

    val second = async { gate.request(req.copy(id = "2")) }
    while (gate.pending.value == null) yield()
    gate.rejectAll()
    assertFalse(withTimeout(2000) { second.await() })

    // Cancelling the waiting agent clears the dialog: no deadlock, nothing left pending.
    val third = async { gate.request(req.copy(id = "3")) }
    while (gate.pending.value == null) yield()
    third.cancel()
    delay(50)
    assertNull(gate.pending.value)
    // The gate still works afterwards.
    val fourth = async { gate.request(req.copy(id = "4")) }
    while (gate.pending.value == null) yield()
    gate.resolve("4", false)
    assertFalse(withTimeout(2000) { fourth.await() })
  }
}
