package com.example.v172

import com.example.data.downloader.Mmproj
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V172MmprojTest {
  @Test fun detectsMmproj() {
    assertTrue(Mmproj.isMmproj("mmproj-Qwen3VL-4B-Instruct-F16.gguf"))
    assertTrue(Mmproj.isMmproj("Qwen3-VL-8B-Instruct-abliterated.mmproj-Q8_0.gguf"))
    assertFalse(Mmproj.isMmproj("Qwen3VL-4B-Instruct-Q4_K_M.gguf"))
  }

  @Test fun officialQwenNaming() {
    val m = "Qwen3VL-4B-Instruct-Q4_K_M.gguf"
    val all = listOf("mmproj-Qwen3VL-4B-Instruct-F16.gguf", "mmproj-Qwen3VL-4B-Instruct-Q8_0.gguf", "mmproj-Qwen3VL-8B-Instruct-F16.gguf")
    assertEquals("mmproj-Qwen3VL-4B-Instruct-Q8_0.gguf", Mmproj.pair(m, all))
  }

  @Test fun communityNaming() {
    val m = "Qwen3-VL-8B-Instruct-abliterated.Q4_K_M.gguf"
    val all = listOf("Qwen3-VL-8B-Instruct-abliterated.mmproj-Q8_0.gguf", "Qwen3-VL-8B-Instruct-abliterated.mmproj-f16.gguf")
    assertEquals("Qwen3-VL-8B-Instruct-abliterated.mmproj-Q8_0.gguf", Mmproj.pair(m, all))
  }

  @Test fun unrelatedModelGetsNoMmproj() {
    assertNull(Mmproj.pair("qwen2.5-coder-3b-instruct-q4_0.gguf", listOf("mmproj-Qwen3VL-4B-Instruct-F16.gguf")))
    assertNull(Mmproj.pair("gemma-4-E4B_q4_0-it.gguf", listOf("mmproj-Qwen3VL-4B-Instruct-F16.gguf")))
  }

  @Test fun mmprojFileIsNeverAModel() {
    assertNull(Mmproj.pair("mmproj-Qwen3VL-4B-Instruct-F16.gguf", listOf("mmproj-Qwen3VL-4B-Instruct-F16.gguf")))
  }

  @Test fun downloadChoosesSmallGoodOne() {
    val repo = listOf("Qwen3VL-4B-Instruct-Q4_K_M.gguf", "mmproj-Qwen3VL-4B-Instruct-F16.gguf", "mmproj-Qwen3VL-4B-Instruct-Q8_0.gguf")
    assertEquals("mmproj-Qwen3VL-4B-Instruct-Q8_0.gguf", Mmproj.forDownload("Qwen3VL-4B-Instruct-Q4_K_M.gguf", repo))
    assertNull(Mmproj.forDownload("x.gguf", listOf("x.gguf")))
  }
}
