package com.example.v172

import org.junit.Assert.assertTrue
import org.junit.Test

/** v1.7.6: the YouTube script was removed (the model drives the app like a person); launcher label matching stays. */
class V172YouTubeFlowTest {
  @Test fun launcherLabelMatching() {
    assertTrue(com.example.phone.AppMatcher.labelMatches("YouTube", "YouTube"))
    assertTrue(com.example.phone.AppMatcher.labelMatches("YouTube, 2 notifications", "YouTube"))
    assertTrue(!com.example.phone.AppMatcher.labelMatches("YouTube Music", "YouTube"))
    assertTrue(!com.example.phone.AppMatcher.labelMatches(null, "YouTube"))
  }
}
