package com.example.v172

import com.example.phone.PhoneAction
import com.example.phone.PhoneActionParser
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class V172PhoneXYTest {
  @Test fun tapXyParsesWithLabel() {
    val a = PhoneActionParser.parse("""{"action":"tap_xy","x":210,"y":640,"label":"Add clip"}""")
    assertEquals(PhoneAction.TapXY(210, 640, "Add clip"), a)
  }

  @Test fun tapXyNeedsLabel() {
    try { PhoneActionParser.parse("""{"action":"tap_xy","x":1,"y":2}"""); fail("label is required") }
    catch (e: PhoneActionParser.ParseError) { assertTrue(e.message!!.contains("label")) }
  }

  @Test fun longPressXyParses() {
    val a = PhoneActionParser.parse("""{"action":"long_press_xy","x":5,"y":6,"label":"clip"}""")
    assertEquals(PhoneAction.LongPressXY(5, 6, "clip"), a)
  }

  @Test fun describeMentionsLabelAndPoint() {
    assertEquals("Tap \"Add clip\" at (210,640)", PhoneAction.TapXY(210, 640, "Add clip").describe(null))
  }
}
