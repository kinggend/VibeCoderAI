package com.example.v15

import com.example.agent.ActionKind
import com.example.agent.ApprovalPolicy
import com.example.agent.HistoryEntry
import com.example.agent.MiniJson
import com.example.agent.ProjectBackups
import com.example.agent.ProjectHistory
import com.example.agent.SkillCodec
import com.example.agent.SkillFile
import com.example.agent.Skills
import com.example.data.Estimate
import com.example.data.model.OutputPresets
import com.example.data.model.SettingsState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class V15LogicTest {
  @get:Rule val tmp = TemporaryFolder()

  // ---- skill JSON ----

  @Test fun skillRoundTrip() {
    val s = SkillFile("Dark toggle", "Adds a theme switch", "Always add a \"dark mode\" toggle.\nUse localStorage.")
    val back = SkillCodec.decode(SkillCodec.encode(s).toByteArray()).getOrThrow()
    assertEquals(s, back)
  }

  @Test fun skillRejectsBadFiles() {
    fun bad(json: String) = assertTrue(json, SkillCodec.decode(json.toByteArray()).isFailure)
    bad("")
    bad("[]")
    bad("""{"name":"a","description":"b"}""") // missing promptText
    bad("""{"name":"a","description":"b","promptText":"c","autoRun":true}""") // extra key
    bad("""{"name":"a","description":"b","promptText":5}""") // wrong type
    bad("""{"name":"a","description":"b","promptText":{"x":"y"}}""") // nested
    bad("""{"name":"a","name":"z","description":"b","promptText":"c"}""") // duplicate key
    bad("""{"name":"a","description":"b","promptText":"c"} trailing""")
    bad("""{"name":"   ","description":"b","promptText":"c"}""") // blank name
    bad("""{"name":"a\nb","description":"b","promptText":"c"}""") // control char in name
    bad("""{"name":"${"n".repeat(41)}","description":"","promptText":"c"}""")
    bad("""{"name":"a","description":"${"d".repeat(121)}","promptText":"c"}""")
    bad("""{"name":"a","description":"","promptText":"${"p".repeat(601)}"}""")
    // Over the file size limit even though the JSON itself would be fine.
    bad("""{"name":"a","description":"","promptText":"c"}""" + " ".repeat(SkillCodec.MAX_FILE_BYTES))
    assertTrue(SkillCodec.decode(byteArrayOf(0xC3.toByte(), 0x28)).isFailure) // invalid UTF-8
  }

  @Test fun skillAcceptsLimitsAndBom() {
    val json = "\uFEFF" + """{"promptText":"${"p".repeat(600)}","name":"${"n".repeat(40)}","description":""}"""
    val s = SkillCodec.decode(json.toByteArray()).getOrThrow()
    assertEquals(40, s.name.length)
    assertEquals(600, s.promptText.length)
  }

  @Test fun skillNameCollisionIsCaseInsensitive() {
    val existing = Skills.builtIn.map { it.id to it.name } + ("c_1" to "My Skill")
    assertEquals(8, Skills.builtIn.size)
    assertTrue(SkillCodec.collides("bug FIXER", existing))
    assertTrue(SkillCodec.collides("  web app builder ", existing))
    assertTrue(SkillCodec.collides("my skill", existing))
    assertFalse("editing keeps its own name", SkillCodec.collides("MY SKILL", existing, ignoreId = "c_1"))
    assertFalse(SkillCodec.collides("Brand new", existing))
  }

  @Test fun exportFileName() {
    assertEquals("dark-mode-toggle.skill.json", SkillCodec.fileName("Dark Mode / Toggle!"))
    assertEquals("skill.skill.json", SkillCodec.fileName("తెలుగు"))
  }

  @Test fun jsonEscapesControlCharacters() {
    val enc = MiniJson.encode(listOf("k" to "a\u0001\"\\\n"))
    assertEquals("a\u0001\"\\\n", MiniJson.parseObject(enc)["k"])
  }

  // ---- presets ----

  @Test fun presetMatching() {
    val d = SettingsState()
    assertEquals("Coding", OutputPresets.label(d)) // defaults are the Coding preset
    val balanced = OutputPresets.apply(d, OutputPresets.all[1])
    assertEquals("Balanced", OutputPresets.label(balanced))
    assertEquals(40, balanced.topK) // Balanced leaves Top-K alone
    assertEquals("Creative", OutputPresets.label(d.copy(temperature = 0.8f, topP = 1.0f, topK = 7)))
    assertEquals("Custom", OutputPresets.label(d.copy(temperature = 0.25f)))
    assertEquals("Custom", OutputPresets.label(d.copy(topK = 41))) // Coding pins Top-K
  }

  // ---- strict mode ----

  @Test fun strictModeAsksForEverything() {
    val loose = SettingsState(autoApproveNewFiles = true, autoApproveSafeEdits = true)
    assertFalse(ApprovalPolicy.needsApproval(ActionKind.NEW_FILE, loose))
    assertFalse(ApprovalPolicy.needsApproval(ActionKind.EDIT_FILE, loose))
    val strict = loose.copy(strictSecurity = true)
    ActionKind.values().forEach { assertTrue(it.name, ApprovalPolicy.needsApproval(it, strict)) }
  }

  // ---- history JSONL ----

  @Test fun historyLineRoundTrip() {
    val e = HistoryEntry(1_700_000_000_123L, HistoryEntry.COMMAND, "npm test \"x\"", false, "exit 1\nboom")
    val line = ProjectHistory.toLine(e)
    assertFalse(line.contains('\n'))
    assertEquals(e, ProjectHistory.fromLine(line))
    val noOk = HistoryEntry(5L, HistoryEntry.RUN, "Build: todo", null, "")
    assertEquals(noOk, ProjectHistory.fromLine(ProjectHistory.toLine(noOk)))
    assertNull(ProjectHistory.fromLine("{broken"))
    assertNull(ProjectHistory.fromLine(""))
  }

  @Test fun historyFileSkipsDamagedLinesNewestFirst() {
    val root = tmp.newFolder("p")
    ProjectHistory.record(root, HistoryEntry.CREATED, "index.html", true)
    ProjectHistory.file(root).appendText("garbage\n")
    ProjectHistory.record(root, HistoryEntry.DELETED, "old.js", true)
    val read = ProjectHistory.read(root)
    assertEquals(listOf("old.js", "index.html"), read.map { it.target })
    assertTrue(ProjectHistory.file(root).path.endsWith(".vibecoder/history/history.jsonl"))
  }

  // ---- snapshots ----

  @Test fun rotationKeepsThree() {
    assertEquals(emptyList<String>(), ProjectBackups.toRotate(listOf("run-1.zip", "run-2.zip")))
    assertEquals(listOf("run-1.zip"), ProjectBackups.toRotate(listOf("run-3.zip", "run-1.zip", "run-2.zip")))
    assertEquals(listOf("run-1.zip", "run-2.zip"), ProjectBackups.toRotate(listOf("run-1.zip", "run-2.zip", "run-3.zip", "run-4.zip")))
  }

  @Test fun freeSpaceDeletesOldestOrSkips() {
    val existing = listOf("run-2.zip" to 30L, "run-1.zip" to 20L)
    assertEquals(emptyList<String>(), ProjectBackups.toFreeSpace(existing, usable = 100, needed = 50))
    assertEquals(listOf("run-1.zip"), ProjectBackups.toFreeSpace(existing, usable = 40, needed = 55))
    assertEquals(listOf("run-1.zip", "run-2.zip"), ProjectBackups.toFreeSpace(existing, usable = 40, needed = 90))
    assertNull(ProjectBackups.toFreeSpace(existing, usable = 10, needed = 100))
  }

  @Test fun snapshotAndRestore() {
    val root = tmp.newFolder("proj")
    File(root, "index.html").writeText("v1")
    File(root, "js").mkdirs(); File(root, "js/app.js").writeText("a1")
    File(root, "build").mkdirs(); File(root, "build/out.bin").writeText("x")
    val saved = ProjectBackups.snapshot(root, now = 1000L)
    assertTrue(saved is ProjectBackups.Outcome.Saved)
    // The agent changes things.
    File(root, "index.html").writeText("v2")
    File(root, "js/app.js").delete()
    File(root, "new.css").writeText("n")
    assertTrue(ProjectBackups.restore(root, ProjectBackups.latest(root)!!))
    assertEquals("v1", File(root, "index.html").readText())
    assertEquals("a1", File(root, "js/app.js").readText())
    assertFalse(File(root, "new.css").exists())
    assertTrue("build output untouched", File(root, "build/out.bin").exists())
    assertNull("used snapshot is consumed", ProjectBackups.latest(root))
  }

  @Test fun snapshotRollsAndExcludes() {
    val root = tmp.newFolder("roll")
    File(root, "a.txt").writeText("a")
    for (t in 1L..5L) ProjectBackups.snapshot(root, now = t)
    assertEquals(listOf("run-3.zip", "run-4.zip", "run-5.zip"), ProjectBackups.list(root).map { it.name })
    assertFalse(ProjectBackups.isIncluded(".vibecoder/backups/run-1.zip"))
    assertFalse(ProjectBackups.isIncluded("node_modules/x/index.js"))
    assertFalse(ProjectBackups.isIncluded("app/build/tmp.txt"))
    assertTrue(ProjectBackups.isIncluded("src/main.js"))
  }

  @Test fun snapshotSkipsLargeProjects() {
    val root = tmp.newFolder("big")
    File(root, "big.bin").outputStream().use { o -> val chunk = ByteArray(1024 * 1024); repeat(11) { o.write(chunk) } }
    val r = ProjectBackups.snapshot(root)
    assertTrue(r is ProjectBackups.Outcome.Skipped)
    assertTrue(ProjectBackups.list(root).isEmpty())
  }

  // ---- estimate ----

  @Test fun estimateMaths() {
    var s = emptyList<Float>()
    repeat(12) { s = Estimate.push(s, (it + 1).toFloat()) }
    assertEquals(Estimate.WINDOW, s.size)
    assertEquals(3f, s.first())
    assertEquals(s, Estimate.push(s, Float.NaN))
    assertEquals(s, Estimate.push(s, 0f))
    assertEquals(7.5f, Estimate.average(s)!!, 0.0001f)
    assertNull(Estimate.average(emptyList()))
    assertEquals(50f, Estimate.seconds(1000, 20f)!!, 0.001f)
    assertNull(Estimate.seconds(1000, null))
    assertEquals(0.0006, Estimate.cost(1000, 0.6)!!, 1e-12)
    assertNull(Estimate.cost(1000, null))
    assertNotNull(Estimate.decode(Estimate.encode(listOf(1.5f, 2f))))
    assertEquals(listOf(1.5f, 2f), Estimate.decode("1.5,2,abc,-1"))
  }
}
