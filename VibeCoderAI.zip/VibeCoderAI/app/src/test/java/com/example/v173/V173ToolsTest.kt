package com.example.v173

import com.example.data.SettingsExport
import com.example.llama.MemoryEstimator
import com.example.project.EditorAction
import com.example.project.EditorShortcuts
import com.example.project.RunTarget
import com.example.project.RunTargets
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V173ToolsTest {
  @Test fun urlsLoseCredentialsAndQuery() {
    assertEquals("https://api.x.com/v1", SettingsExport.safeUrl("https://user:pw@api.x.com/v1?key=SECRET#a"))
    assertEquals("https://api.x.com", SettingsExport.safeUrl("https://api.x.com?k=1"))
  }
  @Test fun escapeHandlesQuotesAndControls() {
    val e = SettingsExport.escape("a\"b\\c\nd")
    assertTrue(e.contains("\\\"") && e.contains("\\\\") && e.contains("\\n"))
    assertFalse(e.contains("\n"))
  }
  @Test fun shortcuts() {
    assertEquals(EditorAction.SAVE, EditorShortcuts.action(true, false, 'S'))
    assertEquals(EditorAction.UNDO, EditorShortcuts.action(true, false, 'z'))
    assertEquals(EditorAction.REDO, EditorShortcuts.action(true, true, 'z'))
    assertEquals(EditorAction.REDO, EditorShortcuts.action(true, false, 'y'))
    assertEquals(EditorAction.FIND, EditorShortcuts.action(true, false, 'f'))
    assertNull(EditorShortcuts.action(false, false, 's'))
    assertNull(EditorShortcuts.action(true, false, 'q'))
  }
  @Test fun runTargets() {
    assertEquals(RunTarget.Preview, RunTargets.detect(listOf("index.html", "main.py"), null))
    assertEquals("npm start", (RunTargets.detect(listOf("package.json"), "{\"scripts\":{\"start\":\"expo start\"}}") as RunTarget.Command).command)
    assertEquals("python3 main.py", (RunTargets.detect(listOf("main.py"), null) as RunTarget.Command).command)
    assertEquals("node app.js", (RunTargets.detect(listOf("app.js"), null) as RunTarget.Command).command)
    assertNull(RunTargets.detect(listOf("README.md"), null))
  }
  @Test fun guardLowersOversizeContext() {
    val gb = 1024L * 1024 * 1024
    val g = MemoryEstimator.guard(4 * gb, 32768, 5 * gb)
    assertTrue(g.lowered)
    assertTrue(g.contextTokens < 32768)
    val ok = MemoryEstimator.guard(1 * gb, 2048, 8 * gb)
    assertFalse(ok.lowered)
    assertEquals(2048, ok.contextTokens)
  }
}
