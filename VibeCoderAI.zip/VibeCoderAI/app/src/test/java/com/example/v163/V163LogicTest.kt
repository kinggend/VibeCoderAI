package com.example.v163

import com.example.agent.DomCheck
import com.example.agent.Intent
import com.example.agent.RepairPrompt
import com.example.agent.ShrinkGuard
import com.example.agent.ToolCalls
import com.example.agent.Truncation
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V163LogicTest {

  private val html = """<!DOCTYPE html><html><body>
<div id="chessboard" class="board dark"></div>
<p id="status"></p>
<script src="app.js"></script></body></html>"""

  // ---- routing ----

  @Test fun fixWithAiMessageIsRepairNotNewBuild() {
    val msg = "Fix these JavaScript errors in the app. Output only the files that change.\nUncaught TypeError: Cannot set properties of null (setting 'innerHTML') (line 25)"
    assertTrue(Intent.isRepairRequest(msg))
    assertFalse(Intent.isFixRequest(msg)) // too long for the old check: this was the v1.6.2 bug
    assertTrue(Intent.isRepairRequest("app not working"))
    assertTrue(Intent.isRepairRequest("fix the errors please"))
    assertFalse(Intent.isRepairRequest("make a playable 3d chess game"))
  }

  // ---- DomCheck ----

  @Test fun reportsMissingIdWithLine() {
    val js = "const a = 1;\n" + "\n".repeat(23) + "document.getElementById('board').innerHTML = '';\n"
    val p = DomCheck.check(html, js)
    assertEquals(1, p.size)
    assertEquals("app.js:25 uses #board but index.html has no id=\"board\"", p[0].message)
  }

  @Test fun knownIdsClassesAndSelectorsPass() {
    val js = """
      const b = document.getElementById("chessboard");
      document.querySelector('#status').textContent = 'x';
      document.querySelectorAll('.board .cell');
      document.getElementsByClassName('dark');
    """.trimIndent()
    val p = DomCheck.check(html, js)
    assertEquals(listOf(".cell"), p.map { "${it.kind}${it.name}" })
  }

  @Test fun idsCreatedByScriptAreNotMissing() {
    val js = """
      const c = document.createElement('div'); c.id = 'cell-0'; c.classList.add('cell', 'light');
      board.innerHTML = '<span id="piece"></span>';
      document.getElementById('cell-0'); document.querySelector('.light'); document.getElementById('piece');
      document.querySelector(`#${'$'}{id}`);
    """.trimIndent()
    assertTrue(DomCheck.check(html, js).isEmpty())
  }

  @Test fun selectorPseudoAndAttributesIgnored() {
    val js = "document.querySelector('#status:hover'); document.querySelector('input[type=\"text\"].missing');"
    assertEquals(listOf("missing"), DomCheck.check(html, js).map { it.name })
  }

  // ---- RepairPrompt ----

  @Test fun repairPromptHasIdsErrorWindowAndFitsBudget() {
    val js = (1..119).joinToString("\n") { if (it == 25) "  document.getElementById('board').innerHTML = html;" else "  line$it();" }
    val err = "Uncaught TypeError: Cannot set properties of null (setting 'innerHTML') (line 25)"
    val prompt = RepairPrompt.build("Fix these JavaScript errors", listOf(err), mapOf("index.html" to html, "app.js" to js), 3600)
    assertTrue(prompt.contains("index.html ids: chessboard, status"))
    assertTrue(prompt.contains("app.js:25 uses #board but index.html has no id=\"board\""))
    assertTrue(prompt.contains("15|   line15();"))
    assertTrue(prompt.contains("35|   line35();"))
    assertFalse(prompt.contains("36|"))
    assertTrue(prompt.contains("EditFile"))
    assertTrue(prompt.contains("Do not plan"))
    assertTrue(prompt.length <= 3600)
    // Small budget (2048 ctx with big output) still keeps the failing line.
    val small = RepairPrompt.build(null, listOf(err), mapOf("index.html" to html, "app.js" to js), 1200)
    assertTrue(small.contains("25|"))
  }

  @Test fun windowAndTargets() {
    assertEquals("1| a\n2| b", RepairPrompt.window("a\nb\nc", 1, 1))
    assertEquals("", RepairPrompt.window("a", 0))
    val t = RepairPrompt.targets(listOf("x (line 7)", "game.js:3 boom"), emptyList(), "app.js")
    assertEquals(mapOf("app.js" to listOf(7), "game.js" to listOf(3)), t)
    assertEquals("main.js", RepairPrompt.mainJs("<script src=\"main.js\"></script>"))
    assertEquals("app.js", RepairPrompt.mainJs("<p></p>"))
  }

  // ---- ShrinkGuard ----

  @Test fun shrinkGuardFlagsBigLossOnly() {
    val old = (1..119).joinToString("\n") { "l$it" }
    val w = ShrinkGuard.warning("app.js", old, (1..48).joinToString("\n") { "l$it" })
    assertNotNull(w)
    assertTrue(w!!.contains("119 to 48"))
    assertNull(ShrinkGuard.warning("app.js", old, (1..80).joinToString("\n") { "l$it" })) // -33%
    assertNull(ShrinkGuard.warning("app.js", "a\nb\nc", "a")) // tiny file
    assertNull(ShrinkGuard.warning("app.js", "", "a"))
    assertNotNull(ShrinkGuard.warning("app.js", old, ""))
  }

  // ---- truncation false positive ----

  @Test fun bareClosingFenceIsNotCut() {
    // First block closed inline ("}```"), so fences are odd but the last one is a closer.
    val text = "```css\nbody { margin: 0; }```\n\n```js\nlet a = 1;\n```"
    assertNull(Truncation.openFile(text))
  }

  @Test fun unclosedFileTagEndingInFenceIsCompleteNotContinued() {
    val text = "<file path=\"styles.css\">\n```css\nbody { margin: 0; }\n.board { display: grid; }\n```"
    val cut = Truncation.toContinue("stop", text)
    assertNotNull(cut)
    assertTrue(cut!!.complete)
    assertEquals("body { margin: 0; }\n.board { display: grid; }\n", cut.partial)
  }

  @Test fun balancedCodeThatStoppedNormallyIsComplete() {
    val css = "<file path=\"styles.css\">\nbody { margin: 0; }\n.a { color: red; }"
    assertTrue(Truncation.toContinue("stop", css)!!.complete)
    // Same text but the model hit the token limit: continue.
    assertFalse(Truncation.toContinue("length", css)!!.complete)
    // Really cut: unbalanced braces.
    assertFalse(Truncation.toContinue("stop", "<file path=\"app.js\">\nfunction f() {\n  go(")!!.complete)
    assertTrue(Truncation.toContinue("stop", "<file path=\"index.html\">\n<html><body></body></html>")!!.complete)
    assertNull(Truncation.toContinue("stop", "<file path=\"a.js\">\nx();\n</file>"))
  }

  @Test fun bracesInsideStringsDoNotCount() {
    assertTrue(Truncation.looksFinished("app.js", "const s = '{';\nfunction f() { return s; }"))
    assertFalse(Truncation.looksFinished("app.js", "function f() { return '}'"))
  }

  // ---- tool parsing ----

  @Test fun parseAllReturnsEveryEdit() {
    val text = "<tool name=\"EditFile\" path=\"app.js\"><find>a</find><replace>b</replace></tool>\n" +
      "<tool name=\"EditFile\" path=\"index.html\"><find><p id=\"status\"></p></find><replace><p id=\"status\"></p><div id=\"board\"></div></replace></tool>"
    val calls = ToolCalls.parseAll(text)
    assertEquals(2, calls.size)
    assertEquals("index.html", calls[1].attrs["path"])
    assertEquals("<p id=\"status\"></p>", ToolCalls.section(calls[1].body, "find"))
  }
}

class V163RepairEditTest {
  @Test fun lineNumbersCopiedFromPromptAreStripped() {
    org.junit.Assert.assertEquals("  a();\n  b();", RepairPrompt.stripLineNumbers("25|   a();\n26|   b();"))
    // Only when every line has one.
    org.junit.Assert.assertEquals("25| a\nb", RepairPrompt.stripLineNumbers("25| a\nb"))
    org.junit.Assert.assertEquals("x = 1|2", RepairPrompt.stripLineNumbers("x = 1|2"))
  }

  @Test fun looseFindMatchesIndentationOnlyWhenUnique() {
    val file = "function f() {\n    const b = document.getElementById('board');\n    b.innerHTML = '';\n}\n"
    org.junit.Assert.assertEquals(
      "    const b = document.getElementById('board');\n    b.innerHTML = '';",
      RepairPrompt.looseFind(file, "const b = document.getElementById('board');\nb.innerHTML = '';")
    )
    org.junit.Assert.assertNull(RepairPrompt.looseFind("a();\na();\n", "a();"))
    org.junit.Assert.assertNull(RepairPrompt.looseFind(file, "missing();"))
  }

  /** The bug video: Qwen 3B, 2048 ctx, Max output (capped to 1448), so repair gets a 1200-char budget. */
  @Test fun bugVideoScenarioFitsTwoThousandContext() {
    val budget = ((2048 - 1448 - 450).coerceAtLeast(400) * 3).coerceIn(1200, 9000)
    org.junit.Assert.assertEquals(1200, budget)
    val html = "<!DOCTYPE html>\n<html><head><link rel=\"stylesheet\" href=\"styles.css\"></head><body>\n<div id=\"chessboard\"></div>\n<div id=\"info\" class=\"panel\"></div>\n<script src=\"app.js\"></script>\n</body></html>"
    val js = (1..119).joinToString("\n") { if (it == 25) "  document.getElementById('board').innerHTML = renderBoard();" else "  step$it(scene, camera);" }
    val err = "Uncaught TypeError: Cannot set properties of null (setting 'innerHTML') (line 25)"
    val p = RepairPrompt.build("Fix the errors the preview showed.", listOf(err), mapOf("index.html" to html, "app.js" to js), budget)
    org.junit.Assert.assertTrue(p, p.contains("app.js:25 uses #board but index.html has no id=\"board\""))
    org.junit.Assert.assertTrue(p.contains("chessboard"))
    org.junit.Assert.assertTrue(p.contains("25|   document.getElementById('board')"))
    // About 4 chars per token: the prompt stays well under the 600 tokens left for input.
    org.junit.Assert.assertTrue("prompt ${p.length} chars", p.length <= 1600)
  }
}
