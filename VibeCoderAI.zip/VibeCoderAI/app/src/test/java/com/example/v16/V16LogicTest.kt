package com.example.v16

import com.example.chat.ImageSizing
import com.example.chat.Mentions
import com.example.chat.VisionSupport
import com.example.data.model.OutputPresets
import com.example.data.model.SettingsState
import com.example.editor.Completion
import com.example.github.GitHubPusher
import com.example.project.FileOps
import com.example.project.ProjectSearch
import com.example.terminal.Prompts
import com.example.terminal.TimeoutConfig
import com.example.transparency.AttachedFile
import com.example.transparency.AttachedImage
import com.example.transparency.ContextManifest
import com.example.transparency.Destination
import com.example.transparency.Redact
import com.example.transparency.SentMessage
import com.example.transparency.Tokens
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.rules.TemporaryFolder
import java.io.File

class V16LogicTest {
  @get:Rule val tmp = TemporaryFolder()

  // ---- search & replace engine ----

  private val text = "val count = 1\nfun inc() { count += 1 }\nval Counter = count\n"

  @Test fun `literal search is case-insensitive by default and reports lines`() {
    val rx = ProjectSearch.pattern("count", ProjectSearch.Options()).getOrThrow()
    val m = ProjectSearch.findIn(text, rx)
    assertEquals(4, m.size) // count, count, Counter, count
    assertEquals(listOf(1, 2, 3, 3), m.map { it.line })
    assertEquals(4, m[0].column)
  }

  @Test fun `case sensitive and whole word narrow the matches`() {
    val cs = ProjectSearch.pattern("count", ProjectSearch.Options(caseSensitive = true)).getOrThrow()
    assertEquals(3, ProjectSearch.findIn(text, cs).size)
    val ww = ProjectSearch.pattern("count", ProjectSearch.Options(wholeWord = true)).getOrThrow()
    assertEquals(3, ProjectSearch.findIn(text, ww).size) // "Counter" is not a whole word match
  }

  @Test fun `literal mode escapes regex characters`() {
    val rx = ProjectSearch.pattern("a.b(", ProjectSearch.Options()).getOrThrow()
    assertEquals(1, ProjectSearch.findIn("a.b( axb(", rx).size)
  }

  @Test fun `regex mode with groups in the replacement`() {
    val o = ProjectSearch.Options(regex = true, caseSensitive = true)
    val rx = ProjectSearch.pattern("val (\\w+)", o).getOrThrow()
    val (out, n) = ProjectSearch.replaceIn(text, rx, "var $1", o)
    assertEquals(2, n)
    assertTrue(out.startsWith("var count = 1"))
    assertTrue(out.contains("var Counter = count"))
  }

  @Test fun `invalid regex and empty query give readable errors`() {
    assertTrue(ProjectSearch.pattern("(", ProjectSearch.Options(regex = true)).exceptionOrNull()!!.message!!.startsWith("Invalid regular expression"))
    assertTrue(ProjectSearch.pattern("", ProjectSearch.Options()).isFailure)
  }

  @Test fun `zero length regex matches never loop`() {
    val rx = ProjectSearch.pattern("^", ProjectSearch.Options(regex = true)).getOrThrow()
    assertEquals(0, ProjectSearch.findIn("a\nb", rx).size)
    assertEquals("a\nb" to 0, ProjectSearch.replaceIn("a\nb", rx, "x", ProjectSearch.Options(regex = true)))
  }

  @Test fun `replace one touches only the chosen match and literal replacement keeps dollars`() {
    val o = ProjectSearch.Options()
    val rx = ProjectSearch.pattern("count", o).getOrThrow()
    val second = ProjectSearch.findIn(text, rx)[1]
    val (out, n) = ProjectSearch.replaceIn(text, rx, "\$total", o, onlyOffset = second.offset)
    assertEquals(1, n)
    assertTrue(out.contains("{ \$total += 1 }"))
    assertTrue(out.startsWith("val count = 1"))
  }

  @Test fun `replace all skips hidden folders, binaries and unsaved files`() {
    val root = tmp.newFolder("p")
    File(root, "a.js").writeText("foo foo")
    File(root, "b.js").writeText("foo")
    File(root, ".vibecoder/history").mkdirs(); File(root, ".vibecoder/history/history.jsonl").writeText("foo")
    File(root, "build").mkdirs(); File(root, "build/out.js").writeText("foo")
    File(root, "img.bin").writeBytes(byteArrayOf(0, 'f'.code.toByte(), 'o'.code.toByte(), 'o'.code.toByte()))
    val found = ProjectSearch.search(root, "foo", ProjectSearch.Options()).getOrThrow()
    assertEquals(setOf("a.js", "b.js"), found.map { it.path }.toSet())
    val changed = ProjectSearch.replaceAll(root, "foo", "bar", ProjectSearch.Options(), skip = setOf("b.js")).getOrThrow()
    assertEquals(mapOf("a.js" to 2), changed)
    assertEquals("bar bar", File(root, "a.js").readText())
    assertEquals("foo", File(root, "b.js").readText())
    assertEquals("foo", File(root, ".vibecoder/history/history.jsonl").readText())
  }

  // ---- path guards (explorer, web preview) ----

  @Test fun `FileOps resolve rejects traversal`() {
    val root = tmp.newFolder("r")
    assertNull(FileOps.resolve(root, "../x"))
    assertNull(FileOps.resolve(root, "a/../../x"))
    assertNull(FileOps.resolve(root, ""))
    assertEquals(File(root, "a/b.txt").canonicalPath, FileOps.resolve(root, "a/b.txt")!!.canonicalPath)
  }

  @Test fun `FileOps inside resolves symlinks and sibling prefixes`() {
    val base = tmp.newFolder("base")
    val root = File(base, "demo").apply { mkdirs() }
    val sibling = File(base, "demo2").apply { mkdirs() }
    assertFalse(FileOps.inside(root, File(sibling, "x")))
    assertFalse(FileOps.inside(root, File(root, "../demo2/x")))
    val outside = tmp.newFolder("outside")
    val link = File(root, "link")
    java.nio.file.Files.createSymbolicLink(link.toPath(), outside.toPath())
    assertFalse(FileOps.inside(root, File(link, "secret.txt")))
  }

  @Test fun `rename and create refuse names with separators and stay inside`() {
    val root = tmp.newFolder("rn")
    val f = File(root, "a.txt").apply { writeText("x") }
    assertTrue(FileOps.rename(root, f, "../evil.txt").isFailure)
    assertTrue(FileOps.rename(root, f, "..").isFailure)
    assertTrue(FileOps.create(root, root, "a/b", folder = false).isFailure)
    val renamed = FileOps.rename(root, f, "b.txt").getOrThrow()
    assertEquals("x", renamed.readText())
    assertTrue(FileOps.rename(root, root, "x").isFailure) // the project root itself
  }

  @Test fun `move refuses a folder into itself and targets outside the project`() {
    val root = tmp.newFolder("mv")
    val dir = File(root, "src/inner").apply { mkdirs() }
    val src = File(root, "src")
    assertTrue(FileOps.move(root, src, dir).isFailure)
    assertTrue(FileOps.move(root, src, tmp.newFolder("elsewhere")).isFailure)
    val f = File(root, "x.js").apply { writeText("1") }
    assertEquals(File(dir, "x.js").canonicalPath, FileOps.move(root, f, dir).getOrThrow().canonicalPath)
    assertTrue(FileOps.delete(root, root).isFailure)
  }

  @Test fun `web preview may only read files inside the project`() {
    val root = tmp.newFolder("web")
    val g = com.example.project.ProjectWebGuard
    assertTrue(g.isAllowedFileUrl(root, "file://" + File(root, "index.html").absolutePath))
    assertTrue(g.isAllowedFileUrl(root, "file://" + File(root, "app.js").absolutePath + "?v=1"))
    assertFalse(g.isAllowedFileUrl(root, "file://" + File(root, "../secrets.xml").absolutePath))
    assertFalse(g.isAllowedFileUrl(root, "file:///data/data/com.x/shared_prefs/vibecoder_secrets.xml"))
    assertFalse(g.isAllowedFileUrl(root, "file:///android_asset/x"))
    assertTrue(g.isAllowedFileUrl(root, "https://example.com/a.js")) // not a file URL (network rules apply)
  }

  @Test fun `agent ProjectFiles resolve blocks dot paths and traversal`() {
    val root = tmp.newFolder("agent")
    assertNull(com.example.agent.ProjectFiles.resolve(root, "../a"))
    assertNull(com.example.agent.ProjectFiles.resolve(root, ".vibecoder/history/history.jsonl"))
    assertNull(com.example.agent.ProjectFiles.resolve(root, "/etc/passwd"))
    assertTrue(com.example.agent.ProjectFiles.resolve(root, "js/app.js") != null)
  }

  // ---- zip slip ----

  private fun zip(entries: List<Pair<String, String>>): File {
    val f = tmp.newFile()
    java.util.zip.ZipOutputStream(f.outputStream()).use { z ->
      entries.forEach { (n, c) -> z.putNextEntry(java.util.zip.ZipEntry(n)); z.write(c.toByteArray()); z.closeEntry() }
    }
    return f
  }

  @Test fun `zip slip entries are rejected before anything is written`() {
    for (bad in listOf("../evil.txt", "a/../../evil.txt", "/abs/evil.txt", "C:\\evil.txt", "..\\evil.txt")) {
      val target = tmp.newFolder()
      val z = zip(listOf("ok.txt" to "fine", bad to "pwned"))
      val err = runCatching { com.example.project.ZipImporter.extract(z, target) }.exceptionOrNull()
      assertTrue("$bad must be rejected", err is SecurityException)
      assertFalse("nothing written for $bad", File(target, "ok.txt").exists())
      assertFalse(File(target.parentFile, "evil.txt").exists())
    }
  }

  @Test fun `zip with too many entries is refused`() {
    val target = tmp.newFolder()
    val z = zip((0..com.example.project.ZipImporter.MAX_ENTRIES).map { "f$it.txt" to "" })
    assertTrue(runCatching { com.example.project.ZipImporter.extract(z, target) }.exceptionOrNull() is SecurityException)
  }

  @Test fun `undo restore ignores entries escaping the project`() {
    val base = tmp.newFolder("rs")
    val root = File(base, "proj").apply { mkdirs() }
    File(root, "a.txt").writeText("now")
    val z = zip(listOf("a.txt" to "before", "../escaped.txt" to "x", ".vibecoder/x" to "y"))
    assertTrue(com.example.agent.ProjectBackups.restore(root, z))
    assertEquals("before", File(root, "a.txt").readText())
    assertFalse(File(base, "escaped.txt").exists())
  }

  // ---- @mentions ----

  @Test fun `trailing mention query rules`() {
    assertEquals("ap", Mentions.trailingQuery("fix @ap"))
    assertEquals("", Mentions.trailingQuery("@"))
    assertEquals("src/app.js", Mentions.trailingQuery("see @src/app.js"))
    assertNull(Mentions.trailingQuery("mail me@x.com"))
    assertNull(Mentions.trailingQuery("@app.js and more"))
    assertNull(Mentions.trailingQuery("no mention"))
    assertEquals("fix ", Mentions.removeTrailing("fix @ap"))
    assertEquals("", Mentions.removeTrailing("@ap"))
  }

  @Test fun `mention token cap warns and rejects`() {
    assertEquals(2048, Mentions.budgetTokens(4096))
    assertEquals(Mentions.MAX_TOTAL_TOKENS, Mentions.budgetTokens(100_000))
    assertEquals(500, Mentions.budgetTokens(512))
    assertTrue(Mentions.check(emptyList(), "a.js", 400, 4096) is Mentions.Check.Ok)
    val dup = listOf(AttachedFile("a.js", 400, 400))
    assertTrue(Mentions.check(dup, "a.js", 400, 4096) is Mentions.Check.Reject)
    // 2048-token budget: 7000 chars ≈ 1750 tokens is over 3/4 -> warn; another 2000 chars -> reject
    assertTrue(Mentions.check(emptyList(), "big.js", 7000, 4096) is Mentions.Check.Warn)
    val used = listOf(AttachedFile("big.js", 7000, 7000))
    assertTrue(Mentions.check(used, "more.js", 2000, 4096) is Mentions.Check.Reject)
    // a huge file is cut to MAX_FILE_CHARS and then counted
    assertTrue(Mentions.check(emptyList(), "huge.js", 1_000_000, 100_000) is Mentions.Check.Warn)
  }

  @Test fun `mention ranking prefers name prefix`() {
    val r = Mentions.rank(listOf("src/util/app_helper.js", "app.js", "lib/mapp.js", "readme.md"), "app")
    assertEquals(listOf("app.js", "src/util/app_helper.js", "lib/mapp.js"), r)
  }

  // ---- images ----

  @Test fun `image downscale keeps aspect and never upscales`() {
    assertEquals(1568 to 882, ImageSizing.fit(4000, 2250))
    assertEquals(882 to 1568, ImageSizing.fit(2250, 4000))
    assertEquals(800 to 600, ImageSizing.fit(800, 600))
    assertEquals(1568 to 1568, ImageSizing.fit(3000, 3000))
    assertEquals(0 to 0, ImageSizing.fit(0, 10))
    assertEquals(2, ImageSizing.sampleSize(4000, 3000)) // 2000 >= 1568, 1000 < 1568
    assertEquals(1, ImageSizing.sampleSize(1000, 800))
    assertEquals(85 + 170 * 4, Tokens.imageEstimate(1000, 800))
  }

  @Test fun `vision support is honest about local and unknown models`() {
    assertTrue(VisionSupport.check("local", "anything") is VisionSupport.Verdict.No)
    assertTrue(VisionSupport.check("remote", "") is VisionSupport.Verdict.No)
    assertTrue(VisionSupport.check("remote", "llama-3.1-8b-instant") is VisionSupport.Verdict.No)
    assertTrue(VisionSupport.check("remote", "gpt-4o-mini") is VisionSupport.Verdict.Ok)
    assertTrue(VisionSupport.check("remote", "qwen2.5-vl-7b-instruct") is VisionSupport.Verdict.Ok)
    assertTrue(VisionSupport.check("remote", "meta-llama/llama-4-scout-17b-16e-instruct") is VisionSupport.Verdict.Ok)
  }

  // ---- terminal ----

  @Test fun `timeout config parsing and limits`() {
    assertEquals(60, TimeoutConfig.parse(null))
    assertEquals(60, TimeoutConfig.parse("garbage"))
    assertEquals(45, TimeoutConfig.parse("45"))
    assertEquals(45, TimeoutConfig.parse("45s"))
    assertEquals(300, TimeoutConfig.parse("5 min"))
    assertEquals(1800, TimeoutConfig.parse("1h"))
    assertEquals(10, TimeoutConfig.parse("3"))
    assertEquals(0, TimeoutConfig.parse("no limit"))
    assertEquals(0, TimeoutConfig.parse("0"))
    assertEquals(0, TimeoutConfig.sanitize(-5))
    assertEquals(1800, TimeoutConfig.sanitize(99999))
    assertNull(TimeoutConfig.toMillis(0))
    assertEquals(60_000L, TimeoutConfig.toMillis(60))
    assertEquals("2 min", TimeoutConfig.label(120))
    assertEquals("no limit", TimeoutConfig.label(0))
  }

  @Test fun `prompt detection`() {
    assertTrue(Prompts.looksLikePrompt("Continue? "))
    assertTrue(Prompts.looksLikePrompt("Proceed (y/n)\n"))
    assertTrue(Prompts.looksLikePrompt("Password:\n"))
    assertFalse(Prompts.looksLikePrompt("done\n"))
    assertFalse(Prompts.looksLikePrompt(""))
  }

  @Test fun `terminal session runs, times out and takes input`() = kotlinx.coroutines.runBlocking {
    val dir = tmp.newFolder("term")
    val tm = com.example.terminal.TerminalManager()
    val ok = tm.start("echo hi", dir).await(5_000)
    assertEquals(0, ok.exitCode); assertEquals("hi", ok.stdout)
    val t0 = System.currentTimeMillis()
    val slow = tm.start("sleep 5", dir).await(300)
    assertTrue(slow.timedOut); assertEquals(124, slow.exitCode)
    assertTrue(System.currentTimeMillis() - t0 < 4_000)
    var asked: String? = null
    val inter = tm.start("printf 'Name? '; read x; echo \"got \$x\"", dir).await(20_000) { tail ->
      asked = tail
      com.example.terminal.InputAnswer.Send("bob\n")
    }
    assertEquals("Name? ", asked)
    assertTrue(inter.stdout.endsWith("got bob"))
  }

  // ---- presets ----

  @Test fun `fast preset lowers context and output, never raises`() {
    val d = SettingsState()
    val fast = OutputPresets.all.first { it.id == "fast" }
    val s = OutputPresets.apply(d.copy(contextLength = 4096, maxOutputTokens = 1536), fast)
    assertEquals(2048, s.contextLength); assertEquals(512, s.maxOutputTokens); assertEquals(0.3f, s.temperature)
    assertEquals("Fast", OutputPresets.label(s))
    val small = OutputPresets.apply(d.copy(contextLength = 1024), fast)
    assertEquals(1024, small.contextLength) // never raised
    assertEquals(512, small.maxOutputTokens)
    assertEquals("Fast", OutputPresets.label(small))
    val coding = OutputPresets.apply(s, OutputPresets.all.first { it.id == "coding" })
    assertEquals(2048, coding.contextLength) // coding leaves context alone
    assertEquals("Coding", OutputPresets.label(coding))
  }

  // ---- context manifest / destination / redaction ----

  @Test fun `manifest lists everything and counts tokens`() {
    val m = ContextManifest(
      destination = Destination.of("remote", "https://api.groq.com/openai/v1"),
      model = "gpt-4o-mini",
      messages = listOf(SentMessage("system", "x".repeat(400)), SentMessage("user", "hi"), SentMessage("assistant", "hello"), SentMessage("user", "y".repeat(40))),
      skills = listOf("Short answers"),
      files = listOf(AttachedFile("app.js", 800, 800)),
      images = listOf(AttachedImage("img.jpg", 512, 512, 1000, sent = true)),
      temperature = 0.2f, topP = 0.95f, topK = null, maxTokens = 1024, contextLength = null
    )
    assertEquals("Remote: api.groq.com", m.destination.label)
    assertEquals(2, m.historyTurns)
    assertEquals(100 + 4 + 1 + 4 + 2 + 4 + 10 + 4 + 255, m.estimatedTokens)
    assertTrue(m.promptTokensLabel.startsWith("≈"))
    val lines = m.settingsLines().toMap()
    assertEquals("Remote: api.groq.com", lines["Destination"])
    assertTrue(lines["Authorization header"]!!.contains("••••"))
    assertEquals(200, AttachedFile("a", 800, 800).tokens)
  }

  @Test fun `destination encoding round trip`() {
    assertEquals(Destination.ON_DEVICE, Destination.of("local", "http://x"))
    assertEquals("On-device", Destination.ON_DEVICE.label)
    assertEquals("192.168.1.5", Destination.of("remote", "http://192.168.1.5:11434/v1").remoteHost)
    assertEquals(Destination.ON_DEVICE, Destination.decode(Destination.encode(Destination.ON_DEVICE)))
    assertEquals("h", Destination.decode(Destination.encode(Destination("h")))!!.remoteHost)
    assertNull(Destination.decode(null))
  }

  @Test fun `secrets are redacted from text`() {
    val t = "HTTP 401 Incorrect API key provided: sk-proj-abcdefghijklmnop1234. token ghp_abcdefghijklmnopqrstuvwxyz123456 Authorization: Bearer abcdefghijklmnopqrst"
    val r = Redact.text(t)
    assertFalse(r.contains("abcdefghijklmnop1234"))
    assertFalse(r.contains("ghp_abc"))
    assertTrue(r.contains("Bearer ••••"))
    assertEquals("key=••••", Redact.text("key=mysecret-value", listOf("mysecret-value")))
    assertEquals("••••wxyz", Redact.mask("github_pat_123456wxyz"))
    assertEquals("••••", Redact.mask("short"))
  }

  // ---- auto-complete ----

  @Test fun `completion suggests identifiers from the file and keywords`() {
    val src = "const counterValue = 1;\nfunction inc() { counterValue++ }\ncou"
    val s = Completion.suggest(src, src.length, "js")
    assertEquals("counterValue", s.first())
    val k = Completion.suggest("fun main() { va", 15, "kt")
    assertTrue(k.contains("val") && k.contains("var"))
    assertTrue(Completion.suggest("x", 1, "js").isEmpty()) // 1-char prefix
    assertEquals("bg-col", Completion.prefixAt("a { bg-col", 10, "css"))
    val (out, cur) = Completion.apply("let x = cou;", 11, "counterValue")
    assertEquals("let x = counterValue;", out)
    assertEquals(20, cur)
  }

  // ---- GitHub ----

  @Test fun `github repo parsing and branch rules`() {
    assertEquals(GitHubPusher.Repo("kinggend", "VibeCoderAI"), GitHubPusher.parseRepo("https://github.com/kinggend/VibeCoderAI"))
    assertEquals(GitHubPusher.Repo("o", "r"), GitHubPusher.parseRepo("git@github.com:o/r.git"))
    assertEquals(GitHubPusher.Repo("o", "r"), GitHubPusher.parseRepo("o/r"))
    assertNull(GitHubPusher.parseRepo("https://gitlab.com/o/r/x"))
    assertNull(GitHubPusher.parseRepo("o/../r"))
    assertNull(GitHubPusher.branchError("feature/v1.6"))
    assertTrue(GitHubPusher.branchError("bad..name") != null)
    assertTrue(GitHubPusher.branchError("has space") != null)
  }

  @Test fun `github push plan never includes history, backups or build output`() {
    val root = tmp.newFolder("gh")
    File(root, "index.html").writeText("<p>")
    File(root, ".vibecoder/backups").mkdirs(); File(root, ".vibecoder/backups/run-1.zip").writeText("z")
    File(root, ".git").mkdirs(); File(root, ".git/config").writeText("c")
    File(root, "build").mkdirs(); File(root, "build/a.apk").writeText("a")
    File(root, ".env").writeText("SECRET=1")
    val p = GitHubPusher.plan(root)
    assertEquals(listOf("index.html"), p.files.map { it.path })
  }
}
