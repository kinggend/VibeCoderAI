package com.example.v14

import com.example.patch.EditFileEngine
import com.example.patch.EditResult
import com.example.patch.LineDiff
import com.example.patch.UnifiedDiff
import com.example.data.model.DiffType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class PatchEnginesTest {

  @Test fun editReplacesUniqueMatch() {
    val r = EditFileEngine.apply("a\nb\nc\n", "b", "B")
    assertTrue(r is EditResult.Ok)
    assertEquals("a\nB\nc\n", (r as EditResult.Ok).text)
    assertEquals(2, r.line)
  }

  @Test fun editFailsWhenMissing() {
    assertTrue(EditFileEngine.apply("abc", "zzz", "y") is EditResult.Fail)
  }

  @Test fun editFailsWhenAmbiguous() {
    val r = EditFileEngine.apply("x = 1\nx = 1\n", "x = 1", "x = 2")
    assertTrue(r is EditResult.Fail)
    assertTrue((r as EditResult.Fail).reason.contains("2 places"))
  }

  @Test fun editFailsOnEmptyFind() {
    assertTrue(EditFileEngine.apply("abc", "", "y") is EditResult.Fail)
  }

  @Test fun editHandlesCrlfFiles() {
    val r = EditFileEngine.apply("one\r\ntwo\r\nthree\r\n", "one\ntwo", "1\n2")
    assertEquals("1\r\n2\r\nthree\r\n", (r as EditResult.Ok).text)
  }

  @Test fun countIsNonOverlapping() {
    assertEquals(2, EditFileEngine.countOccurrences("aaaa", "aa"))
  }

  private val original = "line1\nline2\nline3\nline4\nline5\n"

  @Test fun patchAppliesWithContext() {
    val diff = """
      --- a/f.txt
      +++ b/f.txt
      @@ -2,3 +2,3 @@
       line2
      -line3
      +LINE3
       line4
    """.trimIndent()
    val fp = UnifiedDiff.parse(diff).single()
    assertEquals("f.txt", fp.path)
    val r = UnifiedDiff.apply(original, fp)
    assertEquals("line1\nline2\nLINE3\nline4\nline5\n", (r as UnifiedDiff.ApplyResult.Ok).text)
  }

  @Test fun patchToleratesWrongLineNumbers() {
    val diff = "@@ -40,2 +40,2 @@\n line4\n-line5\n+five\n"
    val r = UnifiedDiff.apply(original, UnifiedDiff.parse(diff, "f.txt").single())
    assertEquals("line1\nline2\nline3\nline4\nfive\n", (r as UnifiedDiff.ApplyResult.Ok).text)
  }

  @Test fun patchRejectsContextMismatch() {
    val diff = "--- a/f.txt\n+++ b/f.txt\n@@ -2,2 +2,2 @@\n line2\n-lineX\n+Y\n"
    assertTrue(UnifiedDiff.apply(original, UnifiedDiff.parse(diff).single()) is UnifiedDiff.ApplyResult.Fail)
  }

  @Test fun patchMultipleHunksAndInsert() {
    val diff = "--- a/f\n+++ b/f\n@@ -1,1 +1,2 @@\n line1\n+inserted\n@@ -5,1 +6,1 @@\n-line5\n+end\n"
    val r = UnifiedDiff.apply(original, UnifiedDiff.parse(diff).single())
    assertEquals("line1\ninserted\nline2\nline3\nline4\nend\n", (r as UnifiedDiff.ApplyResult.Ok).text)
  }

  @Test fun patchCreatesNewFile() {
    val diff = "--- /dev/null\n+++ b/new.js\n@@ -0,0 +1,2 @@\n+a\n+b\n"
    val fp = UnifiedDiff.parse(diff).single()
    assertTrue(fp.isNewFile)
    assertEquals("a\nb\n", (UnifiedDiff.apply("", fp) as UnifiedDiff.ApplyResult.Ok).text)
  }

  @Test fun patchParsesTwoFiles() {
    val diff = "--- a/x\n+++ b/x\n@@ -1 +1 @@\n-1\n+2\n--- a/y\n+++ b/y\n@@ -1 +1 @@\n-3\n+4\n"
    assertEquals(listOf("x", "y"), UnifiedDiff.parse(diff).map { it.path })
  }

  @Test(expected = IllegalArgumentException::class) fun patchRejectsGarbage() {
    UnifiedDiff.parse("hello world")
  }

  @Test(expected = IllegalArgumentException::class) fun patchRejectsTruncatedHunk() {
    UnifiedDiff.parse("--- a/x\n+++ b/x\n@@ -1,3 +1,3 @@\n a\n")
  }

  @Test fun lineDiffMarksChanges() {
    val d = LineDiff.diff("a\nb\nc", "a\nB\nc")
    assertEquals(1 to 1, LineDiff.stats(d))
    assertTrue(d.any { it.type == DiffType.REMOVED && it.content == "b" })
    assertTrue(d.any { it.type == DiffType.ADDED && it.content == "B" })
  }

  @Test fun lineDiffOfIdenticalIsEmpty() {
    assertTrue(LineDiff.diff("same\n", "same\n").isEmpty())
  }
}
