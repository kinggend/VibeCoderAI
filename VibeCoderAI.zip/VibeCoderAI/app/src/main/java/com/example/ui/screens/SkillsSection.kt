package com.example.ui.screens

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.Skill
import com.example.agent.SkillCodec
import com.example.agent.SkillFile
import com.example.agent.Skills
import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.GroupedSection
import com.example.ui.components.TextButton
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CodeBackground
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Editor state for a new or edited custom skill. [id] null = new. */
private data class SkillDraft(val id: String?, val name: String, val description: String, val prompt: String)

/**
 * Settings block: switch agent skills on or off, and create, edit, delete, export and import your own.
 * v1.5: imported skills are previewed first and always start switched off.
 */
@Composable
fun SkillsSection() {
  val haptics = rememberHaptics()
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val skills = Skills.version.let { Skills.all() }
  var draft by remember { mutableStateOf<SkillDraft?>(null) }
  var importPreview by remember { mutableStateOf<SkillFile?>(null) }
  var message by remember { mutableStateOf<Pair<String, String>?>(null) }
  var exporting by remember { mutableStateOf<Skill?>(null) }
  var deleting by remember { mutableStateOf<Skill?>(null) }

  val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri: Uri? ->
    val skill = exporting
    exporting = null
    if (uri == null || skill == null) return@rememberLauncherForActivityResult
    scope.launch {
      val err = SkillCodec.validate(skill.name, skill.description, skill.prompt)
      val result = if (err != null) Result.failure(IllegalArgumentException(err)) else withContext(Dispatchers.IO) {
        runCatching {
          val json = SkillCodec.encode(SkillFile(skill.name, skill.description, skill.prompt))
          context.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray()) } ?: error("Could not open the file.")
        }
      }
      message = result.fold({ "Exported" to "\"${skill.name}\" was saved." }, { "Export failed" to (it.message ?: "Unknown error") })
    }
  }

  val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
    if (uri == null) return@rememberLauncherForActivityResult
    scope.launch {
      val parsed = withContext(Dispatchers.IO) {
        runCatching {
          // Read at most one byte over the limit, so a huge file is rejected without loading it.
          val bytes = context.contentResolver.openInputStream(uri)?.use { input ->
            val buf = java.io.ByteArrayOutputStream()
            val chunk = ByteArray(4096)
            while (buf.size() <= SkillCodec.MAX_FILE_BYTES) {
              val n = input.read(chunk)
              if (n < 0) break
              buf.write(chunk, 0, n)
            }
            buf.toByteArray()
          } ?: error("Could not open the file.")
          SkillCodec.decode(bytes).getOrThrow()
        }
      }
      parsed.fold({ importPreview = it }, { message = "Cannot import this file" to (it.message ?: "Unknown error") })
    }
  }

  GroupedSection(
    "Agent skills",
    footer = "Enabled skills are added to the model's instructions. Each one costs a few tokens, so keep only what you need. Imported skills start switched off."
  ) {
    skills.forEach { skill ->
      Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(top = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(Modifier.weight(1f).padding(end = 8.dp)) {
          Text(skill.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
          Text(skill.description, color = TextMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        Switch(
          checked = Skills.isEnabled(skill),
          onCheckedChange = { haptics.tick(); Skills.setEnabled(skill, it) },
          colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White)
        )
      }
      if (!skill.builtIn) {
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          SmallAction("Edit", CyberCyanPrimary) { draft = SkillDraft(skill.id, skill.name, skill.description.takeIf { it != "Custom skill" }.orEmpty(), skill.prompt) }
          SmallAction("Export", CyberCyanPrimary) { exporting = skill; exportLauncher.launch(SkillCodec.fileName(skill.name)) }
          SmallAction("Delete", CyberCoralError) { deleting = skill }
        }
      }
    }
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
      TextButton(onClick = { draft = SkillDraft(null, "", "", "") }, modifier = Modifier.heightIn(min = 48.dp)) {
        Text("+ New skill", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
      }
      TextButton(onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "application/octet-stream")) }, modifier = Modifier.heightIn(min = 48.dp)) {
        Text("Import", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
      }
    }
  }

  draft?.let { d -> SkillEditor(d, onDismiss = { draft = null }) }

  importPreview?.let { file ->
    var name by remember(file) { mutableStateOf(file.name) }
    val nameError = Skills.nameError(name)
    GlassAlertDialog(
      onDismissRequest = { importPreview = null },
      title = { Text("Import skill?") },
      text = {
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Read the instructions below. They are added to the model's prompt only after you switch the skill on.", color = TextSecondary, fontSize = 14.sp)
          OutlinedTextField(
            name, { name = it.take(SkillCodec.MAX_NAME) },
            label = { Text("Name") }, singleLine = true,
            isError = nameError != null,
            supportingText = { Text(nameError ?: "${name.trim().length}/${SkillCodec.MAX_NAME}") }
          )
          if (file.description.isNotBlank()) Text(file.description, color = TextMuted, fontSize = 13.sp)
          Text(
            file.promptText,
            color = TextPrimary,
            fontSize = 13.sp,
            lineHeight = 18.sp,
            fontFamily = FontFamily.Monospace,
            modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CodeBackground).padding(10.dp)
          )
          Text("It will be added switched off.", color = CyberGreenSuccess, fontSize = 13.sp, fontWeight = FontWeight.Medium)
        }
      },
      confirmButton = {
        TextButton(enabled = nameError == null, onClick = {
          // enabled = false: an imported skill never switches itself on.
          val err = Skills.saveCustom(name, file.description, file.promptText, enabled = false)
          importPreview = null
          message = if (err == null) "Imported" to "\"${name.trim()}\" is in your skills, switched off." else "Cannot import this file" to err
        }) { Text("Import") }
      },
      dismissButton = { TextButton(onClick = { importPreview = null }) { Text("Cancel") } }
    )
  }

  deleting?.let { skill ->
    GlassAlertDialog(
      onDismissRequest = { deleting = null },
      title = { Text("Delete \"${skill.name}\"?") },
      text = { Text("This removes the skill from this phone. Export it first if you want to keep a copy.") },
      confirmButton = {
        TextButton(onClick = { Skills.deleteCustom(skill.id); deleting = null }) { Text("Delete", color = CyberCoralError) }
      },
      dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
    )
  }

  message?.let { (title, body) ->
    GlassAlertDialog(
      onDismissRequest = { message = null },
      title = { Text(title) },
      text = { Text(body) },
      confirmButton = { TextButton(onClick = { message = null }) { Text("OK") } }
    )
  }
}

@Composable
private fun SmallAction(label: String, color: Color, onClick: () -> Unit) {
  TextButton(onClick = onClick, modifier = Modifier.heightIn(min = 48.dp)) {
    Text(label, color = color, fontSize = 13.sp, fontWeight = FontWeight.Medium)
  }
}

@Composable
private fun SkillEditor(initial: SkillDraft, onDismiss: () -> Unit) {
  var name by remember { mutableStateOf(initial.name) }
  var description by remember { mutableStateOf(initial.description) }
  var prompt by remember { mutableStateOf(initial.prompt) }
  var touched by remember { mutableStateOf(false) }
  val nameError = if (name.isBlank() && !touched) null else Skills.nameError(name, initial.id)
  val fieldError = SkillCodec.validate(name.ifBlank { "x" }, description, prompt.ifBlank { "x" })
  val canSave = name.isNotBlank() && prompt.isNotBlank() && Skills.nameError(name, initial.id) == null && fieldError == null
  GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text(if (initial.id == null) "New skill" else "Edit skill") },
    text = {
      Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        OutlinedTextField(
          name, { name = it.take(SkillCodec.MAX_NAME); touched = true },
          label = { Text("Name") }, singleLine = true,
          isError = nameError != null,
          supportingText = { Text(nameError ?: "${name.trim().length}/${SkillCodec.MAX_NAME}") }
        )
        OutlinedTextField(
          description, { description = it.replace("\n", " ").take(SkillCodec.MAX_DESCRIPTION) },
          label = { Text("Description (optional)") }, singleLine = true,
          supportingText = { Text("${description.trim().length}/${SkillCodec.MAX_DESCRIPTION}") }
        )
        OutlinedTextField(
          prompt, { prompt = it.take(SkillCodec.MAX_PROMPT) },
          label = { Text("Instructions for the model") },
          placeholder = { Text("e.g. Always add a dark mode toggle") },
          minLines = 3,
          supportingText = { Text("${prompt.trim().length}/${SkillCodec.MAX_PROMPT}") }
        )
      }
    },
    confirmButton = {
      TextButton(enabled = canSave, onClick = {
        if (Skills.saveCustom(name, description, prompt, editId = initial.id) == null) onDismiss()
      }) { Text(if (initial.id == null) "Add" else "Save") }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
  )
}
