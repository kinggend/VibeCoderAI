package com.example.ui.components

// v1.4: pure string helpers behind MiddleEllipsisText, extracted so they run in plain JUnit tests.

/** Compound extensions that are kept whole (checked before the plain last-dot extension). */
private val COMPOUND_EXTENSIONS = listOf(
  ".gradle.kts", ".d.ts", ".tar.gz", ".tar.xz", ".min.js", ".min.css",
  ".test.ts", ".test.js", ".spec.ts", ".spec.js", ".module.css"
)

/** Splits a file name into (stem, extension). The extension includes its dot; "" when there is none. */
internal fun splitFileExtension(name: String): Pair<String, String> {
  val lower = name.lowercase()
  COMPOUND_EXTENSIONS.firstOrNull { lower.endsWith(it) && name.length > it.length }?.let { ext ->
    return name.dropLast(ext.length) to name.takeLast(ext.length)
  }
  val dot = name.lastIndexOf('.')
  // No dot, a leading-dot file (".gitignore") or a very long "extension": treat it all as stem.
  if (dot <= 0 || name.length - dot > 10) return name to ""
  return name.substring(0, dot) to name.substring(dot)
}

/** Builds "head…tail.ext" keeping [keep] characters of the stem (60 % head, 40 % tail). */
internal fun middleEllipsize(stem: String, ext: String, keep: Int): String {
  val k = keep.coerceIn(0, stem.length)
  val head = ((k * 3 + 4) / 5).coerceIn(0, k)
  val tail = (k - head).coerceIn(0, stem.length - head)
  return stem.take(head) + "\u2026" + stem.takeLast(tail) + ext
}
