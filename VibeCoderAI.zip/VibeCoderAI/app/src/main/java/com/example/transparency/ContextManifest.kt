package com.example.transparency

/**
 * v1.6 "What the AI sees". Everything here is built from the exact payload the engine sends
 * (LlamaEngine.generateCompletionStream reports it through onRequest), so the sheet can never list
 * less than what left the composer. Pure Kotlin: unit tested.
 */

/** Where a request goes: the phone itself, or a remote host. */
data class Destination(val remoteHost: String?) {
  val isRemote: Boolean get() = remoteHost != null
  val label: String get() = if (remoteHost == null) "On-device" else "Remote: $remoteHost"

  companion object {
    val ON_DEVICE = Destination(null)

    /** "remote" backend with a parsable URL host, else on-device. A bad URL still counts as remote. */
    fun of(backendMode: String, remoteUrl: String): Destination =
      if (backendMode != "remote") ON_DEVICE
      else Destination(hostOf(remoteUrl) ?: remoteUrl.trim().ifEmpty { "unknown server" })

    fun hostOf(url: String): String? = runCatching { java.net.URI(url.trim()).host }.getOrNull()?.takeIf { it.isNotBlank() }

    /** Stored form (Room column) and back. null stays null (messages saved before v1.6). */
    fun encode(d: Destination?): String? = d?.let { it.remoteHost ?: "device" }
    fun decode(s: String?): Destination? = when {
      s.isNullOrBlank() -> null
      s == "device" -> ON_DEVICE
      else -> Destination(s)
    }
  }
}

/** A project file attached with @mention (or the paperclip), as it was sent. */
data class AttachedFile(val path: String, val bytes: Long, val chars: Int, val truncated: Boolean = false) {
  val tokens: Int get() = Tokens.estimate(chars)
}

/** An image attached to the message (already downscaled). [sent] false = kept on the phone, with [reason]. */
data class AttachedImage(val name: String, val width: Int, val height: Int, val bytes: Long, val sent: Boolean, val reason: String? = null)

/** One message of the request exactly as sent: role and full text. */
data class SentMessage(val role: String, val content: String)

/**
 * The full request one generation sent. [messages] is the literal payload (system, history, user);
 * the other fields describe it so the sheet can show sizes and settings.
 */
data class ContextManifest(
  val destination: Destination,
  val model: String,
  val messages: List<SentMessage>,
  val skills: List<String>,
  val files: List<AttachedFile>,
  val images: List<AttachedImage>,
  val temperature: Float,
  val topP: Float,
  val topK: Int?,
  val maxTokens: Int,
  val contextLength: Int?,
  /** Exact llama.cpp count for on-device prompts when known; otherwise null (estimate is shown). */
  val exactPromptTokens: Int? = null,
  val sentAt: Long = System.currentTimeMillis()
) {
  val systemPrompt: String get() = messages.firstOrNull { it.role == "system" }?.content.orEmpty()
  val historyTurns: Int get() = (messages.size - 1 - (if (messages.firstOrNull()?.role == "system") 1 else 0)).coerceAtLeast(0)
  val estimatedTokens: Int get() = messages.sumOf { Tokens.estimate(it.content.length) + 4 } + images.filter { it.sent }.sumOf { Tokens.imageEstimate(it.width, it.height) }
  val promptTokensLabel: String get() = exactPromptTokens?.let { "$it tokens (exact)" } ?: "≈$estimatedTokens tokens (estimate)"
  val totalChars: Int get() = messages.sumOf { it.content.length }

  /** Lines of the "settings used" block (nothing hidden: model, sampling, limits, destination). */
  fun settingsLines(): List<Pair<String, String>> = buildList {
    add("Destination" to destination.label)
    add("Model" to model.ifBlank { "server default" })
    add("Temperature" to "%.2f".format(temperature))
    add("Top-P" to "%.2f".format(topP))
    topK?.let { add("Top-K" to "$it") }
    add("Max output tokens" to "$maxTokens")
    contextLength?.let { add("Context window" to "$it") }
    if (destination.isRemote) add("Authorization header" to "Bearer •••• (your saved API key, never shown)")
  }
}

object Tokens {
  /** ~4 characters per token, rounded up (same rule the app used since v1.4 for remote prompts). */
  fun estimate(chars: Int): Int = if (chars <= 0) 0 else (chars + 3) / 4

  /** OpenAI-style tile estimate for a downscaled image: 85 + 170 per 512 px tile. */
  fun imageEstimate(w: Int, h: Int): Int {
    if (w <= 0 || h <= 0) return 0
    val tiles = ((w + 511) / 512) * ((h + 511) / 512)
    return 85 + 170 * tiles
  }
}

/**
 * Removes secrets from any text that is shown, logged, saved to History or exported
 * (server error bodies sometimes echo part of the key). Pure, unit tested.
 */
object Redact {
  private val PATTERNS = listOf(
    Regex("""\b(sk|rk|pk)-[A-Za-z0-9_\-]{12,}"""),
    Regex("""\bgh[pousr]_[A-Za-z0-9]{20,}"""),
    Regex("""\bgithub_pat_[A-Za-z0-9_]{20,}"""),
    Regex("""\bhf_[A-Za-z0-9]{20,}"""),
    Regex("""\bgsk_[A-Za-z0-9]{20,}"""),
    Regex("""\bAIza[0-9A-Za-z_\-]{30,}"""),
    Regex("""(?i)(bearer\s+)[A-Za-z0-9._\-]{12,}""")
  )

  fun text(input: String, known: Collection<String> = emptyList()): String {
    var out = input
    for (k in known) {
      val s = k.trim()
      if (s.length >= 6) out = out.replace(s, "••••")
    }
    for (p in PATTERNS) {
      out = p.replace(out) { m -> if (m.groupValues.size > 1 && m.groupValues[1].lowercase().startsWith("bearer")) m.groupValues[1] + "••••" else "••••" }
    }
    return out
  }

  /** "sk-…abcd" style preview for a saved key: never more than the last 4 characters. */
  fun mask(secret: String): String {
    val s = secret.trim()
    return when {
      s.isEmpty() -> ""
      s.length <= 8 -> "••••"
      else -> "••••" + s.takeLast(4)
    }
  }
}
