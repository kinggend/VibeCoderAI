package com.example.agent

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * An agent skill is a short instruction pack added to the system prompt while it is switched on.
 * Built-in skills ship with the app; custom skills are written by the user and stored on the phone.
 * Only enabled skills cost tokens, and the total is capped so small models are not overloaded.
 */
data class Skill(
  val id: String,
  val name: String,
  val description: String,
  val prompt: String,
  val builtIn: Boolean,
  val defaultOn: Boolean = false,
  /** Also applied in plain chat (answers), not only when building. */
  val forChat: Boolean = false
)

object Skills {
  private var prefs: SharedPreferences? = null

  /** Bumped on every change so Compose screens re-read the list. */
  var version by mutableIntStateOf(0)
    private set

  private const val MAX_PROMPT_CHARS = 1500

  val builtIn: List<Skill> = listOf(
    Skill(
      "web-app", "Web app builder",
      "index.html + styles.css + app.js, correctly linked.",
      "Always create index.html, styles.css and app.js. index.html must contain <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">, " +
        "<link rel=\"stylesheet\" href=\"styles.css\"> and <script src=\"app.js\"></script> before </body>. " +
        "Every id or class used by app.js must exist in index.html. Code must run without errors.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "ui-polish", "Clean mobile UI",
      "Rounded cards, big tap targets, fits a 360 px screen.",
      "Design for a 360px wide phone: system-ui font, 16px padding, 14px rounded cards, buttons at least 44px tall, " +
        "flex or grid layout, no horizontal scroll, sizes in %, rem or vw (never fixed widths above 340px).",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "bug-fixer", "Bug fixer",
      "Fix errors by changing only what is broken.",
      "When fixing errors: read the error lines, change only what is broken, keep working code, and output the complete updated files.",
      builtIn = true, defaultOn = true
    ),
    Skill(
      "oled-dark", "OLED dark theme",
      "Black background, white text, iOS blue accent.",
      "Use a dark OLED theme: body background #000000, text #ffffff, cards #1c1c1e, accent #0a84ff, subtle 1px borders #2a2a2c.",
      builtIn = true
    ),
    Skill(
      "games", "Games and 3D",
      "Canvas or CSS 3D games with touch controls.",
      "For games use a canvas or CSS grid sized with min(100vw, 100vh), a requestAnimationFrame loop, touch and keyboard controls, " +
        "a score display and a restart button. For 3D use CSS 3D transforms or canvas math, no libraries.",
      builtIn = true
    ),
    Skill(
      "indian-ui", "Telugu / Indian language UI",
      "Correct lang attribute and fonts for Telugu, Hindi.",
      "Write UI text in the language the user asks for. For Telugu use <html lang=\"te\"> and font-family 'Noto Sans Telugu', system-ui, sans-serif; " +
        "for Hindi use lang=\"hi\". Keep text short and large (at least 16px).",
      builtIn = true
    ),
    Skill(
      "storage", "Offline data storage",
      "Save data in localStorage, no network.",
      "Persist user data with localStorage (JSON.stringify / JSON.parse inside try/catch). Never call network APIs or CDNs.",
      builtIn = true
    ),
    Skill(
      "concise-chat", "Short answers",
      "Brief, direct chat replies.",
      "In chat answer briefly and directly, in the same language the user writes in.",
      builtIn = true, defaultOn = true, forChat = true
    )
  )

  fun init(context: Context) {
    if (prefs == null) prefs = context.applicationContext.getSharedPreferences("agent_skills", Context.MODE_PRIVATE)
  }

  private fun customArray(): JSONArray =
    runCatching { JSONArray(prefs?.getString("custom", "[]") ?: "[]") }.getOrDefault(JSONArray())

  fun custom(): List<Skill> = runCatching {
    val arr = customArray()
    (0 until arr.length()).map { i ->
      val o = arr.getJSONObject(i)
      Skill(
        id = o.getString("id"),
        name = o.getString("name"),
        // v1.5: custom skills keep their own description (older ones fall back to "Custom skill").
        description = o.optString("description").ifBlank { "Custom skill" },
        prompt = o.getString("prompt"),
        builtIn = false,
        defaultOn = true,
        forChat = false
      )
    }
  }.getOrDefault(emptyList())

  fun all(): List<Skill> = builtIn + custom()

  fun isEnabled(skill: Skill): Boolean = prefs?.getBoolean("on_${skill.id}", skill.defaultOn) ?: skill.defaultOn

  fun setEnabled(skill: Skill, on: Boolean) {
    prefs?.edit()?.putBoolean("on_${skill.id}", on)?.apply()
    version++
  }

  /** v1.5: why [name] cannot be used (empty, too long, or taken by a built-in or another custom skill), or null. */
  fun nameError(name: String, ignoreId: String? = null): String? =
    SkillCodec.validate(name, "", "x")
      ?: if (SkillCodec.collides(name, all().map { it.id to it.name }, ignoreId)) "A skill named \"${name.trim()}\" already exists." else null

  /**
   * v1.5: creates (or, with [editId], updates) a custom skill. Returns an error message, or null on success.
   * [enabled] = false is used for imports: an imported skill never switches itself on.
   */
  fun saveCustom(name: String, description: String, prompt: String, editId: String? = null, enabled: Boolean = true): String? {
    nameError(name, editId)?.let { return it }
    SkillCodec.validate(name, description, prompt)?.let { return it }
    val arr = customArray()
    val id = editId ?: ("c_" + UUID.randomUUID().toString().take(8))
    val o = JSONObject().put("id", id).put("name", name.trim()).put("description", description.trim()).put("prompt", prompt.trim())
    val out = JSONArray()
    var replaced = false
    for (i in 0 until arr.length()) {
      val cur = arr.getJSONObject(i)
      if (cur.getString("id") == id) { out.put(o); replaced = true } else out.put(cur)
    }
    if (!replaced) out.put(o)
    val e = prefs?.edit()?.putString("custom", out.toString())
    if (editId == null) e?.putBoolean("on_$id", enabled)
    e?.apply()
    version++
    return null
  }

  fun deleteCustom(id: String) {
    val arr = customArray()
    val kept = JSONArray()
    for (i in 0 until arr.length()) if (arr.getJSONObject(i).getString("id") != id) kept.put(arr.getJSONObject(i))
    prefs?.edit()?.putString("custom", kept.toString())?.remove("on_$id")?.apply()
    version++
  }

  /**
   * v1.6: names of the skills [promptFor] actually puts in the prompt, for "What the AI sees".
   * A skill cut by the size cap is marked, and one that does not fit at all is left out (it was not sent).
   */
  fun activeNames(chat: Boolean): List<String> {
    val active = all().filter { isEnabled(it) && (!chat || it.forChat) }
    var pos = "\nSkills:\n".length
    val out = mutableListOf<String>()
    for ((i, sk) in active.withIndex()) {
      if (pos >= MAX_PROMPT_CHARS) break
      val len = (if (i > 0) 1 else 0) + 2 + sk.prompt.length
      out += if (pos + len > MAX_PROMPT_CHARS) "${sk.name} (cut short by the ${MAX_PROMPT_CHARS}-character skill limit)" else sk.name
      pos += len
    }
    return out
  }

  /** Text appended to the system prompt: the enabled skills (chat mode only uses chat skills). */
  fun promptFor(chat: Boolean): String {
    val active = all().filter { isEnabled(it) && (!chat || it.forChat) }
    if (active.isEmpty()) return ""
    return ("\nSkills:\n" + active.joinToString("\n") { "- " + it.prompt }).take(MAX_PROMPT_CHARS)
  }
}
