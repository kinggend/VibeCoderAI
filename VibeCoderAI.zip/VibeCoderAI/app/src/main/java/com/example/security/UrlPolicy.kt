package com.example.security

/**
 * v1.7.6: where an API key may be sent in plain text. https:// is always fine. http:// is only for this phone
 * and the local network (Ollama, llama-server, LM Studio on a PC), never for a public host, because the
 * Authorization header would cross the internet readable by anyone on the path. Pure Kotlin, unit-tested.
 */
object UrlPolicy {
  private val IPV4 = Regex("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$")

  fun scheme(url: String): String? = Regex("^([A-Za-z][A-Za-z0-9+.-]*):").find(url.trim())?.groupValues?.get(1)?.lowercase()

  fun host(url: String): String? {
    val rest = url.trim().substringAfter("://", "")
    if (rest.isEmpty()) return null
    val authority = rest.substringBefore('/').substringBefore('?').substringBefore('#').substringAfterLast('@')
    val h = if (authority.startsWith("[")) authority.substringAfter('[').substringBefore(']') else authority.substringBefore(':')
    return h.lowercase().ifEmpty { null }
  }

  fun isPrivateHost(host: String): Boolean {
    if (host == "localhost" || host.endsWith(".local") || host.endsWith(".lan") || host.endsWith(".internal")) return true
    if (host == "::1" || host.startsWith("fe80:") || host.startsWith("fc") || host.startsWith("fd")) return host.contains(':')
    val m = IPV4.find(host) ?: return false
    val o = m.groupValues.drop(1).map { it.toInt() }
    if (o.any { it > 255 }) return false
    return when {
      o[0] == 10 || o[0] == 127 -> true
      o[0] == 192 && o[1] == 168 -> true
      o[0] == 172 && o[1] in 16..31 -> true
      o[0] == 169 && o[1] == 254 -> true
      o[0] == 100 && o[1] in 64..127 -> true   // CGNAT / Tailscale
      else -> false
    }
  }

  /** An error message when [url] must not be called with credentials, or null when it is fine. */
  fun remoteProblem(url: String): String? {
    val s = scheme(url) ?: return "The server address needs to start with https:// or http://."
    val h = host(url) ?: return "The server address has no host name."
    return when (s) {
      "https" -> null
      "http" -> if (isPrivateHost(h)) null else
        "Plain http:// is only allowed for this phone or your local network. Use https:// for $h so your API key is not sent in the clear."
      else -> "Only https:// and http:// server addresses are supported."
    }
  }

  /** Links the phone agent may open on the web: http and https only (never file:, content:, intent:, tel:, sms:...). */
  fun isWebUrl(url: String): Boolean = scheme(url).let { it == "http" || it == "https" } && host(url) != null
}
