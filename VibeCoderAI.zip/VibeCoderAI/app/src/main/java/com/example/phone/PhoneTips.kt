package com.example.phone

/**
 * v1.7.5: short, app-agnostic help that makes the general model loop sturdier without a script per app.
 * Pure Kotlin, unit-tested without Android.
 */
object PhoneTips {
  /** Always-on habits for any app (kept tiny: every word costs prompt time on a phone). */
  const val GENERAL = "Habits: to find something, tap the Search icon or bar, type the name, then tap the matching result. " +
    "If a list is long, scroll before giving up. Never repeat an action that did nothing."

  private val FILES = Regex("files|file manager|my files|documents|downloads", RegexOption.IGNORE_CASE)
  private val SETTINGS = Regex("settings", RegexOption.IGNORE_CASE)
  private val CHAT = Regex("whatsapp|telegram|messages|signal", RegexOption.IGNORE_CASE)
  private val MAPS = Regex("maps", RegexOption.IGNORE_CASE)

  private val QUICK = Regex(
    "flash ?light|torch|wi-?fi|bluetooth|hotspot|airplane|flight mode|mobile data|brightness|do not disturb|\\bdnd\\b|auto.?rotate|location|silent|vibrate|battery saver|dark mode",
    RegexOption.IGNORE_CASE
  )
  private val HOME = Regex("home screen|launcher", RegexOption.IGNORE_CASE)

  /** A hint from the task itself: system switches live in quick settings, not in an app. */
  fun forTask(task: String): String? =
    if (QUICK.containsMatchIn(task)) "System switches (flashlight, Wi-Fi, Bluetooth, brightness...) are tiles in quick settings: " +
      "send {\"action\":\"quick_settings\"}, then tap the tile. Do not open apps for them." else null

  /** One extra line for the current app, or null. */
  fun forApp(label: String, pkg: String): String? {
    val k = "$label $pkg"
    return when {
      HOME.containsMatchIn(k) -> "You are on the home screen. Do not wait: open the app the task needs with open_app, or use quick_settings for system switches."
      FILES.containsMatchIn(k) -> "Files app: use the Search icon at the top, type the file name, tap the result. Folders like Downloads are under Browse or Internal storage."
      CHAT.containsMatchIn(k) -> "Chat app: open the chat first, then tap the Message box, type, then Send. Check the chat title is the right person."
      SETTINGS.containsMatchIn(k) -> "Settings: use the search bar at the top instead of scrolling through menus."
      MAPS.containsMatchIn(k) -> "Maps: tap the search box, type the place, tap the first suggestion, then Directions."
      else -> null
    }
  }

  /** A warning for the model when the screen has not changed, scaled by how many steps in a row. */
  fun stuckHint(unchanged: Int): String? = when {
    unchanged >= 4 -> "STUCK: the screen has not changed for $unchanged steps. Do something different now: press back, scroll, or tap another element. Do not repeat the last action."
    unchanged >= 2 -> "The last action did not change the screen. Try a different element or scroll."
    else -> null
  }

  /** On the first step the model is told to think in steps before acting. */
  fun planLine(step: Int): String? =
    if (step == 1) "Plan: decide the 3-5 steps this task needs, then do only the next one." else null
}
