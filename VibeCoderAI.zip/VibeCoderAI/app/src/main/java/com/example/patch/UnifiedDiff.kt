package com.example.patch

/**
 * v1.4 ApplyPatch: parses and applies unified diffs (`--- a/x`, `+++ b/x`, `@@ -l,n +l,n @@`).
 * Every hunk's context and removed lines must match the file exactly (only a trailing CR is ignored);
 * a hunk may sit up to [MAX_OFFSET] lines away from its stated position. Any mismatch rejects the whole
 * patch for that file, nothing is half-applied. Pure: no I/O, unit tested.
 */
object UnifiedDiff {

  const val MAX_OFFSET = 200

  data class Hunk(val oldStart: Int, val lines: List<String>) {
    /** Lines the file must contain (context + removed), in order. */
    val oldLines: List<String> get() = lines.filter { it.startsWith(" ") || it.startsWith("-") || it.isEmpty() }.map { if (it.isEmpty()) "" else it.substring(1) }
    /** Lines after the hunk is applied (context + added). */
    val newLines: List<String> get() = lines.filter { it.startsWith(" ") || it.startsWith("+") || it.isEmpty() }.map { if (it.isEmpty()) "" else it.substring(1) }
  }

  /** One file's part of a patch. [oldPath]/[newPath] are null for /dev/null (create / delete). */
  data class FilePatch(val oldPath: String?, val newPath: String?, val hunks: List<Hunk>) {
    val isNewFile: Boolean get() = oldPath == null && newPath != null
    val isDelete: Boolean get() = newPath == null && oldPath != null
    val path: String get() = newPath ?: oldPath ?: ""
  }

  sealed class ApplyResult {
    data class Ok(val text: String, val hunksApplied: Int) : ApplyResult()
    data class Fail(val reason: String) : ApplyResult()
  }

  private val HUNK = Regex("""^@@\s+-(\d+)(?:,(\d+))?\s+\+(\d+)(?:,(\d+))?\s+@@.*$""")

  private fun cleanPath(raw: String): String? {
    val p = raw.trim().substringBefore('\t').trim()
    if (p == "/dev/null") return null
    return p.removePrefix("a/").removePrefix("b/")
  }

  /**
   * Parses [diff]. When the diff has no ---/+++ headers, its hunks are attributed to [defaultPath].
   * Throws [IllegalArgumentException] for malformed input.
   */
  fun parse(diff: String, defaultPath: String? = null): List<FilePatch> {
    val lines = diff.replace("\r\n", "\n").split('\n')
    val out = mutableListOf<FilePatch>()
    var oldPath: String? = defaultPath
    var newPath: String? = defaultPath
    var hunks = mutableListOf<Hunk>()
    var sawHeader = false
    var i = 0

    fun flush() {
      if (hunks.isNotEmpty() || (sawHeader && (oldPath == null || newPath == null))) {
        if (oldPath == null && newPath == null) throw IllegalArgumentException("Patch has no file path.")
        out.add(FilePatch(oldPath, newPath, hunks))
      }
      hunks = mutableListOf()
    }

    while (i < lines.size) {
      val line = lines[i]
      when {
        line.startsWith("--- ") && i + 1 < lines.size && lines[i + 1].startsWith("+++ ") -> {
          flush()
          sawHeader = true
          oldPath = cleanPath(line.substring(4))
          newPath = cleanPath(lines[i + 1].substring(4))
          i += 2
          continue
        }
        line.startsWith("@@") -> {
          val m = HUNK.matchEntire(line.trim()) ?: throw IllegalArgumentException("Bad hunk header: $line")
          val oldStart = m.groupValues[1].toInt()
          val oldCount = m.groupValues[2].ifEmpty { "1" }.toInt()
          val newCount = m.groupValues[4].ifEmpty { "1" }.toInt()
          val body = mutableListOf<String>()
          var seenOld = 0
          var seenNew = 0
          i++
          while (i < lines.size && (seenOld < oldCount || seenNew < newCount)) {
            val l = lines[i]
            when {
              l.startsWith("\\") -> { i++; continue } // "\ No newline at end of file"
              l.startsWith(" ") || l.isEmpty() -> { seenOld++; seenNew++ }
              l.startsWith("-") -> seenOld++
              l.startsWith("+") -> seenNew++
              else -> throw IllegalArgumentException("Unexpected line in hunk: $l")
            }
            body.add(l)
            i++
          }
          if (seenOld != oldCount || seenNew != newCount) throw IllegalArgumentException("Hunk at -$oldStart is truncated.")
          while (i < lines.size && lines[i].startsWith("\\")) i++
          hunks.add(Hunk(oldStart, body))
          continue
        }
        else -> i++
      }
    }
    flush()
    if (out.isEmpty()) throw IllegalArgumentException("No hunks found. Use unified diff format with @@ headers.")
    return out
  }

  /** Applies [patch]'s hunks to [original]. */
  fun apply(original: String, patch: FilePatch): ApplyResult {
    if (patch.isNewFile) {
      if (original.isNotEmpty()) return ApplyResult.Fail("${patch.path} already exists.")
      val text = patch.hunks.flatMap { it.newLines }.joinToString("\n")
      return ApplyResult.Ok(if (text.isEmpty()) text else text + "\n", patch.hunks.size)
    }
    val crlf = original.contains("\r\n")
    val norm = if (crlf) original.replace("\r\n", "\n") else original
    val endsWithNl = norm.endsWith("\n")
    val file = (if (endsWithNl) norm.dropLast(1) else norm).let { if (it.isEmpty() && !endsWithNl) mutableListOf() else it.split('\n').toMutableList() }

    var delta = 0 // shift caused by earlier hunks
    var lastEnd = 0
    patch.hunks.forEachIndexed { idx, h ->
      val old = h.oldLines
      val expected = (h.oldStart - 1 + delta).coerceAtLeast(0).let { if (old.isEmpty() && h.oldStart > 0) h.oldStart + delta else it }
      val at = findBlock(file, old, expected, lastEnd)
        ?: return ApplyResult.Fail("Hunk ${idx + 1} (line ${h.oldStart}) does not match the file. Read the file again and regenerate the patch.")
      val newL = h.newLines
      repeat(old.size) { file.removeAt(at) }
      file.addAll(at, newL)
      delta += newL.size - old.size
      lastEnd = at + newL.size
    }
    var text = file.joinToString("\n")
    if (endsWithNl && file.isNotEmpty()) text += "\n"
    if (crlf) text = text.replace("\n", "\r\n")
    return ApplyResult.Ok(text, patch.hunks.size)
  }

  private fun matchesAt(file: List<String>, block: List<String>, at: Int): Boolean {
    if (at < 0 || at + block.size > file.size) return false
    for (k in block.indices) if (file[at + k].trimEnd('\r') != block[k].trimEnd('\r')) return false
    return true
  }

  /** Exact position first, then the nearest match within [MAX_OFFSET] lines (never before [minAt]). */
  private fun findBlock(file: List<String>, block: List<String>, expected: Int, minAt: Int): Int? {
    if (block.isEmpty()) return expected.coerceIn(minAt.coerceAtMost(file.size), file.size)
    if (expected >= minAt && matchesAt(file, block, expected)) return expected
    for (d in 1..MAX_OFFSET) {
      val up = expected - d
      val down = expected + d
      if (up >= minAt && matchesAt(file, block, up)) return up
      if (down >= minAt && matchesAt(file, block, down)) return down
      if (up < minAt && down > file.size) break
    }
    return null
  }
}
