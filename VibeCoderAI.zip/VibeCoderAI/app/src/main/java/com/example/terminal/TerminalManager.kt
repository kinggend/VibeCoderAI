package com.example.terminal

import com.example.security.SecurityManager
import com.example.security.ValidationResult
import java.io.File

data class TerminalExecutionResult(
  val command: String,
  val exitCode: Int,
  val stdout: String,
  val stderr: String,
  val durationMs: Long,
  val timedOut: Boolean = false,
  val blockedReason: String? = null
)

class TerminalManager(
  private val securityManager: SecurityManager = SecurityManager()
) {

  /** Commands typed in the Terminal screen this session, newest first (observable by Compose). */
  private val recent = androidx.compose.runtime.mutableStateListOf<String>()
  val recentCommands: List<String> get() = recent

  /** Remembers [command] for the Terminal history list (deduplicated, at most 20 entries). */
  fun recordCommand(command: String) {
    val c = command.trim()
    if (c.isEmpty()) return
    recent.remove(c)
    recent.add(0, c)
    while (recent.size > 20) recent.removeAt(recent.lastIndex)
  }

  /**
   * v1.6: timeout for commands that do not pass their own, from Settings (Terminal command timeout).
   * null = no limit (the Stop button / agent Stop still ends the process).
   */
  @Volatile var defaultTimeoutMs: Long? = TimeoutConfig.toMillis(TimeoutConfig.DEFAULT_SEC)

  /** Runs [command] to the end (non-interactive callers: tests, tools). Cancelling the caller kills the process. */
  suspend fun executeCommand(
    command: String,
    workspaceDir: File,
    timeoutMs: Long? = defaultTimeoutMs
  ): TerminalExecutionResult = start(command, workspaceDir).await(timeoutMs)

  /**
   * v1.6: starts [command] with stdin kept open, so the Terminal screen (or the user, when the agent asks)
   * can type into it. Blocked and built-in commands return an already finished session.
   */
  fun start(command: String, workspaceDir: File): TerminalSession {
    when (val validation = securityManager.validateCommand(command, workspaceDir)) {
      is ValidationResult.Blocked -> return TerminalSession.finished(
        TerminalExecutionResult(command, 126, "", "Security Error: ${validation.reason}", 0, blockedReason = validation.reason)
      )
      else -> {}
    }
    if (!workspaceDir.exists()) workspaceDir.mkdirs()
    tryExecuteInternalCommand(command, workspaceDir)?.let { return TerminalSession.finished(it) }
    return try {
      val process = ProcessBuilder().command("sh", "-c", command).directory(workspaceDir).redirectErrorStream(false).start()
      TerminalSession(command, process)
    } catch (e: Exception) {
      TerminalSession.finished(TerminalExecutionResult(command, 1, "", "Process Execution Error: ${e.message}", 0))
    }
  }

  private fun tryExecuteInternalCommand(rawCommand: String, workspace: File): TerminalExecutionResult? {
    val tokens = rawCommand.trim().split(Regex("\\s+"))
    if (tokens.isEmpty()) return null
    val cmd = tokens[0]
    val args = tokens.drop(1)

    return when (cmd) {
      "pwd" -> TerminalExecutionResult(
        command = rawCommand,
        exitCode = 0,
        stdout = workspace.absolutePath,
        stderr = "",
        durationMs = 0
      )
      "ls" -> {
        val targetDir = if (args.isNotEmpty() && !args.last().startsWith("-")) {
          File(workspace, args.last())
        } else workspace

        if (!securityManager.isPathSafe(targetDir, workspace)) {
          return TerminalExecutionResult(rawCommand, 1, "", "ls: Access denied outside workspace", 0)
        }

        if (!targetDir.exists()) {
          return TerminalExecutionResult(rawCommand, 2, "", "ls: ${targetDir.name}: No such file or directory", 0)
        }

        val showAll = args.any { it.contains("a") }
        val longFormat = args.any { it.contains("l") }

        val files = targetDir.listFiles()?.filter { showAll || !it.name.startsWith(".") } ?: emptyList()
        val out = if (longFormat) {
          files.joinToString("\n") { file ->
            val type = if (file.isDirectory) "d" else "-"
            val size = file.length()
            val name = if (file.isDirectory) "${file.name}/" else file.name
            "$type rwxr-xr-x 1 user staff $size $name"
          }
        } else {
          files.joinToString("  ") { if (it.isDirectory) "${it.name}/" else it.name }
        }

        TerminalExecutionResult(rawCommand, 0, out, "", 0)
      }
      "cat" -> {
        if (args.isEmpty()) return TerminalExecutionResult(rawCommand, 1, "", "cat: missing file operand", 0)
        val file = File(workspace, args[0])
        if (!securityManager.isPathSafe(file, workspace)) {
          return TerminalExecutionResult(rawCommand, 1, "", "cat: Access denied outside workspace", 0)
        }
        if (!file.exists() || file.isDirectory) {
          return TerminalExecutionResult(rawCommand, 1, "", "cat: ${args[0]}: No such file", 0)
        }
        TerminalExecutionResult(rawCommand, 0, file.readText(), "", 0)
      }
      "echo" -> {
        val text = args.joinToString(" ").removeSurrounding("\"").removeSurrounding("'")
        TerminalExecutionResult(rawCommand, 0, text, "", 0)
      }
      "mkdir" -> {
        if (args.isEmpty()) return TerminalExecutionResult(rawCommand, 1, "", "mkdir: missing operand", 0)
        val dir = File(workspace, args.last())
        if (!securityManager.isPathSafe(dir, workspace)) {
          return TerminalExecutionResult(rawCommand, 1, "", "mkdir: Access denied outside workspace", 0)
        }
        val ok = dir.mkdirs()
        TerminalExecutionResult(rawCommand, if (ok || dir.exists()) 0 else 1, "", if (ok || dir.exists()) "" else "mkdir: cannot create directory", 0)
      }
      "find" -> {
        val found = workspace.walkTopDown().maxDepth(4).map { it.relativeTo(workspace).path }.filter { it.isNotEmpty() }
        TerminalExecutionResult(rawCommand, 0, found.joinToString("\n"), "", 0)
      }
      "git" -> {
        if (args.firstOrNull() == "status") {
          val files = workspace.walkTopDown().filter { it.isFile }.toList()
          TerminalExecutionResult(
            rawCommand,
            0,
            "On branch main\nWorkspace clean: ${files.size} project files tracked.",
            "",
            0
          )
        } else null
      }
      else -> null
    }
  }
}
