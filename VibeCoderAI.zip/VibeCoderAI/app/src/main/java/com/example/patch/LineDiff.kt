package com.example.patch

import com.example.data.model.DiffLine
import com.example.data.model.DiffType

/**
 * v1.4: line diff for approval dialogs (LCS on lines, unchanged runs collapsed to [context] lines each
 * side). Large inputs fall back to "all removed / all added" so the UI never stalls. Pure, unit tested.
 */
object LineDiff {
  private const val MAX_CELLS = 2_000_000L

  fun diff(old: String, new: String, context: Int = 3): List<DiffLine> {
    val a = if (old.isEmpty()) emptyList() else old.replace("\r\n", "\n").split('\n')
    val b = if (new.isEmpty()) emptyList() else new.replace("\r\n", "\n").split('\n')
    // Trim common prefix / suffix first: most edits are small.
    var pre = 0
    while (pre < a.size && pre < b.size && a[pre] == b[pre]) pre++
    var suf = 0
    while (suf < a.size - pre && suf < b.size - pre && a[a.size - 1 - suf] == b[b.size - 1 - suf]) suf++
    val am = a.subList(pre, a.size - suf)
    val bm = b.subList(pre, b.size - suf)

    val full = ArrayList<DiffLine>()
    for (i in 0 until pre) full.add(DiffLine(DiffType.UNCHANGED, a[i], i + 1))
    if (am.size.toLong() * bm.size.toLong() > MAX_CELLS) {
      am.forEachIndexed { i, l -> full.add(DiffLine(DiffType.REMOVED, l, pre + i + 1)) }
      bm.forEachIndexed { i, l -> full.add(DiffLine(DiffType.ADDED, l, pre + i + 1)) }
    } else {
      val n = am.size
      val m = bm.size
      val lcs = Array(n + 1) { IntArray(m + 1) }
      for (i in n - 1 downTo 0) for (j in m - 1 downTo 0) {
        lcs[i][j] = if (am[i] == bm[j]) lcs[i + 1][j + 1] + 1 else maxOf(lcs[i + 1][j], lcs[i][j + 1])
      }
      var i = 0
      var j = 0
      while (i < n || j < m) {
        when {
          i < n && j < m && am[i] == bm[j] -> { full.add(DiffLine(DiffType.UNCHANGED, am[i], pre + i + 1)); i++; j++ }
          j < m && (i >= n || lcs[i][j + 1] >= lcs[i + 1][j]) -> { full.add(DiffLine(DiffType.ADDED, bm[j], pre + j + 1)); j++ }
          else -> { full.add(DiffLine(DiffType.REMOVED, am[i], pre + i + 1)); i++ }
        }
      }
    }
    for (k in 0 until suf) {
      val idx = a.size - suf + k
      full.add(DiffLine(DiffType.UNCHANGED, a[idx], idx + 1))
    }
    return collapse(full, context)
  }

  /** Keeps changed lines plus [context] unchanged lines around them; gaps become one "…" line. */
  fun collapse(lines: List<DiffLine>, context: Int): List<DiffLine> {
    if (lines.none { it.type != DiffType.UNCHANGED }) return emptyList()
    val keep = BooleanArray(lines.size)
    lines.forEachIndexed { i, l ->
      if (l.type != DiffType.UNCHANGED) for (k in (i - context).coerceAtLeast(0)..(i + context).coerceAtMost(lines.lastIndex)) keep[k] = true
    }
    val out = ArrayList<DiffLine>()
    var gap = false
    lines.forEachIndexed { i, l ->
      if (keep[i]) { out.add(l); gap = false } else if (!gap) { out.add(DiffLine(DiffType.UNCHANGED, "…", 0)); gap = true }
    }
    return out
  }

  /** Counts (added, removed) lines. */
  fun stats(lines: List<DiffLine>): Pair<Int, Int> =
    lines.count { it.type == DiffType.ADDED } to lines.count { it.type == DiffType.REMOVED }
}
