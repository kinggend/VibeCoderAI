package com.example.data

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Encrypts small secrets (API key, server URL, model name) with an AES-256-GCM key that lives in
 * the Android Keystore. The key never leaves the Keystore (TEE / StrongBox where the phone has
 * one), so the app's files only ever hold ciphertext. Values are stored as "v1:<iv>:<ciphertext>".
 */
class SecretCipher(context: Context) {
  private val prefs = context.getSharedPreferences(FILE, Context.MODE_PRIVATE)

  fun get(name: String): String {
    val stored = prefs.getString(name, null) ?: return ""
    return runCatching { decrypt(stored) }.getOrElse {
      // Key lost (restored from another phone, Keystore wiped): drop the unreadable value.
      prefs.edit().remove(name).apply(); ""
    }
  }

  fun put(name: String, value: String) {
    if (value.isEmpty()) { prefs.edit().remove(name).apply(); return }
    prefs.edit().putString(name, encrypt(value)).apply()
  }

  private fun encrypt(plain: String): String {
    val c = Cipher.getInstance(TRANSFORM)
    c.init(Cipher.ENCRYPT_MODE, key())
    val ct = c.doFinal(plain.toByteArray(Charsets.UTF_8))
    return "v1:" + b64(c.iv) + ":" + b64(ct)
  }

  private fun decrypt(stored: String): String {
    val parts = stored.split(":")
    require(parts.size == 3 && parts[0] == "v1") { "bad format" }
    val c = Cipher.getInstance(TRANSFORM)
    c.init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, unb64(parts[1])))
    return String(c.doFinal(unb64(parts[2])), Charsets.UTF_8)
  }

  private fun key(): SecretKey {
    val ks = KeyStore.getInstance(KEYSTORE).apply { load(null) }
    (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
    fun gen(strongBox: Boolean): SecretKey {
      val b = KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
        .setKeySize(256)
        .setRandomizedEncryptionRequired(true)
      if (strongBox && android.os.Build.VERSION.SDK_INT >= 28) b.setIsStrongBoxBacked(true)
      val g = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE)
      g.init(b.build())
      return g.generateKey()
    }
    // StrongBox (separate secure chip) when present, otherwise the TEE-backed Keystore.
    return runCatching { gen(true) }.getOrElse { gen(false) }
  }

  private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
  private fun unb64(s: String) = Base64.decode(s, Base64.NO_WRAP)

  companion object {
    const val FILE = "vibecoder_secrets"
    private const val KEYSTORE = "AndroidKeyStore"
    private const val ALIAS = "vibecoder_secrets_aes"
    private const val TRANSFORM = "AES/GCM/NoPadding"
  }
}
