package com.example.agent.tools

import com.example.data.model.Project
import com.example.security.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class FileReadTool(
  private val securityManager: SecurityManager = SecurityManager()
) : Tool {
  override val name = "file_read"
  override val description = "Reads content from a file with optional startLine and endLine boundaries."

  override suspend fun execute(project: Project, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
    val path = arguments["path"] ?: return@withContext ToolResult(false, "", "Missing 'path' parameter.")
    val file = if (path.startsWith("/")) File(path) else File(project.rootDir, path)

    if (!securityManager.isPathSafe(file, project.rootDir)) {
      return@withContext ToolResult(false, "", "Security Violation: Access denied to path outside workspace.")
    }

    if (!file.exists() || file.isDirectory) {
      return@withContext ToolResult(false, "", "File does not exist or is a directory: $path")
    }

    try {
      val lines = file.readLines()
      val startLine = arguments["start_line"]?.toIntOrNull()?.coerceAtLeast(1) ?: 1
      val endLine = arguments["end_line"]?.toIntOrNull()?.coerceAtMost(lines.size) ?: lines.size

      if (startLine > lines.size) {
        return@withContext ToolResult(true, "")
      }

      val sliced = lines.subList(startLine - 1, endLine)
      val formatted = sliced.mapIndexed { idx, line ->
        "${startLine + idx}: $line"
      }.joinToString("\n")

      ToolResult(
        success = true,
        output = formatted,
        metadata = mapOf("totalLines" to lines.size, "returnedLines" to sliced.size)
      )
    } catch (e: Exception) {
      ToolResult(false, "", "Failed to read file: ${e.message}")
    }
  }
}
