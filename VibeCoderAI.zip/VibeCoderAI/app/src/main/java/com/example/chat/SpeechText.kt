package com.example.chat

/**
 * v1.6.1 voice mode: turns a model reply (markdown, code, agent tags) into text worth reading aloud.
 * Code is never read out: each code block or file becomes [CODE_NOTE], since it is shown on screen.
 */
object SpeechText {
  const val CODE_NOTE = "Code shown on screen."

  private val fence = Regex("```[\\s\\S]*?(```|$)")
  private val tildeFence = Regex("~~~[\\s\\S]*?(~~~|$)")
  private val fileBlock = Regex("<file\\b[^>]*>[\\s\\S]*?(</file>|$)", RegexOption.IGNORE_CASE)
  private val toolTag = Regex("<tool\\b[^>]*/>|<tool\\b[^>]*>[\\s\\S]*?(</tool>|$)", RegexOption.IGNORE_CASE)
  private val thinkTag = Regex("<think>[\\s\\S]*?(</think>|$)", RegexOption.IGNORE_CASE)
  private val htmlTag = Regex("</?[A-Za-z][^>]*>")
  private val image = Regex("!\\[([^\\]]*)]\\([^)]*\\)")
  private val link = Regex("\\[([^\\]]+)]\\([^)]*\\)")
  private val inlineCode = Regex("`([^`\\n]*)`")
  private val bold = Regex("(\\*\\*|~~)(?=\\S)(.+?)(?<=\\S)\\1")
  private val starItalic = Regex("\\*(?=\\S)([^*\\n]+?)(?<=\\S)\\*")
  private val underscore = Regex("(?<!\\w)(__|_)(?=\\S)(.+?)(?<=\\S)\\1(?!\\w)")
  private val url = Regex("https?://\\S+")
  private val tableRule = Regex("^\\s*\\|?\\s*:?-{2,}:?\\s*(\\|\\s*:?-{2,}:?\\s*)*\\|?\\s*$")
  private val lineMarker = Regex("^\\s*(#{1,6}\\s+|>+\\s?|[-*+]\\s+(\\[[ xX]]\\s+)?|\\d+[.)]\\s+)")
  private val repeatedNote = Regex("(${Regex.escape(CODE_NOTE)}\\s*){2,}")

  fun forSpeech(reply: String): String {
    var s = reply.replace("\r\n", "\n")
    s = fence.replace(s, "\n$CODE_NOTE\n")
    s = tildeFence.replace(s, "\n$CODE_NOTE\n")
    s = fileBlock.replace(s, "\n$CODE_NOTE\n")
    s = toolTag.replace(s, " ")
    s = thinkTag.replace(s, " ")
    s = htmlTag.replace(s, " ")
    s = image.replace(s) { it.groupValues[1] }
    s = link.replace(s) { it.groupValues[1] }
    s = inlineCode.replace(s) { it.groupValues[1] }
    s = s.lines().filterNot { tableRule.matches(it) && it.contains('-') }.joinToString("\n") { line ->
      var l = lineMarker.replace(line, "")
      if (l.trim().startsWith("|")) l = l.trim().trim('|').split('|').joinToString(", ") { it.trim() }
      l
    }
    s = bold.replace(s) { it.groupValues[2] }
    s = starItalic.replace(s) { it.groupValues[1] }
    s = underscore.replace(s) { it.groupValues[2] }
    s = url.replace(s, "link")
    // A line without end punctuation becomes its own sentence so TTS pauses between list items.
    s = s.lines().map { it.trim() }.filter { it.isNotEmpty() }
      .joinToString(" ") { if (it.last() in ".!?:;,") it else "$it." }
    s = s.replace(Regex("\\s+"), " ").replace(Regex(" ([.,!?;:])"), "$1").trim()
    s = repeatedNote.replace(s, "$CODE_NOTE ").trim()
    return s
  }

  /**
   * Splits [text] into pieces of at most [max] chars at sentence ends (TextToSpeech rejects input over
   * getMaxSpeechInputLength(), 4000 on most engines). A sentence longer than [max] is cut at a space.
   */
  fun chunks(text: String, max: Int = 3500): List<String> {
    require(max >= 20)
    val sentences = Regex("(?<=[.!?])\\s+").split(text.trim()).filter { it.isNotBlank() }
    val out = mutableListOf<String>()
    val cur = StringBuilder()
    fun flush() { if (cur.isNotBlank()) out += cur.toString().trim(); cur.clear() }
    for (raw in sentences) {
      var sen = raw
      while (sen.length > max) {
        flush()
        val cut = sen.lastIndexOf(' ', max).takeIf { it > 0 } ?: max
        out += sen.substring(0, cut).trim()
        sen = sen.substring(cut).trim()
      }
      if (cur.length + sen.length + 1 > max) flush()
      if (cur.isNotEmpty()) cur.append(' ')
      cur.append(sen)
    }
    flush()
    return out
  }
}

/** v1.6.1: labels for the single composer options chip and the chat header line. One source for both. */
object ChatOptionsLabels {
  /** Short form for the narrow composer ("Ultra High" -> "Ultra"); the sheet and header keep full names. */
  fun chip(roleName: String, levelLabel: String): String = "$roleName · ${levelLabel.removeSuffix(" High").ifBlank { levelLabel }}"

  fun headerLine(remote: Boolean, roleName: String, levelLabel: String, thinking: Boolean): String =
    listOfNotNull(if (remote) "Remote" else "Offline", roleName, levelLabel, if (thinking) "Think" else null)
      .joinToString(" · ")
}
