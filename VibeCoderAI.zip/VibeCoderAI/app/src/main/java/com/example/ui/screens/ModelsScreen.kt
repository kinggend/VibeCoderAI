package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import com.example.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import com.example.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.downloader.HfFile
import com.example.data.downloader.HfModel
import com.example.data.downloader.HuggingFaceApi
import com.example.data.downloader.ModelCategories
import com.example.data.downloader.ModelCategory
import com.example.data.downloader.Mmproj
import com.example.data.downloader.ModelDownloadManager
import com.example.data.downloader.ModelDownloadManager.State
import com.example.ui.components.liquidGlass
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private fun fmtSize(b: Long): String =
  if (b >= 1_000_000_000L) "%.2f GB".format(b / 1e9) else "${b / 1_000_000} MB"

private fun categoryColor(c: ModelCategory): Color = when (c) {
  ModelCategory.CODING -> CyberCyanPrimary
  ModelCategory.REASONING -> Color(0xFFBF5AF2)
  ModelCategory.VISION -> CyberAmberWarning
  ModelCategory.LONG -> Color(0xFF64D2FF)
  ModelCategory.LIGHT -> CyberGreenSuccess
  ModelCategory.GENERAL -> TextSecondary
}

private fun fmtCount(n: Long): String = if (n >= 1000) "${n / 1000}k" else n.toString()

@Composable
fun ModelsScreen(
  modelsDir: File,
  currentPath: String?,
  modelLoaded: Boolean,
  modelStatus: String?,
  downloads: ModelDownloadManager,
  onSelectModel: (String?) -> Unit,
  onUnload: () -> Unit,
  onBenchmark: () -> String,
  settings: com.example.data.model.SettingsState = com.example.data.model.SettingsState(),
  onUpdateSettings: (com.example.data.model.SettingsState) -> Unit = {},
  bottomInset: androidx.compose.ui.unit.Dp = 0.dp,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  val items by downloads.items.collectAsState()
  var query by remember { mutableStateOf("qwen2.5 coder instruct") }
  var results by remember { mutableStateOf<List<HfModel>>(emptyList()) }
  var searching by remember { mutableStateOf(false) }
  var error by remember { mutableStateOf<String?>(null) }
  var selected by remember { mutableStateOf<HfModel?>(null) }
  var category by remember { mutableStateOf<ModelCategory?>(ModelCategory.CODING) }
  var files by remember { mutableStateOf<List<HfFile>>(emptyList()) }
  var loadingFiles by remember { mutableStateOf(false) }
  val doneCount = items.values.count { it.state == State.DONE }

  // v1.4: downloads run in the background with a progress notification. On Android 13+ ask for the
  // notification permission first; a denial only hides the notification, the download still runs.
  val ctx = androidx.compose.ui.platform.LocalContext.current
  var pendingStart by remember { mutableStateOf<Pair<String, HfFile>?>(null) }
  val notifPermission = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
  ) { granted ->
    pendingStart?.let { (id, f) -> downloads.start(scope, id, f) }
    pendingStart = null
    if (!granted) {
      android.widget.Toast.makeText(ctx, "Notifications are off: the download still runs, progress shows here.", android.widget.Toast.LENGTH_LONG).show()
    }
  }
  fun startDownload(modelId: String, f: HfFile) {
    val needsAsk = android.os.Build.VERSION.SDK_INT >= 33 &&
      androidx.core.content.ContextCompat.checkSelfPermission(ctx, android.Manifest.permission.POST_NOTIFICATIONS) !=
      android.content.pm.PackageManager.PERMISSION_GRANTED
    if (needsAsk) {
      pendingStart = modelId to f
      notifPermission.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    } else {
      downloads.start(scope, modelId, f)
    }
  }

  fun search() {
    scope.launch {
      searching = true
      error = null
      selected = null
      try {
        results = withContext(Dispatchers.IO) { HuggingFaceApi.search(query) }
        if (results.isEmpty()) error = "No GGUF models found."
      } catch (e: Exception) {
        error = e.message ?: "Search failed. Check your internet connection."
      }
      searching = false
    }
  }

  fun open(m: HfModel) {
    selected = m
    files = emptyList()
    scope.launch {
      loadingFiles = true
      try {
        files = withContext(Dispatchers.IO) { HuggingFaceApi.listGguf(m.id) }
        if (files.isEmpty()) error = "No .gguf files in this repository."
      } catch (e: Exception) {
        error = e.message ?: "Could not load files."
      }
      loadingFiles = false
    }
  }

  val remote = settings.backendMode == "remote"
  Column(
    modifier = modifier
      .fillMaxSize()
      .imePadding()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 16.dp, vertical = 16.dp),
    verticalArrangement = Arrangement.spacedBy(24.dp)
  ) {
    Column {
      com.example.ui.components.LargeTitle("Models")
      Text(
        "Choose where the AI runs and manage your models.",
        color = TextSecondary, fontSize = 14.sp,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(horizontal = 2.dp)
      )
    }

    ModelSection("Run on") { BackendCard(settings, onUpdateSettings) }

    if (remote) {
      ModelSurface {
        Text("Using your remote server", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
        Text(
          "Local models are paused. Switch to \"On this phone\" to use a downloaded GGUF model.",
          color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(top = 4.dp)
        )
      }
    } else {
      ModelSection("Offline model") {
        ModelManagerCard(
          modelsDir = modelsDir,
          currentPath = currentPath,
          modelLoaded = modelLoaded,
          modelStatus = modelStatus,
          onSelectModel = onSelectModel,
          refreshKey = doneCount,
          onUnload = onUnload,
          onBenchmark = onBenchmark
        )
      }
    }

    // Active and finished downloads
    if (items.isNotEmpty()) {
      ModelSection("Downloads") {
        items.values.toList().forEach { item ->
          ModelSurface {
            Text(item.destName.removeSuffix(".gguf"), color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2)
            if (item.state != State.DONE) {
              PercentProgressBar(
                fraction = item.fraction,
                color = when (item.state) {
                  State.FAILED -> CyberCoralError
                  State.PAUSED -> CyberAmberWarning
                  else -> CyberCyanPrimary
                },
                modifier = Modifier.padding(top = 10.dp)
              )
            }
            val status = when (item.state) {
              State.RUNNING -> "${(item.fraction * 100).toInt()}% · ${fmtSize(item.downloaded)} / ${fmtSize(item.total)}"
              State.PAUSED -> "Paused · ${fmtSize(item.downloaded)} / ${fmtSize(item.total)}"
              State.DONE -> "Downloaded · ${fmtSize(item.total)}"
              State.FAILED -> item.error ?: "Failed"
            }
            val statusColor = when (item.state) {
              State.DONE -> CyberGreenSuccess
              State.FAILED -> CyberCoralError
              State.PAUSED -> CyberAmberWarning
              State.RUNNING -> TextSecondary
            }
            Text(status, color = statusColor, fontSize = 13.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(top = 8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 12.dp)) {
              when (item.state) {
                State.RUNNING -> PillButton("Pause", { downloads.pause(item.key) })
                State.PAUSED, State.FAILED -> PillButton(if (item.state == State.PAUSED) "Resume" else "Retry", {
                  startDownload(item.modelId, HfFile(item.fileName, item.total))
                }, primary = true)
                State.DONE -> {
                  // The image helper (mmproj) is not a chat model: it is picked up automatically with its vision model.
                  if (Mmproj.isMmproj(item.destName)) Text("Image helper ready. Select its vision model above.", color = CyberCyanPrimary, fontSize = 13.sp, modifier = Modifier.align(Alignment.CenterVertically))
                  else PillButton("Use this model", { onSelectModel(File(modelsDir, item.destName).absolutePath) }, primary = true)
                  PillButton("Dismiss", { downloads.dismiss(item.key) })
                }
              }
              if (item.state != State.DONE) PillButton("Cancel", { downloads.cancel(item.key) })
            }
          }
        }
      }
    }

    // Hugging Face browser
    ModelSection("Get more models", "Search Hugging Face. Internet is only used to download; replies stay fully offline.") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it; category = null },
          singleLine = true,
          modifier = Modifier.weight(1f),
          shape = com.example.ui.theme.UiTokens.CardShape,
          placeholder = { Text("Search GGUF models") },
          leadingIcon = { androidx.compose.material3.Icon(Icons.Default.Search, null, tint = TextMuted) },
          trailingIcon = if (searching) {
            {
              androidx.compose.material3.CircularProgressIndicator(
                modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = CyberCyanPrimary
              )
            }
          } else null,
          keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Search),
          keyboardActions = androidx.compose.foundation.text.KeyboardActions(onSearch = { if (!searching && query.isNotBlank()) search() }),
          colors = OutlinedTextFieldDefaults.colors(
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary,
            focusedBorderColor = CyberCyanPrimary,
            unfocusedBorderColor = ObsidianBorder,
            cursorColor = CyberCyanPrimary
          )
        )
        PillButton(
          if (searching) "..." else "Search",
          onClick = { search() },
          primary = true,
          enabled = !searching && query.isNotBlank(),
          modifier = Modifier.heightIn(min = 52.dp)
        )
      }

      Row(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())
      ) {
        ModelCategory.values().filter { it != ModelCategory.GENERAL }.forEach { c ->
          val on = category == c
          Box(modifier = Modifier.clip(CircleShape).clickable(enabled = !searching) {
            category = c
            query = c.query
            search()
          }) {
            Chip(
              c.label,
              color = if (on) Color.White else categoryColor(c),
              background = if (on) categoryColor(c) else categoryColor(c).copy(alpha = 0.14f)
            )
          }
        }
      }
      category?.let {
        Text(it.blurb, color = TextSecondary, fontSize = 12.5.sp, modifier = Modifier.padding(horizontal = 4.dp))
      }

      error?.let { Text(it, color = CyberCoralError, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp)) }

      results.forEach { m ->
        val isOpen = selected?.id == m.id
        ModelSurface(borderColor = if (isOpen) CyberCyanPrimary else ObsidianBorder) {
          Column(modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { open(m) }) {
            Text(m.id, color = if (isOpen) CyberCyanPrimary else TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 6.dp).horizontalScroll(rememberScrollState())) {
              ModelCategories.tagsFor(m.id).forEach { c ->
                Chip(
                  if (c == ModelCategory.VISION) "Vision · reads images (needs image helper)" else "Best for: ${c.label}",
                  color = categoryColor(c), background = categoryColor(c).copy(alpha = 0.14f)
                )
              }
            }
            Text("${fmtCount(m.downloads)} downloads · ${fmtCount(m.likes)} likes", color = TextSecondary, fontSize = 12.5.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(top = 2.dp))
          }
          if (isOpen) {
            if (loadingFiles) Text("Loading files...", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 10.dp))
            if (files.any { Mmproj.isMmproj(it.name) }) {
              Text(
                "Vision model: choosing a model file also downloads its image helper (mmproj), about 0.4-1.2 GB. Needs 4096 context and more RAM.",
                color = CyberAmberWarning, fontSize = 12.5.sp, lineHeight = 17.sp, modifier = Modifier.padding(top = 10.dp)
              )
            }
            files.forEach { f ->
              val k = downloads.key(m.id, f)
              val existing = items[k]
              val isHelper = Mmproj.isMmproj(f.name)
              Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth().padding(top = 12.dp)) {
                Column(modifier = Modifier.weight(1f)) {
                  Text(f.name.removeSuffix(".gguf"), color = TextPrimary, fontSize = 13.sp, maxLines = 2)
                  Row(horizontalArrangement = Arrangement.spacedBy(6.dp), modifier = Modifier.padding(top = 4.dp)) {
                    Chip(fmtSize(f.sizeBytes))
                    modelTags(f.name).forEach { Chip(it) }
                    if (isHelper) Chip("Image helper", color = CyberAmberWarning, background = CyberAmberWarning.copy(alpha = 0.14f))
                  }
                }
                if (existing == null) PillButton("Download", {
                  startDownload(m.id, f)
                  // A vision model is useless without its image helper: fetch it too (unless already added).
                  if (!isHelper) Mmproj.forDownload(f.name, files.map { it.name })?.let { hn ->
                    files.firstOrNull { it.name == hn }?.takeIf { items[downloads.key(m.id, it)] == null }?.let { downloads.start(scope, m.id, it) }
                  }
                }, primary = true, modifier = Modifier.padding(start = 8.dp))
                else Text("Added", color = TextSecondary, fontSize = 12.5.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(start = 8.dp))
              }
            }
          }
        }
      }
    }
    Spacer(modifier = Modifier.height(bottomInset))
  }
}
