package com.example.agent

import android.content.Context
import com.example.build.BuildRunner
import com.example.build.ErrorAnalyzer
import com.example.data.model.FileChange
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.patch.EditFileEngine
import com.example.patch.EditResult
import com.example.patch.LineDiff
import com.example.patch.UnifiedDiff
import com.example.terminal.TerminalManager
import java.io.File

/** A specialist agent: its own instructions, and whether it may change files. */
data class AgentRole(val id: String, val name: String, val blurb: String, val system: String, val canWrite: Boolean)

object AgentRoles {
  // v1.4: concise tool list (token lean). Old lowercase names still work (see ToolCalls.canonical).
  private const val READ_TOOLS =
    "Tools: use exactly one per reply, then stop and wait for its result.\n" +
      "<tool name=\"ListFiles\"/>\n" +
      "<tool name=\"ReadFile\">app.js</tool>\n" +
      "<tool name=\"SearchFiles\">text</tool>\n" +
      "<tool name=\"RunCheck\"/> runs the app, returns JavaScript errors\n" +
      "<tool name=\"AnalyzeErrors\"/> lists file:line errors from the last build or command\n"

  private const val WRITE_TOOLS =
    "<tool name=\"EditFile\" path=\"app.js\"><find>exact current text</find><replace>new text</replace></tool>\n" +
      "<tool name=\"ApplyPatch\" path=\"app.js\">unified diff with @@ hunks</tool>\n" +
      "<tool name=\"WriteFile\" path=\"app.js\">complete file</tool>\n" +
      "<tool name=\"RunCommand\">ls</tool>\n" +
      "<tool name=\"BuildProject\"/>\n" +
      "Edits of existing files and commands wait for the user's approval.\n"

  val BUILDER = AgentRole(
    "builder", "Builder", "Plans, builds and tests apps by itself.", "", true
  )
  val DEBUGGER = AgentRole(
    "debugger", "Debugger", "Runs the app, finds the error, fixes it.",
    "You are the Debugger agent for a small offline web app (index.html, styles.css, app.js). You find and fix bugs.\n" +
      READ_TOOLS + WRITE_TOOLS +
      "Workflow: RunCheck, ReadFile the broken file, fix it with EditFile (small, exact) or complete " +
      "<file path=\"x\">...</file> blocks. Prefer EditFile for small fixes.",
    true
  )
  val REVIEWER = AgentRole(
    "reviewer", "Reviewer", "Reads your code and lists problems. Changes nothing.",
    "You are the Reviewer agent for a small offline web app. You read the code and report problems; you never change files.\n" +
      READ_TOOLS + "Read the files, then answer in plain text with at most 6 short bullet points: file, problem, fix. " +
      "No code blocks and no <file> blocks.",
    false
  )
  val DESIGNER = AgentRole(
    "designer", "Designer", "Makes the UI look polished, keeps features.",
    "You are the Designer agent for a small offline web app. You improve the visual design: spacing, typography, colours, rounded cards, " +
      "smooth animations, mobile layout. Keep all features, element ids and JavaScript behaviour unchanged.\n" +
      READ_TOOLS + WRITE_TOOLS + "Read the files first, then change them with EditFile or complete <file path=\"x\">...</file> blocks.",
    true
  )

  /** v1.7.4: not a real agent; the task decides (see TaskRouter). Behaves as Builder until resolved. */
  val AUTO = AgentRole("auto", "Auto", "Picks Builder, Debugger, Reviewer, Designer or Phone from your task.", "", true)

  val all = listOf(BUILDER, DEBUGGER, REVIEWER, DESIGNER)
  /** Chips shown in Chat options. */
  val choices = listOf(AUTO) + all
  fun from(id: String): AgentRole = if (id == AUTO.id) AUTO else all.firstOrNull { it.id == id } ?: BUILDER
}

/**
 * A tool call emitted by the model. [arg] is the trimmed body (paths, queries); [body] keeps the raw
 * body with whitespace (file content, find/replace text); [attrs] holds attributes such as path="x".
 */
data class ToolCall(val name: String, val arg: String, val attrs: Map<String, String> = emptyMap(), val body: String = arg)

object ToolCalls {
  private val CLOSED = Regex("""<tool\s+name\s*=\s*["']?(\w+)["']?([^>]*?)\s*(?:/>|>(.*?)</tool>)""", RegexOption.DOT_MATCHES_ALL)
  private val OPEN_TAIL = Regex("""<tool\b.*\z""", RegexOption.DOT_MATCHES_ALL)
  private val ATTR = Regex("""(\w+)\s*=\s*["']([^"']*)["']""")

  fun parse(text: String): ToolCall? =
    CLOSED.find(text)?.let { m ->
      val attrs = ATTR.findAll(m.groupValues[2]).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
      val raw = m.groupValues[3]
      ToolCall(m.groupValues[1].lowercase(), raw.trim(), attrs, raw)
    }

  /** v1.6.3: every tool call in [text], in order (repair mode applies several EditFile calls from one reply). */
  fun parseAll(text: String): List<ToolCall> =
    CLOSED.findAll(text).map { m ->
      val attrs = ATTR.findAll(m.groupValues[2]).associate { it.groupValues[1].lowercase() to it.groupValues[2] }
      val raw = m.groupValues[3]
      ToolCall(m.groupValues[1].lowercase(), raw.trim(), attrs, raw)
    }.toList()

  /** Text between <tag> and </tag> (one leading/trailing newline removed), or null. */
  fun section(body: String, tag: String): String? =
    Regex("<$tag>(.*?)</$tag>", RegexOption.DOT_MATCHES_ALL).find(body)?.groupValues?.get(1)
      ?.removePrefix("\r\n")?.removePrefix("\n")?.removeSuffix("\n")?.removeSuffix("\r")

  /** v1.4 canonical tool name for any old or new spelling the model may emit. */
  fun canonical(name: String): String = when (name.lowercase().replace("_", "").replace("-", "")) {
    "listfiles", "ls" -> "ListFiles"
    "readfile", "fileread", "read" -> "ReadFile"
    "writefile", "filewrite", "write" -> "WriteFile"
    "search", "searchfiles", "filesearch", "grep" -> "SearchFiles"
    "editfile", "filepatch", "edit" -> "EditFile"
    "applypatch", "patch" -> "ApplyPatch"
    "runcommand", "terminalrun", "run", "shell", "command" -> "RunCommand"
    "buildproject", "projectbuild", "build" -> "BuildProject"
    "analyzeerrors", "analyseerrors", "errors" -> "AnalyzeErrors"
    "runcheck", "check" -> "RunCheck"
    else -> name
  }

  /** Removes tool tags from text shown in the chat. */
  fun strip(text: String): String = OPEN_TAIL.replace(CLOSED.replace(text, ""), "")
}

/** What a tool may use: settings, terminal, builds, and the approval gate. */
class ToolEnv(
  val settings: SettingsState,
  val terminal: TerminalManager,
  val buildRunner: BuildRunner,
  val canWrite: Boolean,
  val approve: suspend (ApprovalRequest) -> Boolean,
  /** v1.6: every tool call is reported here (live step list); nothing the agent does is silent. */
  val onStep: (String) -> Unit = {},
  /** v1.6: a command waits for input; the user answers (never the agent). null = stop such commands. */
  val askInput: (suspend (InputRequest) -> com.example.terminal.InputAnswer)? = null
) {
  /** Last build / command output, read by AnalyzeErrors when the model gives no log. */
  @Volatile var lastLog: String = ""
}

/** The actions an agent can take on the project. */
object AgentTools {
  private const val READ_CAP = 6000

  private fun pathOf(call: ToolCall): String =
    (call.attrs["path"] ?: call.attrs["file"] ?: call.arg.lineSequence().firstOrNull().orEmpty()).trim()

  /** v1.6.3: [shrink] (ShrinkGuard warning) forces the approval dialog even when auto-approve is on, and is shown in it. */
  private suspend fun gate(env: ToolEnv, kind: ActionKind, title: String, item: ApprovalItem, shrink: String? = null): Boolean {
    if (shrink != null) env.onStep(shrink)
    return (shrink == null && !ApprovalPolicy.needsApproval(kind, env.settings)) ||
      env.approve(ApprovalRequest(title = title, reason = shrink ?: "Proposed by the agent", items = listOf(item)))
  }

  suspend fun execute(context: Context, project: Project, call: ToolCall, env: ToolEnv): String {
    val root = project.rootDir
    val tool = ToolCalls.canonical(call.name)
    val writes = tool in setOf("WriteFile", "EditFile", "ApplyPatch", "RunCommand", "BuildProject")
    if (writes && !env.canWrite) {
      env.onStep("Refused $tool: this agent is read-only")
      return "This agent cannot change files or run commands."
    }
    // v1.6: live step + History line for every call, reads included.
    val label = stepLabel(tool, call)
    env.onStep(label)
    if (!writes) ProjectHistory.record(root, HistoryEntry.TOOL, label.take(200), null, "agent read")
    return when (tool) {
      "ListFiles" -> {
        val files = root.walkTopDown()
          .onEnter { it == root || !it.name.startsWith(".") }
          .filter { it.isFile && !it.name.startsWith(".") }
          .map { it.relativeTo(root).path + " (" + it.length() + " bytes)" }
          .take(60).toList()
        if (files.isEmpty()) "The project has no files yet." else files.joinToString("\n")
      }
      "ReadFile" -> {
        val p = pathOf(call)
        val f = ProjectFiles.resolve(root, p)
        if (f == null || !f.isFile) "File not found: $p. Use ListFiles."
        else {
          val t = f.readText()
          if (t.length <= READ_CAP) t else t.take(READ_CAP) + "\n[truncated: ${t.length - READ_CAP} more characters]"
        }
      }
      "SearchFiles" -> {
        val q = call.arg.lowercase()
        if (q.isBlank()) "Give some text to search for." else {
          val hits = mutableListOf<String>()
          root.walkTopDown().onEnter { it == root || !it.name.startsWith(".") }
            .filter { it.isFile && it.length() < 200_000 && it.extension.lowercase() in setOf("html", "css", "js", "json", "md", "txt", "kt", "java", "xml", "py", "ts") }
            .forEach { f ->
              if (f.name.lowercase().contains(q) && hits.size < 15) hits.add(f.relativeTo(root).path + " (file name)")
              f.readLines().forEachIndexed { i, line ->
                if (hits.size < 15 && line.lowercase().contains(q)) hits.add("${f.relativeTo(root).path}:${i + 1}: ${line.trim().take(120)}")
              }
            }
          if (hits.isEmpty()) "No matches." else hits.joinToString("\n")
        }
      }
      "WriteFile" -> {
        val p = (call.attrs["path"] ?: "").trim()
        if (p.isEmpty()) return "WriteFile needs path=\"...\"."
        val f = ProjectFiles.resolve(root, p) ?: return "Unsafe path: $p"
        val content = call.body.removePrefix("\r\n").removePrefix("\n")
        val exists = f.isFile
        val old = if (exists) f.readText() else ""
        val kind = if (exists) ActionKind.EDIT_FILE else ActionKind.NEW_FILE
        if (!gate(env, kind, if (exists) "Overwrite $p?" else "Create $p?", ApprovalItem(kind, path = p, diff = LineDiff.diff(old, content)), ShrinkGuard.warning(p, old, content))) {
          return "The user declined writing $p. Do not retry the same change."
        }
        ProjectFiles.write(root, FileChange(p, content, !exists)).fold(
          onSuccess = { "Wrote $p (${content.lines().size} lines)." },
          onFailure = { "Write failed: ${it.message}" }
        )
      }
      "EditFile" -> {
        val p = pathOf(call).ifEmpty { return "EditFile needs path=\"...\"." }
        val f = ProjectFiles.resolve(root, p)
        if (f == null || !f.isFile) return "File not found: $p."
        val find = ToolCalls.section(call.body, "find") ?: call.attrs["find"] ?: return "EditFile needs <find>...</find>."
        val replace = ToolCalls.section(call.body, "replace") ?: call.attrs["replace"] ?: ""
        val old = f.readText()
        when (val r = EditFileEngine.apply(old, find, replace)) {
          is EditResult.Fail -> "EditFile failed: ${r.reason}"
          is EditResult.Ok -> {
            if (!gate(env, ActionKind.EDIT_FILE, "Edit $p?", ApprovalItem(ActionKind.EDIT_FILE, path = p, diff = LineDiff.diff(old, r.text)), ShrinkGuard.warning(p, old, r.text))) {
              "The user declined the edit to $p."
            } else ProjectFiles.write(root, FileChange(p, r.text, false)).fold(
              onSuccess = { "Edited $p at line ${r.line}." },
              onFailure = { "Write failed: ${it.message}" }
            )
          }
        }
      }
      "ApplyPatch" -> applyPatch(root, call, env)
      "RunCommand" -> {
        val cmd = call.arg.ifBlank { call.attrs["cmd"] ?: call.attrs["command"] ?: "" }.trim()
        if (cmd.isEmpty()) return "RunCommand needs a command."
        // Agent-proposed commands always ask (ApprovalPolicy: COMMAND).
        if (!gate(env, ActionKind.COMMAND, "Run command?", ApprovalItem(ActionKind.COMMAND, command = cmd))) {
          return "The user declined the command."
        }
        // v1.6: stdin stays open; when the command waits for input the user is asked (never auto-answered).
        val session = env.terminal.start(cmd, root)
        val res = session.await(com.example.terminal.TimeoutConfig.toMillis(env.settings.terminalTimeoutSec)) { tail ->
          env.onStep("Waiting for your input: $cmd")
          env.askInput?.invoke(InputRequest(command = cmd, outputTail = tail)) ?: com.example.terminal.InputAnswer.Stop
        }
        env.onStep("exit ${res.exitCode}${if (res.timedOut) " (timed out)" else ""} · $cmd")
        ProjectHistory.record(root, HistoryEntry.COMMAND, cmd.take(200), res.exitCode == 0, "exit ${res.exitCode}" + if (res.timedOut) ", timed out" else "")
        val out = buildString {
          append("exit ").append(res.exitCode)
          if (res.stdout.isNotBlank()) append("\n").append(res.stdout.take(2500))
          if (res.stderr.isNotBlank()) append("\nstderr:\n").append(res.stderr.take(1500))
        }
        env.lastLog = res.stdout + "\n" + res.stderr
        out
      }
      "BuildProject" -> {
        val result = env.buildRunner.runBuild(project)
        env.lastLog = result.logs.joinToString("\n")
        ProjectHistory.record(root, HistoryEntry.COMMAND, "Build project", result.status == com.example.data.model.BuildStatus.SUCCESS, result.status.name.lowercase())
        val errs = if (result.errors.isNotEmpty()) result.errors else ErrorAnalyzer.parse(env.lastLog)
        "Build ${result.status.name.lowercase()}.\n" + (if (errs.isEmpty()) result.logs.takeLast(6).joinToString("\n") else ErrorAnalyzer.format(errs, 10))
      }
      "AnalyzeErrors" -> {
        val log = call.arg.ifBlank { env.lastLog }
        if (log.isBlank()) "No log yet. Run BuildProject, RunCommand or RunCheck first."
        else ErrorAnalyzer.format(ErrorAnalyzer.parse(log))
      }
      "RunCheck" -> {
        val errors = HeadlessCheck.run(context, root)
        env.lastLog = errors.joinToString("\n")
        if (errors.isEmpty()) "The app loaded with no errors." else errors.take(6).joinToString("\n")
      }
      else -> "Unknown tool '${call.name}'. Available: ListFiles, ReadFile, SearchFiles, EditFile, ApplyPatch, WriteFile, RunCommand, BuildProject, AnalyzeErrors, RunCheck."
    }
  }

  /** v1.6: plain-language step for the live list, with the full command text for RunCommand. */
  fun stepLabel(tool: String, call: ToolCall): String {
    val p = (call.attrs["path"] ?: call.attrs["file"] ?: call.arg.lineSequence().firstOrNull().orEmpty()).trim()
    return when (tool) {
      "ListFiles" -> "Listing project files"
      "ReadFile" -> "Reading file $p"
      "SearchFiles" -> "Searching files for \"${call.arg.take(60)}\""
      "WriteFile" -> "Writing file ${call.attrs["path"].orEmpty()}"
      "EditFile" -> "Editing file $p"
      "ApplyPatch" -> "Applying patch" + (call.attrs["path"]?.let { " to $it" } ?: "")
      "RunCommand" -> "Running command: $ " + call.arg.ifBlank { call.attrs["cmd"] ?: call.attrs["command"] ?: "" }.trim()
      "BuildProject" -> "Building the project"
      "AnalyzeErrors" -> "Analyzing errors"
      "RunCheck" -> "Running the app headlessly to find errors"
      else -> "Unknown tool ${call.name}"
    }
  }

  private suspend fun applyPatch(root: File, call: ToolCall, env: ToolEnv): String {
    val patches = try {
      UnifiedDiff.parse(call.body, call.attrs["path"]?.trim()?.ifEmpty { null })
    } catch (e: IllegalArgumentException) {
      return "ApplyPatch failed: ${e.message}"
    }
    data class Planned(val path: String, val file: File, val kind: ActionKind, val old: String, val new: String?)
    val plan = mutableListOf<Planned>()
    for (fp in patches) {
      val f = ProjectFiles.resolve(root, fp.path) ?: return "ApplyPatch failed: unsafe path ${fp.path}"
      if (fp.isDelete) {
        if (!f.isFile) return "ApplyPatch failed: ${fp.path} does not exist."
        plan += Planned(fp.path, f, ActionKind.DELETE_FILE, f.readText(), null)
        continue
      }
      val old = if (f.isFile) f.readText() else ""
      if (!fp.isNewFile && !f.isFile) return "ApplyPatch failed: ${fp.path} does not exist."
      when (val r = UnifiedDiff.apply(old, fp)) {
        is UnifiedDiff.ApplyResult.Fail -> return "ApplyPatch rejected for ${fp.path}: ${r.reason}"
        is UnifiedDiff.ApplyResult.Ok -> plan += Planned(fp.path, f, if (f.isFile) ActionKind.EDIT_FILE else ActionKind.NEW_FILE, old, r.text)
      }
    }
    val items = plan.map { ApprovalItem(it.kind, path = it.path, diff = LineDiff.diff(it.old, it.new ?: "")) }
    val shrink = plan.mapNotNull { p -> p.new?.let { ShrinkGuard.warning(p.path, p.old, it) } }.joinToString("\n").ifEmpty { null }
    shrink?.let { env.onStep(it) }
    if ((shrink != null || plan.any { ApprovalPolicy.needsApproval(it.kind, env.settings) }) &&
      !env.approve(ApprovalRequest(title = "Apply patch to ${plan.size} file(s)?", reason = shrink ?: "Proposed by the agent", items = items))
    ) return "The user declined the patch."
    val done = mutableListOf<String>()
    for (p in plan) {
      if (p.new == null) {
        val deleted = p.file.delete()
        ProjectHistory.record(root, HistoryEntry.DELETED, p.path, deleted)
        if (deleted) done += "deleted ${p.path}" else return "Could not delete ${p.path}. Applied so far: $done"
      } else {
        ProjectFiles.write(root, FileChange(p.path, p.new, p.kind == ActionKind.NEW_FILE)).onFailure {
          return "Write failed for ${p.path}: ${it.message}. Applied so far: $done"
        }
        done += "patched ${p.path}"
      }
    }
    return "Patch applied: " + done.joinToString(", ")
  }
}
