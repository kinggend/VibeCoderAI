package com.example.ui.components

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

/** Collapsible section: a header row with a chevron; the content is hidden until the user opens it. */
@Composable
fun Accordion(
  title: String,
  modifier: Modifier = Modifier,
  subtitle: String? = null,
  initiallyExpanded: Boolean = false,
  content: @Composable ColumnScope.() -> Unit
) {
  var expanded by rememberSaveable(title) { mutableStateOf(initiallyExpanded) }
  val turn by animateFloatAsState(if (expanded) 180f else 0f, label = "accordionChevron")
  Column(modifier.fillMaxWidth().animateContentSize()) {
    Row(
      Modifier
        .fillMaxWidth()
        .heightIn(min = 48.dp)
        .clickable(role = Role.Button, onClickLabel = if (expanded) "Collapse $title" else "Expand $title") { expanded = !expanded }
        .semantics { stateDescription = if (expanded) "Expanded" else "Collapsed" }
        .padding(vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Column(Modifier.weight(1f)) {
        Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        if (subtitle != null) Text(subtitle, color = TextMuted, fontSize = 12.5.sp)
      }
      Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = TextMuted, modifier = Modifier.rotate(turn))
    }
    if (expanded) Column(Modifier.padding(bottom = 6.dp), content = content)
  }
}
