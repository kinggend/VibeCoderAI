package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import android.graphics.BlurMaskFilter
import android.graphics.Paint

/** Corner radius of the old glow (30 dp) times 0.7. */
val NeonGlowCorner: Dp = 21.dp

/**
 * Soft neon glow around the edge of whatever it wraps (use it on a full-screen Box). A wide, blurred,
 * low-alpha halo sits under a thin, slightly blurred core. Both pulse together between 0.3 and 1.0.
 * Drawn on top of the content; strokes are centred on the edge, so the visible half stays inside the bounds.
 */
fun Modifier.neonEdgeGlow(
  color: Color,
  corner: Dp = NeonGlowCorner,
  haloWidth: Dp = 14.dp,
  haloBlur: Dp = 12.dp,
  coreWidth: Dp = 3.dp
): Modifier = composed {
  val pulse by rememberInfiniteTransition(label = "neon").animateFloat(
    initialValue = 0.3f, targetValue = 1f,
    animationSpec = infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
    label = "neonPulse"
  )
  drawWithContent {
    drawContent()
    val r = corner.toPx()
    val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE; strokeWidth = haloWidth.toPx()
      maskFilter = BlurMaskFilter(haloBlur.toPx(), BlurMaskFilter.Blur.NORMAL)
      this.color = color.toArgb(); alpha = (255 * 0.4f * pulse).toInt()
    }
    val core = Paint(Paint.ANTI_ALIAS_FLAG).apply {
      style = Paint.Style.STROKE; strokeWidth = coreWidth.toPx()
      maskFilter = BlurMaskFilter(2.5.dp.toPx(), BlurMaskFilter.Blur.NORMAL)
      this.color = color.toArgb(); alpha = (255 * pulse).toInt()
    }
    drawIntoCanvas { c ->
      c.nativeCanvas.drawRoundRect(0f, 0f, size.width, size.height, r, r, halo)
      c.nativeCanvas.drawRoundRect(0f, 0f, size.width, size.height, r, r, core)
    }
  }
}
