package com.example.agent.tools

import com.example.data.model.Project
import com.example.security.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class FileSearchTool(
  private val securityManager: SecurityManager = SecurityManager()
) : Tool {
  override val name = "file_search"
  override val description = "Searches for files by pattern or content within project workspace."

  override suspend fun execute(project: Project, arguments: Map<String, String>): ToolResult = withContext(Dispatchers.IO) {
    val query = arguments["query"] ?: return@withContext ToolResult(false, "", "Missing 'query' parameter.")
    val isContentSearch = arguments["content"]?.toBoolean() ?: false
    val root = project.rootDir

    val matches = mutableListOf<String>()
    root.walkTopDown().filter { it.isFile && !it.name.startsWith(".git") }.forEach { file ->
      val relPath = file.relativeTo(root).path
      if (isContentSearch) {
        try {
          val content = file.readText()
          if (content.contains(query, ignoreCase = true)) {
            val lines = content.lines()
            val matchingLineNums = lines.mapIndexedNotNull { idx, line ->
              if (line.contains(query, ignoreCase = true)) idx + 1 else null
            }
            matches.add("$relPath (lines: ${matchingLineNums.take(5).joinToString(", ")})")
          }
        } catch (_: Exception) {}
      } else {
        if (file.name.contains(query, ignoreCase = true) || relPath.contains(query, ignoreCase = true)) {
          matches.add(relPath)
        }
      }
    }

    if (matches.isEmpty()) {
      ToolResult(true, "No files found matching query '$query'.")
    } else {
      ToolResult(true, "Found ${matches.size} match(es):\n" + matches.take(50).joinToString("\n"))
    }
  }
}
