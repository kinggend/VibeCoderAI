package com.example.agent

/** v1.5: the only data a shared skill file carries. */
data class SkillFile(val name: String, val description: String, val promptText: String)

/**
 * v1.5: skill export/import format and name rules (pure, unit tested).
 * A skill file is exactly {"name", "description", "promptText"}: no other keys, strings only,
 * bounded sizes. Anything else is rejected with a reason the user can read.
 */
object SkillCodec {
  const val MAX_FILE_BYTES = 8 * 1024
  const val MAX_NAME = 40
  const val MAX_DESCRIPTION = 120
  const val MAX_PROMPT = 600
  private val KEYS = setOf("name", "description", "promptText")

  fun encode(s: SkillFile): String =
    MiniJson.encode(listOf("name" to s.name, "description" to s.description, "promptText" to s.promptText), pretty = true) + "\n"

  /** Field-level validation shared by the editor and the importer. Returns an error or null. */
  fun validate(name: String, description: String, prompt: String): String? {
    val n = name.trim()
    return when {
      n.isEmpty() -> "Name is empty."
      n.length > MAX_NAME -> "Name is longer than $MAX_NAME characters."
      n.any { it.isISOControl() } -> "Name contains control characters."
      description.trim().length > MAX_DESCRIPTION -> "Description is longer than $MAX_DESCRIPTION characters."
      description.any { it.isISOControl() } -> "Description must be one line."
      prompt.isBlank() -> "Prompt text is empty."
      prompt.trim().length > MAX_PROMPT -> "Prompt text is longer than $MAX_PROMPT characters."
      prompt.any { it.isISOControl() && it != '\n' && it != '\t' } -> "Prompt text contains control characters."
      else -> null
    }
  }

  /** Strict import. [bytes] is the raw file; never trust its size, keys or types. */
  fun decode(bytes: ByteArray): Result<SkillFile> = runCatching {
    require(bytes.isNotEmpty()) { "The file is empty." }
    require(bytes.size <= MAX_FILE_BYTES) { "The file is larger than ${MAX_FILE_BYTES / 1024} KB." }
    val text = runCatching {
      java.nio.charset.StandardCharsets.UTF_8.newDecoder()
        .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
        .decode(java.nio.ByteBuffer.wrap(bytes)).toString().removePrefix("\uFEFF")
    }.getOrElse { throw IllegalArgumentException("The file is not UTF-8 text.") }
    val obj = try { MiniJson.parseObject(text) } catch (e: MiniJson.JsonError) {
      throw IllegalArgumentException("Not a valid skill file: ${e.message}")
    }
    val extra = obj.keys - KEYS
    require(extra.isEmpty()) { "Unexpected field(s): ${extra.joinToString()}." }
    val missing = KEYS - obj.keys
    require(missing.isEmpty()) { "Missing field(s): ${missing.joinToString()}." }
    val values = KEYS.associateWith { k -> obj[k] as? String ?: throw IllegalArgumentException("\"$k\" must be text.") }
    val name = values.getValue("name"); val desc = values.getValue("description"); val prompt = values.getValue("promptText")
    validate(name, desc, prompt)?.let { throw IllegalArgumentException(it) }
    SkillFile(name.trim(), desc.trim(), prompt.trim())
  }

  /** True when [name] matches (case-insensitive, trimmed) any of [existing], skipping [ignoreId]'s own name. */
  fun collides(name: String, existing: List<Pair<String, String>>, ignoreId: String? = null): Boolean {
    val n = name.trim().lowercase()
    return existing.any { (id, other) -> id != ignoreId && other.trim().lowercase() == n }
  }

  /** File name for export: lowercase letters, digits and dashes. */
  fun fileName(name: String): String =
    name.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').ifEmpty { "skill" }.take(40) + ".skill.json"
}
