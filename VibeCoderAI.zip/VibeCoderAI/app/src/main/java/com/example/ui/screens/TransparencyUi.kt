package com.example.ui.screens

import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.InputRequest
import com.example.terminal.InputAnswer
import com.example.transparency.ContextManifest
import com.example.transparency.Destination
import com.example.ui.components.Button
import com.example.ui.components.TextButton
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.Palette
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/** v1.6: "On-device" / "Remote: host" under every message, so it is always clear if data left the phone. */
@Composable
internal fun DestinationBadge(dest: Destination?, modifier: Modifier = Modifier) {
  val label = dest?.label ?: "Sent before v1.6 (destination not recorded)"
  val remote = dest?.isRemote == true
  Row(
    modifier = modifier
      .clip(CircleShape)
      .background((if (remote) CyberAmberWarning else TextMuted).copy(alpha = 0.12f))
      .padding(horizontal = 8.dp, vertical = 3.dp)
      .semantics(mergeDescendants = true) {
        contentDescription = when {
          dest == null -> label
          remote -> "Data sent to ${dest.remoteHost}"
          else -> "Data stayed on this phone"
        }
      },
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(
      if (remote) Icons.Default.Cloud else Icons.Default.PhoneAndroid,
      contentDescription = null,
      tint = if (remote) CyberAmberWarning else TextSecondary,
      modifier = Modifier.size(12.dp)
    )
    Spacer(Modifier.width(4.dp))
    Text(label, color = if (remote) CyberAmberWarning else TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
  }
}

/** Tappable "Context" chip: opens what the AI saw. 48 dp tall touch target around a small pill. */
@Composable
internal fun ContextChip(manifest: ContextManifest, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .heightIn(min = 48.dp)
      .clip(CircleShape)
      .clickable(role = Role.Button, onClickLabel = "Show what the AI saw", onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Row(
      modifier = Modifier
        .clip(CircleShape)
        .background(CyberCyanPrimary.copy(alpha = 0.14f))
        .padding(horizontal = 10.dp, vertical = 5.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.Visibility, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(13.dp))
      Spacer(Modifier.width(5.dp))
      Text("Context · ${manifest.promptTokensLabel.substringBefore(" (")}", color = CyberCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
  }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun GlassSheet(onDismiss: () -> Unit, content: @Composable (close: () -> Unit) -> Unit) {
  val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = state,
    modifier = Modifier.border(1.dp, com.example.ui.components.GlassPopupColors.rim(), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    scrimColor = Color.Black.copy(alpha = if (Palette.dark) 0.45f else 0.25f),
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    content { scope.launch { state.hide() }.invokeOnCompletion { onDismiss() } }
  }
}

/**
 * v1.6 "What the AI sees": the complete request of one generation. Every message is shown in full on
 * demand; sizes and settings are listed above it. This is built from the payload the engine sent.
 */
@Composable
internal fun ContextSheet(m: ContextManifest, onDismiss: () -> Unit) {
  val clipboard = LocalClipboardManager.current
  GlassSheet(onDismiss) { close ->
    LazyColumn(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp).navigationBarsPadding(),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      item {
        Text("What the AI saw", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(
          "This is the complete request for this reply. Nothing else was sent." +
            if (m.destination.isRemote) " Over HTTPS/HTTP the server also receives your saved API key in the Authorization header (shown masked below)." else " It never left this phone.",
          color = TextSecondary, fontSize = 14.sp, lineHeight = 20.sp
        )
      }
      item { DestinationBadge(m.destination) }
      item { SheetSection("Size") { KeyValue("Prompt", m.promptTokensLabel); KeyValue("Characters", "%,d".format(m.totalChars)); KeyValue("Earlier chat turns included", "${m.historyTurns}") } }
      item { SheetSection("Settings used") { m.settingsLines().forEach { (k, v) -> KeyValue(k, v) } } }
      item {
        SheetSection("Active skills") {
          if (m.skills.isEmpty()) Muted("None. (Agent roles and planning use their own prompt, shown under System prompt.)")
          else m.skills.forEach { Text("• $it", color = TextPrimary, fontSize = 14.sp) }
        }
      }
      item {
        SheetSection("Attached files") {
          if (m.files.isEmpty()) Muted("None.")
          else m.files.forEach { f ->
            KeyValue(f.path, "${humanBytes(f.bytes)} · ≈${f.tokens} tok" + if (f.truncated) " · cut" else "")
          }
        }
      }
      item {
        SheetSection("Images") {
          if (m.images.isEmpty()) Muted("None.")
          else m.images.forEach { im -> KeyValue(im.name, "${im.width}×${im.height} JPEG · ${humanBytes(im.bytes)}" + if (!im.sent) " · not sent: ${im.reason}" else "") }
        }
      }
      item { Text("MESSAGES SENT (${m.messages.size})", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold) }
      items(m.messages.size) { i ->
        val msg = m.messages[i]
        var open by remember { mutableStateOf(i == m.messages.lastIndex) }
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .background(ObsidianSurfaceVariant.copy(alpha = 0.7f))
            .animateContentSize(tween(180))
        ) {
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(min = 48.dp)
              .clickable(onClickLabel = if (open) "Hide text" else "Show full text") { open = !open }
              .padding(horizontal = 12.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              when (msg.role) { "system" -> "System prompt"; "user" -> "User message"; else -> "Earlier reply (${msg.role})" },
              color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
            )
            Text("%,d chars".format(msg.content.length), color = TextMuted, fontSize = 12.sp)
            Spacer(Modifier.width(8.dp))
            Text(if (open) "Hide" else "Show", color = CyberCyanPrimary, fontSize = 12.sp)
          }
          if (open) {
            Text(
              msg.content,
              color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp, fontFamily = FontFamily.Monospace,
              modifier = Modifier.padding(horizontal = 12.dp).heightIn(max = 420.dp).verticalScroll(rememberScrollState())
            )
            TextButton(onClick = { clipboard.setText(AnnotatedString(msg.content)) }, modifier = Modifier.heightIn(min = 48.dp)) {
              Text("Copy", color = CyberCyanPrimary, fontSize = 13.sp)
            }
          }
        }
      }
      item {
        Button(
          onClick = close,
          shape = CircleShape,
          colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
          modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).padding(bottom = 12.dp)
        ) { Text("Done", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
      }
    }
  }
}

@Composable
private fun SheetSection(title: String, content: @Composable () -> Unit) {
  Column(
    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ObsidianSurfaceVariant.copy(alpha = 0.5f)).padding(12.dp),
    verticalArrangement = Arrangement.spacedBy(4.dp)
  ) {
    Text(title.uppercase(), color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
    content()
  }
}

@Composable
private fun KeyValue(k: String, v: String) {
  Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top) {
    Text(k, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f), maxLines = 2, overflow = TextOverflow.Ellipsis)
    Spacer(Modifier.width(8.dp))
    Text(v, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.widthIn(max = 220.dp))
  }
}

@Composable
private fun Muted(t: String) = Text(t, color = TextMuted, fontSize = 13.sp)

internal fun humanBytes(b: Long): String = when {
  b < 1024 -> "$b B"
  b < 1024 * 1024 -> "%.1f KB".format(b / 1024.0)
  else -> "%.1f MB".format(b / 1048576.0)
}

/** v1.6: one-time plain-language notice the first time a remote host is used. Cancel sends nothing. */
@Composable
internal fun RemoteNoticeDialog(host: String, onContinue: () -> Unit, onCancel: () -> Unit) {
  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onCancel,
    title = { Text("This message will leave your phone") },
    text = {
      Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("You chose a remote model. When you send, this goes to $host:", color = TextSecondary, fontSize = 15.sp)
        listOf(
          "your message and any @files or images you attach",
          "the app's system prompt and your active skills",
          "recent chat turns (chat) or your project's files (building)",
          "model settings (model name, temperature, top-p, max tokens)",
          "your saved API key, as the Authorization header"
        ).forEach { Text("• $it", color = TextPrimary, fontSize = 14.sp, lineHeight = 19.sp) }
        Text("What $host does with it is up to that server. Tap Context under any reply to see exactly what was sent. Nothing is sent if you cancel.", color = TextSecondary, fontSize = 14.sp, lineHeight = 19.sp)
      }
    },
    confirmButton = { TextButton(onClick = onContinue, modifier = Modifier.heightIn(min = 48.dp)) { Text("Send to $host") } },
    dismissButton = { TextButton(onClick = onCancel, modifier = Modifier.heightIn(min = 48.dp)) { Text("Cancel") } }
  )
}

/**
 * v1.6: an agent command is waiting for input. The user types the answer or uses the quick keys; the agent
 * never answers for them. "Keep waiting" leaves the process alone.
 */
@Composable
internal fun InputRequestDialog(req: InputRequest, onAnswer: (InputAnswer) -> Unit) {
  var text by remember(req.id) { mutableStateOf("") }
  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = {},
    title = { Text("Command needs your input") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("$ ${req.command}", color = TextPrimary, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
        Text(
          req.outputTail.takeLast(400),
          color = TextSecondary, fontFamily = FontFamily.Monospace, fontSize = 12.sp, lineHeight = 16.sp,
          modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.Black).padding(8.dp).heightIn(max = 160.dp).verticalScroll(rememberScrollState())
        )
        Text("The agent paused. Nothing is typed for you.", color = TextMuted, fontSize = 12.sp)
        Box(Modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).padding(horizontal = 14.dp, vertical = 12.dp)) {
          if (text.isEmpty()) Text("Type a reply", color = TextMuted, fontSize = 14.sp)
          BasicTextField(text, { text = it }, singleLine = true, textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp, fontFamily = FontFamily.Monospace), cursorBrush = SolidColor(CyberCyanPrimary), modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Input for the command" })
        }
        TerminalKeys(
          onKey = { k -> onAnswer(InputAnswer.Send(k)) },
          onCtrlC = { onAnswer(InputAnswer.Stop) }
        )
      }
    },
    confirmButton = { TextButton(onClick = { onAnswer(InputAnswer.Send(text + "\n")) }, enabled = text.isNotEmpty(), modifier = Modifier.heightIn(min = 48.dp)) { Text("Send") } },
    dismissButton = { TextButton(onClick = { onAnswer(InputAnswer.KeepWaiting) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Keep waiting") } },
    properties = androidx.compose.ui.window.DialogProperties(dismissOnClickOutside = false)
  )
}

/** Quick keys shared by the Terminal screen and the input dialog: y, n, Enter, Ctrl+C. */
@Composable
internal fun TerminalKeys(onKey: (String) -> Unit, onCtrlC: () -> Unit, enabled: Boolean = true) {
  Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
    listOf("y" to "y\n", "n" to "n\n", "Enter" to "\n").forEach { (label, send) ->
      KeyPill(label, enabled, "Send $label") { onKey(send) }
    }
    KeyPill("Ctrl+C", enabled, "Interrupt the command", danger = true) { onCtrlC() }
  }
}

@Composable
private fun KeyPill(label: String, enabled: Boolean, desc: String, danger: Boolean = false, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .heightIn(min = 48.dp)
      .widthIn(min = 48.dp)
      .clip(CircleShape)
      .background(if (danger) com.example.ui.theme.CyberCoralError.copy(alpha = 0.16f) else ObsidianSurfaceVariant)
      .clickable(enabled = enabled, role = Role.Button, onClickLabel = desc, onClick = onClick)
      .padding(horizontal = 14.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(label, color = if (!enabled) TextMuted else if (danger) com.example.ui.theme.CyberCoralError else TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold)
  }
}

/** Removable chips for @files and images in the composer. */
@Composable
internal fun AttachmentChips(
  files: List<com.example.transparency.AttachedFile>,
  images: List<com.example.chat.ImagePayload>,
  onRemoveFile: (String) -> Unit,
  onRemoveImage: (String) -> Unit,
  modifier: Modifier = Modifier
) {
  if (files.isEmpty() && images.isEmpty()) return
  Row(modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
    files.forEach { f ->
      RemovableChip(
        icon = { Icon(Icons.Default.Description, null, tint = CyberCyanPrimary, modifier = Modifier.size(14.dp)) },
        label = "@${f.path} · ≈${f.tokens} tok",
        removeDesc = "Remove ${f.path}"
      ) { onRemoveFile(f.path) }
    }
    images.forEach { im ->
      RemovableChip(
        icon = { Thumbnail(im.localPath, 22) },
        label = "${im.width}×${im.height} · ${humanBytes(im.bytes)}",
        removeDesc = "Remove image"
      ) { onRemoveImage(im.localPath) }
    }
  }
}

@Composable
private fun RemovableChip(icon: @Composable () -> Unit, label: String, removeDesc: String, onRemove: () -> Unit) {
  Row(
    modifier = Modifier.clip(CircleShape).background(ObsidianSurfaceVariant).padding(start = 10.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    icon()
    Spacer(Modifier.width(6.dp))
    Text(label, color = TextPrimary, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 220.dp))
    Box(
      Modifier.size(48.dp).clip(CircleShape).clickable(role = Role.Button, onClickLabel = removeDesc, onClick = onRemove),
      contentAlignment = Alignment.Center
    ) { Icon(Icons.Default.Close, contentDescription = removeDesc, tint = TextMuted, modifier = Modifier.size(16.dp)) }
  }
}

/** Image thumbnail decoded at small size off the file; a placeholder icon when the file is gone. */
@Composable
internal fun Thumbnail(path: String, sizeDp: Int, modifier: Modifier = Modifier) {
  val bmp = remember(path) { com.example.chat.ImageEncoder.thumbnail(path, sizeDp * 3) }
  if (bmp != null) {
    Image(
      bmp.asImageBitmap(), contentDescription = "Attached image", contentScale = ContentScale.Crop,
      modifier = modifier.size(sizeDp.dp).clip(RoundedCornerShape(if (sizeDp > 40) 12.dp else 6.dp))
    )
  } else {
    Icon(Icons.Default.Image, contentDescription = "Image no longer on this phone", tint = TextMuted, modifier = modifier.size(sizeDp.dp))
  }
}

/** "@" file picker shown above the composer while typing a mention. */
@Composable
internal fun MentionPicker(query: String, candidates: List<String>, onPick: (String) -> Unit, modifier: Modifier = Modifier) {
  Column(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 14.dp)
      .clip(RoundedCornerShape(18.dp))
      .background(com.example.ui.components.GlassPopupColors.container)
      .border(1.dp, com.example.ui.components.GlassPopupColors.rim(), RoundedCornerShape(18.dp))
      .heightIn(max = 240.dp)
      .verticalScroll(rememberScrollState())
      .padding(vertical = 4.dp)
  ) {
    Text(
      if (query.isEmpty()) "Attach a project file" else "Files matching \"$query\"",
      color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
    )
    if (candidates.isEmpty()) {
      Text("No files match. Keep typing, or check the active project in Projects.", color = TextSecondary, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp))
    }
    candidates.forEach { p ->
      Row(
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).clickable(onClickLabel = "Attach $p") { onPick(p) }.padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.Description, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(8.dp))
        com.example.ui.components.MiddleEllipsisText(text = p, color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.weight(1f))
      }
    }
  }
}
