package com.example.phone

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.view.View
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.animation.LinearInterpolator

/**
 * Full-screen, touch-through layer drawn while the Phone agent works:
 *  - a colour-sweeping glow around the screen edge (so it is obvious the agent has control), and
 *  - a mouse-style cursor that glides to wherever the agent taps, with a ripple on each click.
 * It never takes touches (the window is FLAG_NOT_TOUCHABLE), so real gestures pass straight through.
 */
class PhoneFxView(context: Context) : View(context) {
  private val dp = resources.displayMetrics.density
  private val rect = RectF()
  private val loc = IntArray(2)
  private val sweepMatrix = Matrix()
  private var sweep: SweepGradient? = null
  private var angle = 0f

  private val edge = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
  private val cursorFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Color.WHITE }
  private val cursorLine = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF111111.toInt(); strokeWidth = 1.6f * dp; strokeJoin = Paint.Join.ROUND }
  private val ripple = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = 0xFF4FC3F7.toInt(); strokeWidth = 3f * dp }
  private val rippleFill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = 0xFF4FC3F7.toInt() }
  private val arrow = Path().apply {
    // Classic pointer: tip at (0,0).
    moveTo(0f, 0f); lineTo(0f, 17f * dp); lineTo(4.4f * dp, 13.2f * dp); lineTo(7.4f * dp, 20f * dp)
    lineTo(10.2f * dp, 18.8f * dp); lineTo(7.3f * dp, 12.2f * dp); lineTo(12.6f * dp, 12.2f * dp); close()
  }

  // Cursor state in screen coordinates.
  private var cx = 0f
  private var cy = 0f
  private var cursorOn = false
  private var pressed = false
  private var rippleP = -1f          // 0..1 while a ripple is playing, -1 when idle
  private var rippleLong = false

  private val spin = ValueAnimator.ofFloat(0f, 360f).apply {
    duration = 3600; repeatCount = ValueAnimator.INFINITE; interpolator = LinearInterpolator()
    addUpdateListener { angle = it.animatedValue as Float; invalidate() }
  }
  private var glide: ValueAnimator? = null
  private var ripAnim: ValueAnimator? = null

  override fun onAttachedToWindow() { super.onAttachedToWindow(); if (!spin.isStarted) spin.start() }
  override fun onDetachedFromWindow() { spin.cancel(); glide?.cancel(); ripAnim?.cancel(); super.onDetachedFromWindow() }

  override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
    sweep = SweepGradient(
      w / 2f, h / 2f,
      // Three colours (cyan, purple, pink), first repeated at the end so the sweep has no seam.
      intArrayOf(0xFF00E5FF.toInt(), 0xFFB040FF.toInt(), 0xFFFF4081.toInt(), 0xFF00E5FF.toInt()),
      null
    )
  }

  /** Moves the cursor to ([x],[y]) in screen px. Returns how long the glide takes, in ms. */
  fun glideTo(x: Float, y: Float, ms: Long? = null): Long {
    val dist = if (cursorOn) Math.hypot((x - cx).toDouble(), (y - cy).toDouble()).toFloat() else 0f
    val dur = ms ?: (if (!cursorOn) 1L else (160 + dist / dp * 0.9f).toLong().coerceIn(180L, 520L))
    glide?.cancel()
    if (!cursorOn) { cx = x; cy = y; cursorOn = true; invalidate(); return 1L }
    val sx = cx; val sy = cy
    glide = ValueAnimator.ofFloat(0f, 1f).apply {
      duration = dur; interpolator = AccelerateDecelerateInterpolator()
      addUpdateListener { cx = sx + (x - sx) * it.animatedFraction; cy = sy + (y - sy) * it.animatedFraction; invalidate() }
      start()
    }
    return dur
  }

  /** A click ripple at the cursor; a long press holds the ring longer. */
  fun pulse(long: Boolean) {
    rippleLong = long; pressed = true
    ripAnim?.cancel()
    ripAnim = ValueAnimator.ofFloat(0f, 1f).apply {
      duration = if (long) 800 else 420
      addUpdateListener { rippleP = it.animatedFraction; invalidate() }
      addListener(object : android.animation.AnimatorListenerAdapter() {
        override fun onAnimationEnd(a: android.animation.Animator) { rippleP = -1f; pressed = false; invalidate() }
      })
      start()
    }
  }

  fun hideCursor() { cursorOn = false; invalidate() }

  override fun onDraw(c: Canvas) {
    super.onDraw(c)
    getLocationOnScreen(loc)
    val w = width.toFloat(); val h = height.toFloat()
    // ---- Edge glow: three strokes, wide and faint to thin and bright ----
    sweep?.let { s ->
      sweepMatrix.setRotate(angle, w / 2f, h / 2f); s.setLocalMatrix(sweepMatrix); edge.shader = s
      val r = 30f * dp
      for ((sw, a) in listOf(22f to 40, 12f to 95, 4.5f to 255)) {
        edge.strokeWidth = sw * dp; edge.alpha = a
        val inset = sw * dp / 2f
        rect.set(inset, inset, w - inset, h - inset)
        c.drawRoundRect(rect, r, r, edge)
      }
    }
    // ---- Cursor ----
    if (!cursorOn) return
    val x = cx - loc[0]; val y = cy - loc[1]
    if (rippleP >= 0f) {
      val p = rippleP
      ripple.alpha = ((1f - p) * 255).toInt(); c.drawCircle(x, y, (10f + 34f * p) * dp, ripple)
      rippleFill.alpha = ((1f - p) * 90).toInt(); c.drawCircle(x, y, (6f + 14f * p) * dp, rippleFill)
    }
    c.save()
    c.translate(x, y)
    if (pressed) c.scale(0.88f, 0.88f)
    c.drawPath(arrow, cursorFill); c.drawPath(arrow, cursorLine)
    c.restore()
  }
}
