package com.example.transparency

import android.content.Context
import android.net.Uri
import com.example.data.SettingsStore
import com.example.data.db.AppDatabase
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * v1.6 Settings › Privacy & transparency: what is stored where, export everything, and clear it.
 * Secrets (API key, GitHub token) are never exported: their Keystore key cannot leave the phone anyway.
 */
object MyData {
  data class Place(val what: String, val where: String, val note: String)

  fun projectsDir(context: Context) = File(context.filesDir, "vibecoder_projects")
  fun imagesDir(context: Context) = File(context.filesDir, "chat_images")

  /** Plain list for the privacy page. Paths are the real ones on this phone. */
  fun places(context: Context): List<Place> {
    val files = context.filesDir.absolutePath
    val data = context.filesDir.parentFile?.absolutePath ?: files
    return listOf(
      Place("Chats and token usage", "$data/databases/vibecoder.db", "Room database: messages, where each was sent, token counts."),
      Place("API key, server URL, model name, GitHub token", "$data/shared_prefs/vibecoder_secrets.xml", "Encrypted (AES-256-GCM). The key is in the Android Keystore and never leaves the phone; excluded from Android backup."),
      Place("Settings", "$data/shared_prefs/vibecoder_settings.xml", "Plain values like theme, context size, timeout. No secrets."),
      Place("Agent skills", "$data/shared_prefs/agent_skills.xml", "Your custom skills and which skills are on."),
      Place("Projects", "$files/vibecoder_projects/", "Your app files."),
      Place("Agent history", "<project>/.vibecoder/history/history.jsonl", "Every file change, command and file the agent read, with time and result."),
      Place("Undo backups", "<project>/.vibecoder/backups/run-*.zip", "Zip of the project before each agent run, newest 3 kept."),
      Place("Chat images", "$files/chat_images/", "Downscaled copies of images you attached."),
      Place("Models", "$files/models/", "GGUF model files you downloaded or imported."),
      Place("Built APKs and exports", "$files/builds/ and cache/exports/", "Created only when you build or export.")
    )
  }

  /** Network use of this app, verified against the code (v1.6). */
  val network: List<Pair<String, String>> = listOf(
    "Remote model server" to "Only when you choose a remote backend: to the URL you entered, with your API key.",
    "Hugging Face" to "Only when you search or download models (huggingface.co).",
    "GitHub" to "Only when you tap Push to GitHub (api.github.com), with your token.",
    "Web preview" to "The app loads only your project's local files. Code you or the AI write can still request web resources (fonts, CDNs) when you preview it.",
    "Voice input" to "Uses the phone's speech recognizer app (offline preferred). That app's own privacy policy applies."
  )

  /** Exports everything except secrets to [uri] (a zip the user created with the system file picker). */
  suspend fun exportAll(context: Context, uri: Uri, progress: (String) -> Unit = {}): Result<Int> = runCatching {
    val store = SettingsStore(context)
    val secrets = store.secretValues()
    var count = 0
    val out = context.contentResolver.openOutputStream(uri) ?: error("Could not open the file to write.")
    ZipOutputStream(out.buffered()).use { zos ->
      fun put(name: String, bytes: ByteArray) {
        zos.putNextEntry(ZipEntry(name)); zos.write(bytes); zos.closeEntry(); count++
      }
      put("README.txt", (
        "VibeCoderAI data export (${java.util.Date()})\n\n" +
          "settings.json  your settings (API key and GitHub token are NOT included)\n" +
          "chats/         every conversation as JSON\n" +
          "skills.json    your custom skills\n" +
          "projects/      your project files, with each project's .vibecoder/history (undo backup zips are left out)\n" +
          "chat_images/   images you attached\n"
        ).toByteArray())

      progress("Settings")
      val s = store.load()
      val settings = JSONObject()
        .put("backendMode", s.backendMode).put("remoteUrl", Redact.text(s.remoteUrl, secrets)).put("remoteModel", s.remoteModel)
        .put("apiKeySaved", s.remoteKey.isNotBlank()).put("contextLength", s.contextLength).put("maxOutputTokens", s.maxOutputTokens)
        .put("temperature", s.temperature.toDouble()).put("topP", s.topP.toDouble()).put("topK", s.topK)
        .put("outputLevel", s.outputLevel).put("agentRole", s.agentRole).put("strictSecurity", s.strictSecurity)
        .put("terminalTimeoutSec", s.terminalTimeoutSec).put("theme", s.themeMode).put("accent", s.accent)
      put("settings.json", settings.toString(2).toByteArray())

      progress("Chats")
      val dao = AppDatabase.get(context).chatDao()
      for (session in dao.sessions()) {
        val msgs = JSONArray()
        dao.messages(session.id).forEach { m ->
          msgs.put(JSONObject().put("sender", m.sender).put("time", m.timestamp).put("destination", m.destination ?: "unknown").put("text", Redact.text(m.content, secrets)))
        }
        put("chats/${session.id}.json", JSONObject().put("title", Redact.text(session.title, secrets)).put("updated", session.updated).put("messages", msgs).toString(2).toByteArray())
      }

      progress("Skills")
      val skills = JSONArray()
      com.example.agent.Skills.custom().forEach { sk ->
        skills.put(JSONObject().put("name", sk.name).put("description", sk.description).put("promptText", sk.prompt))
      }
      put("skills.json", skills.toString(2).toByteArray())

      progress("Projects")
      val root = projectsDir(context)
      root.walkTopDown()
        .onEnter { d -> !(d.name == "backups" && d.parentFile?.name == ".vibecoder") }
        .filter { it.isFile }
        .forEach { f -> put("projects/" + f.relativeTo(root).invariantSeparatorsPath, f.readBytes()) }

      progress("Images")
      imagesDir(context).listFiles()?.filter { it.isFile }?.forEach { put("chat_images/${it.name}", it.readBytes()) }
    }
    count
  }

  /** Deletes every conversation and attached image. Token usage stays (Settings › Data has Clear usage). */
  suspend fun clearChats(context: Context) {
    val db = AppDatabase.get(context)
    val dao = db.chatDao()
    dao.sessions().forEach { dao.deleteSession(it.id); dao.deleteMessages(it.id) }
    imagesDir(context).deleteRecursively()
  }

  /** Deletes History logs and undo backups of every project. Returns how many projects were cleaned. */
  fun clearHistoryAndBackups(context: Context): Int {
    var n = 0
    projectsDir(context).listFiles()?.filter { it.isDirectory }?.forEach { p ->
      val v = File(p, ".vibecoder")
      val h = File(v, "history"); val b = File(v, "backups")
      if (h.exists() || b.exists()) n++
      h.deleteRecursively(); b.deleteRecursively()
    }
    return n
  }
}
