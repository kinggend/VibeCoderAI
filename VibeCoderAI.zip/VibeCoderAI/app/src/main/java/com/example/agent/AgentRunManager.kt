package com.example.agent

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

/**
 * v1.6.2: owns the agent run outside any screen. Runs used to be launched in the Chat screen's
 * composition scope, so switching tabs cancelled them. This lives as long as the app process
 * (AppGraph), screens only observe [state], and the foreground service keeps it alive in the background.
 *
 * shortcut: one run at a time for the whole app (stricter than one per project), because the
 * orchestrator holds one chat and one model; upgrade when runs get their own orchestrator.
 */
class AgentRunManager(private val scope: CoroutineScope) {
  data class Progress(
    val running: Boolean = false,
    val projectName: String? = null,
    val step: Int = 0,
    val total: Int = 0,
    val label: String = ""
  )

  private val _state = MutableStateFlow(Progress())
  val state: StateFlow<Progress> = _state.asStateFlow()

  @Volatile private var job: Job? = null

  /** Starts [block] unless a run is already going. The state goes back to idle when it ends, fails or is cancelled. */
  fun start(projectName: String?, block: suspend CoroutineScope.() -> Unit): Job? {
    synchronized(this) {
      if (job?.isActive == true) return null
      _state.value = Progress(running = true, projectName = projectName)
      // Lazy start: the job is stored and watched before it can possibly finish.
      val j = scope.launch(start = CoroutineStart.LAZY, block = block)
      job = j
      j.invokeOnCompletion {
        synchronized(this) { if (job === j) { job = null; _state.value = Progress() } }
      }
      j.start()
      return j
    }
  }

  fun step(step: Int, total: Int, label: String) {
    val s = _state.value
    if (s.running) _state.value = s.copy(step = step, total = total, label = label)
  }

  fun label(text: String) {
    val s = _state.value
    if (s.running) _state.value = s.copy(label = text)
  }

  val isRunning: Boolean get() = job?.isActive == true

  fun cancel() { job?.cancel() }
}

/** v1.6.2: title and text of the "agent is running" notification. */
fun AgentRunManager.Progress.notificationText(): Pair<String, String> {
  val title = projectName?.takeIf { it.isNotBlank() }?.let { "VibeCoder is building $it" } ?: "VibeCoder is working"
  val stepText = if (total > 1) "Step $step of $total" else null
  val text = listOfNotNull(stepText, label.takeIf { it.isNotBlank() }).joinToString(" · ").ifBlank { "Starting" }
  return title to text
}
