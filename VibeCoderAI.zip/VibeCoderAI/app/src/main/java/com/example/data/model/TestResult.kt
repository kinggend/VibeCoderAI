package com.example.data.model

data class TestResult(
  val suite: String,
  val name: String,
  val passed: Boolean,
  val durationMs: Long,
  val details: String,
  val stackTrace: String? = null
)

data class TestSuiteSummary(
  val suiteName: String,
  val passed: Int,
  val failed: Int,
  val total: Int,
  val durationMs: Long
)
