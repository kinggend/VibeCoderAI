package com.example.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue

/** v1.5: pure maths for the output estimate (unit tested). */
object Estimate {
  const val WINDOW = 10

  /** Appends [sample] and keeps the last [window] samples. Ignores non-finite or non-positive speeds. */
  fun push(samples: List<Float>, sample: Float, window: Int = WINDOW): List<Float> =
    if (!sample.isFinite() || sample <= 0f) samples else (samples + sample).takeLast(window)

  fun average(samples: List<Float>): Float? = if (samples.isEmpty()) null else samples.sum() / samples.size

  fun seconds(tokens: Int, tokensPerSecond: Float?): Float? =
    if (tokensPerSecond == null || tokensPerSecond <= 0f) null else tokens / tokensPerSecond

  fun cost(tokens: Int, dollarsPerMillion: Double?): Double? =
    if (dollarsPerMillion == null || dollarsPerMillion < 0) null else tokens * dollarsPerMillion / 1_000_000.0

  fun formatSeconds(s: Float): String = when {
    s < 1f -> "<1 s"
    s < 90f -> "${s.toInt()} s"
    else -> "${(s / 60f).toInt()} min ${(s % 60f).toInt()} s"
  }

  fun formatCost(d: Double): String = when {
    d == 0.0 -> "$0"
    d < 0.0001 -> "<$0.0001"
    d < 0.01 -> "$" + "%.4f".format(java.util.Locale.US, d)
    else -> "$" + "%.2f".format(java.util.Locale.US, d)
  }

  fun encode(samples: List<Float>): String = samples.joinToString(",")
  fun decode(text: String?): List<Float> = text.orEmpty().split(',').mapNotNull { it.toFloatOrNull() }.filter { it.isFinite() && it > 0f }
}

/**
 * v1.5: measured tokens/sec (on-device and remote kept apart) and the user's own $/1M-token prices
 * per model. No prices ship with the app.
 */
object GenerationStats {
  private var prefs: SharedPreferences? = null

  /** Bumped on change so Compose re-reads. */
  var version by mutableIntStateOf(0)
    private set

  fun init(context: Context) {
    if (prefs == null) prefs = context.applicationContext.getSharedPreferences("generation_stats", Context.MODE_PRIVATE)
  }

  private fun key(remote: Boolean) = if (remote) "tps_remote" else "tps_local"

  fun recordSpeed(remote: Boolean, tokensPerSecond: Float, outputTokens: Int) {
    // Very short replies are dominated by prompt time; they would skew the average.
    if (outputTokens < 16) return
    val p = prefs ?: return
    val next = Estimate.push(Estimate.decode(p.getString(key(remote), null)), tokensPerSecond)
    p.edit().putString(key(remote), Estimate.encode(next)).apply()
    version++
  }

  fun averageSpeed(remote: Boolean): Float? = Estimate.average(Estimate.decode(prefs?.getString(key(remote), null)))

  /** model id/file name to $ per 1M output tokens. */
  fun prices(): Map<String, Double> = prefs?.all.orEmpty()
    .filterKeys { it.startsWith("price:") }
    .mapNotNull { (k, v) -> (v as? String)?.toDoubleOrNull()?.let { k.removePrefix("price:") to it } }
    .toMap()

  fun price(model: String): Double? = prices()[model]

  fun setPrice(model: String, dollarsPerMillion: Double?) {
    if (model.isBlank()) return
    val e = prefs?.edit() ?: return
    if (dollarsPerMillion == null) e.remove("price:$model") else e.putString("price:$model", dollarsPerMillion.toString())
    e.apply()
    version++
  }
}
