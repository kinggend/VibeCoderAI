package com.example.ui.components

/** How the bar reads: pure so it is unit-tested. */
enum class RamLevel { FITS, TIGHT, TOO_BIG, UNKNOWN }

object RamBarMath {
  /** Required / free, or 0 when free RAM is unknown. */
  fun ratio(requiredMb: Long, freeMb: Long): Float = if (freeMb <= 0) 0f else requiredMb.toFloat() / freeMb
  fun level(requiredMb: Long, freeMb: Long): RamLevel = when {
    freeMb <= 0 -> RamLevel.UNKNOWN
    requiredMb > freeMb -> RamLevel.TOO_BIG
    requiredMb > freeMb * 0.85 -> RamLevel.TIGHT
    else -> RamLevel.FITS
  }
}
