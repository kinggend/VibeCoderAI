package com.example.data.downloader

import android.content.Context
import androidx.work.Constraints
import androidx.work.ExistingWorkPolicy
import androidx.work.NetworkType
import androidx.work.OneTimeWorkRequestBuilder
import androidx.work.WorkInfo
import androidx.work.WorkManager
import androidx.work.WorkQuery
import androidx.work.workDataOf
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import java.io.File
import java.util.concurrent.TimeUnit

/**
 * v1.4: GGUF downloads run in WorkManager ([ModelDownloadWorker]) so they continue after the app is
 * closed. The UI state below is derived from WorkManager's WorkInfo flow (progress, success, failure)
 * and the partial files on disk. Same public API as the old in-process downloader.
 */
class ModelDownloadManager(context: Context, private val modelsDir: File) {

  enum class State { RUNNING, PAUSED, DONE, FAILED }

  data class Item(
    val key: String,
    val modelId: String,
    val fileName: String,
    val total: Long,
    val downloaded: Long,
    val state: State,
    val error: String? = null
  ) {
    val destName: String get() = fileName.substringAfterLast('/')
    val fraction: Float get() = if (total > 0) (downloaded.toFloat() / total).coerceIn(0f, 1f) else 0f
  }

  private val app = context.applicationContext
  private val wm = WorkManager.getInstance(app)
  private val prefs = app.getSharedPreferences("vibecoder_downloads", Context.MODE_PRIVATE)
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

  /** Keys the user cancelled or dismissed (hidden until started again). */
  private val hidden = MutableStateFlow(prefs.getStringSet(KEY_HIDDEN, emptySet())!!.toSet())

  val items: StateFlow<Map<String, Item>> =
    combine(wm.getWorkInfosFlow(WorkQuery.fromTags(TAG)), hidden) { infos, hiddenKeys -> toItems(infos, hiddenKeys) }
      .stateIn(scope, SharingStarted.Eagerly, emptyMap())

  fun key(modelId: String, file: HfFile) = "$modelId/${file.name}"

  private fun workName(key: String) = "model-download:$key"

  private fun setHidden(key: String, hide: Boolean) {
    val next = if (hide) hidden.value + key else hidden.value - key
    hidden.value = next
    prefs.edit().putStringSet(KEY_HIDDEN, next).apply()
  }

  /** Starts a download, or resumes a paused/failed one from the bytes already on disk. */
  @Suppress("UNUSED_PARAMETER")
  fun start(scope: CoroutineScope, modelId: String, file: HfFile) {
    val k = key(modelId, file)
    setHidden(k, false)
    val request = OneTimeWorkRequestBuilder<ModelDownloadWorker>()
      .setInputData(
        workDataOf(
          ModelDownloadWorker.KEY_MODEL_ID to modelId,
          ModelDownloadWorker.KEY_FILE_NAME to file.name,
          ModelDownloadWorker.KEY_TOTAL to file.sizeBytes,
          ModelDownloadWorker.KEY_DIR to modelsDir.absolutePath
        )
      )
      .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
      .setBackoffCriteria(androidx.work.BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
      .addTag(TAG)
      .addTag(TAG_KEY + k)
      .addTag(TAG_MODEL + modelId)
      .addTag(TAG_FILE + file.name)
      .addTag(TAG_TOTAL + file.sizeBytes)
      .addTag(TAG_STARTED + System.currentTimeMillis())
      .build()
    // Unique per file: a second tap while it is queued or running does nothing (no duplicate workers).
    wm.enqueueUniqueWork(workName(k), ExistingWorkPolicy.KEEP, request)
  }

  /** Stops the worker; the partial file stays so Resume continues from it. */
  fun pause(key: String) {
    wm.cancelUniqueWork(workName(key))
  }

  /** Stops the download and deletes the partial file. */
  fun cancel(key: String) {
    wm.cancelUniqueWork(workName(key))
    setHidden(key, true)
    // key = "<modelId>/<fileName>", and the file is saved under the last path segment.
    File(modelsDir, key.substringAfterLast('/') + ".part").delete()
  }

  fun dismiss(key: String) {
    setHidden(key, true)
  }

  private fun tagValue(info: WorkInfo, prefix: String): String? =
    info.tags.firstOrNull { it.startsWith(prefix) }?.removePrefix(prefix)

  private fun toItems(infos: List<WorkInfo>, hiddenKeys: Set<String>): Map<String, Item> {
    val newest = infos
      .filter { tagValue(it, TAG_KEY) != null }
      .groupBy { tagValue(it, TAG_KEY)!! }
      .mapValues { (_, list) -> list.maxByOrNull { tagValue(it, TAG_STARTED)?.toLongOrNull() ?: 0L }!! }
    val out = LinkedHashMap<String, Item>()
    for ((k, info) in newest) {
      if (k in hiddenKeys) continue
      val modelId = tagValue(info, TAG_MODEL) ?: continue
      val fileName = tagValue(info, TAG_FILE) ?: continue
      val tagTotal = tagValue(info, TAG_TOTAL)?.toLongOrNull() ?: 0L
      val destName = fileName.substringAfterLast('/')
      val partLen = File(modelsDir, "$destName.part").let { if (it.exists()) it.length() else 0L }
      val item = when (info.state) {
        WorkInfo.State.ENQUEUED, WorkInfo.State.RUNNING, WorkInfo.State.BLOCKED -> {
          val total = info.progress.getLong(ModelDownloadWorker.KEY_TOTAL, tagTotal).takeIf { it > 0 } ?: tagTotal
          val done = info.progress.getLong(ModelDownloadWorker.KEY_DOWNLOADED, partLen).coerceAtLeast(0L)
          Item(k, modelId, fileName, total, done, State.RUNNING)
        }
        WorkInfo.State.SUCCEEDED -> {
          val dest = File(modelsDir, destName)
          val size = if (dest.exists()) dest.length() else tagTotal
          Item(k, modelId, fileName, size, size, if (dest.exists()) State.DONE else State.FAILED, if (dest.exists()) null else "File missing")
        }
        WorkInfo.State.FAILED -> Item(
          k, modelId, fileName, tagTotal, partLen, State.FAILED,
          info.outputData.getString(ModelDownloadWorker.KEY_ERROR) ?: "Download failed"
        )
        WorkInfo.State.CANCELLED -> Item(k, modelId, fileName, tagTotal, partLen, State.PAUSED)
      }
      out[k] = item
    }
    return out
  }

  companion object {
    @Volatile private var instance: ModelDownloadManager? = null

    /** One manager per process (its WorkManager observer must not be duplicated on rotation). */
    fun get(context: Context, modelsDir: File): ModelDownloadManager =
      instance ?: synchronized(this) { instance ?: ModelDownloadManager(context, modelsDir).also { instance = it } }

    const val TAG = "model-download"
    private const val TAG_KEY = "key:"
    private const val TAG_MODEL = "model:"
    private const val TAG_FILE = "file:"
    private const val TAG_TOTAL = "total:"
    private const val TAG_STARTED = "started:"
    private const val KEY_HIDDEN = "hidden"
  }
}
