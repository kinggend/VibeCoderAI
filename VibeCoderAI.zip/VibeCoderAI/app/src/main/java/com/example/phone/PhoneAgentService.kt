package com.example.phone

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.util.Base64
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.text.InputType
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * v1.7.0: the Phone agent's eyes and hands. The user turns it on in Android's Accessibility settings
 * after the in-app disclosure. It only reads or acts while a phone task the user started is running
 * (PhoneAgent calls it); it does nothing with events on its own.
 */
class PhoneAgentService : AccessibilityService() {

  /** Screen read for one step. [nodes] maps element ids to live nodes for acting on them. */
  class Snapshot(val pkg: String, val root: List<UiNode>, val nodes: Map<Int, AccessibilityNodeInfo>, val width: Int, val height: Int)

  private var overlay: LinearLayout? = null
  private var overlayTitle: TextView? = null
  private var overlayDetail: TextView? = null
  private var overlayButtons: LinearLayout? = null
  private var overlayInput: LinearLayout? = null
  private var overlayEdit: EditText? = null
  private var overlayLp: WindowManager.LayoutParams? = null
  private var fx: PhoneFxView? = null

  /** Set by PhoneAgent: the user typed a message on the overlay while a task runs. */
  @Volatile var onUserMessage: ((String) -> Unit)? = null
  /** Set by PhoneAgent: true while the message box is open (the agent pauses so it never reads this overlay). */
  @Volatile var onCompose: ((Boolean) -> Unit)? = null

  override fun onServiceConnected() {
    instance = this
    _connected.value = true
  }

  override fun onAccessibilityEvent(event: AccessibilityEvent?) = Unit
  override fun onInterrupt() = Unit

  override fun onDestroy() {
    hideOverlay()
    if (instance === this) instance = null
    _connected.value = false
    super.onDestroy()
  }

  // ---- Reading the screen ----

  /** Package of the app on screen right now (cheap: no tree walk), or null when unknown. */
  fun foregroundPkg(): String? = runCatching {
    rootInActiveWindow?.packageName?.toString()
      ?: windows.firstOrNull { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION }?.root?.packageName?.toString()
  }.getOrNull()

  fun snapshot(): Snapshot? {
    // Active window first, then other app windows (some apps keep focus on a small window or dialog).
    val active = rootInActiveWindow
    val appRoots = runCatching {
      windows.filter { it.type == android.view.accessibility.AccessibilityWindowInfo.TYPE_APPLICATION }.mapNotNull { it.root }
    }.getOrDefault(emptyList())
    val roots = (listOfNotNull(active) + appRoots.filter { r -> active == null || r != active }).distinct()
    val root = roots.firstOrNull() ?: return null
    val pkg = root.packageName?.toString().orEmpty()
    val map = HashMap<Int, AccessibilityNodeInfo>()
    var next = 1
    val r = Rect()
    // shortcut: 400 nodes / depth 30 cap keeps a step cheap; raise if long lists lose items.
    fun read(n: AccessibilityNodeInfo, depth: Int): UiNode? {
      if (depth > 30 || map.size >= 400 || !n.isVisibleToUser) return null
      n.getBoundsInScreen(r)
      val id = next++
      map[id] = n
      val kids = (0 until n.childCount).mapNotNull { i -> n.getChild(i)?.let { read(it, depth + 1) } }
      return UiNode(
        id = id, text = if (n.isPassword) null else n.text?.toString(), desc = n.contentDescription?.toString(),
        hint = if (Build.VERSION.SDK_INT >= 26) n.hintText?.toString() else null,
        resId = n.viewIdResourceName, cls = n.className?.toString(),
        left = r.left, top = r.top, right = r.right, bottom = r.bottom,
        clickable = n.isClickable, longClickable = n.isLongClickable, editable = n.isEditable,
        scrollable = n.isScrollable, password = n.isPassword,
        checked = if (n.isCheckable) n.isChecked else null, enabled = n.isEnabled, children = kids
      )
    }
    val tree = roots.filter { it.packageName?.toString() == pkg || it == root }.mapNotNull { read(it, 0) }
    val dm = resources.displayMetrics
    return Snapshot(pkg, tree, map, dm.widthPixels, dm.heightPixels)
  }

  /** Glides the on-screen cursor to ([x],[y]) and, for a click, plays the ripple. Waits so people can follow it. */
  private suspend fun pointer(x: Float, y: Float, press: Boolean, long: Boolean = false) {
    val v = fx ?: return
    val ms = withContext(Dispatchers.Main) { v.glideTo(x, y) }
    delay(ms + 40)
    if (press) {
      withContext(Dispatchers.Main) { v.pulse(long) }
      delay(if (long) 260 else 150)
    }
  }

  /** View changes must run on the main thread; the agent calls these from a worker thread. */
  private suspend fun hideForCapture(all: Boolean = true) {
    if (overlay == null) return
    withContext(Dispatchers.Main) { overlay?.visibility = View.INVISIBLE; if (all) fx?.visibility = View.INVISIBLE }
    if (all) delay(120) // let the windows actually disappear before a screenshot
  }

  private suspend fun restoreAfterCapture() {
    withContext(NonCancellable + Dispatchers.Main) { overlay?.visibility = View.VISIBLE; fx?.visibility = View.VISIBLE }
  }

  /** JPEG data URL of the screen (API 30+), with the overlay hidden. Null when not possible or a secure window. */
  suspend fun screenshot(maxWidth: Int = PhoneAgent.SHOT_W): String? {
    if (Build.VERSION.SDK_INT < 30) return null
    hideForCapture()
    try {
      return suspendCancellableCoroutine { cont ->
        takeScreenshot(android.view.Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
          override fun onSuccess(result: ScreenshotResult) {
            val hw = Bitmap.wrapHardwareBuffer(result.hardwareBuffer, result.colorSpace)
            val soft = hw?.copy(Bitmap.Config.ARGB_8888, false)
            result.hardwareBuffer.close()
            if (soft == null) { cont.resume(null); return }
            // 720 px wide: small toolbar icons in 3D and video apps stay readable.
            val scale = maxWidth.toFloat() / soft.width
            val small = if (scale < 1f) Bitmap.createScaledBitmap(soft, maxWidth, (soft.height * scale).toInt(), true) else soft
            val out = ByteArrayOutputStream()
            small.compress(Bitmap.CompressFormat.JPEG, 60, out)
            cont.resume("data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP))
          }
          override fun onFailure(errorCode: Int) { cont.resume(null) }
        })
      }
    } finally {
      restoreAfterCapture()
    }
  }

  // ---- Acting ----

  private fun clickableAncestor(n: AccessibilityNodeInfo, long: Boolean): AccessibilityNodeInfo? {
    var cur: AccessibilityNodeInfo? = n
    var hops = 0
    while (cur != null && hops < 6) {
      if (if (long) cur.isLongClickable else cur.isClickable) return cur
      cur = cur.parent; hops++
    }
    return null
  }

  /** A real touch (cursor + gesture) on the centre of [n]'s tappable cell: what a finger does on a launcher icon. */
  suspend fun touch(n: AccessibilityNodeInfo): Boolean {
    val r = Rect().also { (clickableAncestor(n, false) ?: n).getBoundsInScreen(it) }
    if (r.isEmpty) return false
    return gesture(r.exactCenterX(), r.exactCenterY(), r.exactCenterX(), r.exactCenterY(), 80)
  }

  suspend fun tap(n: AccessibilityNodeInfo, long: Boolean = false): Boolean {
    val b = Rect().also { n.getBoundsInScreen(it) }
    if (!b.isEmpty) pointer(b.exactCenterX(), b.exactCenterY(), press = true, long = long)
    val target = clickableAncestor(n, long)
    if (target?.performAction(if (long) AccessibilityNodeInfo.ACTION_LONG_CLICK else AccessibilityNodeInfo.ACTION_CLICK) == true) return true
    return gesture(b.exactCenterX(), b.exactCenterY(), b.exactCenterX(), b.exactCenterY(), if (long) 700 else 60)
  }

  suspend fun type(n: AccessibilityNodeInfo?, text: String): Boolean {
    val field = n?.takeIf { it.isEditable } ?: rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.takeIf { it.isEditable } ?: return false
    // Tap the field first so the keyboard comes up like a person typing, then set the text.
    Rect().also { field.getBoundsInScreen(it) }.takeIf { !it.isEmpty }?.let { pointer(it.exactCenterX(), it.exactCenterY(), press = true) }
    field.performAction(AccessibilityNodeInfo.ACTION_CLICK)
    field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
    // Type letter by letter, like a person (the suggestions list updates as it goes). Long text is sped up.
    fun set(t: String) = field.performAction(
      AccessibilityNodeInfo.ACTION_SET_TEXT,
      Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, t) }
    )
    if (text.isEmpty()) return set("")
    val ends = (1..text.length).filter { it == text.length || !Character.isHighSurrogate(text[it - 1]) }
    val perChar = (2600L / ends.size).coerceIn(20L, 70L)
    var ok = false
    for (e in ends) {
      ok = set(text.substring(0, e))
      if (!ok) break
      if (e != text.length) delay(perChar)
    }
    return ok
  }

  fun enter(): Boolean {
    if (Build.VERSION.SDK_INT < 30) return false
    val field = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
    return field.performAction(AccessibilityNodeInfo.AccessibilityAction.ACTION_IME_ENTER.id)
  }

  suspend fun scroll(direction: String, n: AccessibilityNodeInfo?, w: Int, h: Int): Boolean {
    if (n != null && n.isScrollable) {
      val forward = direction == "down" || direction == "right"
      if (n.performAction(if (forward) AccessibilityNodeInfo.ACTION_SCROLL_FORWARD else AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD)) return true
    }
    val cx = w / 2f; val cy = h / 2f
    return when (direction) {
      "up" -> gesture(cx, h * 0.3f, cx, h * 0.75f, 350)
      "left" -> gesture(w * 0.2f, cy, w * 0.8f, cy, 350)
      "right" -> gesture(w * 0.8f, cy, w * 0.2f, cy, 350)
      else -> gesture(cx, h * 0.75f, cx, h * 0.3f, 350)
    }
  }

  /** A tap or swipe on screen, with the overlay hidden so it never catches the touch. */
  suspend fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, ms: Long): Boolean {
    val path = Path().apply { moveTo(x1, y1); if (x1 != x2 || y1 != y2) lineTo(x2, y2) }
    val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, ms.coerceAtLeast(1))).build()
    val isTap = x1 == x2 && y1 == y2
    pointer(x1, y1, press = isTap, long = isTap && ms >= 500)
    if (!isTap) withContext(Dispatchers.Main) { fx?.glideTo(x2, y2, ms.coerceIn(200L, 900L)) }
    hideForCapture(all = false)
    try {
      return suspendCancellableCoroutine { cont ->
        val sent = dispatchGesture(g, object : GestureResultCallback() {
          override fun onCompleted(d: GestureDescription?) { if (cont.isActive) cont.resume(true) }
          override fun onCancelled(d: GestureDescription?) { if (cont.isActive) cont.resume(false) }
        }, null)
        if (!sent && cont.isActive) cont.resume(false)
      }
    } finally {
      restoreAfterCapture()
    }
  }

  fun global(action: Int): Boolean = performGlobalAction(action)

  fun launch(intent: Intent): Boolean = runCatching { startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true }.getOrDefault(false)

  fun installedApps(): List<InstalledApp> {
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return packageManager.queryIntentActivities(i, 0).map {
      InstalledApp(it.loadLabel(packageManager).toString(), it.activityInfo.packageName)
    }.distinctBy { it.pkg }
  }

  fun appLabel(pkg: String): String = runCatching {
    packageManager.getApplicationLabel(packageManager.getApplicationInfo(pkg, 0)).toString()
  }.getOrDefault(pkg)

  // ---- Floating overlay: current step, STOP, and approval buttons ----

  /**
   * Shows or updates the overlay. [buttons] are (label, isDanger, onClick); STOP is always one of them.
   * TYPE_ACCESSIBILITY_OVERLAY needs no extra permission and stays above other apps.
   */
  fun showOverlay(title: String, detail: String, buttons: List<Triple<String, Boolean, () -> Unit>>) {
    val wm = getSystemService(WINDOW_SERVICE) as WindowManager
    val dp = resources.displayMetrics.density
    if (fx == null) {
      val v = PhoneFxView(this)
      v.glowColor = runCatching { com.example.ui.theme.Accents.of(com.example.ui.theme.ThemeController.accent).dark.toInt() }.getOrDefault(0xFF0A84FF.toInt())
      val flp = WindowManager.LayoutParams(
        WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
          WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
          WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
        android.graphics.PixelFormat.TRANSLUCENT
      ).apply {
        gravity = Gravity.TOP or Gravity.START
        if (Build.VERSION.SDK_INT >= 28) layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
      }
      runCatching { wm.addView(v, flp); fx = v }
    }
    if (overlay == null) {
      val box = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding((16 * dp).toInt(), (12 * dp).toInt(), (16 * dp).toInt(), (12 * dp).toInt())
        background = GradientDrawable().apply { cornerRadius = 20 * dp; setColor(0xF0151821.toInt()); setStroke((1 * dp).toInt(), 0x33FFFFFF) }
        elevation = 8 * dp
      }
      overlayTitle = TextView(this).apply { setTextColor(0xFFFFFFFF.toInt()); textSize = 14f; setTypeface(typeface, android.graphics.Typeface.BOLD); maxLines = 2 }
      overlayDetail = TextView(this).apply { setTextColor(0xCCFFFFFF.toInt()); textSize = 13f; maxLines = 4 }
      overlayButtons = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.END }
      // Message box: type a new instruction or correction while the task runs.
      overlayEdit = EditText(this).apply {
        hint = "Tell the agent something…"
        setHintTextColor(0x88FFFFFF.toInt()); setTextColor(0xFFFFFFFF.toInt()); textSize = 14f
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        imeOptions = EditorInfo.IME_ACTION_SEND
        maxLines = 3
        background = GradientDrawable().apply { cornerRadius = 14 * dp; setColor(0x33FFFFFF) }
        setPadding((12 * dp).toInt(), (8 * dp).toInt(), (12 * dp).toInt(), (8 * dp).toInt())
        setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_SEND) { sendMessage(); true } else false }
      }
      val sendBtn = Button(this).apply {
        text = "Send"; isAllCaps = false; setTextColor(0xFFFFFFFF.toInt()); contentDescription = "Send message"
        background = GradientDrawable().apply { cornerRadius = 22 * dp; setColor(0xFF3A6FF7.toInt()) }
        setOnClickListener { sendMessage() }
      }
      overlayInput = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
        addView(overlayEdit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        addView(sendBtn, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (44 * dp).toInt()).apply { marginStart = (8 * dp).toInt() })
      }
      box.addView(overlayTitle); box.addView(overlayDetail)
      box.addView(overlayInput, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = (8 * dp).toInt() })
      box.addView(overlayButtons)
      val lp = WindowManager.LayoutParams(
        (resources.displayMetrics.widthPixels - 24 * dp).toInt(), WindowManager.LayoutParams.WRAP_CONTENT,
        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
        android.graphics.PixelFormat.TRANSLUCENT
      ).apply { gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL; y = (96 * dp).toInt() }
      overlayLp = lp
      runCatching { wm.addView(box, lp); overlay = box }
    }
    overlayTitle?.text = title
    overlayDetail?.text = detail
    overlayDetail?.visibility = if (detail.isBlank()) View.GONE else View.VISIBLE
    overlayButtons?.removeAllViews()
    val all = listOf<Triple<String, Boolean, () -> Unit>>(Triple("Message", false) { toggleInput() }) + buttons
    for ((label, danger, onClick) in all) {
      overlayButtons?.addView(Button(this).apply {
        text = label
        isAllCaps = false
        minHeight = (48 * dp).toInt(); minimumHeight = (48 * dp).toInt()
        setTextColor(0xFFFFFFFF.toInt())
        background = GradientDrawable().apply { cornerRadius = 24 * dp; setColor(if (danger) 0xFFD93A3A.toInt() else 0xFF3A6FF7.toInt()) }
        contentDescription = label
        setOnClickListener { onClick() }
      }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, (48 * dp).toInt()).apply { marginStart = (8 * dp).toInt(); topMargin = (8 * dp).toInt() })
    }
  }

  private fun toggleInput() {
    val box = overlayInput ?: return
    if (box.visibility == View.VISIBLE) closeInput() else openInput()
  }

  /** Opens the message box and lets the keyboard attach to the overlay (it is not focusable otherwise). */
  private fun openInput() {
    val v = overlay ?: return; val lp = overlayLp ?: return
    overlayInput?.visibility = View.VISIBLE
    lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
    lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
    runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(v, lp) }
    onCompose?.invoke(true) // pause the agent: it must not read or tap while you type
    overlayEdit?.let { e -> e.requestFocus(); e.postDelayed({ (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(e, InputMethodManager.SHOW_IMPLICIT) }, 150) }
  }

  private fun closeInput() {
    val v = overlay ?: return; val lp = overlayLp ?: return
    overlayEdit?.let { e -> (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(e.windowToken, 0); e.setText("") }
    overlayInput?.visibility = View.GONE
    lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
    runCatching { (getSystemService(WINDOW_SERVICE) as WindowManager).updateViewLayout(v, lp) }
    onCompose?.invoke(false)
  }

  private fun sendMessage() {
    val text = overlayEdit?.text?.toString()?.trim().orEmpty()
    closeInput()
    if (text.isNotEmpty()) onUserMessage?.invoke(text)
  }

  fun hideOverlay() {
    val wm = getSystemService(WINDOW_SERVICE) as WindowManager
    overlay?.let { v -> runCatching { wm.removeView(v) } }
    fx?.let { v -> runCatching { wm.removeView(v) } }
    overlay = null; overlayTitle = null; overlayDetail = null; overlayButtons = null
    overlayInput = null; overlayEdit = null; overlayLp = null; fx = null
    onCompose?.invoke(false)
  }

  companion object {
    @Volatile var instance: PhoneAgentService? = null
      private set
    private val _connected = MutableStateFlow(false)
    /** True while the user has the service turned on in Accessibility settings. */
    val connected: StateFlow<Boolean> = _connected

    fun settingsIntent(): Intent = Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
  }
}
