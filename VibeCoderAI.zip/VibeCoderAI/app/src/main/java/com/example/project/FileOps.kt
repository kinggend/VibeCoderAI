package com.example.project

import com.example.agent.HistoryEntry
import com.example.agent.ProjectHistory
import java.io.File

/**
 * v1.6 explorer actions (rename, move, delete, new file / folder) for the user. Every target is checked
 * with [inside] so nothing can reach outside the project (".." , absolute paths, symlinks resolved by
 * canonical path). Each action is written to the project History. Pure enough to unit test with temp dirs.
 */
object FileOps {
  /** True when [f] is [root] itself or strictly inside it (canonical paths, so ".." and symlinks are resolved). */
  fun inside(root: File, f: File): Boolean = runCatching {
    val r = root.canonicalPath
    val c = f.canonicalPath
    c == r || c.startsWith(r + File.separator)
  }.getOrDefault(false)

  /** A valid single file or folder name (no separators, not "." / "..", no control characters, ≤ 120 chars). */
  fun nameError(name: String): String? {
    val n = name.trim()
    return when {
      n.isEmpty() -> "Enter a name."
      n == "." || n == ".." -> "That name is not allowed."
      n.contains('/') || n.contains('\\') -> "Use a name without / or \\."
      n.any { it.isISOControl() } -> "The name contains control characters."
      n.length > 120 -> "The name is longer than 120 characters."
      else -> null
    }
  }

  /** [rel] (a relative path typed by the user) inside [root], or null when it escapes or is invalid. */
  fun resolve(root: File, rel: String): File? {
    val clean = rel.replace('\\', '/').trim().trimStart('/')
    if (clean.isEmpty() || clean.split('/').any { it == ".." || it.isEmpty() }) return null
    val f = File(root, clean)
    return if (inside(root, f) && f.canonicalPath != root.canonicalPath) f else null
  }

  private fun rel(root: File, f: File) = f.relativeTo(root).invariantSeparatorsPath

  fun rename(root: File, target: File, newName: String): Result<File> = runCatching {
    nameError(newName)?.let { throw IllegalArgumentException(it) }
    require(inside(root, target) && target.canonicalPath != root.canonicalPath) { "Only files inside the project can be renamed." }
    require(target.exists()) { "${target.name} no longer exists." }
    val dest = File(target.parentFile, newName.trim())
    require(inside(root, dest)) { "The new name must stay inside the project." }
    require(!dest.exists()) { "${dest.name} already exists here." }
    if (!target.renameTo(dest)) error("Android refused to rename ${target.name}.")
    ProjectHistory.record(root, HistoryEntry.RENAMED, "${rel(root, target)} → ${rel(root, dest)}", true, "by you")
    dest
  }

  /** Moves [target] into [folder] (both inside the project; a folder cannot go into itself). */
  fun move(root: File, target: File, folder: File): Result<File> = runCatching {
    require(inside(root, target) && target.canonicalPath != root.canonicalPath) { "Only files inside the project can be moved." }
    require(inside(root, folder) && folder.isDirectory) { "Pick a folder inside the project." }
    require(!(target.isDirectory && inside(target, folder))) { "A folder cannot be moved into itself." }
    val dest = File(folder, target.name)
    require(dest.canonicalPath != target.canonicalPath) { "${target.name} is already in that folder." }
    require(!dest.exists()) { "${folder.name.ifEmpty { "That folder" }} already has a ${target.name}." }
    if (!target.renameTo(dest)) error("Android refused to move ${target.name}.")
    ProjectHistory.record(root, HistoryEntry.MOVED, "${rel(root, target)} → ${rel(root, dest).ifEmpty { "/" }}", true, "by you")
    dest
  }

  fun delete(root: File, target: File): Result<Unit> = runCatching {
    require(inside(root, target) && target.canonicalPath != root.canonicalPath) { "Only files inside the project can be deleted." }
    val r = rel(root, target)
    val ok = if (target.isDirectory) target.deleteRecursively() else target.delete()
    ProjectHistory.record(root, HistoryEntry.DELETED, r, ok, "by you")
    if (!ok) error("Could not delete $r.")
  }

  /** New empty file or folder named [name] inside [parent]. */
  fun create(root: File, parent: File, name: String, folder: Boolean): Result<File> = runCatching {
    nameError(name)?.let { throw IllegalArgumentException(it) }
    require(inside(root, parent) && parent.isDirectory) { "Pick a folder inside the project." }
    val f = File(parent, name.trim())
    require(inside(root, f)) { "The new item must stay inside the project." }
    require(!f.exists()) { "${f.name} already exists." }
    val ok = if (folder) f.mkdirs() else f.createNewFile()
    if (!ok) error("Could not create ${f.name}.")
    ProjectHistory.record(root, HistoryEntry.CREATED, rel(root, f) + if (folder) "/" else "", true, "by you")
    f
  }

  /** Every folder in the project (relative, "" = root) for the Move picker; dot folders and build output hidden. */
  fun folders(root: File): List<String> =
    root.walkTopDown()
      .onEnter { it == root || (!it.name.startsWith(".") && it.name !in setOf("build", "node_modules")) }
      .filter { it.isDirectory }
      .map { rel(root, it) }
      .sorted()
      .toList()
}
