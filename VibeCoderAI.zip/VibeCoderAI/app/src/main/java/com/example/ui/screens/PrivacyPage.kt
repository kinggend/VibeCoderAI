package com.example.ui.screens

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.transparency.MyData
import com.example.ui.components.Button
import com.example.ui.components.GroupedSection
import com.example.ui.components.TextButton
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * v1.6 Settings › Privacy & transparency. Plain list of what is kept where, every network use the code
 * has, and buttons to export or clear the user's data (each clear asks first).
 */
@Composable
internal fun PrivacyPage(onChatsCleared: () -> Unit) {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var confirm by remember { mutableStateOf<String?>(null) }
  var status by remember { mutableStateOf<String?>(null) }
  var busy by remember { mutableStateOf(false) }
  val exporter = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.CreateDocument("application/zip")
  ) { uri ->
    if (uri == null) return@rememberLauncherForActivityResult
    busy = true
    status = "Exporting…"
    scope.launch {
      val r = withContext(Dispatchers.IO) { MyData.exportAll(context, uri) { status = "Exporting $it…" } }
      busy = false
      status = r.fold({ "Exported $it files. API keys and tokens were not included." }, { "Export failed: ${it.message}. Pick another folder and try again." })
    }
  }

  GroupedSection("No analytics or tracking", footer = "Checked in the v1.6 code: no analytics, crash reporting or ad SDK is compiled in. The app only uses the network in the cases below.") {
    MyData.network.forEach { (k, v) ->
      Column(Modifier.padding(vertical = 5.dp)) {
        Text(k, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(v, color = TextSecondary, fontSize = 13.5.sp, lineHeight = 19.sp)
      }
    }
  }

  GroupedSection("What is stored on this phone", footer = "Android backup (if you turned it on) may copy settings, chats and projects to your Google account. The encrypted secrets file is always excluded.") {
    remember { MyData.places(context) }.forEach { p ->
      Column(Modifier.padding(vertical = 5.dp)) {
        Text(p.what, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(p.where, color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
        Text(p.note, color = TextSecondary, fontSize = 13.5.sp, lineHeight = 19.sp)
      }
    }
  }

  GroupedSection("Your data") {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
      Button(
        onClick = { exporter.launch("vibecoderai-my-data.zip") },
        enabled = !busy,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
      ) { Text("Export all my data (zip)", fontWeight = FontWeight.SemiBold) }
      Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
        TextButton(onClick = { confirm = "chats" }, enabled = !busy, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
          Text("Clear chats", color = CyberCoralError, fontWeight = FontWeight.SemiBold)
        }
        TextButton(onClick = { confirm = "history" }, enabled = !busy, modifier = Modifier.weight(1f).heightIn(min = 48.dp)) {
          Text("Clear history & backups", color = CyberCoralError, fontWeight = FontWeight.SemiBold)
        }
      }
      status?.let { Text(it, color = TextSecondary, fontSize = 13.sp) }
    }
  }

  confirm?.let { what ->
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { confirm = null },
      title = { Text(if (what == "chats") "Delete all chats?" else "Delete history and backups?") },
      text = {
        Text(
          if (what == "chats") "Every conversation and attached image is deleted from this phone. Projects are kept. This cannot be undone."
          else "The agent History log and the Undo backups of every project are deleted. Your project files are kept, but Undo last run will no longer be possible. This cannot be undone."
        )
      },
      confirmButton = {
        TextButton(onClick = {
          confirm = null
          busy = true
          scope.launch {
            status = if (what == "chats") {
              runCatching { withContext(Dispatchers.IO) { MyData.clearChats(context) } }
                .fold({ onChatsCleared(); "All chats deleted." }, { "Could not delete chats: ${it.message}" })
            } else {
              val n = withContext(Dispatchers.IO) { MyData.clearHistoryAndBackups(context) }
              "History and backups deleted in $n project(s)."
            }
            busy = false
          }
        }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Delete", color = CyberCoralError) }
      },
      dismissButton = { TextButton(onClick = { confirm = null }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Cancel") } }
    )
  }
}
