package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.background
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.border
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.composed
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

class Haptics(private val h: HapticFeedback) {
  /** Light tick for toggles and slider steps. v1.6: off when Settings › Haptic feedback is off. */
  fun tick() { if (AppHaptics.enabled) h.performHapticFeedback(HapticFeedbackType.TextHandleMove) }

  /** Stronger feedback for important actions. */
  fun strong() { if (AppHaptics.enabled) h.performHapticFeedback(HapticFeedbackType.LongPress) }
}

/**
 * v1.6 event haptics: generation start/finish and terminal command finish. Uses View haptics, which
 * Android skips when the user turned touch feedback off system-wide, plus the app's own switch.
 */
object AppHaptics {
  @Volatile var enabled: Boolean = true

  fun start(view: android.view.View) = perform(view, if (android.os.Build.VERSION.SDK_INT >= 23) android.view.HapticFeedbackConstants.CONTEXT_CLICK else android.view.HapticFeedbackConstants.VIRTUAL_KEY)

  fun success(view: android.view.View) = perform(view, if (android.os.Build.VERSION.SDK_INT >= 30) android.view.HapticFeedbackConstants.CONFIRM else android.view.HapticFeedbackConstants.VIRTUAL_KEY)

  fun error(view: android.view.View) = perform(view, if (android.os.Build.VERSION.SDK_INT >= 30) android.view.HapticFeedbackConstants.REJECT else android.view.HapticFeedbackConstants.LONG_PRESS)

  private fun perform(view: android.view.View, constant: Int) {
    if (enabled) view.performHapticFeedback(constant)
  }
}

@Composable
fun rememberHaptics(): Haptics {
  val h = LocalHapticFeedback.current
  return remember(h) { Haptics(h) }
}

/**
 * v1.2: shared press-down scale for elements that already report presses through an
 * [InteractionSource] (Material Buttons, chips, icon buttons). The animated value is only read inside
 * graphicsLayer, so a press never recomposes the caller.
 */
fun Modifier.pressScale(
  interactionSource: androidx.compose.foundation.interaction.InteractionSource,
  pressedScale: Float = 0.97f
): Modifier = composed {
  val pressed by interactionSource.collectIsPressedAsState()
  val scale = animateFloatAsState(
    targetValue = if (pressed) pressedScale else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "pressScaleSource"
  )
  this.graphicsLayer {
    scaleX = scale.value
    scaleY = scale.value
  }
}

/**
 * Spring scale-down while a finger is on the element. Does not consume the touch.
 * Note: every `clickable` already scales through the app-wide PressScaleIndication, so only use this on
 * elements that are not clickable themselves.
 */
fun Modifier.pressScale(pressedScale: Float = 0.97f): Modifier = composed {
  var pressed by remember { mutableStateOf(false) }
  val scale by animateFloatAsState(
    targetValue = if (pressed) pressedScale else 1f,
    animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
    label = "pressScale"
  )
  this
    .graphicsLayer {
      scaleX = scale
      scaleY = scale
    }
    .pointerInput(Unit) {
      awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false)
        pressed = true
        waitForUpOrCancellation()
        pressed = false
      }
    }
}

@Composable
fun LargeTitle(text: String, modifier: Modifier = Modifier) {
  Text(
    text = text,
    color = TextPrimary,
    fontSize = 34.sp,
    lineHeight = 41.sp,
    fontWeight = FontWeight.Bold,
    letterSpacing = (-0.4).sp,
    modifier = modifier.padding(top = 8.dp, bottom = 4.dp)
  )
}

/** iOS grouped list: small caps header above a rounded white/graphite card. */
@Composable
fun GroupedSection(
  title: String,
  modifier: Modifier = Modifier,
  footer: String? = null,
  content: @Composable ColumnScope.() -> Unit
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
      text = title.uppercase(),
      color = TextMuted,
      fontSize = 12.sp,
      fontWeight = FontWeight.Medium,
      modifier = Modifier.padding(start = 16.dp, bottom = 6.dp)
    )
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .liquidGlass(com.example.ui.theme.UiTokens.CardShape, 8.dp)
        .padding(horizontal = 16.dp, vertical = 10.dp),
      content = content
    )
    if (footer != null) {
      Text(
        text = footer,
        color = TextMuted,
        fontSize = 12.5.sp,
        lineHeight = 17.sp,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
        modifier = Modifier.padding(start = 16.dp, end = 16.dp, top = 6.dp)
      )
    }
  }
}

/** Specular rim: bright top-left, soft accent-tinted dispersion on the far edges (v1.6.1: follows the accent). */
@Composable
fun specularBrush(): Brush =
  if (com.example.ui.theme.Palette.dark) {
    Brush.linearGradient(
      listOf(
        Color.White.copy(alpha = 0.60f),
        Color.White.copy(alpha = 0.05f),
        com.example.ui.theme.CyberCyanPrimary.copy(alpha = 0.22f),
        com.example.ui.theme.AccentDeep.copy(alpha = 0.18f),
        Color.White.copy(alpha = 0.34f)
      )
    )
  } else {
    Brush.linearGradient(
      listOf(
        Color.White,
        Color.White.copy(alpha = 0.25f),
        com.example.ui.theme.CyberCyanPrimary.copy(alpha = 0.35f),
        com.example.ui.theme.AccentDeep.copy(alpha = 0.25f),
        Color.White.copy(alpha = 0.95f)
      )
    )
  }

/**
 * Apple-style liquid glass, no blur (cheap): a thin translucent body, a top sheen, a faint bottom
 * reflection, an inner highlight line and a refractive rim.
 */
fun Modifier.liquidGlass(shape: Shape, elevation: Dp = 10.dp): Modifier = composed {
  val dark = com.example.ui.theme.Palette.dark
  val shadowColor = Color.Black.copy(alpha = if (dark) 0.50f else 0.10f)
  val sheen = Brush.verticalGradient(
    0f to Color.White.copy(alpha = if (dark) 0.13f else 0.60f),
    0.45f to Color.White.copy(alpha = if (dark) 0.02f else 0.08f),
    1f to Color.White.copy(alpha = if (dark) 0.06f else 0.22f)
  )
  val inner = Brush.verticalGradient(
    listOf(Color.White.copy(alpha = if (dark) 0.22f else 0.9f), Color.Transparent)
  )
  this
    .shadow(elevation, shape, clip = false, ambientColor = shadowColor, spotColor = shadowColor)
    .clip(shape)
    .background(ObsidianSurface)
    .background(sheen)
    .border(1.dp, specularBrush(), shape)
    .padding(1.dp)
    .border(0.5.dp, inner, shape)
}
