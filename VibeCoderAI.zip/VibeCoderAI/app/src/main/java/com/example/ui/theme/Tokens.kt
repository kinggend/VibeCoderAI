package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Shared design tokens (v1.1) so every screen uses the same radii, touch targets and secondary text style. */
object UiTokens {
  /** Corner radius of every container card in Settings and Models. */
  val CardRadius = 16.dp
  val CardShape = RoundedCornerShape(CardRadius)

  /** Minimum touch target for any tappable control. v1.6: 48 dp (Android accessibility guideline), was 44. */
  val MinTouchTarget = 48.dp

  /** Icon size inside toolbar / action icon buttons. */
  val ActionIconSize = 22.dp

  /** Weight for subtitles, hints and tips so they stay readable on OLED black. */
  val SecondaryWeight = FontWeight.Medium

  /** Size of secondary values shown on the right of settings rows. */
  val RowValueSize = 15.sp
}
