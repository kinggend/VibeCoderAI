package com.example.data.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** v1.4: one conversation in the history drawer. */
@Entity(tableName = "chat_sessions")
data class ChatSessionEntity(
  @PrimaryKey val id: String,
  val title: String,
  val updated: Long,
  @ColumnInfo(name = "message_count") val messageCount: Int
)

/** v1.4: one chat message; file changes are kept as a small JSON array (paths, status, line counts). */
@Entity(
  tableName = "chat_messages",
  foreignKeys = [
    ForeignKey(
      entity = ChatSessionEntity::class,
      parentColumns = ["id"],
      childColumns = ["session_id"],
      onDelete = ForeignKey.CASCADE
    )
  ],
  indices = [Index("session_id")]
)
data class ChatMessageEntity(
  @PrimaryKey(autoGenerate = true) val rowId: Long = 0,
  @ColumnInfo(name = "message_id") val messageId: String,
  @ColumnInfo(name = "session_id") val sessionId: String,
  val position: Int,
  val sender: String,
  val content: String,
  val timestamp: Long,
  @ColumnInfo(name = "is_note") val isNote: Boolean,
  val reasoning: String?,
  @ColumnInfo(name = "changes_json") val changesJson: String?,
  /** v1.6 (schema 2): "device" or the remote host the message went to. */
  val destination: String? = null,
  /** v1.6 (schema 2): newline-separated image paths and "@path" attached files. */
  val attachments: String? = null
)

/** v1.4: token usage of one generation. */
@Entity(tableName = "token_usage")
data class TokenUsageEntity(
  @PrimaryKey(autoGenerate = true) val id: Long = 0,
  val timestamp: Long,
  val model: String,
  @ColumnInfo(name = "prompt_tokens") val promptTokens: Int,
  @ColumnInfo(name = "output_tokens") val outputTokens: Int,
  @ColumnInfo(name = "cached_tokens") val cachedTokens: Int,
  @ColumnInfo(name = "tokens_per_second") val tokensPerSecond: Float,
  /** False when prompt tokens are an estimate (remote backend). */
  val exact: Boolean,
  @ColumnInfo(name = "duration_ms") val durationMs: Long
)

/** Aggregate row for the diagnostics sheet. */
data class UsageTotals(
  val runs: Int,
  val promptTokens: Long,
  val outputTokens: Long,
  val cachedTokens: Long,
  val avgTokensPerSecond: Double,
  val estimatedRuns: Int
)
