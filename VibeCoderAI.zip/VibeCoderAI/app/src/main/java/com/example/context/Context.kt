package com.example.context

/**
 * v1.4 module layout: prompt/context code lives under com.example.context. The original implementation
 * stays in com.example.agent (moving it would touch every caller); these aliases are the new entry points.
 */
typealias ContextManager = com.example.agent.ContextManager
