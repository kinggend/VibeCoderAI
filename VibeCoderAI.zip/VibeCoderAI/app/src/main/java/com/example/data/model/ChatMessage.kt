package com.example.data.model

enum class MessageSender {
  USER,
  AGENT,
  SYSTEM,
  TOOL
}

data class ToolCallInfo(
  val toolName: String,
  val arguments: Map<String, String>,
  val status: String = "running", // running, success, error
  val resultSummary: String? = null
)

enum class ChangeStatus { PENDING, APPLIED, DISCARDED, FAILED }

/** A file the model wants to create or overwrite. */
data class FileChange(
  val path: String,
  val content: String,
  val isNew: Boolean,
  val status: ChangeStatus = ChangeStatus.PENDING,
  val error: String? = null,
  /** Line count kept after a restart, when [content] is no longer stored. */
  val savedLines: Int = 0
) {
  val lineCount: Int get() = if (content.isEmpty() && savedLines > 0) savedLines else content.count { it == '\n' } + 1
}

data class ChatMessage(
  val id: String,
  val sender: MessageSender,
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val toolCall: ToolCallInfo? = null,
  val patchProposal: PatchProposal? = null,
  val isStreaming: Boolean = false,
  val thoughts: String? = null,
  val reasoning: String? = null,
  val fileChanges: List<FileChange> = emptyList(),
  /** v1.6: where this message's data went (On-device / Remote: host). null = saved before v1.6. */
  val destination: com.example.transparency.Destination? = null,
  /** v1.6: the exact request behind this reply ("What the AI sees"). Kept for this app session only. */
  val context: com.example.transparency.ContextManifest? = null,
  /** v1.6: downscaled images attached to a user message (files in app storage), shown as thumbnails. */
  val images: List<String> = emptyList(),
  /** v1.6: project files attached with @ (relative paths), shown as chips. */
  val attachedFiles: List<String> = emptyList()
)
