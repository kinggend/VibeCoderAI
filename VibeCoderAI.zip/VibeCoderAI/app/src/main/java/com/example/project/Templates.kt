package com.example.project

import com.example.data.model.Project
import com.example.data.model.ProjectType
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Ready-made web projects. Small models do far better editing a working app than writing one from scratch. */
data class Template(val id: String, val name: String, val blurb: String, val files: Map<String, String>)

private const val BASE_CSS = """
:root{color-scheme:dark}
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
body{margin:0;padding:20px;min-height:100vh;background:#000;color:#fff;font-family:system-ui,-apple-system,sans-serif}
h1{font-size:28px;margin:8px 0 16px;letter-spacing:-.4px}
.card{background:#1c1c1e;border-radius:18px;padding:16px;border:1px solid #2a2a2c}
button{background:#0a84ff;color:#fff;border:0;border-radius:14px;padding:12px 18px;font-size:16px;font-weight:600}
button:active{transform:scale(.96);opacity:.85}
input{width:100%;background:#1c1c1e;color:#fff;border:1px solid #2a2a2c;border-radius:14px;padding:12px 14px;font-size:16px;outline:none}
input:focus{border-color:#0a84ff}
"""

private fun page(title: String, body: String, extraCss: String = "") = mapOf(
  "index.html" to """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>$title</title>
<link rel="stylesheet" href="styles.css">
</head>
<body>
$body
<script src="app.js"></script>
</body>
</html>
""",
  "styles.css" to BASE_CSS.trim() + "\n" + extraCss.trim() + "\n"
)

object Templates {
  val all: List<Template> = listOf(
    Template(
      "todo", "Todo list", "Add, tick and delete tasks. Saved on the phone.",
      page(
        "Todo",
        """<h1>Todo</h1>
<div style="display:flex;gap:8px"><input id="t" placeholder="New task"><button id="add">Add</button></div>
<ul id="list" class="card" style="list-style:none;padding:8px 16px;margin-top:16px"></ul>""",
        "li{display:flex;align-items:center;gap:12px;padding:12px 0;border-bottom:1px solid #2a2a2c}li:last-child{border:0}li.done span{text-decoration:line-through;color:#8e8e93}li span{flex:1}li b{color:#ff453a;padding:4px 8px}"
      ) + ("app.js" to """let tasks = [];
try { tasks = JSON.parse(localStorage.getItem('tasks') || '[]'); } catch (e) {}
const list = document.getElementById('list');
const input = document.getElementById('t');
function save() { localStorage.setItem('tasks', JSON.stringify(tasks)); }
function render() {
  list.innerHTML = '';
  tasks.forEach((t, i) => {
    const li = document.createElement('li');
    if (t.done) li.className = 'done';
    li.innerHTML = '<input type="checkbox" style="width:22px" ' + (t.done ? 'checked' : '') + '><span></span><b>&times;</b>';
    li.querySelector('span').textContent = t.text;
    li.querySelector('input').onchange = () => { t.done = !t.done; save(); render(); };
    li.querySelector('b').onclick = () => { tasks.splice(i, 1); save(); render(); };
    list.appendChild(li);
  });
}
document.getElementById('add').onclick = () => {
  const v = input.value.trim();
  if (!v) return;
  tasks.push({ text: v, done: false });
  input.value = '';
  save(); render();
};
input.addEventListener('keydown', e => { if (e.key === 'Enter') document.getElementById('add').click(); });
render();
""")
    ),
    Template(
      "calculator", "Calculator", "Clean iOS-style calculator.",
      page(
        "Calculator",
        """<div id="screen">0</div>
<div id="keys"></div>""",
        "body{display:flex;flex-direction:column;justify-content:flex-end;padding:16px}#screen{font-size:64px;text-align:right;padding:16px 8px;font-weight:300;overflow:hidden}#keys{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}#keys button{aspect-ratio:1;border-radius:50%;font-size:26px;background:#333}#keys button.op{background:#ff9f0a}#keys button.fn{background:#a5a5a5;color:#000}#keys button.zero{grid-column:span 2;aspect-ratio:auto;border-radius:40px}"
      ) + ("app.js" to """const keys = ['C','±','%','÷','7','8','9','×','4','5','6','-','1','2','3','+','0','.','='];
const screen = document.getElementById('screen');
const pad = document.getElementById('keys');
let cur = '0', prev = null, op = null, fresh = true;
keys.forEach(k => {
  const b = document.createElement('button');
  b.textContent = k;
  if ('÷×-+='.includes(k)) b.className = 'op';
  else if ('C±%'.includes(k)) b.className = 'fn';
  if (k === '0') b.className = 'zero';
  b.onclick = () => press(k);
  pad.appendChild(b);
});
function calc(a, b, o) {
  a = parseFloat(a); b = parseFloat(b);
  const r = o === '+' ? a + b : o === '-' ? a - b : o === '×' ? a * b : b === 0 ? NaN : a / b;
  return String(parseFloat(r.toPrecision(10)));
}
function press(k) {
  if (/\d/.test(k)) { cur = fresh || cur === '0' ? k : cur + k; fresh = false; }
  else if (k === '.') { if (!cur.includes('.')) cur += '.'; fresh = false; }
  else if (k === 'C') { cur = '0'; prev = null; op = null; fresh = true; }
  else if (k === '±') cur = String(-parseFloat(cur));
  else if (k === '%') cur = String(parseFloat(cur) / 100);
  else if (k === '=') { if (op && prev !== null) { cur = calc(prev, cur, op); prev = null; op = null; fresh = true; } }
  else { if (op && prev !== null && !fresh) cur = calc(prev, cur, op); prev = cur; op = k; fresh = true; }
  screen.textContent = cur === 'NaN' ? 'Error' : cur;
}
""")
    ),
    Template(
      "snake", "Snake game", "Swipe or tap arrows to play.",
      page(
        "Snake",
        """<h1>Snake <span id="score" style="color:#8e8e93;font-size:18px">0</span></h1>
<canvas id="c" width="320" height="320" style="width:100%;max-width:360px;background:#111;border-radius:18px;display:block;margin:0 auto"></canvas>
<p style="text-align:center;color:#8e8e93">Swipe on the board to steer</p>
<div style="text-align:center"><button id="restart">Restart</button></div>"""
      ) + ("app.js" to """const c = document.getElementById('c'), x = c.getContext('2d');
const N = 16, S = c.width / N;
let snake, dir, food, score, timer;
function reset() {
  snake = [{ x: 8, y: 8 }]; dir = { x: 1, y: 0 }; score = 0;
  document.getElementById('score').textContent = 0;
  placeFood(); clearInterval(timer); timer = setInterval(step, 130);
}
function placeFood() { food = { x: Math.floor(Math.random() * N), y: Math.floor(Math.random() * N) }; }
function step() {
  const h = { x: snake[0].x + dir.x, y: snake[0].y + dir.y };
  if (h.x < 0 || h.y < 0 || h.x >= N || h.y >= N || snake.some(s => s.x === h.x && s.y === h.y)) { clearInterval(timer); return; }
  snake.unshift(h);
  if (h.x === food.x && h.y === food.y) { score++; document.getElementById('score').textContent = score; placeFood(); } else snake.pop();
  draw();
}
function draw() {
  x.fillStyle = '#111'; x.fillRect(0, 0, c.width, c.height);
  x.fillStyle = '#ff453a'; x.fillRect(food.x * S + 2, food.y * S + 2, S - 4, S - 4);
  x.fillStyle = '#30d158'; snake.forEach(s => x.fillRect(s.x * S + 1, s.y * S + 1, S - 2, S - 2));
}
let sx = 0, sy = 0;
c.addEventListener('touchstart', e => { sx = e.touches[0].clientX; sy = e.touches[0].clientY; });
c.addEventListener('touchend', e => {
  const dx = e.changedTouches[0].clientX - sx, dy = e.changedTouches[0].clientY - sy;
  if (Math.abs(dx) > Math.abs(dy)) { if (dx > 0 && dir.x !== -1) dir = { x: 1, y: 0 }; else if (dx < 0 && dir.x !== 1) dir = { x: -1, y: 0 }; }
  else { if (dy > 0 && dir.y !== -1) dir = { x: 0, y: 1 }; else if (dy < 0 && dir.y !== 1) dir = { x: 0, y: -1 }; }
});
document.getElementById('restart').onclick = reset;
reset(); draw();
""")
    ),
    Template(
      "landing", "Landing page", "Hero, features and a contact button.",
      page(
        "My Website",
        """<header class="card" style="text-align:center;padding:32px 16px;background:linear-gradient(135deg,#0a84ff33,#bf5af233)">
<h1>My Website</h1><p style="color:#aeaeb2">A clean mobile-first page you can edit.</p>
<button id="cta">Get in touch</button></header>
<section id="features" style="display:grid;gap:12px;margin-top:16px"></section>
<p id="msg" style="text-align:center;color:#30d158"></p>""",
        ".feature{display:flex;gap:12px;align-items:center}.feature i{font-style:normal;font-size:28px}"
      ) + ("app.js" to """const features = [
  ['⚡', 'Fast', 'Loads instantly, even on slow networks.'],
  ['📱', 'Mobile first', 'Designed for phone screens.'],
  ['🔒', 'Private', 'Works fully offline.']
];
const box = document.getElementById('features');
features.forEach(([icon, title, text]) => {
  const d = document.createElement('div');
  d.className = 'card feature';
  d.innerHTML = '<i>' + icon + '</i><div><b>' + title + '</b><div style="color:#8e8e93">' + text + '</div></div>';
  box.appendChild(d);
});
document.getElementById('cta').onclick = () => { document.getElementById('msg').textContent = 'Thanks! We will contact you soon.'; };
""")
    )
  )
}

/** Creates a new web project from [template] and makes it the active project. */
suspend fun ProjectManager.createFromTemplate(template: Template): Project {
  val project = createProject("${template.id}-${(100..999).random()}", ProjectType.WEB_HTML, template.name)
  withContext(Dispatchers.IO) {
    project.rootDir.listFiles()?.filter { !it.name.startsWith(".") }?.forEach { it.deleteRecursively() }
    template.files.forEach { (path, content) -> File(project.rootDir, path).writeText(content) }
  }
  return project
}
