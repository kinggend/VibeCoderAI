package com.example.data

import com.example.data.model.SettingsState

/** One agent skill as written to the export file. [prompt] is only filled for custom skills (built-in text ships with the app). */
data class ExportSkill(val id: String, val name: String, val description: String, val prompt: String?, val builtIn: Boolean, val enabled: Boolean)

/**
 * "Export settings": preferences and agent skills as a JSON text. API keys never leave the phone this way:
 * the remote key is omitted, the server URL loses any user:password@ and ?query part, and the model file is
 * named without its folder. Hand-written JSON keeps this pure Kotlin (unit-tested, no Android classes).
 */
object SettingsExport {
  const val FORMAT = 1

  /** "https://user:pw@host/v1?key=abc" -> "https://host/v1". */
  fun safeUrl(url: String): String {
    var u = url.trim().substringBefore('?').substringBefore('#')
    val scheme = u.indexOf("://")
    if (scheme >= 0) {
      val rest = u.substring(scheme + 3)
      val slash = rest.indexOf('/').let { if (it < 0) rest.length else it }
      val at = rest.substring(0, slash).lastIndexOf('@')
      if (at >= 0) u = u.substring(0, scheme + 3) + rest.substring(at + 1)
    }
    return u
  }

  fun escape(s: String): String {
    val b = StringBuilder(s.length + 8)
    for (c in s) when {
      c == '\\' -> b.append("\\\\")
      c == '"' -> b.append("\\\"")
      c == '\n' -> b.append("\\n")
      c == '\r' -> b.append("\\r")
      c == '\t' -> b.append("\\t")
      c < ' ' -> b.append("\\u%04x".format(c.code))
      else -> b.append(c)
    }
    return b.toString()
  }

  private fun q(s: String) = "\"${escape(s)}\""

  fun toJson(s: SettingsState, skills: List<ExportSkill>, appVersion: String, exportedAt: String): String {
    val prefs = listOf(
      "activeModelId" to q(s.activeModelId),
      "customModelFile" to (s.customModelPath?.substringAfterLast('/')?.let { q(it) } ?: "null"),
      "cpuThreads" to "${s.cpuThreads}",
      "contextLength" to "${s.contextLength}",
      "maxOutputTokens" to "${s.maxOutputTokens}",
      "temperature" to "${s.temperature}",
      "topP" to "${s.topP}",
      "topK" to "${s.topK}",
      "repetitionPenalty" to "${s.repetitionPenalty}",
      "thinking" to "${s.thinking}",
      "autoRebuildAfterPatch" to "${s.autoRebuildAfterPatch}",
      "maxRepairRetries" to "${s.maxRepairRetries}",
      "requireApprovalForDestructive" to "${s.requireApprovalForDestructive}",
      "autoApproveNewFiles" to "${s.autoApproveNewFiles}",
      "autoApproveSafeEdits" to "${s.autoApproveSafeEdits}",
      "gpuOffload" to "${s.gpuOffload}",
      "gpuLayers" to "${s.gpuLayers}",
      "themeMode" to q(s.themeMode),
      "glassBlur" to "${s.glassBlur}",
      "blurRadiusDp" to "${s.blurRadiusDp}",
      "accent" to q(s.accent),
      "strictSecurity" to "${s.strictSecurity}",
      "autonomous" to "${s.autonomous}",
      "terminalTimeoutSec" to "${s.terminalTimeoutSec}",
      "editorAutocomplete" to "${s.editorAutocomplete}",
      "haptics" to "${s.haptics}",
      "voiceLanguage" to q(s.voiceLanguage),
      "voiceRate" to "${s.voiceRate}",
      "voiceAutoContinue" to "${s.voiceAutoContinue}",
      "outputLevel" to q(s.outputLevel),
      "agentRole" to q(s.agentRole),
      "backendMode" to q(s.backendMode),
      "remoteUrl" to q(safeUrl(s.remoteUrl)),
      "remoteModel" to q(s.remoteModel)
    )
    val sb = StringBuilder()
    sb.append("{\n  \"format\": $FORMAT,\n  \"app\": ${q(appVersion)},\n  \"exportedAt\": ${q(exportedAt)},\n")
    sb.append("  \"note\": \"API keys and tokens are never included.\",\n")
    sb.append("  \"preferences\": {\n")
    sb.append(prefs.joinToString(",\n") { (k, v) -> "    ${q(k)}: $v" })
    sb.append("\n  },\n  \"skills\": [\n")
    sb.append(skills.joinToString(",\n") { k ->
      "    {\"id\": ${q(k.id)}, \"name\": ${q(k.name)}, \"description\": ${q(k.description)}, \"builtIn\": ${k.builtIn}, \"enabled\": ${k.enabled}" +
        (if (k.prompt != null) ", \"prompt\": ${q(k.prompt)}" else "") + "}"
    })
    sb.append("\n  ]\n}\n")
    return sb.toString()
  }
}
