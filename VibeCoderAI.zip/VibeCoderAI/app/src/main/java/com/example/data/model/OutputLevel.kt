package com.example.data.model

/**
 * How much the model is asked to write. Each level sets the context window and the maximum output
 * length together (bigger numbers need more RAM and take longer) and adds a short instruction.
 */
enum class OutputLevel(
  val id: String,
  val label: String,
  val context: Int,
  val maxOut: Int,
  val hint: String,
  val blurb: String
) {
  LOW("low", "Low", 2048, 512, "Keep it minimal: only the essential features and short code.", "Fastest. Short answers and tiny apps."),
  MEDIUM("medium", "Medium", 3072, 1024, "", "Balanced speed and detail."),
  HIGH("high", "High", 4096, 1536, "Write complete features with clear, tidy code.", "Complete small apps. Recommended."),
  ULTRA("ultra", "Ultra High", 6144, 2560, "Be thorough: complete features, polished design, input validation, empty and error states.", "More detail. Slower and uses more RAM."),
  MAX("max", "Max", 8192, 4096, "Be maximally thorough: full features, polished animations, edge cases, accessibility and helpful comments.", "Longest output. Slowest and uses the most RAM.");

  companion object {
    fun from(id: String): OutputLevel = values().firstOrNull { it.id == id } ?: HIGH
  }
}

fun SettingsState.withLevel(level: OutputLevel): SettingsState =
  copy(outputLevel = level.id, contextLength = level.context, maxOutputTokens = level.maxOut)
