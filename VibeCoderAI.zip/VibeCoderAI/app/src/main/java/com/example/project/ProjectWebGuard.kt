package com.example.project

import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import java.io.File

/**
 * v1.6 security: WebViews that run project code (Preview, headless check) may read only that project's
 * files. Generated code can no longer read the app's private files (settings, chats, other projects)
 * through file:// URLs, and no JavaScript bridge is exposed.
 */
object ProjectWebGuard {
  /** Pure rule (unit tested): a file:// URL is allowed only when it resolves inside [root]. Other schemes are not files. */
  fun isAllowedFileUrl(root: File, url: String): Boolean {
    if (!url.startsWith("file:", ignoreCase = true)) return true
    val path = runCatching { java.net.URI(url.substringBefore('#').substringBefore('?')).path }.getOrNull() ?: return false
    if (path.isEmpty()) return false
    return FileOps.inside(root, File(path))
  }

  fun harden(settings: WebSettings) {
    settings.allowFileAccess = true // needed to load the project's own index.html, styles.css, app.js
    settings.allowContentAccess = false
    @Suppress("DEPRECATION") settings.allowFileAccessFromFileURLs = false
    @Suppress("DEPRECATION") settings.allowUniversalAccessFromFileURLs = false
    settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
    settings.setGeolocationEnabled(false)
    settings.javaScriptCanOpenWindowsAutomatically = false
    settings.setSupportMultipleWindows(false)
  }

  /** Client that blocks file loads outside [root] and keeps navigation inside the project. */
  open class Client(private val root: File, private val onBlocked: (String) -> Unit = {}) : WebViewClient() {
    override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
      val url = request?.url?.toString() ?: return null
      if (!isAllowedFileUrl(root, url)) {
        onBlocked(url)
        return WebResourceResponse("text/plain", "utf-8", 403, "Forbidden", emptyMap(), java.io.ByteArrayInputStream(ByteArray(0)))
      }
      return null
    }

    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
      val url = request?.url?.toString() ?: return true
      if (url.startsWith("file:", true)) {
        if (!isAllowedFileUrl(root, url)) { onBlocked(url); return true }
        return false
      }
      if (url.startsWith("about:", true) || url.startsWith("data:", true) || url.startsWith("blob:", true)) return false
      // Web links leave the preview only when the user tapped them, and then in the real browser.
      if ((url.startsWith("http://", true) || url.startsWith("https://", true)) && request.hasGesture() && view != null) {
        runCatching {
          view.context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK))
        }
      }
      return true
    }
  }
}
