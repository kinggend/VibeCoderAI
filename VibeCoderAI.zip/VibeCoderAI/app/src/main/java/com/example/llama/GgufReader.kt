package com.example.llama

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class GgufHeader(
  val magic: String,
  val version: Int,
  val tensorCount: Long,
  val metadataKvCount: Long,
  val metadata: Map<String, String> = emptyMap(),
  val isValid: Boolean = true,
  val errorMessage: String? = null
)

/**
 * Genuine GGUF binary file parser.
 * Reads the standard GGUF binary container header (magic: 'GGUF', version, tensor and KV metadata count).
 */
class GgufReader {

  companion object {
    private const val GGUF_MAGIC = 0x46554747 // "GGUF" in little-endian ASCII
  }

  fun readHeader(file: File): GgufHeader {
    if (!file.exists() || !file.isFile) {
      return GgufHeader("", 0, 0, 0, isValid = false, errorMessage = "File does not exist: ${file.path}")
    }

    if (file.length() < 24) {
      return GgufHeader("", 0, 0, 0, isValid = false, errorMessage = "File too small to be a valid GGUF container.")
    }

    return try {
      RandomAccessFile(file, "r").use { raf ->
        val headerBytes = ByteArray(24)
        raf.readFully(headerBytes)

        val buffer = ByteBuffer.wrap(headerBytes).order(ByteOrder.LITTLE_ENDIAN)
        val magicInt = buffer.int

        if (magicInt != GGUF_MAGIC) {
          // Check for valid GGUF magic
          val magicStr = String(headerBytes, 0, 4, Charsets.US_ASCII)
          return GgufHeader(magicStr, 0, 0, 0, isValid = false, errorMessage = "Invalid GGUF magic bytes: '$magicStr'. Expected 'GGUF'.")
        }

        val version = buffer.int
        val tensorCount = buffer.long
        val metadataKvCount = buffer.long

        val parsedMeta = mutableMapOf<String, String>()
        parsedMeta["file_size_mb"] = "${file.length() / (1024 * 1024)} MB"
        parsedMeta["version"] = version.toString()
        parsedMeta["tensors"] = tensorCount.toString()
        parsedMeta["metadata_keys"] = metadataKvCount.toString()

        GgufHeader(
          magic = "GGUF",
          version = version,
          tensorCount = tensorCount,
          metadataKvCount = metadataKvCount,
          metadata = parsedMeta,
          isValid = true
        )
      }
    } catch (e: Exception) {
      GgufHeader("", 0, 0, 0, isValid = false, errorMessage = "Failed to parse GGUF binary: ${e.message}")
    }
  }

  /**
   * Creates a mock valid GGUF binary descriptor file for offline development and testing.
   */
  fun writeValidGgufFile(targetFile: File, version: Int = 3, tensorCount: Long = 180, kvCount: Long = 24) {
    targetFile.parentFile?.let { if (!it.exists()) it.mkdirs() }
    RandomAccessFile(targetFile, "rw").use { raf ->
      val buffer = ByteBuffer.allocate(24).order(ByteOrder.LITTLE_ENDIAN)
      buffer.putInt(GGUF_MAGIC)
      buffer.putInt(version)
      buffer.putLong(tensorCount)
      buffer.putLong(kvCount)
      raf.write(buffer.array())
    }
  }
}
