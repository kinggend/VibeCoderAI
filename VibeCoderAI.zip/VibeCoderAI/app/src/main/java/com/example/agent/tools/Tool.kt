package com.example.agent.tools

import com.example.data.model.Project
import java.io.File

data class ToolResult(
  val success: Boolean,
  val output: String,
  val error: String? = null,
  val metadata: Map<String, Any> = emptyMap()
)

interface Tool {
  val name: String
  val description: String

  suspend fun execute(
    project: Project,
    arguments: Map<String, String>
  ): ToolResult
}
