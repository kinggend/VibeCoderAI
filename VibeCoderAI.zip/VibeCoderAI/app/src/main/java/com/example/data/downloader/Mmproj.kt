package com.example.data.downloader

/**
 * v1.7.3: vision GGUF models ship as two files: the text model and an "mmproj" file (the image encoder).
 * Pure Kotlin (no Android) so the pairing rules are unit-tested.
 */
object Mmproj {
  fun isMmproj(fileName: String): Boolean = fileName.lowercase().contains("mmproj")

  // Quantisation / precision words that differ between a model file and its mmproj file.
  private val QUANT = Regex("""(?:^|[-_. ])(?:i?q\d(?:_[a-z0-9]+)*|f16|f32|bf16)(?=$|[-_. ])""")

  /** Letters and digits of the name without ".gguf", "mmproj" and quantisation words. */
  fun core(fileName: String): String {
    var s = fileName.lowercase().removeSuffix(".gguf").replace("mmproj", " ")
    s = QUANT.replace(s, " ")
    return s.replace(Regex("[^a-z0-9]"), "")
  }

  private fun rank(name: String): Int {
    val l = name.lowercase()
    return when {
      "q8_0" in l -> 0   // about half the size of f16 with the same results in practice
      "f16" in l -> 1
      else -> 2
    }
  }

  /** The mmproj in [candidates] that belongs to [modelFile], or null when none clearly does. */
  fun pair(modelFile: String, candidates: List<String>): String? {
    if (isMmproj(modelFile)) return null
    val mc = core(modelFile)
    if (mc.length < 4) return null
    return candidates.filter { isMmproj(it) }
      .map { c ->
        val cc = core(c)
        val score = when {
          cc.isEmpty() -> 0
          cc == mc -> 1000
          (mc.contains(cc) || cc.contains(mc)) && minOf(mc.length, cc.length) >= 6 -> minOf(mc.length, cc.length)
          else -> 0
        }
        Triple(c, score, rank(c))
      }
      .filter { it.second > 0 }
      .sortedWith(compareByDescending<Triple<String, Int, Int>> { it.second }.thenBy { it.third }.thenBy { it.first })
      .firstOrNull()?.first
  }

  /** In a Hugging Face repo: the mmproj to download together with [modelFile]; the smallest good one when unsure. */
  fun forDownload(modelFile: String, repoFiles: List<String>): String? {
    val all = repoFiles.filter { isMmproj(it) }
    if (all.isEmpty()) return null
    return pair(modelFile, all) ?: all.sortedWith(compareBy<String> { rank(it) }.thenBy { it }).first()
  }
}
