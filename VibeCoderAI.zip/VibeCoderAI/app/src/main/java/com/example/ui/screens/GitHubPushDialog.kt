package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.HistoryEntry
import com.example.agent.ProjectHistory
import com.example.data.SettingsStore
import com.example.data.model.Project
import com.example.github.GitHubPusher
import com.example.transparency.Redact
import com.example.ui.components.TextButton
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * v1.6 Projects › More › Push to GitHub. Step 1: repo, branch, token (saved encrypted, shown masked),
 * commit message. Step 2: the exact file list + message, and the push only happens on "Push now".
 */
@Composable
internal fun GitHubPushDialog(project: Project, onDismiss: () -> Unit) {
  val context = LocalContext.current
  val store = remember { SettingsStore(context) }
  val scope = rememberCoroutineScope()
  var repo by remember { mutableStateOf(store.githubRepo) }
  var branch by remember { mutableStateOf(store.githubBranch) }
  var savedToken by remember { mutableStateOf(store.githubToken) }
  var tokenInput by remember { mutableStateOf("") }
  var changingToken by remember { mutableStateOf(savedToken.isBlank()) }
  var message by remember { mutableStateOf("Update from VibeCoderAI") }
  var plan by remember { mutableStateOf<GitHubPusher.Plan?>(null) }
  var progress by remember { mutableStateOf<String?>(null) }
  var result by remember { mutableStateOf<String?>(null) }
  var error by remember { mutableStateOf<String?>(null) }
  var working by remember { mutableStateOf(false) }

  val parsed = GitHubPusher.parseRepo(repo)
  val branchErr = GitHubPusher.branchError(branch.trim())
  val token = if (changingToken) tokenInput.trim() else savedToken
  val formOk = parsed != null && branchErr == null && token.isNotBlank() && message.isNotBlank()

  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = { if (!working) onDismiss() },
    title = { Text(if (plan == null) "Push to GitHub" else "Review the push") },
    text = {
      Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        when {
          result != null -> Text(result!!, color = TextPrimary, fontSize = 14.sp)
          plan == null -> {
            Text("Only you start a push. Files are added or updated on GitHub; files you deleted here are not deleted there.", color = TextSecondary, fontSize = 13.sp)
            Field(repo, { repo = it }, "https://github.com/you/repo", "Repository URL")
            if (repo.isNotBlank() && parsed == null) Err("Use a GitHub URL like https://github.com/owner/repo.")
            Field(branch, { branch = it }, "main", "Branch")
            branchErr?.takeIf { branch.isNotBlank() }?.let { Err(it) }
            if (!changingToken) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Token saved ${Redact.mask(savedToken)}", color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = { changingToken = true; tokenInput = "" }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Change") }
                TextButton(onClick = { store.githubToken = ""; savedToken = ""; changingToken = true }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Remove", color = CyberCoralError) }
              }
            } else {
              Field(tokenInput, { tokenInput = it }, "Fine-grained token (github_pat_…)", "GitHub token", secret = true)
              Text("Create a fine-grained token for this one repository with Contents: Read and write. It is stored encrypted on this phone and never shown or logged.", color = TextMuted, fontSize = 12.sp)
            }
            Field(message, { message = it }, "Commit message", "Commit message")
          }
          else -> {
            val p = plan!!
            Text("${parsed!!.owner}/${parsed.name} · $branch", color = TextPrimary, fontSize = 14.sp, fontFamily = FontFamily.Monospace)
            Text("Commit message: $message", color = TextSecondary, fontSize = 13.sp)
            Text("${p.files.size} file(s), ${humanBytes(p.totalBytes)}:", color = TextPrimary, fontSize = 14.sp)
            Text(
              p.files.joinToString("\n") { it.path },
              color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
              modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(ObsidianSurfaceVariant).padding(8.dp).heightIn(max = 220.dp).verticalScroll(rememberScrollState())
            )
            if (p.skipped.isNotEmpty()) Text("Not pushed: " + p.skipped.joinToString(), color = CyberAmberWarning, fontSize = 12.sp)
            Text("Hidden folders (.vibecoder history and backups, .git) and build output are never pushed.", color = TextMuted, fontSize = 12.sp)
          }
        }
        progress?.let { Text(it, color = TextSecondary, fontSize = 12.sp) }
        error?.let { Err(it) }
      }
    },
    confirmButton = {
      when {
        result != null -> TextButton(onClick = onDismiss, modifier = Modifier.heightIn(min = 48.dp)) { Text("Done") }
        plan == null -> TextButton(enabled = formOk && !working, onClick = {
          error = null
          working = true
          scope.launch {
            val pl = withContext(Dispatchers.IO) { GitHubPusher.plan(project.rootDir) }
            working = false
            if (pl.files.isEmpty()) error = "This project has no files to push." else plan = pl
          }
        }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Review") }
        else -> TextButton(enabled = !working, onClick = {
          error = null
          working = true
          store.githubRepo = repo
          store.githubBranch = branch
          if (changingToken && tokenInput.isNotBlank()) { store.githubToken = tokenInput; savedToken = store.githubToken; changingToken = false }
          val pl = plan!!
          scope.launch {
            val r = withContext(Dispatchers.IO) {
              runCatching { GitHubPusher.push(parsed!!, branch.trim(), token, message.trim(), pl) { progress = it } }
            }
            working = false
            progress = null
            r.onSuccess { url ->
              result = "Pushed ${pl.files.size} file(s).\n$url"
              ProjectHistory.record(project.rootDir, HistoryEntry.PUSH, "${parsed!!.owner}/${parsed.name}@${branch.trim()}", true, "${pl.files.size} file(s) by you")
            }.onFailure { e ->
              // Never echo the token: redact before showing or logging.
              val msg = Redact.text(e.message ?: e.javaClass.simpleName, listOf(token))
              error = if (e is java.net.UnknownHostException) "No internet connection. Connect and try again." else msg
              ProjectHistory.record(project.rootDir, HistoryEntry.PUSH, "${parsed!!.owner}/${parsed.name}@${branch.trim()}", false, msg)
            }
          }
        }, modifier = Modifier.heightIn(min = 48.dp)) { Text(if (working) "Pushing…" else "Push now", color = CyberCyanPrimary) }
      }
    },
    dismissButton = {
      if (result == null) TextButton(enabled = !working, onClick = { if (plan != null) plan = null else onDismiss() }, modifier = Modifier.heightIn(min = 48.dp)) {
        Text(if (plan != null) "Back" else "Cancel")
      }
    }
  )
}

@Composable
private fun Err(t: String) = Text(t, color = CyberCoralError, fontSize = 12.sp)

@Composable
private fun Field(value: String, onChange: (String) -> Unit, hint: String, desc: String, secret: Boolean = false) {
  Box(Modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).heightIn(min = 48.dp).padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) {
    if (value.isEmpty()) Text(hint, color = TextMuted, fontSize = 14.sp)
    BasicTextField(
      value, onChange, singleLine = true,
      textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp),
      cursorBrush = SolidColor(CyberCyanPrimary),
      visualTransformation = if (secret) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
      keyboardOptions = if (secret) KeyboardOptions(keyboardType = KeyboardType.Password, autoCorrectEnabled = false) else KeyboardOptions.Default,
      modifier = Modifier.fillMaxWidth().semantics { contentDescription = desc }
    )
  }
}
