package com.example.chat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File

/** v1.6: reads a picked image, downscales it (max 1568 px, JPEG 85) and keeps a copy for the chat thumbnail. */
object ImageEncoder {
  private const val MAX_INPUT_BYTES = 30L * 1024 * 1024

  fun load(context: Context, uri: Uri): Result<ImagePayload> = runCatching {
    val cr = context.contentResolver
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) } ?: error("Could not open the image.")
    require(bounds.outWidth > 0 && bounds.outHeight > 0) { "This file is not an image Android can read." }
    val opts = BitmapFactory.Options().apply { inSampleSize = ImageSizing.sampleSize(bounds.outWidth, bounds.outHeight) }
    val decoded = cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) } ?: error("Could not decode the image.")
    val (tw, th) = ImageSizing.fit(decoded.width, decoded.height)
    val bmp = if (tw != decoded.width || th != decoded.height) Bitmap.createScaledBitmap(decoded, tw, th, true).also { if (it !== decoded) decoded.recycle() } else decoded
    val out = ByteArrayOutputStream()
    bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
    bmp.recycle()
    val bytes = out.toByteArray()
    require(bytes.size < MAX_INPUT_BYTES) { "The image is too large even after compression." }
    val dir = File(context.filesDir, "chat_images").apply { mkdirs() }
    val file = File(dir, "img-${System.currentTimeMillis()}.jpg")
    file.writeBytes(bytes)
    ImagePayload(
      name = file.name,
      width = tw,
      height = th,
      bytes = bytes.size.toLong(),
      dataUrl = "data:image/jpeg;base64," + android.util.Base64.encodeToString(bytes, android.util.Base64.NO_WRAP),
      localPath = file.absolutePath
    )
  }

  /** Small bitmap for a thumbnail (decoded at reduced size), or null. */
  fun thumbnail(path: String, side: Int = 256): Bitmap? = runCatching {
    val b = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(path, b)
    if (b.outWidth <= 0) return null
    BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = ImageSizing.sampleSize(b.outWidth, b.outHeight, side) })
  }.getOrNull()
}
