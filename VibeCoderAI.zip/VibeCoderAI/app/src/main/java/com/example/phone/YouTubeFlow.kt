package com.example.phone

/**
 * v1.7.3: the YouTube task as a short script, so it runs at screen speed with no model call:
 * tap Search, type the query, press Enter, tap the first video. Every step is read from the live
 * screen, so a different layout just makes [next] return null and the normal model loop takes over.
 * Pure Kotlin: unit-tested without Android.
 */
class YouTubeFlow(query: String, private val play: Boolean) : ScriptedFlow {
  val query: String = query.trim()
    .replace(Regex("^(?:play|search|open)\\s+", RegexOption.IGNORE_CASE), "")
    .replace(Regex("\\s+(?:play|search)$", RegexOption.IGNORE_CASE), "")
    // "Diwali first video": the position words say which result to pick, they are not search terms.
    .replace(Regex("\\s*\\b(?:the\\s+)?(?:first|1st|top)\\s+(?:video|one|result)\\b", RegexOption.IGNORE_CASE), "")
    // "Diwali videos on top video" leaves a dangling "on": drop it.
    .replace(Regex("\\s+(?:on|in|the|at)$", RegexOption.IGNORE_CASE), "")
    .trim()
    .ifBlank { query.trim() }

  private var typed = false
  private var entered = false
  private var picked: String? = null
  private var waits = 0
  private var misses = 0

  /** True after several screens where the script found nothing to do: the model should take over. */
  override val gaveUp: Boolean get() = misses >= 3 || waits > 8

  /** The next action, or null when this screen is not one the script understands. */
  override fun next(screen: CompactScreen, pkg: String): PhoneAction? {
    if (pkg != FastPaths.YOUTUBE_PKG) return null
    val els = screen.elements
    picked?.let { return PhoneAction.Done("Playing \"$it\" on YouTube") }
    // Still loading: not a miss.
    if (els.size < 3) return PhoneAction.Wait(800)

    if (!typed) {
      els.firstOrNull { it.editable && !it.password }?.let { typed = true; return PhoneAction.Type(it.id, query) }
      els.firstOrNull { isSearchButton(it) }?.let { return PhoneAction.Tap(it.id) }
      misses++
      return null
    }
    if (!entered) { entered = true; return PhoneAction.Enter }

    // Newer YouTube layouts (a Shorts shelf first, cards without "play video") are matched loosely after a short wait.
    val video = els.firstOrNull { isVideoResult(it) } ?: if (waits >= 2) els.firstOrNull { isLooseResult(it) } else null
    if (video != null) {
      if (!play) return PhoneAction.Done("Showing YouTube results for \"$query\"")
      picked = title(video)
      return PhoneAction.Tap(video.id)
    }
    waits++
    return if (waits <= 8) PhoneAction.Wait(1000) else null
  }

  companion object {
    private val DURATION = Regex("\\d+\\s*(?:hours?|minutes?|seconds?)")

    fun isSearchButton(e: ScreenElement): Boolean {
      val l = e.label.lowercase()
      return e.clickable && !e.editable && (l == "search" || l == "search youtube" || l.startsWith("search "))
    }

    /** A search-result video: YouTube describes it as "Title - 4 minutes, 21 seconds - Channel - 65M views - play video". */
    fun isVideoResult(e: ScreenElement): Boolean {
      if (!e.clickable) return false
      val l = e.full.lowercase()
      if ("shorts" in l && "play video" !in l) return false
      // Ads in the results are not what the user asked to play.
      if (Regex("\\b(?:sponsored|advertis\\w*)\\b").containsMatchIn(l)) return false
      return "play video" in l || (DURATION.containsMatchIn(l) && (" views" in l || "watching" in l))
    }

    /** Any tappable result card: has a view count or a play label, is not an ad, is not the search box. */
    fun isLooseResult(e: ScreenElement): Boolean {
      if (!e.clickable || e.editable) return false
      val l = e.full.lowercase()
      if (Regex("\\b(?:sponsored|advertis\\w*)\\b").containsMatchIn(l)) return false
      return " views" in l || "play short" in l || "play video" in l || "watching" in l
    }

    private fun title(e: ScreenElement): String = e.full.substringBefore(" - ").take(60)
  }
}
