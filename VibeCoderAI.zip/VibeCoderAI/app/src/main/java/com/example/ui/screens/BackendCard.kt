package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.SettingsState
import com.example.llama.RemoteClient
import com.example.ui.components.GroupedSection
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Choose where the model runs: on this phone (GGUF) or on an OpenAI-compatible server (Ollama, llama-server, LM Studio). */
@Composable
fun BackendCard(settings: SettingsState, onUpdate: (SettingsState) -> Unit) {
  val haptics = rememberHaptics()
  val remote = settings.backendMode == "remote"

  ModelSurface {
    Row(
      modifier = Modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).padding(4.dp)
    ) {
      listOf("local" to "On this phone", "remote" to "Remote server").forEach { (key, label) ->
        val sel = settings.backendMode == key
        Box(
          modifier = Modifier
            .weight(1f)
            .clip(CircleShape)
            .background(if (sel) CyberCyanPrimary else Color.Transparent)
            .clickable { onUpdate(settings.copy(backendMode = key)) }
            .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
            .padding(vertical = 11.dp),
          contentAlignment = Alignment.Center
        ) { Text(label, color = if (sel) Color.White else TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
      }
    }
    Text(
      if (remote) "Uses a server you run (Ollama, LM Studio, llama-server). Needs the server running and reachable."
      else "Runs the downloaded GGUF model on this phone. Fully offline.",
      color = com.example.ui.theme.TextSecondary, fontSize = 13.sp, lineHeight = 18.sp,
      fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, modifier = Modifier.padding(top = 12.dp)
    )
    if (remote) {
      RemoteServerForm(settings, onUpdate)
    }
  }
}

/** Ready-made servers. Tapping one fills the URL; "Custom" keeps whatever is typed. */
private data class Provider(val name: String, val url: String, val needsKey: Boolean, val hint: String)

private val PROVIDERS = listOf(
  Provider("Ollama", "http://127.0.0.1:11434/v1", false, "Runs on this phone (Termux) or a PC. Use http://PC-IP:11434/v1 for a PC."),
  Provider("LM Studio", "http://127.0.0.1:1234/v1", false, "Start the local server in LM Studio. Use your PC's IP from the phone."),
  Provider("llama-server", "http://127.0.0.1:8080/v1", false, "llama.cpp's own server."),
  Provider("OpenRouter", "https://openrouter.ai/api/v1", true, "Many models, some free. Key from openrouter.ai → Keys."),
  Provider("Groq", "https://api.groq.com/openai/v1", true, "Very fast. Key from console.groq.com → API Keys."),
  Provider("Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", true, "Key from aistudio.google.com → Get API key."),
  Provider("OpenAI", "https://api.openai.com/v1", true, "Key from platform.openai.com → API keys.")
)

private fun maskKey(k: String): String {
  val t = k.trim()
  return if (t.length <= 8) "••••••" else t.take(3) + "••••••" + t.takeLast(4)
}

@Composable
private fun RemoteServerForm(settings: SettingsState, onUpdate: (SettingsState) -> Unit) {
  val scope = rememberCoroutineScope()
  val fieldShape = RoundedCornerShape(16.dp)
  var testResult by remember { mutableStateOf<String?>(null) }
  var testing by remember { mutableStateOf(false) }
  // The key is typed into a draft and only saved (encrypted) when the user taps Save.
  var editingKey by remember { mutableStateOf(settings.remoteKey.isEmpty()) }
  var draftKey by remember { mutableStateOf("") }
  var showKey by remember { mutableStateOf(false) }

  val provider = PROVIDERS.firstOrNull { it.url.equals(settings.remoteUrl.trim().trimEnd('/'), ignoreCase = true) }
  val u = settings.remoteUrl.trim().lowercase()
  // v1.7.6: same rule the client enforces (a host like "10.evil.com" is no longer mistaken for the local network).
  val insecure = u.startsWith("http://") && com.example.security.UrlPolicy.remoteProblem(u) != null

  Column(modifier = Modifier.padding(top = 14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    // 1. Provider
    SectionLabel("Provider")
    androidx.compose.foundation.lazy.LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      items(PROVIDERS.size + 1) { idx ->
        val p = PROVIDERS.getOrNull(idx)
        val sel = if (p == null) provider == null else provider == p
        com.example.ui.components.FilterChip(
          selected = sel,
          onClick = {
            testResult = null
            if (p != null) {
              onUpdate(settings.copy(remoteUrl = p.url))
              if (p.needsKey && settings.remoteKey.isEmpty()) editingKey = true
            }
          },
          label = { Text(p?.name ?: "Custom", fontSize = 13.sp) },
          shape = CircleShape
        )
      }
    }
    Text(
      provider?.hint ?: "Any OpenAI-compatible server. The URL usually ends in /v1.",
      color = TextMuted, fontSize = 12.5.sp, lineHeight = 17.sp
    )

    // 2. Server
    OutlinedTextField(
      value = settings.remoteUrl, onValueChange = { testResult = null; onUpdate(settings.copy(remoteUrl = it)) },
      label = { Text("Server URL") }, singleLine = true, shape = fieldShape, modifier = Modifier.fillMaxWidth(),
      isError = insecure && settings.remoteKey.isNotEmpty(),
      keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
        keyboardType = androidx.compose.ui.text.input.KeyboardType.Uri, autoCorrectEnabled = false
      )
    )
    OutlinedTextField(
      value = settings.remoteModel, onValueChange = { onUpdate(settings.copy(remoteModel = it)) },
      label = { Text("Model name (optional)") }, placeholder = { Text("Empty = first model on the server") },
      singleLine = true, shape = fieldShape, modifier = Modifier.fillMaxWidth()
    )

    // 3. API key
    Row(verticalAlignment = Alignment.CenterVertically) {
      SectionLabel("API key", modifier = Modifier.weight(1f))
      Text(
        if (provider?.needsKey == true) "Required" else "Optional",
        color = if (provider?.needsKey == true) CyberCyanPrimary else TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold
      )
    }
    if (!editingKey && settings.remoteKey.isNotEmpty()) {
      // Saved state: never show the key, only a masked preview.
      Row(
        modifier = Modifier.fillMaxWidth().clip(fieldShape).background(ObsidianSurfaceVariant).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Box(
          modifier = Modifier.clip(CircleShape).background(CyberGreenSuccess.copy(alpha = 0.16f)).padding(8.dp),
          contentAlignment = Alignment.Center
        ) {
          androidx.compose.material3.Icon(
            androidx.compose.material.icons.Icons.Filled.Lock, contentDescription = null,
            tint = CyberGreenSuccess, modifier = Modifier.padding(1.dp)
          )
        }
        Column(modifier = Modifier.weight(1f).padding(horizontal = 12.dp)) {
          Text("Key saved", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          Text(maskKey(settings.remoteKey), color = TextMuted, fontSize = 12.5.sp,
            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        }
        androidx.compose.material3.TextButton(onClick = { draftKey = ""; showKey = false; editingKey = true }) {
          Text("Change", color = CyberCyanPrimary, fontSize = 13.sp)
        }
        androidx.compose.material3.TextButton(onClick = { testResult = null; onUpdate(settings.copy(remoteKey = "")); editingKey = true }) {
          Text("Remove", color = CyberCoralError, fontSize = 13.sp)
        }
      }
    } else {
      OutlinedTextField(
        value = draftKey, onValueChange = { draftKey = it.trim() },
        label = { Text("Paste API key") }, singleLine = true, shape = fieldShape, modifier = Modifier.fillMaxWidth(),
        visualTransformation = if (showKey) androidx.compose.ui.text.input.VisualTransformation.None
          else androidx.compose.ui.text.input.PasswordVisualTransformation(),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
          keyboardType = androidx.compose.ui.text.input.KeyboardType.Password, autoCorrectEnabled = false
        ),
        trailingIcon = {
          if (draftKey.isNotEmpty()) androidx.compose.material3.IconButton(onClick = { showKey = !showKey }) {
            androidx.compose.material3.Icon(
              if (showKey) androidx.compose.material.icons.Icons.Filled.VisibilityOff else androidx.compose.material.icons.Icons.Filled.Visibility,
              contentDescription = if (showKey) "Hide key" else "Show key", tint = TextMuted
            )
          }
        }
      )
      Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        if (settings.remoteKey.isNotEmpty()) PillButton(
          "Cancel", onClick = { draftKey = ""; editingKey = false }, modifier = Modifier.weight(1f)
        )
        PillButton(
          "Save key",
          onClick = { testResult = null; onUpdate(settings.copy(remoteKey = draftKey)); draftKey = ""; showKey = false; editingKey = false },
          primary = true, enabled = draftKey.isNotEmpty(), modifier = Modifier.weight(1f)
        )
      }
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
      androidx.compose.material3.Icon(
        if (insecure && settings.remoteKey.isNotEmpty()) androidx.compose.material.icons.Icons.Filled.Warning
        else androidx.compose.material.icons.Icons.Filled.Shield,
        contentDescription = null,
        tint = if (insecure && settings.remoteKey.isNotEmpty()) CyberCoralError else TextMuted,
        modifier = Modifier.padding(end = 8.dp)
      )
      Text(
        if (insecure && settings.remoteKey.isNotEmpty()) "http:// sends your key unencrypted over the internet. Use https://."
        else "Encrypted on this phone with Android Keystore. Never backed up, never shown again.",
        color = if (insecure && settings.remoteKey.isNotEmpty()) CyberCoralError else TextMuted, fontSize = 12.5.sp, lineHeight = 17.sp
      )
    }

    // 4. Test
    PillButton(
      if (testing) "Testing..." else "Test connection",
      onClick = {
        testing = true
        testResult = null
        scope.launch {
          testResult = withContext(Dispatchers.IO) { RemoteClient.test(settings.remoteUrl, settings.remoteKey) }
          testing = false
        }
      },
      primary = true, enabled = !testing && !(editingKey && draftKey.isNotEmpty()),
      modifier = Modifier.fillMaxWidth()
    )
    testResult?.let {
      val ok = it.startsWith("Connected")
      Row(
        modifier = Modifier.fillMaxWidth().clip(fieldShape)
          .background((if (ok) CyberGreenSuccess else CyberCoralError).copy(alpha = 0.12f)).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        androidx.compose.material3.Icon(
          if (ok) androidx.compose.material.icons.Icons.Filled.CheckCircle else androidx.compose.material.icons.Icons.Filled.Error,
          contentDescription = null, tint = if (ok) CyberGreenSuccess else CyberCoralError, modifier = Modifier.padding(end = 8.dp)
        )
        Text(it, color = if (ok) CyberGreenSuccess else CyberCoralError, fontSize = 13.sp)
      }
    }
  }
}

@Composable
private fun SectionLabel(text: String, modifier: Modifier = Modifier) {
  Text(text.uppercase(), color = TextMuted, fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold,
    letterSpacing = 0.8.sp, modifier = modifier)
}
