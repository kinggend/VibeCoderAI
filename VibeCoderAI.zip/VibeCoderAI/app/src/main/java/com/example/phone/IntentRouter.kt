package com.example.phone

import com.example.agent.MiniJson

/**
 * Understands the task in ANY language with one short model call (the idea behind Google's Mobile Actions:
 * the model only picks a function and its arguments, the app runs it). No regex over the user's words.
 * Returns a route for a few fast, reliable functions; null means "not one of them, let the screen agent work".
 */
object IntentRouter {
  val SYSTEM = """You map a phone task, written in any language, to ONE function. Reply with one JSON object only.
Functions:
{"tool":"open_app","app":"<app name>"}   just open an app
{"tool":"youtube","query":"<what to search>","play":true|false}   search YouTube (play=true opens the first result)
{"tool":"whatsapp","contact":"<person>","text":"<message>"}   send a WhatsApp message
{"tool":"open_url","url":"<https url>"}
{"tool":"agent"}   anything else: settings, toggles, files, other apps, multi-step work
Keep query, contact and text in the user's own words; drop filler like "play", "open", "ki", "lo", "ani", "cheyyi". Examples:
"youtube lo arijit singh songs play cheyyi" -> {"tool":"youtube","query":"arijit singh songs","play":true}
"WhatsApp lo Ravi ki hello ani pettu" -> {"tool":"whatsapp","contact":"Ravi","text":"hello"}
"turn on flashlight" -> {"tool":"agent"}"""

  /** The route for the model's [reply]. Null when it chose "agent" or the reply cannot be read. */
  fun parse(reply: String): FastPaths.Route? {
    val text = com.example.agent.Thinking.split(reply).second.ifBlank { reply }
    val m = Regex("\\{[^{}]*\\}").findAll(text).mapNotNull { runCatching { MiniJson.parseObject(it.value) }.getOrNull() }.firstOrNull() ?: return null
    fun s(k: String) = (m[k] as? String)?.trim()?.takeIf { it.isNotEmpty() }
    return when ((s("tool") ?: return null).lowercase()) {
      "open_app" -> s("app")?.let { FastPaths.Route.App(it) }
      "youtube" -> s("query")?.let { FastPaths.Route.YouTube(it, play = m["play"] != false && m["play"] != "false") }
      "whatsapp" -> { val c = s("contact"); val t = s("text"); if (c != null && t != null) FastPaths.Route.Message("WhatsApp", c, t) else null }
      "open_url" -> s("url")?.takeIf { com.example.security.UrlPolicy.isWebUrl(it) }?.let { FastPaths.Route.Url(it) }
      else -> null
    }
  }
}
