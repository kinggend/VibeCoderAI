package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentRunManager
import com.example.agent.RunBoard
import com.example.agent.RunKind
import com.example.agent.RunRecord
import com.example.agent.RunStatus
import com.example.data.db.UsageTotals
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.Palette
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.delay

private val ChatTint = Color(0xFF4FC3F7)
private val CodingTint = Color(0xFFFF8A65)
private val PhoneTint = Color(0xFFBA68C8)

private fun kindTint(k: RunKind) = when (k) { RunKind.CHAT -> ChatTint; RunKind.CODING -> CodingTint; RunKind.PHONE -> PhoneTint }

/**
 * v1.7.5: Agents / Usage. Agents lists every chat, coding and phone-control run in Working / Done / Archived
 * sections; Usage shows totals. Everything eases in: the tab pill slides, sections fold, rings sweep, bars grow.
 */
@Composable
fun AgentsScreen(
  runs: List<RunRecord>,
  live: AgentRunManager.Progress,
  usage: UsageTotals?,
  onBack: () -> Unit,
  onArchive: (String, Boolean) -> Unit,
  onDelete: (String) -> Unit,
  onClearArchived: () -> Unit,
  modifier: Modifier = Modifier
) {
  var tab by rememberSaveable { mutableStateOf(0) }
  Column(
    modifier = modifier
      .fillMaxSize()
      .background(if (Palette.dark) Color.Black else Color(0xFFF2F2F7))
      .statusBarsPadding()
      .navigationBarsPadding()
  ) {
    Box(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), contentAlignment = Alignment.Center) {
      Box(
        Modifier.align(Alignment.CenterStart).size(44.dp).clip(CircleShape).background(ObsidianSurfaceVariant)
          .clickable(onClickLabel = "Back", onClick = onBack),
        contentAlignment = Alignment.Center
      ) { Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary) }
      SegmentedTabs(listOf("Agents", "Usage"), tab) { tab = it }
    }
    AnimatedContent(
      targetState = tab,
      transitionSpec = {
        val dir = if (targetState > initialState) 1 else -1
        (fadeIn(tween(260)) + slideInHorizontally(tween(300, easing = FastOutSlowInEasing)) { dir * it / 6 }) togetherWith
          (fadeOut(tween(140)) + slideOutHorizontally(tween(260, easing = FastOutSlowInEasing)) { -dir * it / 6 })
      },
      label = "agentsTab",
      modifier = Modifier.weight(1f)
    ) { t ->
      if (t == 0) AgentsTab(runs, live, onArchive, onDelete, onClearArchived) else UsageTab(runs, usage)
    }
  }
}

@Composable
private fun SegmentedTabs(labels: List<String>, selected: Int, onSelect: (Int) -> Unit) {
  val segW = 92.dp
  val x by animateDpAsState(segW * selected, spring(dampingRatio = 0.8f, stiffness = Spring.StiffnessMediumLow), label = "tabX")
  Box(
    Modifier.clip(CircleShape).background(ObsidianSurfaceVariant).border(1.dp, ObsidianBorder, CircleShape).padding(3.dp)
  ) {
    Box(Modifier.offset { IntOffset(x.roundToPx(), 0) }.size(segW, 34.dp).clip(CircleShape).background(CyberCyanPrimary.copy(alpha = 0.22f)))
    Row {
      labels.forEachIndexed { i, l ->
        val c by androidx.compose.animation.animateColorAsState(if (i == selected) TextPrimary else TextMuted, tween(200), label = "tabText")
        Box(
          Modifier.size(segW, 34.dp).clip(CircleShape).clickable(onClickLabel = "Show $l") { onSelect(i) },
          contentAlignment = Alignment.Center
        ) { Text(l, color = c, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
      }
    }
  }
}

// ---------------------------------------------------------------- Agents tab

@Composable
private fun AgentsTab(
  runs: List<RunRecord>,
  live: AgentRunManager.Progress,
  onArchive: (String, Boolean) -> Unit,
  onDelete: (String) -> Unit,
  onClearArchived: () -> Unit
) {
  val sections = remember(runs) { RunBoard.sections(runs) }
  var open by rememberSaveable { mutableStateOf<String?>(null) }
  var workingOpen by rememberSaveable { mutableStateOf(true) }
  var doneOpen by rememberSaveable { mutableStateOf(true) }
  var archivedOpen by rememberSaveable { mutableStateOf(false) }
  val now = rememberNow()

  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(bottom = 24.dp)) {
    if (runs.isEmpty()) {
      Spacer(Modifier.height(80.dp))
      Text("No runs yet", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.CenterHorizontally))
      Text(
        "Chat replies, coding runs and phone-control tasks will show up here.",
        color = TextMuted, fontSize = 14.sp, modifier = Modifier.padding(top = 6.dp, start = 24.dp, end = 24.dp).align(Alignment.CenterHorizontally)
      )
      return@Column
    }
    Section("WORKING", sections.working.size, workingOpen, { workingOpen = !workingOpen }) {
      sections.working.forEach { r ->
        RunCard(r, now, live, open == r.id, { open = if (open == r.id) null else r.id }, onArchive, onDelete)
      }
    }
    Section("DONE", sections.done.size, doneOpen, { doneOpen = !doneOpen }) {
      sections.done.forEach { r ->
        RunCard(r, now, live, open == r.id, { open = if (open == r.id) null else r.id }, onArchive, onDelete)
      }
    }
    Section("ARCHIVED", sections.archived.size, archivedOpen, { archivedOpen = !archivedOpen }, action = if (sections.archived.isNotEmpty()) "Clear" else null, onAction = onClearArchived) {
      sections.archived.forEach { r ->
        RunCard(r, now, live, open == r.id, { open = if (open == r.id) null else r.id }, onArchive, onDelete)
      }
    }
  }
}

@Composable
private fun rememberNow(): Long {
  var now by remember { mutableStateOf(System.currentTimeMillis()) }
  LaunchedEffect(Unit) { while (true) { delay(30_000); now = System.currentTimeMillis() } }
  return now
}

@Composable
private fun Section(
  title: String, count: Int, open: Boolean, onToggle: () -> Unit,
  action: String? = null, onAction: () -> Unit = {}, content: @Composable () -> Unit
) {
  val turn by animateFloatAsState(if (open) 180f else 0f, tween(240, easing = FastOutSlowInEasing), label = "secTurn")
  Row(
    Modifier.fillMaxWidth().padding(top = 14.dp).clip(RoundedCornerShape(10.dp)).clickable(onClickLabel = if (open) "Collapse $title" else "Expand $title", onClick = onToggle)
      .heightIn(min = 44.dp).padding(horizontal = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(title, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.6.sp, modifier = Modifier.weight(1f))
    if (action != null && open) {
      Text(action, color = CyberCoralError, fontSize = 12.sp, fontWeight = FontWeight.Medium, modifier = Modifier.clip(CircleShape).clickable(onClick = onAction).padding(horizontal = 10.dp, vertical = 6.dp))
    }
    Text("$count", color = TextMuted, fontSize = 12.sp)
    Spacer(Modifier.width(6.dp))
    Icon(Icons.Default.ExpandMore, contentDescription = null, tint = TextMuted, modifier = Modifier.size(18.dp).rotate(turn))
  }
  AnimatedVisibility(
    visible = open,
    enter = expandVertically(tween(280, easing = FastOutSlowInEasing)) + fadeIn(tween(240)),
    exit = shrinkVertically(tween(220, easing = FastOutSlowInEasing)) + fadeOut(tween(120))
  ) {
    Column(Modifier.animateContentSize(), verticalArrangement = Arrangement.spacedBy(8.dp)) { content() }
  }
}

@Composable
private fun RunCard(
  r: RunRecord, now: Long, live: AgentRunManager.Progress, expanded: Boolean, onToggle: () -> Unit,
  onArchive: (String, Boolean) -> Unit, onDelete: (String) -> Unit
) {
  var shown by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) { shown = true }
  AnimatedVisibility(shown, enter = fadeIn(tween(260)) + slideInVertically(tween(300, easing = FastOutSlowInEasing)) { it / 5 }) {
    Column(
      Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(ObsidianSurfaceVariant)
        .animateContentSize(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow))
        .clickable(onClickLabel = if (expanded) "Hide details" else "Show details", onClick = onToggle)
        .padding(14.dp)
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        val frac = if (r.status == RunStatus.WORKING && live.total > 0) (live.step.toFloat() / live.total).coerceIn(0.05f, 1f) else null
        ProgressRing(r.status, frac, if (r.status == RunStatus.WORKING) live.step.takeIf { it > 0 } ?: r.steps else r.steps)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
          Text(r.title.ifBlank { "(no title)" }, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
          val sub = if (r.status == RunStatus.WORKING) live.label.ifBlank { "Working…" } else r.result.lineSequence().firstOrNull().orEmpty().ifBlank { statusWord(r.status) }
          Text(sub, color = TextMuted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp))
          Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            if (r.tag.isNotBlank()) { Chip(r.tag, CyberCyanPrimary, filled = true); Spacer(Modifier.width(6.dp)) }
            Text(r.agent.ifBlank { r.kind.label }, color = kindTint(r.kind), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
            Text("  •  ${RunBoard.ago(now, r.startedAt)}", color = TextMuted, fontSize = 11.5.sp, maxLines = 1)
          }
        }
        val rot by animateFloatAsState(if (expanded) 90f else 0f, tween(220), label = "cardArrow")
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted, modifier = Modifier.rotate(rot))
      }
      AnimatedVisibility(expanded, enter = expandVertically(tween(240)) + fadeIn(tween(220)), exit = shrinkVertically(tween(200)) + fadeOut(tween(100))) {
        Column(Modifier.padding(top = 12.dp)) {
          if (r.result.isNotBlank()) Text(r.result, color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp, maxLines = 8, overflow = TextOverflow.Ellipsis)
          val meta = buildList {
            add(statusWord(r.status))
            if (r.steps > 0) add("${r.steps} steps")
            if (r.durationMs > 0) add(RunBoard.duration(r.durationMs))
            add(if (r.remote) "Remote" else "On-device")
          }.joinToString("  ·  ")
          Text(meta, color = TextMuted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp))
          if (r.status != RunStatus.WORKING) {
            Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
              PillAction(if (r.archived) "Restore" else "Archive", CyberCyanPrimary) { onArchive(r.id, !r.archived) }
              PillAction("Delete", CyberCoralError) { onDelete(r.id) }
            }
          }
        }
      }
    }
  }
}

private fun statusWord(s: RunStatus) = when (s) { RunStatus.WORKING -> "Working"; RunStatus.DONE -> "Done"; RunStatus.FAILED -> "Failed"; RunStatus.STOPPED -> "Stopped" }

@Composable
private fun PillAction(text: String, color: Color, onClick: () -> Unit) {
  Text(
    text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
    modifier = Modifier.clip(CircleShape).background(color.copy(alpha = 0.14f)).clickable(onClick = onClick).heightIn(min = 36.dp).padding(horizontal = 16.dp, vertical = 8.dp)
  )
}

@Composable
private fun Chip(text: String, color: Color, filled: Boolean) {
  Text(
    text, color = color, fontSize = 11.5.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis,
    modifier = Modifier.widthIn(max = 120.dp).clip(RoundedCornerShape(6.dp)).background(color.copy(alpha = if (filled) 0.16f else 0f)).padding(horizontal = 7.dp, vertical = 2.dp)
  )
}

/** Ring that sweeps in once; a running task with no known total spins instead. */
@Composable
private fun ProgressRing(status: RunStatus, fraction: Float?, steps: Int) {
  val color = when (status) {
    RunStatus.WORKING -> CyberCyanPrimary; RunStatus.DONE -> com.example.ui.theme.CyberGreenSuccess
    RunStatus.FAILED -> CyberCoralError; RunStatus.STOPPED -> CyberAmberWarning
  }
  val target = when (status) { RunStatus.WORKING -> fraction ?: 0.28f; RunStatus.DONE -> 1f; RunStatus.FAILED -> 0.35f; RunStatus.STOPPED -> 0.6f }
  val sweep = remember { Animatable(0f) }
  LaunchedEffect(target) { sweep.animateTo(target, tween(700, easing = FastOutSlowInEasing)) }
  val spin by rememberInfiniteTransition(label = "ringSpin").animateFloat(
    0f, 360f, infiniteRepeatable(tween(1100, easing = LinearEasing), RepeatMode.Restart), label = "spin"
  )
  val track = ObsidianBorder
  Box(Modifier.size(46.dp), contentAlignment = Alignment.Center) {
    Canvas(Modifier.fillMaxSize()) {
      val w = 4.dp.toPx()
      val inset = w / 2
      val sz = Size(size.width - w, size.height - w)
      drawArc(track, 0f, 360f, false, Offset(inset, inset), sz, style = Stroke(w))
      val start = if (status == RunStatus.WORKING && fraction == null) spin - 90f else -90f
      drawArc(color, start, 360f * sweep.value, false, Offset(inset, inset), sz, style = Stroke(w, cap = StrokeCap.Round))
    }
    Text(if (steps > 0) "$steps" else when (status) { RunStatus.DONE -> "✓"; RunStatus.FAILED -> "!"; RunStatus.STOPPED -> "■"; else -> "…" }, color = TextPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
  }
}

// ---------------------------------------------------------------- Usage tab

@Composable
private fun UsageTab(runs: List<RunRecord>, usage: UsageTotals?) {
  val stats = remember(runs) { RunBoard.stats(runs, System.currentTimeMillis()) }
  val tokens = ((usage?.promptTokens ?: 0L) + (usage?.outputTokens ?: 0L))
  Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp).padding(top = 6.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      StatTile("Runs", stats.total.toLong(), { it.toString() }, Modifier.weight(1f), 0)
      StatTile("Tokens", tokens, { RunBoard.compactNumber(it) }, Modifier.weight(1f), 80)
    }
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
      StatTile("Success", ((stats.successRate ?: 0f) * 100).toLong(), { if (stats.successRate == null) "–" else "$it%" }, Modifier.weight(1f), 160)
      StatTile("Speed", ((usage?.avgTokensPerSecond ?: 0.0) * 10).toLong(), { if (it == 0L) "–" else "%.1f t/s".format(java.util.Locale.US, it / 10.0) }, Modifier.weight(1f), 240)
    }
    Card("By type") {
      val max = maxOf(1, stats.byKind.values.maxOrNull() ?: 1)
      RunKind.values().forEach { k -> BarRow(k.label, stats.byKind[k] ?: 0, max, kindTint(k)) }
    }
    Card("Last 7 days") { WeekBars(stats.last7) }
    Card("Time spent") {
      Text(RunBoard.duration(stats.totalMs), color = TextPrimary, fontSize = 22.sp, fontWeight = FontWeight.Bold)
      Text("${stats.succeeded} done · ${stats.failed} failed · ${stats.stopped} stopped", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp))
    }
  }
}

@Composable
private fun Card(title: String, content: @Composable () -> Unit) {
  Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(ObsidianSurfaceVariant).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Text(title, color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 0.5.sp)
    content()
  }
}

@Composable
private fun StatTile(label: String, value: Long, format: (Long) -> String, modifier: Modifier, delayMs: Int) {
  var go by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) { delay(delayMs.toLong()); go = true }
  val v by animateFloatAsState(if (go) value.toFloat() else 0f, tween(800, easing = FastOutSlowInEasing), label = "count")
  Column(modifier.clip(RoundedCornerShape(18.dp)).background(ObsidianSurfaceVariant).padding(16.dp)) {
    Text(format(v.toLong()), color = TextPrimary, fontSize = 26.sp, fontWeight = FontWeight.Bold)
    Text(label, color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp))
  }
}

@Composable
private fun BarRow(label: String, value: Int, max: Int, color: Color) {
  val frac by animateFloatAsState(value.toFloat() / max, tween(700, easing = FastOutSlowInEasing), label = "bar")
  Row(verticalAlignment = Alignment.CenterVertically) {
    Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.width(64.dp))
    Box(Modifier.weight(1f).height(10.dp).clip(CircleShape).background(ObsidianBorder)) {
      Box(Modifier.fillMaxHeight().fillMaxWidth(frac.coerceAtLeast(0.001f)).clip(CircleShape).background(color))
    }
    Text("$value", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(34.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
  }
}

@Composable
private fun WeekBars(days: List<Int>) {
  val max = maxOf(1, days.maxOrNull() ?: 1)
  val labels = remember {
    val c = java.util.Calendar.getInstance()
    val names = listOf("S", "M", "T", "W", "T", "F", "S")
    (6 downTo 0).map { back -> val d = (c.clone() as java.util.Calendar).apply { add(java.util.Calendar.DAY_OF_YEAR, -back) }; names[d.get(java.util.Calendar.DAY_OF_WEEK) - 1] }
  }
  Row(Modifier.fillMaxWidth().height(110.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.Bottom) {
    days.forEachIndexed { i, n ->
      val h by animateFloatAsState(n.toFloat() / max, tween(650, delayMillis = i * 50, easing = FastOutSlowInEasing), label = "day$i")
      Column(Modifier.width(30.dp).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
        Box(Modifier.width(18.dp).height((74 * h).coerceAtLeast(4f).dp).clip(RoundedCornerShape(6.dp)).background(if (n > 0) CyberCyanPrimary else ObsidianBorder))
        Text(labels[i], color = TextMuted, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
      }
    }
  }
}
