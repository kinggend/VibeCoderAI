package com.example.data.repository

import android.content.Context
import com.example.data.db.AppDatabase
import com.example.data.db.ChatMessageEntity
import com.example.data.db.ChatSessionEntity
import com.example.data.db.TokenUsageEntity
import com.example.data.db.UsageTotals
import com.example.data.local.ChatJson
import com.example.data.local.ChatStore
import com.example.data.local.ChatSummary
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import com.example.data.model.TokenUsage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

/**
 * v1.4: chat history and token usage in Room. Replaces the per-chat JSON files of ChatStore, which are
 * migrated once (see [migrateFromFilesIfNeeded]) and left on disk as a backup.
 */
class ChatRepository private constructor(private val context: Context, private val db: AppDatabase) : com.example.domain.ChatHistory {

  private val chats = db.chatDao()
  private val usage = db.tokenUsageDao()
  private val prefs = context.getSharedPreferences("vibecoder_room", Context.MODE_PRIVATE)
  private val migrateLock = Mutex()

  /** History drawer list, newest first. */
  override val sessions: Flow<List<ChatSummary>> = chats.observeSessions().map { list ->
    list.map { ChatSummary(it.id, it.title, it.updated, it.messageCount) }
  }

  val usageTotals: Flow<UsageTotals> = usage.observeTotals()

  suspend fun latestSessionId(): String? = withContext(Dispatchers.IO) { chats.sessions().firstOrNull()?.id }

  override suspend fun load(id: String): List<ChatMessage> = withContext(Dispatchers.IO) {
    chats.messages(id).map { e ->
      ChatMessage(
        id = e.messageId,
        sender = runCatching { MessageSender.valueOf(e.sender) }.getOrDefault(MessageSender.AGENT),
        content = e.content,
        timestamp = e.timestamp,
        thoughts = if (e.isNote) "note" else null,
        reasoning = e.reasoning,
        fileChanges = ChatJson.changesFromJson(e.changesJson),
        destination = com.example.transparency.Destination.decode(e.destination),
        images = e.attachments.orEmpty().lines().filter { it.isNotBlank() && !it.startsWith("@") },
        attachedFiles = e.attachments.orEmpty().lines().filter { it.startsWith("@") }.map { it.removePrefix("@") }
      )
    }
  }

  /** Same rules as the old ChatStore: user/agent messages only, newest 80, titled by the first user line. */
  override suspend fun save(id: String, messages: List<ChatMessage>, updated: Long): Unit = withContext(Dispatchers.IO) {
    val kept = messages.filter { it.sender == MessageSender.USER || it.sender == MessageSender.AGENT }.takeLast(80)
    val firstUser = kept.firstOrNull { it.sender == MessageSender.USER }?.content ?: return@withContext
    val session = ChatSessionEntity(id, titleOf(firstUser), updated, kept.size)
    val rows = kept.mapIndexed { i, m ->
      ChatMessageEntity(
        messageId = m.id,
        sessionId = id,
        position = i,
        sender = m.sender.name,
        content = m.content,
        timestamp = m.timestamp,
        isNote = m.thoughts == "note",
        reasoning = m.reasoning,
        changesJson = ChatJson.changesToJson(m.fileChanges),
        destination = com.example.transparency.Destination.encode(m.destination),
        attachments = (m.images + m.attachedFiles.map { "@$it" }).joinToString("\n").ifEmpty { null }
      )
    }
    chats.replaceSession(session, rows)
  }

  override suspend fun delete(id: String): Unit = withContext(Dispatchers.IO) { chats.deleteSession(id) }

  override suspend fun logUsage(u: TokenUsage): Unit = withContext(Dispatchers.IO) {
    usage.insert(
      TokenUsageEntity(
        timestamp = u.timestamp,
        model = u.model.take(120),
        promptTokens = u.promptTokens,
        outputTokens = u.outputTokens,
        cachedTokens = u.cachedTokens,
        tokensPerSecond = u.tokensPerSecond,
        exact = u.exact,
        durationMs = u.durationMs
      )
    )
  }

  suspend fun clearUsage() = withContext(Dispatchers.IO) { usage.clear() }

  /**
   * One-time import of the file-based chats. Idempotent: sessions are upserted by id and their messages
   * replaced, so a crash half-way simply repeats on the next launch. The flag is written only after every
   * chat was imported; the JSON files stay on disk as a backup. Returns how many chats were imported.
   */
  suspend fun migrateFromFilesIfNeeded(): Int = migrateLock.withLock {
    withContext(Dispatchers.IO) {
      if (prefs.getBoolean(KEY_MIGRATED, false)) return@withContext 0
      val store = ChatStore(context)
      val summaries = store.list()
      var imported = 0
      for (s in summaries) {
        val msgs = store.load(s.id)
        if (msgs.isEmpty()) continue
        save(s.id, msgs, updated = if (s.updated > 0) s.updated else System.currentTimeMillis())
        imported++
      }
      prefs.edit().putBoolean(KEY_MIGRATED, true).putInt("files_migrated_count", imported).apply()
      imported
    }
  }

  private fun titleOf(text: String): String =
    text.lineSequence().firstOrNull { it.isNotBlank() }?.trim()?.take(48) ?: "Chat"

  companion object {
    private const val KEY_MIGRATED = "files_migrated_v1"
    @Volatile private var instance: ChatRepository? = null

    fun get(context: Context): ChatRepository =
      instance ?: synchronized(this) {
        instance ?: ChatRepository(context.applicationContext, AppDatabase.get(context)).also { instance = it }
      }
  }
}
