package com.example.agent

import com.example.terminal.InputAnswer
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/** v1.6: an agent command is waiting for keyboard input. Only the user answers; the agent never does. */
data class InputRequest(val id: String = UUID.randomUUID().toString(), val command: String, val outputTail: String)

/** Same pattern as [ApprovalGate]: one question at a time, cancellable (Stop answers "stop"). */
class InputGate {
  private val _pending = MutableStateFlow<InputRequest?>(null)
  val pending: StateFlow<InputRequest?> = _pending.asStateFlow()
  private val mutex = Mutex()
  @Volatile private var deferred: CompletableDeferred<InputAnswer>? = null

  suspend fun ask(req: InputRequest): InputAnswer = mutex.withLock {
    val d = CompletableDeferred<InputAnswer>()
    deferred = d
    _pending.value = req
    try {
      d.await()
    } finally {
      deferred = null
      if (_pending.value?.id == req.id) _pending.value = null
    }
  }

  fun answer(id: String, a: InputAnswer): Boolean {
    val req = _pending.value ?: return false
    if (req.id != id) return false
    _pending.value = null
    return deferred?.complete(a) ?: false
  }

  fun cancelAll() {
    _pending.value?.let { answer(it.id, InputAnswer.Stop) }
  }
}
