package com.example.ui.theme

import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val AppShapes = Shapes(
  extraSmall = RoundedCornerShape(6.dp),
  small = RoundedCornerShape(10.dp),
  medium = RoundedCornerShape(14.dp),
  large = RoundedCornerShape(18.dp),
  extraLarge = RoundedCornerShape(28.dp)
)

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean? = null,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val system = isSystemInDarkTheme()
  val darkTheme = darkTheme ?: when (ThemeController.mode) {
    "light" -> false
    "dark" -> true
    else -> system
  }
  // Must run before any content reads a palette colour.
  if (Palette.dark != darkTheme) Palette.dark = darkTheme

  val activity = androidx.compose.ui.platform.LocalContext.current as? androidx.activity.ComponentActivity
  androidx.compose.runtime.SideEffect {
    activity?.enableEdgeToEdge(
      statusBarStyle = androidx.activity.SystemBarStyle.auto(
        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT
      ) { darkTheme },
      navigationBarStyle = androidx.activity.SystemBarStyle.auto(
        android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT
      ) { darkTheme }
    )
  }

  val scheme = if (darkTheme) {
    darkColorScheme(
      primary = CyberCyanPrimary, onPrimary = Color.White, primaryContainer = CyberCyanContainer,
      onPrimaryContainer = TextPrimary, secondary = CyberVioletSecondary, onSecondary = Color.White,
      secondaryContainer = CyberVioletContainer, onSecondaryContainer = TextPrimary,
      tertiary = CyberGreenSuccess, onTertiary = Color.White, tertiaryContainer = CyberGreenContainer,
      onTertiaryContainer = TextPrimary, background = ObsidianBackground, onBackground = TextPrimary,
      surface = ObsidianSurfaceSolid, onSurface = TextPrimary, surfaceVariant = ObsidianSurfaceVariant,
      onSurfaceVariant = TextSecondary, outline = ObsidianBorder, error = CyberCoralError,
      onError = Color.White, errorContainer = CyberCoralContainer, onErrorContainer = TextPrimary
    )
  } else {
    lightColorScheme(
      primary = CyberCyanPrimary, onPrimary = Color.White, primaryContainer = CyberCyanContainer,
      onPrimaryContainer = TextPrimary, secondary = CyberVioletSecondary, onSecondary = Color.White,
      secondaryContainer = CyberVioletContainer, onSecondaryContainer = TextPrimary,
      tertiary = CyberGreenSuccess, onTertiary = Color.White, tertiaryContainer = CyberGreenContainer,
      onTertiaryContainer = TextPrimary, background = ObsidianBackground, onBackground = TextPrimary,
      surface = ObsidianSurfaceSolid, onSurface = TextPrimary, surfaceVariant = ObsidianSurfaceVariant,
      onSurfaceVariant = TextSecondary, outline = ObsidianBorder, error = CyberCoralError,
      onError = Color.White, errorContainer = CyberCoralContainer, onErrorContainer = TextPrimary
    )
  }

  MaterialTheme(
    colorScheme = scheme,
    typography = Typography,
    shapes = AppShapes
  ) {
    androidx.compose.runtime.CompositionLocalProvider(
      androidx.compose.foundation.LocalIndication provides com.example.ui.components.PressScaleIndication
    ) {
      androidx.compose.material3.ProvideTextStyle(
        androidx.compose.ui.text.TextStyle(fontFamily = Sans),
        content = content
      )
    }
  }
}
