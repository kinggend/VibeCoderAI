package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.chat.SpeechText
import com.example.data.model.SettingsState
import com.example.transparency.Destination
import com.example.ui.theme.AccentDeep
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import java.util.Locale

/** v1.6.1 voice mode states, shown under the orb. */
internal enum class VoiceState(val label: String) {
  IDLE("Tap the orb to talk"),
  LISTENING("Listening…"),
  THINKING("Thinking…"),
  SPEAKING("Speaking · tap to interrupt"),
  WAITING("Waiting for you on screen")
}

/**
 * Speech in and out for voice mode. Android SpeechRecognizer (on-device recognizer when the phone has one,
 * otherwise the system recognition service with EXTRA_PREFER_OFFLINE) and Android TextToSpeech (an offline
 * voice is picked when the engine has one). All calls on the main thread. Nothing records until [listen].
 */
internal class VoiceIo(private val context: Context, private val onEvent: (Event) -> Unit) {
  sealed interface Event {
    data class Partial(val text: String) : Event
    data class Final(val text: String) : Event
    data class ListenError(val code: Int) : Event
    data class Level(val rmsDb: Float) : Event
    data class TtsReady(val ok: Boolean) : Event
    object SpeakDone : Event
  }

  private val main = Handler(Looper.getMainLooper())
  private var rec: SpeechRecognizer? = null
  private var tts: TextToSpeech? = null
  private var onDeviceFailed = false
  private var lastLang = ""
  var onDevice = false; private set
  var ttsReady = false; private set
  private var released = false

  val recognizerAvailable: Boolean =
    SpeechRecognizer.isRecognitionAvailable(context) ||
      (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(context))

  fun startTts() {
    tts = TextToSpeech(context.applicationContext) { status ->
      main.post {
        if (released) return@post
        ttsReady = status == TextToSpeech.SUCCESS
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
          override fun onStart(id: String?) {}
          override fun onDone(id: String?) { if (id == LAST) main.post { if (!released) onEvent(Event.SpeakDone) } }
          @Deprecated("Deprecated in Java") override fun onError(id: String?) { main.post { if (!released) onEvent(Event.SpeakDone) } }
          override fun onError(id: String?, errorCode: Int) { main.post { if (!released) onEvent(Event.SpeakDone) } }
          override fun onStop(id: String?, interrupted: Boolean) {}
        })
        onEvent(Event.TtsReady(ttsReady))
      }
    }
  }

  /** Language tags the TTS engine can speak, from [candidates]. */
  fun ttsLanguages(candidates: List<String>): List<String> {
    val t = tts ?: return emptyList()
    return candidates.filter { tag ->
      runCatching { t.isLanguageAvailable(Locale.forLanguageTag(tag)) >= TextToSpeech.LANG_AVAILABLE }.getOrDefault(false)
    }
  }

  fun listen(lang: String) {
    if (released) return
    stopListening()
    lastLang = lang
    val useOnDevice = Build.VERSION.SDK_INT >= 31 && !onDeviceFailed && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    val r = runCatching {
      if (useOnDevice) SpeechRecognizer.createOnDeviceSpeechRecognizer(context) else SpeechRecognizer.createSpeechRecognizer(context)
    }.getOrNull() ?: run { onEvent(Event.ListenError(SpeechRecognizer.ERROR_CLIENT)); return }
    onDevice = useOnDevice
    r.setRecognitionListener(listener)
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
      putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
      if (lang.isNotBlank()) putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
    }
    rec = r
    r.startListening(intent)
  }

  fun stopListening() {
    rec?.let { runCatching { it.cancel() }; runCatching { it.destroy() } }
    rec = null
  }

  /** Speaks [text] (already cleaned for speech). Emits SpeakDone when finished, or at once if it can't speak. */
  fun speak(text: String, lang: String, rate: Float) {
    val t = tts
    val parts = SpeechText.chunks(text)
    if (t == null || !ttsReady || parts.isEmpty()) { main.post { onEvent(Event.SpeakDone) }; return }
    val locale = if (lang.isBlank()) Locale.getDefault() else Locale.forLanguageTag(lang)
    runCatching { t.language = locale }
    // Prefer a voice that works without the network, so replies are spoken on the phone.
    runCatching {
      if (t.voice?.isNetworkConnectionRequired == true) {
        t.voices?.firstOrNull { it.locale.language == locale.language && !it.isNetworkConnectionRequired }?.let { t.voice = it }
      }
    }
    t.setSpeechRate(rate.coerceIn(0.5f, 2.0f))
    parts.forEachIndexed { i, p ->
      t.speak(p, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, Bundle(), if (i == parts.lastIndex) LAST else "v$i")
    }
  }

  fun stopSpeaking() { runCatching { tts?.stop() } }

  fun release() {
    released = true
    stopListening()
    runCatching { tts?.stop(); tts?.shutdown() }
    tts = null
  }

  private val listener = object : RecognitionListener {
    override fun onReadyForSpeech(params: Bundle?) {}
    override fun onBeginningOfSpeech() {}
    override fun onRmsChanged(rmsdB: Float) { onEvent(Event.Level(rmsdB)) }
    override fun onBufferReceived(buffer: ByteArray?) {}
    override fun onEndOfSpeech() {}
    override fun onEvent(eventType: Int, params: Bundle?) {}
    override fun onPartialResults(partialResults: Bundle?) {
      partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.let { onEvent(Event.Partial(it)) }
    }
    override fun onResults(results: Bundle?) {
      val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
      stopListening()
      onEvent(Event.Final(text))
    }
    override fun onError(error: Int) {
      // 12 = ERROR_LANGUAGE_NOT_SUPPORTED, 13 = ERROR_LANGUAGE_UNAVAILABLE (API 31): the on-device
      // recognizer has no pack for this language, so fall back to the system recognition service once.
      if (onDevice && !onDeviceFailed && (error == 12 || error == 13 || error == SpeechRecognizer.ERROR_CLIENT)) {
        onDeviceFailed = true
        main.post { listen(lastLang) }
        return
      }
      stopListening()
      onEvent(Event.ListenError(error))
    }
  }

  companion object {
    private const val LAST = "voice-last"
    /** Offered in settings when the TTS engine has them (plus "phone language"). */
    val LANGUAGE_CANDIDATES = listOf("en-IN", "te-IN", "hi-IN", "en-US", "en-GB")

    fun errorText(code: Int): String = when (code) {
      SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Didn't catch that."
      SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT ->
        "Speech recognition needs the internet for this language. Download the offline language pack in your phone's speech settings."
      SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is off."
      SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again in a moment."
      SpeechRecognizer.ERROR_AUDIO -> "Couldn't open the microphone."
      12, 13 -> "This language isn't available for speech recognition on this phone."
      else -> "Speech recognition stopped (code $code)."
    }
  }
}

/**
 * v1.6.1 voice mode: listen → send through the normal chat path → speak the reply → listen again.
 * It never answers approvals: while one is open the loop waits and the user decides on screen.
 * This is speech-to-text + the chat model + text-to-speech, not a native audio model.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
internal fun VoiceModeScreen(
  settings: SettingsState,
  isGenerating: Boolean,
  needsUser: Boolean,
  latestReply: () -> String?,
  onSend: (String) -> Boolean,
  onStopGeneration: () -> Unit,
  onSettingsChange: (SettingsState) -> Unit,
  onEnd: () -> Unit
) {
  val context = androidx.compose.ui.platform.LocalContext.current
  val view = androidx.compose.ui.platform.LocalView.current
  val s by rememberUpdatedState(settings)
  // The recognizer callback is created once, so it must call the newest lambdas, not the first ones.
  val send by rememberUpdatedState(onSend)
  val reply0 by rememberUpdatedState(latestReply)
  var state by remember { mutableStateOf(VoiceState.IDLE) }
  var heard by remember { mutableStateOf("") }
  var reply by remember { mutableStateOf("") }
  var message by remember { mutableStateOf<String?>(null) }
  var level by remember { mutableFloatStateOf(0f) }
  var misses by remember { mutableIntStateOf(0) }
  var showSettings by remember { mutableStateOf(false) }
  var ttsLangs by remember { mutableStateOf<List<String>>(emptyList()) }
  var ttsOk by remember { mutableStateOf<Boolean?>(null) }
  var sawGenerating by remember { mutableStateOf(false) }
  var granted by remember {
    mutableStateOf(androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.RECORD_AUDIO) == android.content.pm.PackageManager.PERMISSION_GRANTED)
  }
  var denied by remember { mutableStateOf(false) }

  lateinit var io: VoiceIo
  fun startListening() {
    if (!granted || !io.recognizerAvailable) return
    io.stopSpeaking()
    heard = ""; message = null; level = 0f
    state = VoiceState.LISTENING
    io.listen(s.voiceLanguage)
  }
  io = remember {
    VoiceIo(context) { e ->
      when (e) {
        is VoiceIo.Event.Partial -> heard = e.text
        is VoiceIo.Event.Level -> level = ((e.rmsDb + 2f) / 12f).coerceIn(0f, 1f)
        is VoiceIo.Event.Final -> {
          level = 0f
          val text = e.text.trim()
          if (text.isEmpty()) { state = VoiceState.IDLE; message = "Didn't catch that." }
          else {
            heard = text; misses = 0; reply = ""; sawGenerating = false
            state = VoiceState.THINKING
            if (!send(text)) { state = VoiceState.IDLE; message = "Couldn't send. Check the chat screen." }
          }
        }
        is VoiceIo.Event.ListenError -> {
          level = 0f
          val quiet = e.code == SpeechRecognizer.ERROR_NO_MATCH || e.code == SpeechRecognizer.ERROR_SPEECH_TIMEOUT
          if (state != VoiceState.LISTENING) return@VoiceIo
          if (quiet && s.voiceAutoContinue && misses < 2) { misses++; startListening() }
          else { state = VoiceState.IDLE; message = VoiceIo.errorText(e.code); misses = 0 }
        }
        is VoiceIo.Event.TtsReady -> {
          ttsOk = e.ok
          if (e.ok) ttsLangs = io.ttsLanguages(VoiceIo.LANGUAGE_CANDIDATES)
        }
        VoiceIo.Event.SpeakDone -> if (state == VoiceState.SPEAKING) {
          if (s.voiceAutoContinue) startListening() else state = VoiceState.IDLE
        }
      }
    }
  }

  val permission = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
  ) { ok -> granted = ok; denied = !ok; if (ok) startListening() }

  DisposableEffect(Unit) {
    io.startTts()
    view.keepScreenOn = true
    onDispose { io.release(); view.keepScreenOn = false }
  }
  // Leaving the app ends voice mode, so the mic is never open in the background.
  androidx.lifecycle.compose.LifecycleEventEffect(androidx.lifecycle.Lifecycle.Event.ON_STOP) { onEnd() }
  LaunchedEffect(granted) { if (granted && io.recognizerAvailable) startListening() }

  // shortcut: a run that starts and fails inside one frame is not seen, so the orb stays on Thinking;
  // tapping it recovers. Upgrade to an orchestrator "run finished" event if that shows up in practice.
  // Reply finished: speak it. An open approval or input request pauses the loop until the user answers.
  LaunchedEffect(isGenerating, needsUser, state) {
    if (state == VoiceState.THINKING && isGenerating) sawGenerating = true
    if (needsUser && (state == VoiceState.THINKING || state == VoiceState.WAITING)) { state = VoiceState.WAITING; return@LaunchedEffect }
    if (state == VoiceState.WAITING && !needsUser) state = VoiceState.THINKING
    if (state == VoiceState.THINKING && sawGenerating && !isGenerating) {
      val spoken = SpeechText.forSpeech(reply0().orEmpty())
      reply = spoken
      if (spoken.isEmpty() || ttsOk != true) {
        if (ttsOk == false) message = "No text-to-speech engine on this phone, so replies are shown, not spoken."
        if (s.voiceAutoContinue && ttsOk != false) startListening() else state = VoiceState.IDLE
      } else {
        state = VoiceState.SPEAKING
        io.speak(spoken, s.voiceLanguage, s.voiceRate)
      }
    }
  }

  fun onOrbTap() {
    when (state) {
      VoiceState.SPEAKING -> { io.stopSpeaking(); startListening() } // barge-in
      VoiceState.LISTENING -> { io.stopListening(); level = 0f; state = VoiceState.IDLE }
      VoiceState.THINKING -> { onStopGeneration(); startListening() }
      VoiceState.IDLE -> startListening()
      VoiceState.WAITING -> {}
    }
  }

  Dialog(
    onDismissRequest = onEnd,
    properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = false)
  ) {
    Column(
      modifier = Modifier
        .fillMaxSize()
        .background(Color.Black)
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 20.dp, vertical = 12.dp),
      horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
          Text("Voice mode", color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
          DestinationBadge(Destination.of(settings.backendMode, settings.remoteUrl), Modifier.padding(top = 4.dp))
        }
        Box(
          Modifier.size(com.example.ui.theme.UiTokens.MinTouchTarget).clip(CircleShape)
            .clickable(onClickLabel = "Voice settings") { showSettings = !showSettings },
          contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Settings, contentDescription = "Voice settings", tint = if (showSettings) CyberCyanPrimary else TextSecondary) }
      }

      if (showSettings) VoiceSettings(settings, ttsLangs, onSettingsChange)

      Spacer(Modifier.weight(1f))
      when {
        !io.recognizerAvailable -> Text(
          "This phone has no speech recognizer, so voice mode can't listen. Install or enable Google speech services (or another recognizer) in system settings.",
          color = TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Center
        )
        !granted -> Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Allow the microphone", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          Text(
            "Voice mode listens only while this screen is open and stops when you tap End or leave the app. Audio goes to your phone's speech recognizer; only the recognised text is sent to the model, like a typed message.",
            color = TextSecondary, fontSize = 14.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
          )
          Button(
            onClick = {
              if (denied) context.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, android.net.Uri.fromParts("package", context.packageName, null)))
              else permission.launch(android.Manifest.permission.RECORD_AUDIO)
            },
            shape = CircleShape,
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
            modifier = Modifier.heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
          ) { Text(if (denied) "Open app settings" else "Allow microphone", fontWeight = FontWeight.SemiBold) }
          if (denied) Text("Microphone was denied. Turn it on in app settings to use voice mode.", color = TextMuted, fontSize = 12.5.sp, textAlign = TextAlign.Center)
        }
        else -> VoiceOrb(state, level) { onOrbTap() }
      }
      Spacer(Modifier.height(20.dp))
      Text(
        state.label, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }
      )
      val line = when {
        message != null -> message!!
        state == VoiceState.WAITING -> "Approve or reject the request on screen. Voice mode never approves for you."
        state == VoiceState.SPEAKING || (state == VoiceState.IDLE && reply.isNotEmpty()) -> reply
        else -> heard
      }
      Column(Modifier.fillMaxWidth().heightIn(max = 160.dp).padding(top = 8.dp).verticalScroll(rememberScrollState())) {
        Text(line, color = if (message != null) com.example.ui.theme.CyberAmberWarning else TextSecondary, fontSize = 15.sp, lineHeight = 21.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
      }
      Spacer(Modifier.weight(1f))

      Text(
        (if (io.onDevice) "Speech recognition: on this phone. " else "Speech recognition: your phone's speech service, which may use Google's servers if there is no offline language pack. ") +
          "Replies are spoken by your phone's text-to-speech. This is speech-to-text, then the chat model, then text-to-speech, not a native audio model. Your words appear in the chat as normal messages.",
        color = TextMuted, fontSize = 11.5.sp, lineHeight = 15.sp, textAlign = TextAlign.Center
      )
      Spacer(Modifier.height(12.dp))
      Button(
        onClick = onEnd,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = ObsidianSurfaceVariant, contentColor = TextPrimary),
        modifier = Modifier.fillMaxWidth().heightIn(min = 52.dp)
      ) {
        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(Modifier.size(8.dp))
        Text("End", fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
      }
    }
  }
}

/** Accent orb. Breathes while idle/thinking, follows mic level while listening, pulses while speaking. */
@Composable
private fun VoiceOrb(state: VoiceState, level: Float, onTap: () -> Unit) {
  val context = androidx.compose.ui.platform.LocalContext.current
  val reduceMotion = remember {
    android.provider.Settings.Global.getFloat(context.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
  }
  val period = when (state) { VoiceState.SPEAKING -> 700; VoiceState.THINKING -> 1100; else -> 1800 }
  val breath by rememberInfiniteTransition(label = "orb").animateFloat(
    0f, 1f, infiniteRepeatable(tween(period, easing = LinearEasing), RepeatMode.Reverse), label = "breath"
  )
  val mic by animateFloatAsState(if (state == VoiceState.LISTENING) level else 0f, tween(90), label = "mic")
  val b = if (reduceMotion) 0f else breath
  val scale = 1f + 0.05f * b + 0.18f * mic
  // v1.6.2: the orb reads the live theme accent (the same colour the header and buttons use), and
  // its deep end is derived from it, so it can never show another accent than the rest of the app.
  val accent = androidx.compose.material3.MaterialTheme.colorScheme.primary
  val deep = androidx.compose.ui.graphics.lerp(accent, Color.Black, 0.30f)
  Box(
    modifier = Modifier
      .size(220.dp)
      .clip(CircleShape)
      .clickable(role = Role.Button, onClickLabel = when (state) {
        VoiceState.SPEAKING -> "Stop speaking and listen"
        VoiceState.LISTENING -> "Stop listening"
        VoiceState.THINKING -> "Stop the reply and listen"
        else -> "Start listening"
      }) { onTap() }
      .semantics { contentDescription = "Voice orb, ${state.label}" },
    contentAlignment = Alignment.Center
  ) {
    Canvas(Modifier.size(220.dp)) {
      val r = size.minDimension / 2f * 0.62f * scale
      // Soft halo (OLED: drawn only around the orb, background stays black).
      drawCircle(
        Brush.radialGradient(listOf(accent.copy(alpha = 0.28f + 0.2f * mic), Color.Transparent), center, r * 1.6f),
        radius = r * 1.6f
      )
      drawCircle(
        Brush.linearGradient(listOf(accent, deep), Offset(center.x - r, center.y - r), Offset(center.x + r, center.y + r)),
        radius = r
      )
      drawCircle(
        Brush.radialGradient(listOf(Color.White.copy(alpha = 0.35f), Color.Transparent), Offset(center.x - r * 0.35f, center.y - r * 0.4f), r * 0.7f),
        radius = r
      )
    }
  }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun VoiceSettings(settings: SettingsState, ttsLangs: List<String>, onChange: (SettingsState) -> Unit) {
  Column(
    Modifier.fillMaxWidth().padding(top = 12.dp).clip(RoundedCornerShape(18.dp)).background(ObsidianSurfaceVariant).padding(14.dp),
    verticalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Text("Language", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    val options = listOf("") + (ttsLangs + listOfNotNull(settings.voiceLanguage.ifBlank { null })).distinct()
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
      options.forEach { tag ->
        val sel = tag == settings.voiceLanguage
        val label = if (tag.isBlank()) "Phone language" else Locale.forLanguageTag(tag).let { "${it.getDisplayLanguage(it)} (${it.country})" }
        Box(
          Modifier.heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
            .selectable(sel, role = Role.RadioButton) { onChange(settings.copy(voiceLanguage = tag)) },
          contentAlignment = Alignment.Center
        ) {
          Text(
            label, color = if (sel) Color.White else TextSecondary, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.clip(CircleShape).background(if (sel) CyberCyanPrimary else Color.Black).padding(horizontal = 12.dp, vertical = 8.dp)
          )
        }
      }
    }
    if (ttsLangs.isEmpty()) Text("Your text-to-speech engine reported no extra languages. Install voices in system TTS settings.", color = TextMuted, fontSize = 12.sp)
    Text("Speech rate ${"%.1f".format(settings.voiceRate)}×", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    Slider(
      value = settings.voiceRate, onValueChange = { onChange(settings.copy(voiceRate = (it * 10).toInt() / 10f)) },
      valueRange = 0.5f..2.0f, steps = 14,
      colors = SliderDefaults.colors(thumbColor = CyberCyanPrimary, activeTrackColor = CyberCyanPrimary, inactiveTrackColor = ObsidianBorder),
      modifier = Modifier.semantics { contentDescription = "Speech rate" }
    )
    Row(
      Modifier.fillMaxWidth().heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
        .toggleable(settings.voiceAutoContinue, role = Role.Switch) { onChange(settings.copy(voiceAutoContinue = it)) },
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(Modifier.weight(1f)) {
        Text("Auto-continue", color = TextPrimary, fontSize = 15.sp)
        Text("Listen again after each reply.", color = TextMuted, fontSize = 12.sp)
      }
      Switch(checked = settings.voiceAutoContinue, onCheckedChange = null, colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White))
    }
  }
}
