package com.example.agent

/**
 * v1.5: tiny strict JSON for flat objects (string / number / boolean / null values only).
 * Used for skill files and history lines so the logic stays plain-JVM testable (android's org.json
 * is a stub in local unit tests). Rejects nested values, duplicate keys and trailing garbage.
 */
object MiniJson {
  class JsonError(message: String) : IllegalArgumentException(message)

  fun quote(s: String): String = buildString(s.length + 2) {
    append('"')
    for (ch in s) when {
      ch == '"' -> append("\\\"")
      ch == '\\' -> append("\\\\")
      ch == '\n' -> append("\\n")
      ch == '\r' -> append("\\r")
      ch == '\t' -> append("\\t")
      ch < ' ' || ch == '\u2028' || ch == '\u2029' -> append("\\u%04x".format(ch.code))
      else -> append(ch)
    }
    append('"')
  }

  /** Encodes [fields] in order. Values: String, Number, Boolean or null. */
  fun encode(fields: List<Pair<String, Any?>>, pretty: Boolean = false): String = buildString {
    append('{')
    fields.forEachIndexed { i, (k, v) ->
      if (i > 0) append(',')
      if (pretty) append("\n  ")
      append(quote(k)).append(if (pretty) ": " else ":")
      append(
        when (v) {
          null -> "null"
          is String -> quote(v)
          is Boolean -> v.toString()
          is Number -> v.toString()
          else -> throw JsonError("Unsupported value type")
        }
      )
    }
    if (pretty && fields.isNotEmpty()) append('\n')
    append('}')
  }

  /** Parses one flat JSON object. Numbers come back as Double, or Long when integral and in range. */
  fun parseObject(text: String): Map<String, Any?> = Parser(text).run {
    ws(); val obj = obj(); ws()
    if (i != s.length) throw JsonError("Unexpected text after the JSON object")
    obj
  }

  private class Parser(val s: String) {
    var i = 0
    fun ws() { while (i < s.length && s[i] in " \t\r\n") i++ }
    fun expect(c: Char) { if (i >= s.length || s[i] != c) throw JsonError("Expected '$c' at $i"); i++ }

    fun obj(): Map<String, Any?> {
      expect('{'); ws()
      val out = LinkedHashMap<String, Any?>()
      if (i < s.length && s[i] == '}') { i++; return out }
      while (true) {
        ws(); val k = str(); ws(); expect(':'); ws()
        if (out.containsKey(k)) throw JsonError("Duplicate key \"$k\"")
        out[k] = value()
        ws()
        if (i < s.length && s[i] == ',') { i++; continue }
        expect('}'); return out
      }
    }

    fun value(): Any? {
      if (i >= s.length) throw JsonError("Unexpected end")
      return when (val c = s[i]) {
        '"' -> str()
        't' -> word("true", true)
        'f' -> word("false", false)
        'n' -> word("null", null)
        '{', '[' -> throw JsonError("Nested objects or arrays are not allowed")
        else -> if (c == '-' || c.isDigit()) num() else throw JsonError("Unexpected '$c' at $i")
      }
    }

    fun word(w: String, v: Any?): Any? {
      if (!s.startsWith(w, i)) throw JsonError("Invalid literal at $i")
      i += w.length; return v
    }

    fun num(): Any {
      val m = NUM.find(s, i)?.takeIf { it.range.first == i } ?: throw JsonError("Invalid number at $i")
      i = m.range.last + 1
      val t = m.value
      return if (t.none { it == '.' || it == 'e' || it == 'E' }) t.toLongOrNull() ?: t.toDouble() else t.toDouble()
    }

    fun str(): String {
      expect('"')
      val sb = StringBuilder()
      while (true) {
        if (i >= s.length) throw JsonError("Unterminated string")
        val c = s[i++]
        when {
          c == '"' -> return sb.toString()
          c == '\\' -> {
            if (i >= s.length) throw JsonError("Bad escape")
            when (val e = s[i++]) {
              '"' -> sb.append('"')
              '\\' -> sb.append('\\')
              '/' -> sb.append('/')
              'b' -> sb.append('\b')
              'f' -> sb.append('\u000C')
              'n' -> sb.append('\n')
              'r' -> sb.append('\r')
              't' -> sb.append('\t')
              'u' -> {
                if (i + 4 > s.length) throw JsonError("Bad unicode escape")
                sb.append(s.substring(i, i + 4).toIntOrNull(16)?.toChar() ?: throw JsonError("Bad unicode escape"))
                i += 4
              }
              else -> throw JsonError("Bad escape \\$e")
            }
          }
          c < ' ' -> throw JsonError("Control character in string")
          else -> sb.append(c)
        }
      }
    }
  }

  private val NUM = Regex("-?(0|[1-9][0-9]*)(\\.[0-9]+)?([eE][+-]?[0-9]+)?")
}
