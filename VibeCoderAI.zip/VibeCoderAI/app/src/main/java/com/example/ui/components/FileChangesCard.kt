package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChangeStatus
import com.example.data.model.FileChange
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun FileChangesCard(
  changes: List<FileChange>,
  canPreview: Boolean,
  onApply: () -> Unit,
  onDiscard: () -> Unit,
  onPreview: () -> Unit
) {
  val pending = changes.any { it.status == ChangeStatus.PENDING }
  val written = changes.count { it.status == ChangeStatus.APPLIED }
  val shape = RoundedCornerShape(16.dp)

  Column(
    modifier = Modifier
      .fillMaxWidth(0.94f)
      .clip(shape)
      .background(ObsidianSurface)
      .border(0.5.dp, ObsidianBorder, shape)
      .padding(horizontal = 14.dp, vertical = 10.dp),
    verticalArrangement = Arrangement.spacedBy(6.dp)
  ) {
    changes.forEach { c ->
      val (label, color) = when (c.status) {
        ChangeStatus.APPLIED -> "${c.lineCount} lines" to CyberGreenSuccess
        ChangeStatus.FAILED -> (c.error ?: "failed") to CyberCoralError
        ChangeStatus.DISCARDED -> "discarded" to TextMuted
        ChangeStatus.PENDING -> (if (c.isNew) "new" else "overwrites") to CyberAmberWarning
      }
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
          text = (if (c.status == ChangeStatus.APPLIED) "✓  " else "•  ") + c.path,
          color = TextPrimary,
          fontSize = 13.sp,
          fontFamily = FontFamily.Monospace,
          maxLines = 1,
          modifier = Modifier.weight(1f)
        )
        Text(label, color = color, fontSize = 12.sp)
      }
    }

    if (pending || (written > 0 && canPreview)) {
      Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 2.dp)) {
        if (pending) {
          Button(
            onClick = onApply,
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = androidx.compose.ui.graphics.Color.White),
            shape = androidx.compose.foundation.shape.CircleShape,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp, vertical = 6.dp)
          ) { Text("Apply", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
          TextButton(onClick = onDiscard) { Text("Discard", fontSize = 13.sp, color = TextSecondary) }
        } else {
          Button(
            onClick = onPreview,
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = androidx.compose.ui.graphics.Color.White),
            shape = androidx.compose.foundation.shape.CircleShape,
            contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 18.dp, vertical = 6.dp)
          ) { Text("Preview app", fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
        }
      }
    }
  }
}
