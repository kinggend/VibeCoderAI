package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Science
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import com.example.ui.components.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import com.example.ui.components.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Project
import com.example.data.model.TestResult
import com.example.testing.TestRunnerEngine
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.launch

@Composable
fun TestsScreen(
  testRunnerEngine: TestRunnerEngine,
  activeProject: Project?,
  onBack: () -> Unit,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  val testResults = remember { mutableStateListOf<TestResult>() }
  var isRunning by remember { mutableStateOf(false) }
  var selectedSuiteFilter by remember { mutableStateOf("All") }
  var expandedTestName by remember { mutableStateOf<String?>(null) }

  fun executeTests() {
    if (isRunning) return
    isRunning = true
    testResults.clear()
    scope.launch {
      val results = testRunnerEngine.runAllTests(activeProject)
      testResults.addAll(results)
      isRunning = false
    }
  }

  LaunchedEffect(Unit) {
    if (testResults.isEmpty()) {
      executeTests()
    }
  }

  val filteredResults = remember(testResults.size, selectedSuiteFilter) {
    if (selectedSuiteFilter == "All") testResults
    else testResults.filter { it.suite == selectedSuiteFilter }
  }

  val totalPassed = testResults.count { it.passed }
  val totalFailed = testResults.count { !it.passed }
  val totalDuration = testResults.sumOf { it.durationMs }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(ObsidianSurface)
        .padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(onClick = onBack, modifier = Modifier.size(36.dp)) {
          Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = TextPrimary)
        }
        Spacer(modifier = Modifier.width(4.dp))
        Icon(imageVector = Icons.Default.Science, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = "Testing Module",
          color = TextPrimary,
          fontSize = 15.sp,
          fontWeight = FontWeight.Bold
        )
      }

      Button(
        onClick = { executeTests() },
        enabled = !isRunning,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.testTag("run_all_tests_button")
      ) {
        if (isRunning) {
          CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Color.White)
          Spacer(modifier = Modifier.width(6.dp))
          Text("Running...", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        } else {
          Icon(imageVector = Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Run All", fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
      }
    }

    // Top Summary Card
    Card(
      shape = RoundedCornerShape(12.dp),
      colors = CardDefaults.cardColors(containerColor = ObsidianSurfaceVariant),
      modifier = Modifier
        .fillMaxWidth()
        .padding(12.dp)
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(12.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "$totalPassed", color = CyberGreenSuccess, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          Text(text = "Passed", color = TextMuted, fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "$totalFailed", color = if (totalFailed > 0) Color(0xFFF85149) else TextMuted, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          Text(text = "Failed", color = TextMuted, fontSize = 11.sp)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(text = "${totalDuration}ms", color = CyberCyanPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
          Text(text = "Duration", color = TextMuted, fontSize = 11.sp)
        }
      }
    }

    // Suite filter chips
    LazyRow(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 2.dp),
      horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
      val suites = listOf("All", "Unit Tests", "Integration Tests", "JNI Tests", "Model Tests", "Build Verification")
      items(suites) { suite ->
        val isSelected = selectedSuiteFilter == suite
        FilterChip(
          selected = isSelected,
          onClick = { selectedSuiteFilter = suite },
          label = { Text(suite, fontSize = 11.sp, color = if (isSelected) Color.White else TextPrimary) },
          colors = FilterChipDefaults.filterChipColors(
            containerColor = ObsidianSurfaceVariant,
            selectedContainerColor = CyberCyanPrimary
          ),
          border = FilterChipDefaults.filterChipBorder(enabled = true, selected = isSelected, borderColor = ObsidianBorder)
        )
      }
    }

    Spacer(modifier = Modifier.height(6.dp))

    // Test cases list
    LazyColumn(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 12.dp),
      verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      items(filteredResults) { result ->
        val isExpanded = expandedTestName == result.name

        Card(
          shape = RoundedCornerShape(6.dp),
          colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
          modifier = Modifier
            .fillMaxWidth()
            .clickable {
              expandedTestName = if (isExpanded) null else result.name
            }
        ) {
          Column(modifier = Modifier.padding(10.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween
            ) {
              Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                  imageVector = if (result.passed) Icons.Default.CheckCircle else Icons.Default.Error,
                  contentDescription = null,
                  tint = if (result.passed) CyberGreenSuccess else Color(0xFFF85149),
                  modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                    text = result.name,
                    color = TextPrimary,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold
                  )
                  Text(
                    text = "${result.suite} • ${result.durationMs}ms",
                    color = TextMuted,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                  )
                }
              }

              Box(
                modifier = Modifier
                  .clip(RoundedCornerShape(4.dp))
                  .background(if (result.passed) Color(0xFF0E4429) else Color(0xFF4C1D1B))
                  .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                  text = if (result.passed) "PASS" else "FAIL",
                  color = if (result.passed) Color(0xFF7EE787) else Color(0xFFFFA198),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  fontFamily = FontFamily.Monospace
                )
              }
            }

            if (isExpanded) {
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = result.details,
                color = Color(0xFFE6EDF3),
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace
              )
              result.stackTrace?.let { st ->
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                  text = st,
                  color = Color(0xFFFFA198),
                  fontSize = 10.sp,
                  fontFamily = FontFamily.Monospace
                )
              }
            }
          }
        }
      }
    }
  }
}
