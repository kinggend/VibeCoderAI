package com.example.github

import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * v1.6 optional, user-initiated "Push to GitHub" over the REST git data API (HTTPS only):
 * blobs -> tree (on top of the branch's current tree) -> commit -> move the branch ref.
 * Files are added or updated; files deleted on the phone are NOT deleted on GitHub (said in the UI).
 * The token is passed in by the caller from SecretCipher and is never logged, stored here or shown.
 */
object GitHubPusher {
  data class Repo(val owner: String, val name: String)

  data class PushFile(val path: String, val file: File)

  data class Plan(val files: List<PushFile>, val skipped: List<String>, val totalBytes: Long)

  const val MAX_FILES = 400
  const val MAX_FILE_BYTES = 5L * 1024 * 1024
  const val MAX_TOTAL_BYTES = 25L * 1024 * 1024
  private val SKIP_DIRS = setOf("build", "node_modules", ".gradle", ".idea")
  private const val API = "https://api.github.com"

  /** "https://github.com/o/r", "github.com/o/r.git", "git@github.com:o/r.git" or "o/r". Pure, unit tested. */
  fun parseRepo(input: String): Repo? {
    var s = input.trim().removeSuffix("/").removeSuffix(".git")
    s = s.removePrefix("https://").removePrefix("http://").removePrefix("git@").removePrefix("www.")
    s = s.removePrefix("github.com/").removePrefix("github.com:")
    val parts = s.split('/')
    if (parts.size != 2) return null
    val ok = Regex("^[A-Za-z0-9_.-]{1,100}$")
    val (o, r) = parts
    if (!ok.matches(o) || !ok.matches(r) || o.startsWith(".") || r == "." || r == "..") return null
    return Repo(o, r)
  }

  /** Valid branch name for a ref (subset of git check-ref-format). */
  fun branchError(b: String): String? = when {
    b.isBlank() -> "Enter a branch name."
    b.startsWith("/") || b.endsWith("/") || b.contains("..") || b.contains("//") || b.endsWith(".lock") -> "That branch name is not valid."
    b.any { it.isWhitespace() || it in "~^:?*[\\" || it.isISOControl() } -> "Branch names cannot contain spaces or ~^:?*[\\."
    else -> null
  }

  /** What would be pushed: project files except dot folders (History, backups, .git) and build output; size caps applied. */
  fun plan(root: File): Plan {
    val files = mutableListOf<PushFile>()
    val skipped = mutableListOf<String>()
    var total = 0L
    root.walkTopDown()
      .onEnter { it == root || (!it.name.startsWith(".") && it.name !in SKIP_DIRS) }
      .filter { it.isFile && !it.name.startsWith(".") }
      .sortedBy { it.relativeTo(root).invariantSeparatorsPath }
      .forEach { f ->
        val rel = f.relativeTo(root).invariantSeparatorsPath
        when {
          f.length() > MAX_FILE_BYTES -> skipped += "$rel (larger than 5 MB)"
          files.size >= MAX_FILES -> skipped += "$rel (over $MAX_FILES files)"
          total + f.length() > MAX_TOTAL_BYTES -> skipped += "$rel (push is capped at 25 MB)"
          else -> { files += PushFile(rel, f); total += f.length() }
        }
      }
    return Plan(files, skipped, total)
  }

  class GitHubError(message: String) : IOException(message)

  private fun call(method: String, path: String, token: String, body: JSONObject? = null): Pair<Int, String> {
    val c = (URL(API + path).openConnection() as HttpURLConnection).apply {
      requestMethod = method
      connectTimeout = 15_000
      readTimeout = 60_000
      setRequestProperty("Accept", "application/vnd.github+json")
      setRequestProperty("X-GitHub-Api-Version", "2022-11-28")
      setRequestProperty("Authorization", "Bearer $token")
      setRequestProperty("User-Agent", "VibeCoderAI")
      if (body != null) {
        doOutput = true
        setRequestProperty("Content-Type", "application/json")
      }
    }
    try {
      if (body != null) c.outputStream.use { it.write(body.toString().toByteArray()) }
      val code = c.responseCode
      val text = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() }.orEmpty()
      return code to text
    } finally {
      c.disconnect()
    }
  }

  private fun explain(code: Int, body: String, what: String): GitHubError {
    val msg = runCatching { JSONObject(body).optString("message") }.getOrDefault("").take(200)
    val hint = when (code) {
      401 -> "The token was rejected. Create a new fine-grained token and save it again."
      403 -> "The token has no write access. Give it Contents: Read and write for this repository."
      404 -> "Repository not found, or the token cannot see it. Check the URL and the token's repository access."
      409 -> "The repository is empty. Add a README on GitHub first, then push again."
      422 -> "GitHub refused the change ($msg)."
      else -> "GitHub answered $code${if (msg.isNotEmpty()) ": $msg" else ""}."
    }
    return GitHubError("$what failed. $hint")
  }

  /**
   * Pushes [plan] as one commit on [branch]. A missing branch is created from the default branch.
   * [progress] gets plain-language steps. Returns the new commit URL. Blocking: call off the main thread.
   */
  fun push(repo: Repo, branch: String, token: String, message: String, plan: Plan, progress: (String) -> Unit = {}): String {
    require(token.isNotBlank()) { "Save a GitHub token first." }
    require(plan.files.isNotEmpty()) { "There are no files to push." }
    val base = "/repos/${repo.owner}/${repo.name}"
    progress("Reading $branch")
    var (code, body) = call("GET", "$base/git/ref/heads/$branch", token)
    val parentSha: String
    if (code == 404) {
      val (rc, rb) = call("GET", base, token)
      if (rc != 200) throw explain(rc, rb, "Opening the repository")
      val def = JSONObject(rb).optString("default_branch", "main")
      val (dc, db) = call("GET", "$base/git/ref/heads/$def", token)
      if (dc != 200) throw explain(dc, db, "Reading the default branch")
      parentSha = JSONObject(db).getJSONObject("object").getString("sha")
      progress("Branch $branch does not exist yet: it will start from $def")
    } else {
      if (code != 200) throw explain(code, body, "Reading the branch")
      parentSha = JSONObject(body).getJSONObject("object").getString("sha")
    }
    val (cc, cb) = call("GET", "$base/git/commits/$parentSha", token)
    if (cc != 200) throw explain(cc, cb, "Reading the last commit")
    val baseTree = JSONObject(cb).getJSONObject("tree").getString("sha")

    val tree = JSONArray()
    plan.files.forEachIndexed { i, pf ->
      progress("Uploading ${i + 1}/${plan.files.size}: ${pf.path}")
      val b64 = android.util.Base64.encodeToString(pf.file.readBytes(), android.util.Base64.NO_WRAP)
      val (bc, bb) = call("POST", "$base/git/blobs", token, JSONObject().put("content", b64).put("encoding", "base64"))
      if (bc != 201) throw explain(bc, bb, "Uploading ${pf.path}")
      tree.put(JSONObject().put("path", pf.path).put("mode", "100644").put("type", "blob").put("sha", JSONObject(bb).getString("sha")))
    }
    progress("Creating the commit")
    val (tc, tb) = call("POST", "$base/git/trees", token, JSONObject().put("base_tree", baseTree).put("tree", tree))
    if (tc != 201) throw explain(tc, tb, "Creating the file tree")
    val (mc, mb) = call("POST", "$base/git/commits", token, JSONObject().put("message", message).put("tree", JSONObject(tb).getString("sha")).put("parents", JSONArray().put(parentSha)))
    if (mc != 201) throw explain(mc, mb, "Creating the commit")
    val commitSha = JSONObject(mb).getString("sha")
    progress("Moving $branch to the new commit")
    if (code == 404) {
      val (nc, nb) = call("POST", "$base/git/refs", token, JSONObject().put("ref", "refs/heads/$branch").put("sha", commitSha))
      if (nc != 201) throw explain(nc, nb, "Creating branch $branch")
    } else {
      // Not forced: if someone pushed meanwhile, GitHub refuses and nothing is overwritten.
      val (uc, ub) = call("PATCH", "$base/git/refs/heads/$branch", token, JSONObject().put("sha", commitSha).put("force", false))
      if (uc != 200) throw explain(uc, ub, "Updating $branch")
    }
    return "https://github.com/${repo.owner}/${repo.name}/commit/$commitSha"
  }
}
