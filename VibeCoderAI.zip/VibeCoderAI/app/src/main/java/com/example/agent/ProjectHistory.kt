package com.example.agent

import java.io.File

/**
 * v1.5: what the agent did to a project, one JSON object per line in
 * `<project>/.vibecoder/history/history.jsonl`. Hidden from the agent (ProjectFiles rejects dot paths).
 */
data class HistoryEntry(
  val ts: Long,
  val type: String,
  val target: String,
  /** null for events without a pass/fail (run start, file writes that cannot fail later). */
  val ok: Boolean? = null,
  val detail: String = ""
) {
  companion object {
    const val CREATED = "file_created"
    const val MODIFIED = "file_modified"
    const val DELETED = "file_deleted"
    const val COMMAND = "command"
    const val RUN = "run_start"
    const val UNDO = "undo"
    /** v1.6 */
    const val TOOL = "agent_tool"
    const val RENAMED = "file_renamed"
    const val MOVED = "file_moved"
    const val REPLACE = "replace_all"
    const val PUSH = "github_push"
  }
}

object ProjectHistory {
  private const val MAX_BYTES = 256 * 1024L
  private const val KEEP_LINES = 800
  private const val MAX_DETAIL = 300

  fun file(root: File): File = File(root, ".vibecoder/history/history.jsonl")

  fun toLine(e: HistoryEntry): String = MiniJson.encode(
    listOf("ts" to e.ts, "type" to e.type, "target" to e.target, "ok" to e.ok, "detail" to e.detail.take(MAX_DETAIL))
  )

  /** Parses one line; null for blank or damaged lines (a crash mid-write must not hide the rest). */
  fun fromLine(line: String): HistoryEntry? = runCatching {
    if (line.isBlank()) return null
    val o = MiniJson.parseObject(line)
    HistoryEntry(
      ts = (o["ts"] as Number).toLong(),
      type = o["type"] as String,
      target = o["target"] as? String ?: "",
      ok = o["ok"] as Boolean?,
      detail = o["detail"] as? String ?: ""
    )
  }.getOrNull()

  /** v1.6: saved secret values to scrub, set by the app at start-up and when a key changes. */
  @Volatile var knownSecrets: List<String> = emptyList()

  @Synchronized
  fun record(root: File, type: String, target: String, ok: Boolean? = null, detail: String = "") {
    runCatching {
      val f = file(root)
      f.parentFile?.mkdirs()
      // v1.6: secrets never reach the log (commands or server errors may contain a token).
      f.appendText(toLine(HistoryEntry(System.currentTimeMillis(), type, com.example.transparency.Redact.text(target, knownSecrets), ok, com.example.transparency.Redact.text(detail, knownSecrets))) + "\n")
      if (f.length() > MAX_BYTES) {
        val kept = f.readLines().takeLast(KEEP_LINES)
        f.writeText(kept.joinToString("\n", postfix = "\n"))
      }
    }
  }

  /** Newest first. */
  fun read(root: File, limit: Int = 300): List<HistoryEntry> = runCatching {
    val f = file(root)
    if (!f.isFile) emptyList() else f.readLines().mapNotNull { fromLine(it) }.takeLast(limit).reversed()
  }.getOrDefault(emptyList())
}
