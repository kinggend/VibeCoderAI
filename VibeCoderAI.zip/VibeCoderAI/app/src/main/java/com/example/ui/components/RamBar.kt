package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

/** "Free RAM vs Required RAM": the filled part is how much of the free RAM this model + context would use. */
@Composable
fun RamBar(requiredMb: Long, freeMb: Long, modifier: Modifier = Modifier) {
  val level = RamBarMath.level(requiredMb, freeMb)
  val color = when (level) {
    RamLevel.TOO_BIG -> CyberCoralError
    RamLevel.TIGHT -> CyberAmberWarning
    else -> CyberGreenSuccess
  }
  val fill by animateFloatAsState(RamBarMath.ratio(requiredMb, freeMb).coerceIn(0f, 1f), label = "ramFill")
  val note = when (level) {
    RamLevel.TOO_BIG -> "Needs ${requiredMb - freeMb} MB more than is free. It will not load safely."
    RamLevel.TIGHT -> "Tight fit: close other apps, or use a smaller context."
    RamLevel.FITS -> "Fits in free RAM."
    RamLevel.UNKNOWN -> "Free RAM is unknown on this device."
  }
  Column(modifier.semantics { contentDescription = "Required $requiredMb megabytes, free $freeMb megabytes. $note" }) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
      Text("Required $requiredMb MB", color = TextSecondary, fontSize = 12.sp)
      Text("Free $freeMb MB", color = TextSecondary, fontSize = 12.sp)
    }
    Spacer(Modifier.height(6.dp))
    Box(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)).background(ObsidianBorder)) {
      Box(Modifier.fillMaxWidth(fill).fillMaxHeight().clip(RoundedCornerShape(4.dp)).background(color))
    }
    Spacer(Modifier.height(4.dp))
    Text(note, color = if (level == RamLevel.TOO_BIG) CyberCoralError else TextMuted, fontSize = 12.sp)
  }
}
