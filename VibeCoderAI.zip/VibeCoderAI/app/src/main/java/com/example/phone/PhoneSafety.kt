package com.example.phone

/**
 * v1.7.0: what the phone agent must never do on its own. A risky tap pauses the run and asks the user;
 * passwords and codes are never typed; banking and payment apps are not controlled at all.
 */
object RiskGuard {
  enum class Risk(val title: String) {
    PAYMENT("a payment or purchase"),
    SEND("sending or posting a message"),
    DELETE("deleting or removing something"),
    ACCOUNT("an account or security change")
  }

  private fun rx(vararg words: String) = Regex("(?<![\\p{L}\\p{N}])(" + words.joinToString("|") + ")(?![\\p{L}\\p{N}])", RegexOption.IGNORE_CASE)

  private val PAYMENT = rx(
    "pay", "pay now", "payment", "proceed to pay", "make payment", "place order", "place your order", "confirm order",
    "confirm and pay", "buy", "buy now", "checkout", "check out", "purchase", "subscribe", "add money", "recharge",
    "upi", "book now", "confirm booking", "complete purchase", "donate", "tip",
    "చెల్లించు", "చెల్లింపు", "కొనండి", "ఆర్డర్ చేయండి", "भुगतान", "खरीदें", "ऑर्डर करें", "पे करें"
  )
  private val SEND = rx(
    "send", "send message", "send money", "transfer", "post", "publish", "share", "forward", "reply", "tweet", "comment", "upload",
    "పంపు", "పంపండి", "షేర్", "भेजें", "भेजो", "पोस्ट"
  )
  private val DELETE = rx(
    "delete", "remove", "uninstall", "erase", "clear data", "clear all", "clear storage", "factory reset", "reset", "discard", "empty trash", "unsubscribe", "block",
    "తొలగించు", "తొలగించండి", "डिलीट", "हटाएं", "हटाओ"
  )
  private val ACCOUNT = rx("sign out", "log out", "logout", "change password", "deactivate", "delete account", "close account", "grant", "allow access")

  /** The risk of tapping an element labelled [label], or null when it is an ordinary tap. */
  fun classify(label: String?): Risk? {
    val l = label?.trim().orEmpty()
    if (l.isEmpty()) return null
    return when {
      PAYMENT.containsMatchIn(l) -> Risk.PAYMENT
      DELETE.containsMatchIn(l) -> Risk.DELETE
      SEND.containsMatchIn(l) -> Risk.SEND
      ACCOUNT.containsMatchIn(l) -> Risk.ACCOUNT
      else -> null
    }
  }

  private val SECRET_FIELD = rx("password", "passcode", "otp", "one time password", "verification code", "pin", "mpin", "upi pin", "cvv", "cvc", "card number", "పాస్‌వర్డ్", "पासवर्ड")

  /** True when the agent must not type into this field: the user types it themselves. */
  fun isSecretField(e: ScreenElement): Boolean = e.password || SECRET_FIELD.containsMatchIn(e.label)

  /** Text that looks like a code or card number is never typed by the agent, wherever the field is. */
  fun looksSecret(text: String): Boolean {
    val digits = text.filter { it.isDigit() }
    return Regex("^\\s*\\d{4,8}\\s*$").matches(text) || digits.length in 13..19 && text.all { it.isDigit() || it == ' ' || it == '-' }
  }
}

object SensitiveApps {
  /** Banking, UPI and wallet apps: the agent stops instead of reading or tapping them. */
  private val PACKAGES = listOf(
    "com.phonepe.app", "net.one97.paytm", "com.google.android.apps.nbu.paisa.user", "in.org.npci.upiapp",
    "com.sbi.", "com.snapwork.hdfc", "com.csam.icici", "com.axis.mobile", "com.msf.kbank", "com.kotak", "com.mobikwik",
    "com.freecharge", "com.dreamplug.androidapp", "com.bankofbaroda", "com.infrasoft.uboi", "com.canarabank", "com.pnb",
    "com.idbibank", "com.fss.", "com.yesbank", "com.indusind", "com.paypal", "com.google.android.apps.walletnfcrel",
    "com.samsung.android.spay", "com.whatsapp.w4b.payments"
  )
  private val WORDS = Regex("bank|banking|upi|wallet|\\bpay\\b", RegexOption.IGNORE_CASE)

  fun isSensitive(pkg: String?, label: String? = null): Boolean {
    val p = pkg?.lowercase().orEmpty()
    if (p.isEmpty()) return false
    if (PACKAGES.any { p == it || (it.endsWith(".") && p.startsWith(it)) || p.startsWith("$it.") }) return true
    return p.contains("bank") || (label != null && WORDS.containsMatchIn(label))
  }
}
