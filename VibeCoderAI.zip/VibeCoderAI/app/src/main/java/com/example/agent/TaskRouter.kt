package com.example.agent

/** v1.7.4: picks the specialist for a task when the Agent chip is "Auto". Pure Kotlin, unit-tested. */
object TaskRouter {
  enum class Pick { BUILDER, DEBUGGER, REVIEWER, DESIGNER, PHONE }

  private val phone = Regex(
    "\\b(youtube|whatsapp|instagram|facebook|telegram|snapchat|chrome|camera|gallery|play store|wifi|wi-fi|bluetooth|alarm|" +
      "flashlight|torch|dial|home screen|swipe|screenshot|brightness|volume|my phone|phone lo)\\b|" +
      "^(open|launch|start)\\s+(the\\s+)?(app\\s+)?[a-z ]{2,20}$|^(call|message|text)\\s"
  )
  private val fileLike = Regex("\\.(html|css|js|py|kt|json|md)\\b|\\b(file|code|project|index)\\b")
  private val review = Regex("\\b(review|audit|code review|check (my|the) code|find (the )?(problems|issues)|any (bugs|issues|problems)|lint|analy[sz]e)\\b")
  private val fix = Regex("\\b(fix|debug|bug|bugs|error|errors|crash|crashes|broken|not working|doesn'?t work|won'?t (work|load|start)|work avvatledu|panicheyyatledu)\\b")
  private val design = Regex(
    "\\b(design|redesign|style|styling|beautiful|prettier|pretty|polish|modern|animation|animate|colou?rs?|theme|font|layout|" +
      "responsive|gradient|dark mode|ui|ux|look|looks)\\b"
  )
  private val build = Regex("\\b(create|build|generate|develop|new)\\b|\\bmake (me )?(a|an)\\b")

  fun pick(text: String, hasApp: Boolean): Pick {
    val t = text.trim().lowercase()
    if (phone.containsMatchIn(t) && !fileLike.containsMatchIn(t)) return Pick.PHONE
    if (!hasApp) return Pick.BUILDER
    if (review.containsMatchIn(t) && !build.containsMatchIn(t)) return Pick.REVIEWER
    if (build.containsMatchIn(t)) return Pick.BUILDER
    if (fix.containsMatchIn(t)) return Pick.DEBUGGER
    if (design.containsMatchIn(t)) return Pick.DESIGNER
    return Pick.BUILDER
  }

  fun role(p: Pick): AgentRole = when (p) {
    Pick.DEBUGGER -> AgentRoles.DEBUGGER
    Pick.REVIEWER -> AgentRoles.REVIEWER
    Pick.DESIGNER -> AgentRoles.DESIGNER
    else -> AgentRoles.BUILDER
  }
}
