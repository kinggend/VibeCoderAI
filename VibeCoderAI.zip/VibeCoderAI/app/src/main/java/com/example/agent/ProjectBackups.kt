package com.example.agent

import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * v1.5: whole-project zip taken before every autonomous agent run, so "Undo last run" can put the
 * files back. Stored in `<project>/.vibecoder/backups/run-<millis>.zip`, rolling [KEEP] snapshots.
 * Dot folders (.vibecoder, .history, .git) and build output are never included or touched on restore.
 */
object ProjectBackups {
  const val KEEP = 3
  const val MAX_PROJECT_BYTES = 10L * 1024 * 1024
  /** Free space kept beyond the new snapshot so a backup never fills the phone. */
  const val DISK_MARGIN = 50L * 1024 * 1024
  private val EXCLUDED_DIRS = setOf("build", "node_modules")

  sealed class Outcome {
    data class Saved(val file: File) : Outcome()
    data class Skipped(val reason: String) : Outcome()
  }

  // ---- pure rules (unit tested) ----

  /** Names to delete so that, after adding one more, at most [keep] remain. Oldest first by name (run-<millis>). */
  fun toRotate(existing: List<String>, keep: Int = KEEP): List<String> {
    val sorted = existing.sorted()
    val drop = sorted.size - (keep - 1)
    return if (drop > 0) sorted.take(drop) else emptyList()
  }

  /**
   * Oldest snapshots to delete so [needed] bytes fit in [usable] free space, or null when deleting all
   * of them is still not enough (the backup is skipped). [existing] is name to size.
   */
  fun toFreeSpace(existing: List<Pair<String, Long>>, usable: Long, needed: Long): List<String>? {
    var free = usable
    val out = mutableListOf<String>()
    for ((name, size) in existing.sortedBy { it.first }) {
      if (free >= needed) break
      out += name
      free += size
    }
    return if (free >= needed) out else null
  }

  fun isIncluded(relativePath: String): Boolean {
    val parts = relativePath.replace('\\', '/').split('/')
    return parts.none { it.startsWith(".") || it in EXCLUDED_DIRS }
  }

  // ---- file work ----

  fun dir(root: File): File = File(root, ".vibecoder/backups")

  fun list(root: File): List<File> =
    dir(root).listFiles { f -> f.isFile && f.name.startsWith("run-") && f.name.endsWith(".zip") }?.sortedBy { it.name } ?: emptyList()

  fun latest(root: File): File? = list(root).lastOrNull()

  /** Millis the snapshot was taken, from its name. */
  fun takenAt(f: File): Long = f.name.removePrefix("run-").removeSuffix(".zip").toLongOrNull() ?: f.lastModified()

  private fun projectFiles(root: File): List<File> =
    root.walkTopDown()
      .onEnter { it == root || isIncluded(it.relativeTo(root).path) }
      .filter { it.isFile && isIncluded(it.relativeTo(root).path) }
      .toList()

  fun snapshot(root: File, now: Long = System.currentTimeMillis()): Outcome = runCatching {
    if (!root.isDirectory) return Outcome.Skipped("Project folder is missing.")
    val files = projectFiles(root)
    if (files.isEmpty()) return Outcome.Skipped("Nothing to back up yet.")
    val size = files.sumOf { it.length() }
    if (size > MAX_PROJECT_BYTES) return Outcome.Skipped("Project is larger than 10 MB, so no undo snapshot was taken.")
    val d = dir(root).apply { mkdirs() }
    val existing = list(root)
    // Make room: rolling limit first, then disk space (oldest go first).
    toRotate(existing.map { it.name }).forEach { File(d, it).delete() }
    val remaining = list(root)
    val free = toFreeSpace(remaining.map { it.name to it.length() }, d.usableSpace, size + DISK_MARGIN)
      ?: return Outcome.Skipped("Not enough free storage for an undo snapshot.")
    free.forEach { File(d, it).delete() }
    val target = File(d, "run-$now.zip")
    val tmp = File(d, "run-$now.zip.part")
    ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zos ->
      for (f in files) {
        zos.putNextEntry(ZipEntry(f.relativeTo(root).invariantSeparatorsPath))
        f.inputStream().use { it.copyTo(zos) }
        zos.closeEntry()
      }
    }
    if (!tmp.renameTo(target)) { tmp.delete(); return Outcome.Skipped("Could not save the snapshot.") }
    Outcome.Saved(target)
  }.getOrElse { Outcome.Skipped("Snapshot failed: ${it.message}") }

  /**
   * Puts the project back to [zip]: current project files (outside dot folders and build output) are
   * removed, then the snapshot is extracted. Entries escaping the project folder are ignored.
   * The used snapshot is deleted, so the next undo goes one run further back.
   */
  fun restore(root: File, zip: File): Boolean = runCatching {
    if (!zip.isFile) return false
    val rootPath = root.canonicalPath + File.separator
    // Read everything first: a damaged zip must not leave the project half deleted.
    val entries = mutableListOf<Pair<File, ByteArray>>()
    ZipInputStream(BufferedInputStream(zip.inputStream())).use { zis ->
      while (true) {
        val e = zis.nextEntry ?: break
        if (e.isDirectory || !isIncluded(e.name)) continue
        val out = File(root, e.name)
        if (!out.canonicalPath.startsWith(rootPath)) continue
        entries += out to zis.readBytes()
      }
    }
    root.listFiles()?.filter { isIncluded(it.name) }?.forEach { it.deleteRecursively() }
    for ((f, bytes) in entries) {
      f.parentFile?.mkdirs()
      f.writeBytes(bytes)
    }
    zip.delete()
    true
  }.getOrDefault(false)
}
