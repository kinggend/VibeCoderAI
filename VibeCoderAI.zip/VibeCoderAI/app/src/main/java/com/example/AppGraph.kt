package com.example

import android.content.Context
import com.example.agent.AgentOrchestrator
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.llama.LlamaEngine
import com.example.project.ProjectManager
import com.example.terminal.TerminalManager
import com.example.testing.TestRunnerEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

/**
 * v1.6.2: app-wide instances. They used to be `remember`ed in MainScreen, so rotating the phone or
 * Android recreating the activity dropped the running agent and the loaded model. Now they live as
 * long as the process; screens only observe them. Holds the application context only (no activity leak).
 */
class AppGraph private constructor(val app: Context) {
  val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  val projectManager = ProjectManager(app)
  val terminalManager = TerminalManager()
  val buildRunner = BuildRunner()
  val selfRepairEngine = SelfRepairEngine(buildRunner = buildRunner)
  val testRunnerEngine = TestRunnerEngine(context = app, buildRunner = buildRunner, terminalManager = terminalManager)
  val llamaEngine = LlamaEngine(app)
  val orchestrator = AgentOrchestrator(
    context = app,
    llamaEngine = llamaEngine,
    selfRepairEngine = selfRepairEngine,
    terminalManager = terminalManager,
    buildRunner = buildRunner,
    onUsage = { usage ->
      scope.launch(Dispatchers.IO) {
        runCatching { com.example.data.repository.ChatRepository.get(app).logUsage(usage) }
      }
    }
  )

  /** First-launch work (project init, model load, restoring the last chat) runs once per process, not per activity. */
  @Volatile var started = false
  @Volatile var chatRestored = false

  /** True while an activity of the app is on screen (decides whether an approval also needs a notification). */
  val visibleFlow = MutableStateFlow(false)

  /** Bumped by the run notification's tap: MainScreen switches to the Chat tab. */
  val openChatRequests = MutableStateFlow(0L)

  init {
    com.example.agent.AgentRunService.watch(this)
  }

  companion object {
    @Volatile private var instance: AppGraph? = null
    fun get(context: Context): AppGraph =
      instance ?: synchronized(this) { instance ?: AppGraph(context.applicationContext).also { instance = it } }
  }
}
