package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.Stable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerInputScope
import androidx.compose.ui.input.pointer.util.VelocityTracker
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.ChatSummary
import com.example.ui.components.Haptics
import com.example.ui.components.IconButton
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.Palette
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch
import kotlin.math.abs

/*
 * v1.3: chat history is a left push drawer (Claude style) instead of the centered History sheet.
 * The old sheet's logic (open / delete / new chat over ChatStore) is unchanged and wired in MainScreen;
 * this file holds the drawer state, its drag gesture and its content.
 */

/**
 * Drawer position as one Animatable 0 (closed) .. 1 (open). The value is only read inside graphicsLayer /
 * draw lambdas, so dragging or animating never recomposes the screen. [isOpen] survives rotation.
 */
@Stable
class HistoryDrawerState internal constructor(
  private val openState: MutableState<Boolean>,
  private val scope: CoroutineScope,
  private val haptics: Haptics
) {
  val progress = Animatable(if (openState.value) 1f else 0f)
  val isOpen: Boolean get() = openState.value

  /** True while any part of the drawer is on screen (changes only at the ends, not per frame). */
  val visible: Boolean by derivedStateOf { openState.value || progress.value > 0.001f }

  /** Drawer width and fling threshold in px, set from composition (they change only on rotation). */
  var widthPx: Float = 1f
  var flingPx: Float = 1000f

  private var dragValue = 0f

  fun open() = animate(true)
  fun close() = animate(false)

  internal fun beginDrag() {
    dragValue = progress.value
  }

  internal fun dragBy(dx: Float) {
    dragValue = (dragValue + dx / widthPx.coerceAtLeast(1f)).coerceIn(0f, 1f)
    val v = dragValue
    scope.launch { progress.snapTo(v) }
  }

  /** Settle after a drag: a fling decides, otherwise whichever side is nearer. */
  internal fun settle(velocityX: Float) {
    val target = when {
      velocityX > flingPx -> true
      velocityX < -flingPx -> false
      else -> dragValue > 0.5f
    }
    animate(target, velocityX / widthPx.coerceAtLeast(1f))
  }

  private fun animate(open: Boolean, velocity: Float = 0f) {
    val was = openState.value
    openState.value = open
    if (open && !was) haptics.tick()
    scope.launch {
      progress.animateTo(
        if (open) 1f else 0f,
        spring(dampingRatio = 1f, stiffness = 400f),
        initialVelocity = velocity
      )
    }
  }
}

@Composable
fun rememberHistoryDrawerState(): HistoryDrawerState {
  val saved = rememberSaveable { mutableStateOf(false) }
  val scope = rememberCoroutineScope()
  val haptics = rememberHaptics()
  return remember { HistoryDrawerState(saved, scope, haptics) }
}

/**
 * Horizontal drawer drag, observed in the Initial pass so it can claim the gesture before children,
 * but only once the finger has clearly moved horizontally in [direction] (+1 right, -1 left, 0 either).
 * Vertical moves and taps are left to the children untouched. [onTap] fires for a tap that never moved.
 */
internal suspend fun PointerInputScope.detectDrawerDrag(
  state: HistoryDrawerState,
  direction: Int,
  startAllowed: (Offset) -> Boolean = { true },
  onTap: (() -> Unit)? = null
) {
  awaitEachGesture {
    val down = awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
    if (!startAllowed(down.position)) return@awaitEachGesture
    val slop = viewConfiguration.touchSlop
    val tracker = VelocityTracker()
    tracker.addPosition(down.uptimeMillis, down.position)
    var total = Offset.Zero
    var dragging = false
    var undecided = true
    var tapped = false
    while (true) {
      val event = awaitPointerEvent(PointerEventPass.Initial)
      val change = event.changes.firstOrNull { it.id == down.id } ?: break
      tracker.addPosition(change.uptimeMillis, change.position)
      if (!change.pressed) {
        tapped = undecided && !dragging
        if (dragging) change.consume()
        break
      }
      val delta = change.position - change.previousPosition
      if (undecided) {
        total += delta
        if (abs(total.x) > slop) {
          val rightWay = direction == 0 || (direction > 0 && total.x > 0f) || (direction < 0 && total.x < 0f)
          if (rightWay && abs(total.x) > abs(total.y) * 1.2f) {
            dragging = true
            undecided = false
            state.beginDrag()
          } else {
            if (onTap == null) break
            undecided = false
          }
        } else if (abs(total.y) > slop) {
          if (onTap == null) break
          undecided = false
        }
      }
      if (dragging) {
        change.consume()
        state.dragBy(delta.x)
      }
    }
    if (dragging) state.settle(tracker.calculateVelocity().x)
    else if (tapped) onTap?.invoke()
  }
}

/** Drawer content: title + search, New chat pill, Recents list. Pure black in dark mode (OLED). */
@Composable
fun HistoryDrawerContent(
  chats: List<ChatSummary>,
  currentId: String,
  onOpen: (String) -> Unit,
  onDelete: (String) -> Unit,
  onNew: () -> Unit,
  modifier: Modifier = Modifier,
  /** v1.7.5: opens the Agents / Usage screen. */
  onAgents: () -> Unit = {}
) {
  val dark = Palette.dark
  var searching by remember { mutableStateOf(false) }
  var query by remember { mutableStateOf("") }
  val shown = remember(chats, query) {
    val q = query.trim()
    if (q.isEmpty()) chats else chats.filter { it.title.contains(q, ignoreCase = true) }
  }
  val subtle = if (dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.06f)

  Column(
    modifier = modifier
      .fillMaxHeight()
      .background(if (dark) Color.Black else Color(0xFFF2F2F7))
      .statusBarsPadding()
      .navigationBarsPadding()
      .padding(horizontal = 12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().height(56.dp).padding(start = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "History",
        color = TextPrimary,
        fontSize = 24.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = (-0.3).sp,
        modifier = Modifier.weight(1f)
      )
      IconButton(onClick = {
        searching = !searching
        if (!searching) query = ""
      }) {
        Icon(
          if (searching) Icons.Default.Close else Icons.Default.Search,
          contentDescription = if (searching) "Close search" else "Search chats",
          tint = TextSecondary,
          modifier = Modifier.size(22.dp)
        )
      }
    }

    Row(
      modifier = Modifier
        .padding(bottom = 8.dp).fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(subtle)
        .clickable(onClickLabel = "Open Agents and Usage", onClick = onAgents)
        .heightIn(min = 48.dp).padding(horizontal = 14.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(androidx.compose.material.icons.Icons.Default.SmartToy, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(20.dp))
      Spacer(Modifier.width(12.dp))
      Text("Agents & usage", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
      Text("Chat · Coding · Phone", color = TextMuted, fontSize = 12.sp)
    }

    if (searching) {
      Box(
        modifier = Modifier
          .padding(bottom = 8.dp)
          .fillMaxWidth()
          .height(44.dp)
          .clip(RoundedCornerShape(22.dp))
          .background(subtle)
          .padding(horizontal = 16.dp),
        contentAlignment = Alignment.CenterStart
      ) {
        if (query.isEmpty()) Text("Search chats", color = TextMuted, fontSize = 15.sp)
        BasicTextField(
          value = query,
          onValueChange = { query = it },
          singleLine = true,
          textStyle = TextStyle(color = TextPrimary, fontSize = 15.sp),
          cursorBrush = SolidColor(CyberCyanPrimary),
          modifier = Modifier.fillMaxWidth()
        )
      }
    }

    Row(
      modifier = Modifier
        .padding(top = 2.dp, bottom = 14.dp)
        .fillMaxWidth()
        .height(46.dp)
        .clip(RoundedCornerShape(23.dp))
        .background(CyberCyanPrimary)
        .clickable { onNew() },
      horizontalArrangement = Arrangement.Center,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(Icons.Default.Add, contentDescription = null, tint = Color.White, modifier = Modifier.size(20.dp))
      Spacer(Modifier.width(6.dp))
      Text("New chat", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)
    }

    Text(
      "Recents",
      color = TextMuted,
      fontSize = 13.sp,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.padding(start = 8.dp, bottom = 6.dp)
    )

    if (shown.isEmpty()) {
      Box(Modifier.fillMaxWidth().weight(1f).padding(horizontal = 8.dp, vertical = 12.dp)) {
        Text(
          if (chats.isEmpty()) "No saved chats yet. Send a message and it shows up here."
          else "No chats match \u201c${query.trim()}\u201d.",
          color = TextMuted,
          fontSize = 14.sp,
          lineHeight = 20.sp
        )
      }
    } else {
      LazyColumn(
        modifier = Modifier.weight(1f).fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(2.dp),
        contentPadding = PaddingValues(bottom = 12.dp)
      ) {
        items(shown, key = { it.id }) { chat ->
          val selected = chat.id == currentId
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .heightIn(min = 48.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(if (selected) subtle else Color.Transparent)
              .clickable { onOpen(chat.id) }
              .padding(start = 12.dp, end = 2.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
              Icons.Outlined.ChatBubbleOutline,
              contentDescription = null,
              tint = if (selected) TextPrimary else TextMuted,
              modifier = Modifier.size(18.dp)
            )
            Spacer(Modifier.width(12.dp))
            Text(
              chat.title.ifBlank { "Untitled chat" },
              color = TextPrimary,
              fontSize = 15.sp,
              fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f)
            )
            IconButton(onClick = { onDelete(chat.id) }) {
              Icon(
                Icons.Outlined.DeleteOutline,
                contentDescription = "Delete chat",
                tint = TextMuted,
                modifier = Modifier.size(19.dp)
              )
            }
          }
        }
      }
    }
  }
}
