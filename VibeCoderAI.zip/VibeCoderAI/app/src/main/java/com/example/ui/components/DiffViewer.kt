package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DiffLine
import com.example.data.model.DiffType
import com.example.ui.theme.DiffAddedBg
import com.example.ui.theme.DiffAddedText
import com.example.ui.theme.DiffRemovedBg
import com.example.ui.theme.DiffRemovedText
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

@Composable
fun DiffViewer(
  diffLines: List<DiffLine>,
  modifier: Modifier = Modifier
) {
  val horizontalScroll = rememberScrollState()

  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .background(com.example.ui.theme.CodeBackground)
      .padding(vertical = 8.dp)
      .horizontalScroll(horizontalScroll)
  ) {
    if (diffLines.isEmpty()) {
      Text(
        text = "No diff available.",
        color = TextMuted,
        fontFamily = FontFamily.Monospace,
        fontSize = 12.sp,
        modifier = Modifier.padding(horizontal = 12.dp)
      )
    } else {
      diffLines.forEach { line ->
        val bgColor = when (line.type) {
          DiffType.ADDED -> DiffAddedBg
          DiffType.REMOVED -> DiffRemovedBg
          DiffType.UNCHANGED -> Color.Transparent
        }
        val textColor = when (line.type) {
          DiffType.ADDED -> DiffAddedText
          DiffType.REMOVED -> DiffRemovedText
          DiffType.UNCHANGED -> TextPrimary
        }
        val symbol = when (line.type) {
          DiffType.ADDED -> "+"
          DiffType.REMOVED -> "-"
          DiffType.UNCHANGED -> " "
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(bgColor)
            .padding(horizontal = 8.dp, vertical = 2.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = line.lineNumber.toString().padStart(3, ' '),
            color = TextMuted,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.width(32.dp)
          )
          Text(
            text = symbol,
            color = textColor,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.width(16.dp)
          )
          Text(
            text = line.content,
            color = textColor,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
          )
        }
      }
    }
  }
}
