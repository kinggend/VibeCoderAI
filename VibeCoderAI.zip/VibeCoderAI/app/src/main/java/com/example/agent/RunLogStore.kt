package com.example.agent

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.io.File
import java.util.UUID

/**
 * v1.7.5: the last runs (chat, coding, phone) in one small file, so the Agents screen can show them after a restart.
 * Only titles, short results and counts are kept; no files or screen contents.
 */
class RunLogStore(context: Context) {
  private val file = File(context.applicationContext.filesDir, "run_log.jsonl")
  private val lock = Any()
  private val _runs = MutableStateFlow(load())
  val runs: StateFlow<List<RunRecord>> = _runs.asStateFlow()

  private fun load(): List<RunRecord> = runCatching {
    file.takeIf { it.isFile }?.readLines().orEmpty().mapNotNull { RunRecord.fromJson(it) }
      // A run that was still WORKING when the process died is not working any more.
      .map { if (it.status == RunStatus.WORKING) it.copy(status = RunStatus.STOPPED, endedAt = it.startedAt) else it }
  }.getOrDefault(emptyList())

  private fun save(list: List<RunRecord>) {
    runCatching { file.writeText(list.joinToString("\n") { it.toJson() } + "\n") }
  }

  private fun update(change: (List<RunRecord>) -> List<RunRecord>) {
    synchronized(lock) {
      val next = change(_runs.value).sortedByDescending { it.startedAt }.take(MAX)
      _runs.value = next
      save(next)
    }
  }

  fun begin(kind: RunKind, title: String, tag: String, agent: String, remote: Boolean): String {
    val id = UUID.randomUUID().toString()
    val rec = RunRecord(id, kind, title.trim().lineSequence().firstOrNull().orEmpty().take(120), tag = tag.take(40), agent = agent,
      startedAt = System.currentTimeMillis(), remote = remote)
    update { it + rec }
    return id
  }

  fun end(id: String, status: RunStatus, result: String, steps: Int) {
    update { list ->
      list.map { if (it.id == id) it.copy(status = status, result = result.trim().take(400), steps = steps, endedAt = System.currentTimeMillis()) else it }
    }
  }

  fun archive(id: String, archived: Boolean = true) = update { l -> l.map { if (it.id == id) it.copy(archived = archived) else it } }
  fun delete(id: String) = update { l -> l.filterNot { it.id == id } }
  fun clearArchived() = update { l -> l.filterNot { it.archived } }

  private companion object { const val MAX = 100 }
}
