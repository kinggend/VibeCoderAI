package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.ui.layout.onSizeChanged
import com.example.ui.components.glassSource
import com.example.ui.components.glassSurface
import com.example.ui.components.rememberGlassState
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.offset
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.text.font.FontWeight
import com.example.ui.components.specularBrush
import com.example.ui.theme.Palette
import com.example.ui.components.rememberHaptics
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.SelfRepairEngine
import com.example.build.BuildRunner
import com.example.data.SettingsStore
import com.example.data.model.SettingsState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.withTimeoutOrNull
import com.example.llama.LlamaBridge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.tween
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.llama.LlamaEngine
import com.example.project.ProjectManager
import com.example.terminal.TerminalManager
import com.example.testing.TestRunnerEngine
import com.example.ui.screens.AgentScreen
import com.example.ui.screens.WebPreviewScreen
import com.example.ui.screens.BuildScreen
import com.example.ui.screens.ModelsScreen
import com.example.data.downloader.ModelDownloadManager
import com.example.data.local.ChatStore
import com.example.data.local.ChatSummary
import com.example.ui.screens.HistoryDrawerContent
import com.example.ui.screens.detectDrawerDrag
import com.example.ui.screens.rememberHistoryDrawerState
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.systemGestureExclusion
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import com.example.ui.screens.ProjectScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TerminalScreen
import com.example.ui.screens.TestsScreen
import com.example.ui.theme.CyberCyanContainer
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary

enum class AppDestination(val label: String, val icon: androidx.compose.ui.graphics.vector.ImageVector) {
  AGENT("Chat", Icons.Default.SmartToy),
  PROJECT("Projects", Icons.Default.Folder),
  MODELS("Models", Icons.Default.Memory),
  TERMINAL("Terminal", Icons.Default.Terminal),
  SETTINGS("Settings", Icons.Default.Settings),
  BUILD("Build", Icons.Default.Build)
}

@Composable
fun MainScreen() {
  val context = LocalContext.current

  // v1.6.2: shared instances live app-wide (AppGraph), so a running agent survives tab switches, rotation and activity recreation.
  val graph = remember { com.example.AppGraph.get(context) }
  val projectManager = graph.projectManager
  val terminalManager = graph.terminalManager
  val buildRunner = graph.buildRunner
  val selfRepairEngine = graph.selfRepairEngine
  val testRunnerEngine = graph.testRunnerEngine
  val llamaEngine = graph.llamaEngine

  val settingsStore = remember { SettingsStore(context) }
  remember { com.example.agent.Skills.init(context) }
  val scope = rememberCoroutineScope()
  var settings by remember { mutableStateOf(settingsStore.load()) }
  // v1.6: settings that live outside Compose (terminal timeout, haptics, secrets to redact from History).
  LaunchedEffect(settings.terminalTimeoutSec, settings.haptics, settings.remoteKey) {
    terminalManager.defaultTimeoutMs = com.example.terminal.TimeoutConfig.toMillis(settings.terminalTimeoutSec)
    com.example.ui.components.AppHaptics.enabled = settings.haptics
    com.example.agent.ProjectHistory.knownSecrets = withContext(Dispatchers.IO) { settingsStore.secretValues() }
  }
  // After activity recreation the model may already be loaded: start from its real state.
  var modelLoaded by remember { mutableStateOf(settings.backendMode == "remote" || llamaEngine.isReady) }
  var modelStatus by remember { mutableStateOf<String?>(if (graph.started) llamaEngine.statusMessage else "Loading model...") }
  val orchestrator = graph.orchestrator

  val downloads = remember { ModelDownloadManager.get(context, llamaEngine.modelsDir()) }
  // v1.4: chat history lives in Room (ChatRepository); old JSON chats are migrated once on first launch.
  val chatRepo = remember { com.example.data.repository.ChatRepository.get(context) }

  // Chat history: reopen the latest conversation, then persist changes (debounced) under the current chat id.
  val chatList by chatRepo.sessions.collectAsState(initial = emptyList<ChatSummary>())
  // v1.3: history is a left push drawer; its open state survives rotation.
  val drawer = rememberHistoryDrawerState()
  var showAgents by androidx.compose.runtime.saveable.rememberSaveable { androidx.compose.runtime.mutableStateOf(false) }
  LaunchedEffect(Unit) {
    // v1.6.2: restore the last chat once per process; a recreated activity keeps the live chat (and run).
    if (!graph.chatRestored) {
      graph.chatRestored = true
      runCatching { chatRepo.migrateFromFilesIfNeeded() }
        .onFailure { LlamaBridge.safeLog("Chat migration to Room failed (will retry next launch)", it) }
      runCatching { chatRepo.latestSessionId() }.getOrNull()?.let { latest ->
        val saved = runCatching { chatRepo.load(latest) }.getOrDefault(emptyList())
        orchestrator.openChat(latest, saved)
      }
    }
    orchestrator.messages.collectLatest { msgs ->
      delay(1000)
      runCatching { chatRepo.save(orchestrator.chatId, msgs) }
    }
  }

  // v1.4: memory-safe loading. When the estimate does not fit, ask: Load anyway / smaller context / Cancel.
  var memoryPrompt by remember { mutableStateOf<Pair<SettingsState, com.example.llama.MemoryEstimator.Verdict>?>(null) }

  suspend fun loadModel(s: SettingsState) {
    if (s.backendMode == "remote") {
      modelLoaded = true
      modelStatus = "Remote server: ${s.remoteUrl}"
      return
    }
    withContext(Dispatchers.IO) {
      try {
        llamaEngine.initialize(s)
      } catch (oom: OutOfMemoryError) {
        llamaEngine.unload()
        false
      }
    }
    modelLoaded = llamaEngine.isReady
    modelStatus = llamaEngine.statusMessage
    llamaEngine.lastMemoryVerdict?.let { memoryPrompt = s to it }
    llamaEngine.notice?.let { android.widget.Toast.makeText(context, it, android.widget.Toast.LENGTH_LONG).show() }
    if (modelLoaded) {
      modelStatus = "Measuring speed..."
      val bench = scope.async(Dispatchers.IO) { llamaEngine.benchmark() }
      val result = withTimeoutOrNull(60_000) { bench.await() }
      modelStatus = if (result == null) {
        llamaEngine.stopNow()
        "Speed test did not finish in 60 s, so inference is stuck or extremely slow. Native log:\n" +
          LlamaBridge.instance.debugLog()
      } else {
        result.lineSequence().firstOrNull() ?: ""
      }
    }
  }

  // v1.4: Android is critically low on memory: free the model (never mid-generation) and say so.
  LaunchedEffect(Unit) {
    com.example.llama.MemoryPressure.events.collect {
      if (!orchestrator.isGenerating.value && llamaEngine.isReady) {
        withContext(Dispatchers.IO) { llamaEngine.unload() }
        modelLoaded = false
        modelStatus = "Model unloaded because Android is low on memory. It reloads on the next message."
        android.widget.Toast.makeText(context, "Model unloaded to free memory", android.widget.Toast.LENGTH_LONG).show()
      }
    }
  }

  // Initialize projects and llama model
  LaunchedEffect(Unit) {
    com.example.build.ApkPackager.appContext = context.applicationContext
    if (graph.started) return@LaunchedEffect
    projectManager.initialize()
    graph.started = true
    // Never reload or benchmark the model under a running generation.
    if (!orchestrator.isGenerating.value) loadModel(settings)
  }

  val activeProject by projectManager.activeProject.collectAsState()

  // Header label for the chat screen: the model in use, or a graceful fallback when there is none.
  val modelLabel = remember(
    settings.backendMode, settings.remoteModel, settings.remoteUrl,
    settings.customModelPath, settings.activeModelId, modelLoaded, modelStatus
  ) {
    if (settings.backendMode == "remote") {
      // v1.2: friendly alias in the header; the full name stays on the Models screen.
      settings.remoteModel.trim().takeIf { it.isNotBlank() }?.let { com.example.ui.components.friendlyModelName(it) } ?: settings.remoteModel.trim().ifBlank {
        runCatching { java.net.URL(settings.remoteUrl).host }.getOrNull()?.takeIf { it.isNotBlank() } ?: "Remote"
      }
    } else {
      val file = llamaEngine.resolveModelFile(settings)
      if (file.isFile) {
        com.example.ui.components.friendlyModelName(file.name).ifBlank { file.name.removeSuffix(".gguf").removeSuffix(".GGUF") }
      } else {
        "No model"
      }
    }
  }

  // v1.6.2: rememberSaveable so rotation keeps the tab; the run notification's tap opens Chat.
  var currentDestination by androidx.compose.runtime.saveable.rememberSaveable { mutableStateOf(AppDestination.AGENT) }
  val openChatAt by graph.openChatRequests.collectAsState()
  LaunchedEffect(openChatAt) { if (openChatAt > 0L) currentDestination = AppDestination.AGENT }
  // v1.4: "Insert" on a chat code block switches to the Projects editor, which consumes the request.
  val editorRequest by com.example.project.EditorBridge.requests.collectAsState()
  LaunchedEffect(editorRequest?.id) {
    if (editorRequest != null) currentDestination = AppDestination.PROJECT
  }
  LaunchedEffect(activeProject?.rootPath) { com.example.project.EditorBridge.projectRoot = activeProject?.rootPath }
  var isViewingTests by remember { mutableStateOf(false) }
  var pushProject by remember { mutableStateOf<com.example.data.model.Project?>(null) }
  pushProject?.let { p -> com.example.ui.screens.GitHubPushDialog(p) { pushProject = null } }
  var isPreviewing by remember { mutableStateOf(false) }

  BackHandler(enabled = drawer.isOpen || isPreviewing || isViewingTests || currentDestination != AppDestination.AGENT) {
    if (drawer.isOpen) {
      drawer.close()
    } else if (isPreviewing) {
      isPreviewing = false
    } else if (isViewingTests) {
      isViewingTests = false
    } else {
      currentDestination = AppDestination.AGENT
    }
  }

  val glass = rememberGlassState()
  val density = androidx.compose.ui.platform.LocalDensity.current
  // Derived so the screen does not recompose on every frame of the keyboard animation.
  val imeInsets = WindowInsets.ime
  val imeOpen by remember { androidx.compose.runtime.derivedStateOf { imeInsets.getBottom(density) > 0 } }
  val generating by orchestrator.isGenerating.collectAsState()
  // v1.6.2: the background-run notification (progress, Stop, "Needs your approval") needs this on Android 13+.
  // Asked once, the first time a run starts; runs work without it, the notification is just hidden.
  val notifAsk = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
  ) { granted ->
    if (!granted) android.widget.Toast.makeText(context, "Runs still continue in the background, but without a progress notification.", android.widget.Toast.LENGTH_LONG).show()
  }
  LaunchedEffect(generating) {
    if (!generating || android.os.Build.VERSION.SDK_INT < 33) return@LaunchedEffect
    val granted = androidx.core.content.ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) ==
      android.content.pm.PackageManager.PERMISSION_GRANTED
    val prefs = context.getSharedPreferences("vibecoder_ui", android.content.Context.MODE_PRIVATE)
    if (!granted && !prefs.getBoolean("asked_run_notifications", false)) {
      prefs.edit().putBoolean("asked_run_notifications", true).apply()
      notifAsk.launch(android.Manifest.permission.POST_NOTIFICATIONS)
    }
  }
  // v1.4: agent approvals (file overwrites/edits/deletes, commands) show on every tab, not only Chat.
  val approvalRequest by orchestrator.approvals.pending.collectAsState()
  androidx.compose.runtime.CompositionLocalProvider(com.example.ui.components.LocalGlassState provides glass) {
  // v1.6: an agent command waiting for keyboard input asks here (never auto-answered).
  val inputRequest by orchestrator.inputs.pending.collectAsState()
  inputRequest?.let { req ->
    com.example.ui.screens.InputRequestDialog(req) { a -> orchestrator.inputs.answer(req.id, a) }
  }
  approvalRequest?.let { req ->
    com.example.ui.components.AgentApprovalDialog(
      request = req,
      onApprove = { orchestrator.approvals.resolve(req.id, true) },
      onReject = { orchestrator.approvals.resolve(req.id, false) }
    )
  }
  memoryPrompt?.let { (s, v) ->
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { memoryPrompt = null },
      title = { Text("Not enough free memory") },
      text = {
        Text(
          "This model with a ${s.contextLength}-token context needs about ${v.neededBytes / 1048576} MB, " +
            "but only ${v.availableBytes / 1048576} MB is free. Loading anyway may make Android close the app." +
            (v.suggestedContext?.let { "\n\nA $it-token context should fit." } ?: "")
        )
      },
      confirmButton = {
        Row {
          v.suggestedContext?.let { ctx ->
            androidx.compose.material3.TextButton(onClick = {
              memoryPrompt = null
              val updated = s.copy(contextLength = ctx)
              settings = updated
              settingsStore.save(updated)
              modelStatus = "Loading model..."
              scope.launch { loadModel(updated) }
            }) { Text("Use $ctx") }
          }
          androidx.compose.material3.TextButton(onClick = {
            memoryPrompt = null
            llamaEngine.allowLowMemoryLoad(s)
            modelStatus = "Loading model..."
            scope.launch { loadModel(s) }
          }) { Text("Load anyway") }
        }
      },
      dismissButton = {
        androidx.compose.material3.TextButton(onClick = { memoryPrompt = null }) { Text("Cancel") }
      }
    )
  }
  // The model cannot run (not enough RAM, engine error): the agent has already stopped. Tapping outside or Back
  // does not close this; the user picks what to do. More retries cannot add memory.
  val halt by orchestrator.halt.collectAsState()
  halt?.let { h ->
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = {},
      properties = androidx.compose.ui.window.DialogProperties(dismissOnBackPress = false, dismissOnClickOutside = false),
      title = { Text(h.title) },
      text = {
        androidx.compose.foundation.layout.Column {
          Text(h.message)
          if (h.kind == com.example.agent.EngineHalt.Kind.MEMORY && h.neededMb > 0) {
            androidx.compose.foundation.layout.Spacer(Modifier.height(14.dp))
            com.example.ui.components.RamBar(h.neededMb, h.availableMb)
          }
        }
      },
      confirmButton = {
        Row {
          h.suggestedContext?.let { ctx ->
            androidx.compose.material3.TextButton(onClick = {
              orchestrator.clearHalt()
              val updated = settings.copy(contextLength = ctx)
              settings = updated
              settingsStore.save(updated)
              modelStatus = "Loading model..."
              scope.launch { loadModel(updated) }
            }) { Text("Use $ctx context") }
          }
          androidx.compose.material3.TextButton(onClick = {
            orchestrator.clearHalt()
            currentDestination = AppDestination.MODELS
          }) { Text("Choose a smaller model") }
        }
      },
      dismissButton = {
        androidx.compose.material3.TextButton(onClick = { orchestrator.clearHalt() }) { Text("Not now") }
      }
    )
  }
  }
  LaunchedEffect(generating, imeOpen) { com.example.ui.theme.ThemeController.busy = generating || imeOpen }
  val showBar = !isViewingTests && !isPreviewing && !imeOpen
  var barHeight by remember { mutableStateOf(0.dp) }
  val inset = if (showBar) barHeight else 0.dp

  // v1.2.1: popups (separate windows) read the main glass layer for a real backdrop blur.
  androidx.compose.runtime.CompositionLocalProvider(com.example.ui.components.LocalGlassState provides glass) {
  // v1.3 history drawer geometry. The drawer and the pushed screen read drawer.progress only inside
  // graphicsLayer lambdas, so opening/closing/dragging never recomposes the screen.
  val screenWidthDp = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp
  val drawerWidth = minOf(screenWidthDp * 0.82f, 340f).dp
  val drawerWidthPx = with(density) { drawerWidth.toPx() }
  drawer.widthPx = drawerWidthPx
  drawer.flingPx = with(density) { 400.dp.toPx() }
  val edgePx = with(density) { 24.dp.toPx() }
  val exclusionBandPx = with(density) { 200.dp.toPx() }
  // Edge swipe opens history only on the Chat screen, never over sub-screens, and never from the dock area.
  val edgeEnabled = currentDestination == AppDestination.AGENT && !isPreviewing && !isViewingTests && !drawer.isOpen
  val edgeEnabledNow by androidx.compose.runtime.rememberUpdatedState(edgeEnabled)
  val dockTopFromBottomPx by androidx.compose.runtime.rememberUpdatedState(
    with(density) { (if (showBar) barHeight else 0.dp).toPx() }
  )
  val screenBg = MaterialTheme.colorScheme.background
  // Opening the drawer (button or edge swipe) drops the keyboard so the composer does not ride along.
  val keyboard = androidx.compose.ui.platform.LocalSoftwareKeyboardController.current
  val focusManager = androidx.compose.ui.platform.LocalFocusManager.current
  LaunchedEffect(drawer.visible) {
    if (drawer.visible) {
      focusManager.clearFocus()
      keyboard?.hide()
    }
  }

  Box(
    modifier = Modifier
      .fillMaxSize()
      .background(screenBg)
  ) {
    if (drawer.visible) {
      HistoryDrawerContent(
        chats = chatList,
        currentId = orchestrator.chatId,
        onOpen = { id ->
          scope.launch {
            val msgs = runCatching { chatRepo.load(id) }.getOrDefault(emptyList())
            orchestrator.openChat(id, msgs)
            currentDestination = AppDestination.AGENT
            drawer.close()
          }
        },
        onDelete = { id ->
          scope.launch {
            runCatching { chatRepo.delete(id) }
            if (id == orchestrator.chatId) orchestrator.newChat()
          }
        },
        onNew = {
          orchestrator.newChat()
          currentDestination = AppDestination.AGENT
          drawer.close()
        },
        onAgents = { showAgents = true; drawer.close() },
        modifier = Modifier
          .width(drawerWidth)
          .graphicsLayer { translationX = (drawer.progress.value - 1f) * drawerWidthPx }
          .pointerInput(drawer) { detectDrawerDrag(drawer, direction = -1) }
      )
    }
    // Whole app (header, chat, composer, dock) is pushed right with the drawer.
    Box(
      modifier = Modifier
        .fillMaxSize()
        .graphicsLayer {
          val p = drawer.progress.value
          translationX = p * drawerWidthPx
          val s = 1f - 0.02f * p
          scaleX = s
          scaleY = s
        }
        .background(screenBg)
        .then(
          if (edgeEnabled) Modifier.systemGestureExclusion { c ->
            // Android honours at most 200dp of exclusion per edge: keep the back gesture elsewhere.
            val top = (c.size.height - exclusionBandPx) / 2f
            androidx.compose.ui.geometry.Rect(0f, top, edgePx, top + exclusionBandPx)
          } else Modifier
        )
        .pointerInput(drawer) {
          detectDrawerDrag(
            drawer,
            direction = 1,
            startAllowed = { pos ->
              edgeEnabledNow && pos.x <= edgePx && pos.y < size.height - dockTopFromBottomPx
            }
          )
        }
    ) {
  Box(
    modifier = Modifier
      .fillMaxSize()
      .statusBarsPadding()
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .glassSource(glass, MaterialTheme.colorScheme.background)
    ) {
      val previewProject = activeProject
      // v1.2: sub-screens (web preview, tests) fade in and out instead of popping.
      val overlay = when {
        isPreviewing && previewProject != null -> 2
        isViewingTests -> 1
        else -> 0
      }
      AnimatedContent(
        targetState = overlay,
        transitionSpec = { fadeIn(tween(200, delayMillis = 30)) togetherWith fadeOut(tween(140)) },
        label = "subScreen"
      ) { shownOverlay ->
      if (shownOverlay == 2 && previewProject != null) {
        WebPreviewScreen(
          project = previewProject,
          onBack = { isPreviewing = false },
          onFixErrors = { errors ->
            isPreviewing = false
            currentDestination = AppDestination.AGENT
            orchestrator.sendMessage(
              "Fix these JavaScript errors in the app. Output only the files that change.\n$errors",
              previewProject,
              settings
            )
          }
        )
      } else if (shownOverlay == 1) {
        TestsScreen(
          testRunnerEngine = testRunnerEngine,
          activeProject = activeProject,
          onBack = { isViewingTests = false }
        )
      } else {
        // v1.6: on wide screens Chat and Projects are one side-by-side screen, so switching between them does not animate or reset.
        val wideScreen = androidx.compose.ui.platform.LocalConfiguration.current.screenWidthDp >= 840
        AnimatedContent(
          targetState = if (wideScreen && currentDestination == AppDestination.PROJECT) AppDestination.AGENT else currentDestination,
          transitionSpec = {
            // Fade plus a slight slide in the direction of the tab that was picked.
            val dir = if (targetState.ordinal >= initialState.ordinal) 1 else -1
            (fadeIn(tween(220, delayMillis = 40)) +
              androidx.compose.animation.slideInHorizontally(tween(260)) { w -> dir * w / 14 }) togetherWith
              (fadeOut(tween(120)) +
                androidx.compose.animation.slideOutHorizontally(tween(200)) { w -> -dir * w / 18 })
          },
          label = "screen"
        ) { dest ->
        when (dest) {
          AppDestination.AGENT, AppDestination.PROJECT -> androidx.compose.foundation.layout.BoxWithConstraints(Modifier.fillMaxSize()) {
          // v1.6 tablets / unfolded foldables (>= 840 dp): Projects (explorer + editor) and Chat side by side.
          val wide = maxWidth >= 840.dp
          val showChat = wide || dest == AppDestination.AGENT
          val showProject = wide || dest == AppDestination.PROJECT
          Row(Modifier.fillMaxSize()) {
          if (showProject) Box(Modifier.weight(if (wide) 0.58f else 1f)) {
            val agentBusy by orchestrator.isGenerating.collectAsState()
            ProjectScreen(
              projectManager = projectManager,
              modifier = Modifier.padding(bottom = inset),
              agentBusy = agentBusy,
              autocomplete = settings.editorAutocomplete,
              onPushToGitHub = { pushProject = activeProject }
            )
          }
          if (wide) Box(Modifier.width(1.dp).fillMaxSize().background(com.example.ui.theme.ObsidianBorder))
          if (showChat) Box(Modifier.weight(if (wide) 0.42f else 1f)) {
            AgentScreen(
              orchestrator = orchestrator,
              projectManager = projectManager,
              activeProject = activeProject,
              settings = settings,
              onPreview = { isPreviewing = true },
              onOpenBuild = { currentDestination = AppDestination.BUILD },
              onOpenHistory = { drawer.open() },
              onSettingsChange = {
                settings = it
                settingsStore.save(it)
              },
              bottomInset = inset,
              modelName = modelLabel
            )
          }
          }
          }
          AppDestination.MODELS -> {
            ModelsScreen(
              modelsDir = llamaEngine.modelsDir(),
              currentPath = settings.customModelPath,
              modelLoaded = modelLoaded,
              modelStatus = modelStatus,
              downloads = downloads,
              bottomInset = inset,
              onSelectModel = { path ->
                val updated = settings.copy(customModelPath = path)
                settings = updated
                settingsStore.save(updated)
                modelLoaded = false
                modelStatus = "Loading model..."
                scope.launch { loadModel(updated) }
              },
              onBenchmark = { llamaEngine.benchmark() },
              memory = remember(settings.customModelPath, settings.activeModelId, settings.backendMode, modelLoaded) { llamaEngine.modelMemory(settings) },
              settings = settings,
              onUpdateSettings = {
                settings = it
                settingsStore.save(it)
              },
              onUnload = {
                scope.launch {
                  withContext(Dispatchers.IO) { llamaEngine.unload() }
                  modelLoaded = false
                  modelStatus = llamaEngine.statusMessage
                }
              }
            )
          }
          AppDestination.TERMINAL -> {
            TerminalScreen(
              terminalManager = terminalManager,
              activeProject = activeProject,
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.BUILD -> {
            BuildScreen(
              buildRunner = buildRunner,
              selfRepairEngine = selfRepairEngine,
              activeProject = activeProject,
              onNavigateToAgent = { currentDestination = AppDestination.AGENT },
              modifier = Modifier.padding(bottom = inset)
            )
          }
          AppDestination.SETTINGS -> {
            SettingsScreen(
              settings = settings,
              onUpdateSettings = { raw ->
                // A context window that exceeds free RAM falls back to a safe size, with a message.
                val mem = if (raw.contextLength != settings.contextLength) llamaEngine.modelMemory(raw) else null
                val g = mem?.let { com.example.llama.MemoryEstimator.guard(it.fileBytes, maxOf(raw.contextLength, it.minContext), it.freeBytes) }
                val it = if (g != null && g.lowered && g.contextTokens < raw.contextLength) {
                  android.widget.Toast.makeText(
                    context,
                    "${raw.contextLength} tokens needs about ${g.neededBytes / 1048576} MB, more than the free RAM. Using ${g.contextTokens}.",
                    android.widget.Toast.LENGTH_LONG
                  ).show()
                  raw.copy(contextLength = g.contextTokens)
                } else raw
                settings = it
                settingsStore.save(it)
                com.example.ui.theme.ThemeController.mode = it.themeMode
                com.example.ui.theme.ThemeController.blur = it.glassBlur
                com.example.ui.theme.ThemeController.blurRadiusDp = it.blurRadiusDp
                com.example.ui.theme.ThemeController.accent = it.accent
              },
              onOpenTestRunner = { isViewingTests = true },
              onClearChat = { orchestrator.newChat() },
              bottomInset = inset
            )
          }
        }
        }
      }
      }
    }

    if (showBar) {
      // Fade under the dock so scrolled content never fights the glass (replaces blur when it is off).
      if (!com.example.ui.theme.ThemeController.blurActive) {
        Box(
          modifier = Modifier
            .align(Alignment.BottomCenter)
            .fillMaxWidth()
            .height(barHeight + 28.dp)
            .background(
              androidx.compose.ui.graphics.Brush.verticalGradient(
                listOf(Color.Transparent, MaterialTheme.colorScheme.background.copy(alpha = 0.92f))
              )
            )
        )
      }
      GlassDock(
        glass = glass,
        tabs = AppDestination.values().filter { it != AppDestination.BUILD },
        selected = currentDestination,
        onSelect = { currentDestination = it },
        agentRunning = generating,
        modifier = Modifier
          .align(Alignment.BottomCenter)
          .onSizeChanged { barHeight = with(density) { it.height.toDp() } }
          .navigationBarsPadding()
          .padding(horizontal = 16.dp, vertical = 8.dp)
      )
    }

  }
    // Scrim over the pushed screen: fades 0 -> 45% black, tap or drag left to close.
    if (drawer.visible) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .graphicsLayer { alpha = drawer.progress.value }
          .background(Color.Black.copy(alpha = 0.45f))
          .then(
            if (drawer.isOpen) Modifier.pointerInput(drawer) {
              detectDrawerDrag(drawer, direction = -1, onTap = { drawer.close() })
            } else Modifier
          )
      )
    }
    }
  
    // v1.7.5: Agents / Usage slides over everything (including the dock).
    androidx.compose.animation.AnimatedVisibility(
      visible = showAgents,
      enter = androidx.compose.animation.slideInHorizontally(tween(320, easing = androidx.compose.animation.core.FastOutSlowInEasing)) { it } + fadeIn(tween(220)),
      exit = androidx.compose.animation.slideOutHorizontally(tween(260, easing = androidx.compose.animation.core.FastOutSlowInEasing)) { it } + fadeOut(tween(160))
    ) {
      val runList by graph.runLog.runs.collectAsState()
      val live by graph.orchestrator.runs.state.collectAsState()
      val usage by chatRepo.usageTotals.collectAsState(initial = null)
      androidx.activity.compose.BackHandler { showAgents = false }
      com.example.ui.screens.AgentsScreen(
        runs = runList, live = live, usage = usage,
        onBack = { showAgents = false },
        onArchive = { id, a -> graph.runLog.archive(id, a) },
        onDelete = { id -> graph.runLog.delete(id) },
        onClearArchived = { graph.runLog.clearArchived() }
      )
    }
  }
  }
}

/**
 * iOS 26 style floating dock: blurred glass pill with a "liquid" lens.
 * v1.3: at rest the selected tab sits in a soft inset pill. While a finger is down the lens lifts: it
 * grows ~1.32x, overflows the dock (drawn in an unclipped sibling overlay above the clipped glass), turns
 * into clear glass with a bright specular rim, and the tab under it is magnified. v1.1.1 logic is kept:
 * tap selects on touch-down; a drag moves only the lens/highlight and switches the screen once on release.
 * All motion values (lens x, lift) are read only in draw / graphicsLayer lambdas: no per-frame recomposition.
 */
@Composable
private fun GlassDock(
  glass: com.example.ui.components.GlassState,
  tabs: List<AppDestination>,
  selected: AppDestination,
  onSelect: (AppDestination) -> Unit,
  modifier: Modifier = Modifier,
  /** v1.6.2: a run is going; the Chat tab shows a dot while another tab is open. */
  agentRunning: Boolean = false
) {
  val shape = RoundedCornerShape(36.dp)
  val haptics = rememberHaptics()
  val density = androidx.compose.ui.platform.LocalDensity.current
  val padPx = with(density) { 6.dp.toPx() }
  // The dock's content area starts 1dp in (border + padding(1.dp)); the overlay uses outer coordinates.
  val rimInsetPx = with(density) { 1.dp.toPx() }
  var widthPx by remember { mutableStateOf(0) }
  val itemW = if (widthPx > 0 && tabs.isNotEmpty()) (widthPx - 2 * padPx) / tabs.size else 0f
  val index = tabs.indexOf(selected).coerceAtLeast(0)
  val offset = remember { androidx.compose.animation.core.Animatable(0f) }
  // 0 = resting inset pill, 1 = lifted clear-glass lens (finger down).
  val lift = remember { androidx.compose.animation.core.Animatable(0f) }
  var placed by remember { mutableStateOf(false) }
  val scope = rememberCoroutineScope()
  var dragging by remember { mutableStateOf(false) }
  var pressed by remember { mutableStateOf(false) }
  var hoverIndex by remember { mutableStateOf(-1) }
  val shownIndex = if (dragging && hoverIndex >= 0) hoverIndex else index
  val lensOverIndex = if (pressed) (if (hoverIndex >= 0) hoverIndex else index) else -1
  val settleSpring = androidx.compose.animation.core.spring<Float>(dampingRatio = 0.72f, stiffness = 420f)
  val followSpring = androidx.compose.animation.core.spring<Float>(dampingRatio = 0.7f, stiffness = 700f)
  LaunchedEffect(index, itemW) {
    if (itemW <= 0f || dragging) return@LaunchedEffect
    val target = index * itemW
    if (!placed) {
      offset.snapTo(target)
      placed = true
    } else {
      offset.animateTo(target, settleSpring)
    }
  }
  val dark = Palette.dark
  val rim = specularBrush()
  // Resting pill: soft translucent inset with a hairline rim.
  val restFill = if (dark) Color.White.copy(alpha = 0.12f) else Color.White.copy(alpha = 0.55f)
  val restRim = if (dark) Color.White.copy(alpha = 0.16f) else Color.Black.copy(alpha = 0.06f)
  // Lifted lens: almost clear glass.
  val lensFill = if (dark) Color.White.copy(alpha = 0.07f) else Color.White.copy(alpha = 0.22f)
  val lensRimTop = Color.White.copy(alpha = if (dark) 0.45f else 0.95f)
  val lensRimBottom = Color.White.copy(alpha = if (dark) 0.10f else 0.35f)
  val lensOuterLine = if (dark) Color.Black.copy(alpha = 0.35f) else Color.Black.copy(alpha = 0.10f)
  val shadowColor = Color.Black.copy(alpha = if (dark) 0.22f else 0.08f)
  val currentIndex by androidx.compose.runtime.rememberUpdatedState(index)
  val currentSelect by androidx.compose.runtime.rememberUpdatedState(onSelect)

  /** Horizontal stretch from lens speed (0 at rest, up to ~0.22 on a fast swipe). */
  fun stretch(): Float =
    if (itemW <= 0f) 0f else (kotlin.math.abs(offset.velocity) / (itemW * 12f)).coerceIn(0f, 0.22f)

  Box(modifier = modifier) {
    Box(
      modifier = Modifier
        .shadow(28.dp, shape, clip = false, ambientColor = Color.Black.copy(alpha = 0.55f), spotColor = Color.Black.copy(alpha = 0.55f))
        .glassSurface(
          glass, shape,
          if (dark) Color.White.copy(alpha = 0.05f) else Color.White.copy(alpha = 0.38f),
          // v1.5: user blur radius (Settings > Appearance), 10 to 40 dp.
          blurRadiusPx = with(androidx.compose.ui.platform.LocalDensity.current) { com.example.ui.theme.ThemeController.blurRadiusDp.dp.toPx() }
        )
        .background(
          androidx.compose.ui.graphics.Brush.verticalGradient(
            0f to Color.White.copy(alpha = if (dark) 0.16f else 0.55f),
            0.5f to Color.Transparent,
            1f to Color.White.copy(alpha = if (dark) 0.05f else 0.18f)
          )
        )
        .border(1.dp, rim, shape)
        .padding(1.dp)
        .border(0.5.dp, androidx.compose.ui.graphics.Brush.verticalGradient(listOf(Color.White.copy(alpha = if (dark) 0.28f else 0.95f), Color.Transparent)), shape)
        .onSizeChanged { widthPx = it.width }
        .drawBehind {
          // Resting inset pill (fades out as the lens lifts; the lifted lens is drawn in the overlay).
          val l = lift.value
          val a = 1f - l
          if (itemW > 0f && a > 0.01f) {
            val st = stretch()
            val s = 1f + 0.3f * l
            val h = (size.height - 2 * padPx) * s
            val w = itemW * s * (1f + st)
            val cx = padPx + offset.value + itemW / 2f
            val topLeft = androidx.compose.ui.geometry.Offset(cx - w / 2f, size.height / 2f - h / 2f)
            val sz = androidx.compose.ui.geometry.Size(w, h)
            val corner = androidx.compose.ui.geometry.CornerRadius(h / 2f)
            drawRoundRect(restFill, topLeft, sz, corner, alpha = a)
            drawRoundRect(restRim, topLeft, sz, corner, style = androidx.compose.ui.graphics.drawscope.Stroke(0.75.dp.toPx()), alpha = a)
          }
        }
        // One gesture for tap and drag: the tab under the finger is selected the moment it touches down,
        // so a plain press works with no movement, and sliding the finger still moves the lens.
        .pointerInput(tabs, itemW) {
          if (itemW > 0f && tabs.isNotEmpty()) {
            awaitEachGesture {
              fun indexAt(x: Float): Int = ((x - padPx) / itemW).toInt().coerceIn(0, tabs.lastIndex)
              val down = awaitFirstDown(requireUnconsumed = false)
              // A plain tap still selects the moment the finger touches down.
              val first = indexAt(down.position.x)
              if (first != currentIndex) {
                haptics.tick()
                currentSelect(tabs[first])
              }
              down.consume()
              pressed = true
              hoverIndex = first
              scope.launch {
                lift.animateTo(1f, androidx.compose.animation.core.spring(dampingRatio = 0.6f, stiffness = 520f))
              }
              val slop = viewConfiguration.touchSlop
              var hover = first
              var dragged = false
              var completed = false
              try {
                while (true) {
                  val event = awaitPointerEvent()
                  val change = event.changes.firstOrNull() ?: break
                  if (!dragged && kotlin.math.abs(change.position.x - down.position.x) > slop) {
                    dragged = true
                    hoverIndex = hover
                    dragging = true
                  }
                  if (dragged) {
                    val lensX = (change.position.x - padPx - itemW / 2f).coerceIn(0f, tabs.lastIndex * itemW)
                    // Springy follow that keeps up with the finger and keeps its velocity for the stretch.
                    scope.launch { offset.animateTo(lensX, followSpring) }
                    val i = indexAt(change.position.x)
                    if (i != hover) {
                      hover = i
                      hoverIndex = i
                      haptics.tick()
                    }
                  }
                  change.consume()
                  if (!change.pressed) break
                }
                completed = true
              } finally {
                pressed = false
                hoverIndex = -1
                if (dragged) {
                  dragging = false
                  if (completed && hover != currentIndex) {
                    // Lens shrinks back to the resting pill at the new tab (LaunchedEffect), screen switches once.
                    currentSelect(tabs[hover])
                  } else {
                    scope.launch { offset.animateTo(currentIndex * itemW, settleSpring) }
                  }
                  scope.launch {
                    lift.animateTo(0f, androidx.compose.animation.core.spring(dampingRatio = 0.7f, stiffness = 500f))
                  }
                } else {
                  // Tap: make sure the lift is visible, then settle back (~250 ms in total).
                  scope.launch {
                    if (completed && lift.value < 0.85f) lift.animateTo(1f, tween(90))
                    lift.animateTo(0f, androidx.compose.animation.core.spring(dampingRatio = 0.75f, stiffness = 600f))
                  }
                }
              }
            }
          }
        }
        .padding(6.dp)
    ) {
      Row(horizontalArrangement = Arrangement.SpaceEvenly) {
        tabs.forEachIndexed { i, destination ->
          TabItem(
            destination = destination,
            selected = i == shownIndex,
            lensOver = i == lensOverIndex,
            running = agentRunning && destination == AppDestination.AGENT && i != shownIndex,
            magnify = {
              if (itemW <= 0f) 0f
              else lift.value * (1f - kotlin.math.abs(offset.value - i * itemW) / itemW).coerceIn(0f, 1f)
            },
            modifier = Modifier.weight(1f)
          )
        }
      }
    }
    // Lifted lens overlay: a sibling above the glass with no clip, so the lens can overflow the dock.
    Box(
      modifier = Modifier
        .matchParentSize()
        .drawBehind {
          val l = lift.value
          if (itemW <= 0f || l <= 0.01f) return@drawBehind
          val a = (l * 1.5f).coerceAtMost(1f)
          val st = stretch()
          val s = 1f + 0.32f * l
          val baseH = size.height - 2 * rimInsetPx - 2 * padPx
          val h = baseH * s * (1f - 0.3f * st)
          val w = itemW * s * (1f + st)
          val cx = rimInsetPx + padPx + offset.value + itemW / 2f
          val cy = size.height / 2f
          val left = cx - w / 2f
          val top = cy - h / 2f
          val corner = androidx.compose.ui.geometry.CornerRadius(h / 2f)
          val sz = androidx.compose.ui.geometry.Size(w, h)
          // Soft outer shadow (a few stacked translucent rounded rects, no blur pass).
          for (k in 1..3) {
            val grow = k * 1.6.dp.toPx()
            drawRoundRect(
              shadowColor,
              androidx.compose.ui.geometry.Offset(left - grow, top - grow + 1.5.dp.toPx()),
              androidx.compose.ui.geometry.Size(w + 2 * grow, h + 2 * grow),
              androidx.compose.ui.geometry.CornerRadius(h / 2f + grow),
              alpha = a * (0.5f / k)
            )
          }
          val tl = androidx.compose.ui.geometry.Offset(left, top)
          drawRoundRect(lensFill, tl, sz, corner, alpha = a)
          // Inner highlight at the top.
          drawRoundRect(
            androidx.compose.ui.graphics.Brush.verticalGradient(
              0f to Color.White.copy(alpha = if (dark) 0.20f else 0.55f),
              0.45f to Color.Transparent,
              startY = top,
              endY = top + h
            ),
            tl, sz, corner, alpha = a
          )
          // Hairline outer edge so the rim reads on light glass too.
          drawRoundRect(lensOuterLine, tl, sz, corner, style = androidx.compose.ui.graphics.drawscope.Stroke(0.5.dp.toPx()), alpha = a)
          // Bright specular rim: top ~45% white fading to ~10% at the bottom.
          val rimW = 1.25.dp.toPx()
          drawRoundRect(
            androidx.compose.ui.graphics.Brush.verticalGradient(
              listOf(lensRimTop, lensRimBottom),
              startY = top,
              endY = top + h
            ),
            androidx.compose.ui.geometry.Offset(left + rimW / 2f, top + rimW / 2f),
            androidx.compose.ui.geometry.Size(w - rimW, h - rimW),
            androidx.compose.ui.geometry.CornerRadius((h - rimW) / 2f),
            style = androidx.compose.ui.graphics.drawscope.Stroke(rimW),
            alpha = a
          )
        }
    )
  }
}

@Composable
private fun TabItem(
  destination: AppDestination,
  selected: Boolean,
  lensOver: Boolean = false,
  magnify: () -> Float = { 0f },
  modifier: Modifier = Modifier,
  running: Boolean = false
) {
  // Inactive tabs use the full-strength secondary label colour (v1.2: raised from 0.92 alpha) so they stay legible on glass.
  // v1.3: the tab under the lifted lens turns bright (white in dark mode) and bold.
  val lensTint = if (Palette.dark) Color.White else TextPrimary
  val tint by animateColorAsState(
    when {
      lensOver -> lensTint
      selected -> CyberCyanPrimary
      else -> androidx.compose.ui.graphics.lerp(com.example.ui.theme.TextSecondary, TextPrimary, 0.3f)
    },
    animationSpec = tween(if (lensOver) 120 else 220),
    label = "tabTint"
  )
  val glowAlpha by androidx.compose.animation.core.animateFloatAsState(
    if (selected) 1f else 0f, animationSpec = tween(260), label = "tabGlow"
  )
  val iconScale by androidx.compose.animation.core.animateFloatAsState(
    if (selected) 1.08f else 1f,
    animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.55f, stiffness = 420f),
    label = "tabScale"
  )
  val lift by androidx.compose.animation.core.animateDpAsState(
    if (selected) (-1).dp else 0.dp, animationSpec = tween(220), label = "tabLift"
  )
  val glow = CyberCyanPrimary
  Column(
    modifier = modifier
      // v1.3: icon + label under the lifted lens magnify (up to 1.2x, by overlap); graphicsLayer only.
      .graphicsLayer {
        val m = 1f + 0.2f * magnify()
        scaleX = m
        scaleY = m
      }
      .clip(RoundedCornerShape(26.dp))
      .height(54.dp)
      .padding(vertical = 4.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    Box(
      modifier = Modifier
        .size(width = 44.dp, height = 28.dp)
        .offset(y = lift)
        .drawBehind {
          if (glowAlpha > 0f) {
            drawCircle(
              brush = androidx.compose.ui.graphics.Brush.radialGradient(
                listOf(glow.copy(alpha = 0.42f * glowAlpha), Color.Transparent),
                center = center,
                radius = size.minDimension * 0.95f
              ),
              radius = size.minDimension * 0.95f,
              center = center
            )
          }
        },
      contentAlignment = Alignment.Center
    ) {
      Icon(
        imageVector = destination.icon,
        contentDescription = if (running) "${destination.label}, agent running" else destination.label,
        tint = tint,
        modifier = Modifier
          .size(24.dp)
          .graphicsLayer {
            scaleX = iconScale
            scaleY = iconScale
          }
      )
      // v1.6.2: running dot (accent, with a background-coloured ring so it reads on glass in both themes).
      androidx.compose.animation.AnimatedVisibility(
        visible = running,
        enter = androidx.compose.animation.scaleIn(tween(160)) + fadeIn(tween(160)),
        exit = androidx.compose.animation.scaleOut(tween(120)) + fadeOut(tween(120)),
        modifier = Modifier.align(Alignment.TopEnd)
      ) {
        Box(
          Modifier
            .size(10.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(MaterialTheme.colorScheme.background)
            .padding(2.dp)
            .clip(androidx.compose.foundation.shape.CircleShape)
            .background(CyberCyanPrimary)
        )
      }
    }
    Spacer(Modifier.height(2.dp))
    Text(
      destination.label,
      color = tint,
      fontSize = 10.5.sp,
      lineHeight = 13.sp,
      maxLines = 1,
      fontWeight = if (selected || lensOver) FontWeight.SemiBold else FontWeight.Medium,
      modifier = Modifier.offset(y = lift)
    )
  }
}
