package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.runtime.getValue
import androidx.compose.animation.core.animateFloat
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceSolid
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/** Flat, modern card used across the Models page (no shadows or glass layers, so it scrolls smoothly). */
@Composable
internal fun ModelSurface(
  modifier: Modifier = Modifier,
  borderColor: Color = ObsidianBorder,
  dimmed: Boolean = false,
  content: @Composable ColumnScope.() -> Unit
) {
  val shape = com.example.ui.theme.UiTokens.CardShape
  val dark = com.example.ui.theme.Palette.dark
  // v1.2: unselected cards sit a step darker with a faint 1 dp rim so the selected (blue) card stands out.
  val dimOverlay = if (dark) Color.Black.copy(alpha = 0.22f) else Color.Black.copy(alpha = 0.035f)
  val dimBorder = if (dark) Color.White.copy(alpha = 0.08f) else Color.Black.copy(alpha = 0.08f)
  Column(
    modifier = modifier
      .fillMaxWidth()
      .clip(shape)
      .background(ObsidianSurfaceSolid)
      .then(if (dimmed) Modifier.background(dimOverlay).border(1.dp, dimBorder, shape) else Modifier)
      .then(
        if (dimmed) Modifier
        else Modifier.border(if (borderColor == ObsidianBorder) 0.5.dp else 1.5.dp, borderColor, shape)
      )
      .padding(16.dp),
    content = content
  )
}

@Composable
internal fun ModelSection(title: String, subtitle: String? = null, content: @Composable ColumnScope.() -> Unit) {
  Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
    Column(modifier = Modifier.padding(horizontal = 4.dp)) {
      Text(title, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
      if (subtitle != null) Text(
        subtitle, color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight
      )
    }
    content()
  }
}

@Composable
internal fun Chip(text: String, color: Color = TextSecondary, background: Color = ObsidianSurfaceVariant) {
  Box(
    modifier = Modifier
      .clip(CircleShape)
      .background(background)
      .padding(horizontal = 10.dp, vertical = 4.dp)
  ) { Text(text, color = color, fontSize = 12.sp, fontWeight = FontWeight.Medium) }
}

/**
 * Rounded action button. [primary] = filled accent with a soft accent shadow (the main action of a card);
 * otherwise an outlined/tonal secondary style so the two are clearly different at a glance.
 */
@Composable
internal fun PillButton(
  text: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  primary: Boolean = false,
  enabled: Boolean = true,
  destructive: Boolean = false
) {
  val accent = if (destructive) com.example.ui.theme.CyberCoralError else CyberCyanPrimary
  val alpha = if (enabled) 1f else 0.5f
  Box(
    modifier = modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .then(
        if (primary && enabled) Modifier.shadow(6.dp, CircleShape, clip = false, ambientColor = accent, spotColor = accent)
        else Modifier
      )
      .clip(CircleShape)
      .background(if (primary) accent.copy(alpha = alpha) else accent.copy(alpha = 0.12f * alpha))
      .then(if (primary) Modifier else Modifier.border(1.dp, accent.copy(alpha = 0.45f * alpha), CircleShape))
      .clickable(enabled = enabled, onClick = onClick)
      .padding(horizontal = 16.dp, vertical = 11.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text,
      color = if (primary) Color.White.copy(alpha = if (enabled) 1f else 0.8f) else accent.copy(alpha = alpha),
      fontSize = 14.sp,
      fontWeight = FontWeight.SemiBold,
      maxLines = 1,
      overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
    )
  }
}

/**
 * Status chip with a coloured dot. While [pulsing] (model loading) the dot breathes with a soft glow.
 */
@Composable
internal fun StatusDotChip(text: String, color: Color, pulsing: Boolean) {
  val transition = androidx.compose.animation.core.rememberInfiniteTransition(label = "statusPulse")
  val pulse by transition.animateFloat(
    initialValue = 0f,
    targetValue = 1f,
    animationSpec = androidx.compose.animation.core.infiniteRepeatable(
      animation = androidx.compose.animation.core.tween(900, easing = androidx.compose.animation.core.FastOutSlowInEasing),
      repeatMode = androidx.compose.animation.core.RepeatMode.Reverse
    ),
    label = "statusPulseValue"
  )
  val p = if (pulsing) pulse else 0f
  Row(
    modifier = Modifier
      .clip(CircleShape)
      .background(color.copy(alpha = 0.14f))
      .padding(start = 10.dp, end = 12.dp, top = 5.dp, bottom = 5.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
      modifier = Modifier
        .size(14.dp)
        .drawBehind {
          if (pulsing) {
            // Soft halo that grows and fades with the pulse.
            drawCircle(
              color = color.copy(alpha = 0.45f * (1f - p) + 0.10f),
              radius = size.minDimension / 2f * (0.75f + 0.55f * p)
            )
          }
        },
      contentAlignment = Alignment.Center
    ) {
      Box(
        modifier = Modifier
          .size(8.dp)
          .graphicsLayer {
            val sc = if (pulsing) 0.85f + 0.3f * p else 1f
            scaleX = sc
            scaleY = sc
            alpha = if (pulsing) 0.55f + 0.45f * p else 1f
          }
          .clip(CircleShape)
          .background(color)
      )
    }
    Spacer(Modifier.width(6.dp))
    Text(text, color = color, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
  }
}

/** Thick rounded progress bar with the percentage shown next to it. */
@Composable
internal fun PercentProgressBar(
  fraction: Float,
  color: Color = CyberCyanPrimary,
  modifier: Modifier = Modifier,
  label: String = "${(fraction.coerceIn(0f, 1f) * 100).toInt()}%"
) {
  val animated by androidx.compose.animation.core.animateFloatAsState(
    fraction.coerceIn(0f, 1f), animationSpec = androidx.compose.animation.core.tween(250), label = "progress"
  )
  Row(modifier = modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
    androidx.compose.material3.LinearProgressIndicator(
      progress = { animated },
      modifier = Modifier.weight(1f).height(8.dp).clip(CircleShape),
      color = color,
      trackColor = ObsidianSurfaceVariant,
      strokeCap = androidx.compose.ui.graphics.StrokeCap.Round,
      gapSize = 0.dp,
      drawStopIndicator = {}
    )
    Spacer(Modifier.width(10.dp))
    Text(
      label,
      color = TextPrimary,
      fontSize = 13.sp,
      fontWeight = FontWeight.SemiBold,
      maxLines = 1,
      modifier = Modifier.widthIn(min = 40.dp)
    )
  }
}

/** "7B", "Q4_K_M" style tags parsed from a GGUF file name. */
internal fun modelTags(name: String): List<String> {
  val out = mutableListOf<String>()
  Regex("""(?<![a-z0-9])(\d+(?:\.\d+)?)[bB](?![a-z])""").find(name)?.let { out += it.groupValues[1] + "B" }
  Regex("""(?i)(iq\d(?:_[a-z0-9]+)*|q\d(?:_[a-z0-9]+)*|bf16|f16|f32)""").find(name)?.let { out += it.value.uppercase() }
  return out
}

internal fun Modifier.rowClickable(onClick: () -> Unit): Modifier = this.clickable(onClick = onClick)
