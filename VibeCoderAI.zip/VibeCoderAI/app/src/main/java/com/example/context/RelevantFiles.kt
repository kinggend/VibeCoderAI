package com.example.context

/**
 * v1.4 token efficiency: ranks project files by how relevant they are to the task, so the prompt
 * carries the files the model needs first and lists the rest by name only. Pure, unit tested.
 */
object RelevantFiles {

  private val CSS_WORDS = listOf("style", "color", "colour", "design", "layout", "theme", "dark", "font", "css", "spacing", "animation", "responsive", "ui", "look")
  private val JS_WORDS = listOf("button", "click", "logic", "function", "script", "js", "javascript", "bug", "error", "save", "storage", "timer", "calculate", "event", "not working", "fix")
  private val HTML_WORDS = listOf("html", "page", "section", "header", "footer", "form", "input", "title", "layout", "add a", "element")

  /** Higher is more relevant. 0 = nothing points at this file. */
  fun score(relativePath: String, task: String): Int {
    val t = task.lowercase()
    val p = relativePath.lowercase()
    val name = p.substringAfterLast('/')
    var s = 0
    if (t.contains(name)) s += 10
    else if (t.contains(name.substringBeforeLast('.')) && name.substringBeforeLast('.').length >= 4) s += 5
    when (name.substringAfterLast('.', "")) {
      "css" -> if (CSS_WORDS.any { t.contains(it) }) s += 3
      "js", "ts", "mjs" -> if (JS_WORDS.any { t.contains(it) }) s += 3
      "html", "htm" -> if (HTML_WORDS.any { t.contains(it) }) s += 3
    }
    if (name in setOf("index.html", "app.js", "styles.css", "style.css", "main.js", "script.js")) s += 1
    return s
  }

  /** [paths] sorted by [score] (desc), ties by name, so the prompt budget goes to relevant files first. */
  fun rank(paths: List<String>, task: String): List<String> =
    if (task.isBlank()) paths.sortedBy { it.substringAfterLast('/') }
    else paths.sortedWith(compareByDescending<String> { score(it, task) }.thenBy { it.substringAfterLast('/') })
}
