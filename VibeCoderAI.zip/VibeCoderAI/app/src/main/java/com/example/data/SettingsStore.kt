package com.example.data

import android.content.Context
import com.example.data.model.SettingsState

/** Persists user settings (including the selected model file) across app restarts. */
class SettingsStore(context: Context) {
  private val prefs = context.getSharedPreferences("vibecoder_settings", Context.MODE_PRIVATE)
  /** Server URL, model name and API key are kept encrypted (Android Keystore), never in this file. */
  private val secrets = SecretCipher(context)

  /** v1.4.2: move remote settings that older versions saved as plain text into encrypted storage. */
  private fun migrateSecrets() {
    if (prefs.getBoolean("secrets1", false)) return
    for ((old, new) in listOf("remoteUrl" to S_URL, "remoteModel" to S_MODEL, "remoteKey" to S_KEY)) {
      prefs.getString(old, null)?.let { secrets.put(new, it) }
    }
    prefs.edit().remove("remoteUrl").remove("remoteModel").remove("remoteKey").putBoolean("secrets1", true).commit()
  }

  fun load(): SettingsState {
    val d = SettingsState()
    // v2: bigger defaults so a full web app fits in one response.
    if (!prefs.getBoolean("schema2", false)) {
      prefs.edit().remove("contextLength").remove("maxOutputTokens").remove("repetitionPenalty").putBoolean("schema2", true).apply()
    }
    // v3: repetition penalty used to default to 1.0 (off), which made small models loop on the same word.
    if (!prefs.getBoolean("schema3", false)) {
      prefs.edit().remove("repetitionPenalty").putBoolean("schema3", true).apply()
    }
    migrateSecrets()
    return d.copy(
      activeModelId = prefs.getString("activeModelId", d.activeModelId) ?: d.activeModelId,
      customModelPath = prefs.getString("customModelPath", null),
      cpuThreads = prefs.getInt("cpuThreads", d.cpuThreads),
      contextLength = prefs.getInt("contextLength", d.contextLength),
      maxOutputTokens = prefs.getInt("maxOutputTokens", d.maxOutputTokens),
      temperature = prefs.getFloat("temperature", d.temperature),
      topP = prefs.getFloat("topP", d.topP),
      topK = prefs.getInt("topK", d.topK),
      repetitionPenalty = prefs.getFloat("repetitionPenalty", d.repetitionPenalty),
      autoRebuildAfterPatch = prefs.getBoolean("autoRebuildAfterPatch", d.autoRebuildAfterPatch),
      maxRepairRetries = prefs.getInt("maxRepairRetries", d.maxRepairRetries),
      requireApprovalForDestructive = prefs.getBoolean("requireApprovalForDestructive", d.requireApprovalForDestructive),
      autoApproveNewFiles = prefs.getBoolean("autoApproveNewFiles", d.autoApproveNewFiles),
      autoApproveSafeEdits = prefs.getBoolean("autoApproveSafeEdits", d.autoApproveSafeEdits),
      gpuOffload = prefs.getBoolean("gpuOffload", d.gpuOffload),
      gpuLayers = prefs.getInt("gpuLayers", d.gpuLayers),
      themeMode = prefs.getString("themeMode", d.themeMode) ?: d.themeMode,
      glassBlur = prefs.getBoolean("glassBlur2", d.glassBlur),
      blurRadiusDp = prefs.getInt("blurRadiusDp", d.blurRadiusDp).coerceIn(10, 40),
      accent = prefs.getString("accent", d.accent) ?: d.accent,
      strictSecurity = prefs.getBoolean("strictSecurity", d.strictSecurity),
      autonomous = prefs.getBoolean("autonomous", d.autonomous),
      terminalTimeoutSec = com.example.terminal.TimeoutConfig.sanitize(prefs.getInt("terminalTimeoutSec", d.terminalTimeoutSec)),
      editorAutocomplete = prefs.getBoolean("editorAutocomplete", d.editorAutocomplete),
      haptics = prefs.getBoolean("haptics", d.haptics),
      voiceLanguage = prefs.getString("voiceLanguage", d.voiceLanguage) ?: d.voiceLanguage,
      voiceRate = prefs.getFloat("voiceRate", d.voiceRate).coerceIn(0.5f, 2.0f),
      voiceAutoContinue = prefs.getBoolean("voiceAutoContinue", d.voiceAutoContinue),
      thinking = prefs.getBoolean("thinking", d.thinking),
      outputLevel = prefs.getString("outputLevel", d.outputLevel) ?: d.outputLevel,
      agentRole = prefs.getString("agentRole", d.agentRole) ?: d.agentRole,
      backendMode = prefs.getString("backend", d.backendMode) ?: d.backendMode,
      remoteUrl = secrets.get(S_URL).ifEmpty { d.remoteUrl },
      remoteModel = secrets.get(S_MODEL).ifEmpty { d.remoteModel },
      remoteKey = secrets.get(S_KEY).ifEmpty { d.remoteKey }
    )
  }

  fun save(s: SettingsState) {
    prefs.edit()
      .putString("activeModelId", s.activeModelId)
      .putString("customModelPath", s.customModelPath)
      .putInt("cpuThreads", s.cpuThreads)
      .putInt("contextLength", s.contextLength)
      .putInt("maxOutputTokens", s.maxOutputTokens)
      .putFloat("temperature", s.temperature)
      .putFloat("topP", s.topP)
      .putInt("topK", s.topK)
      .putFloat("repetitionPenalty", s.repetitionPenalty)
      .putBoolean("thinking", s.thinking)
      .putBoolean("autoRebuildAfterPatch", s.autoRebuildAfterPatch)
      .putInt("maxRepairRetries", s.maxRepairRetries)
      .putBoolean("requireApprovalForDestructive", s.requireApprovalForDestructive)
      .putBoolean("autoApproveNewFiles", s.autoApproveNewFiles && !s.strictSecurity)
      .putBoolean("autoApproveSafeEdits", s.autoApproveSafeEdits && !s.strictSecurity)
      .putBoolean("gpuOffload", s.gpuOffload)
      .putInt("gpuLayers", s.gpuLayers)
      .putString("themeMode", s.themeMode)
      .putBoolean("glassBlur2", s.glassBlur)
      .putInt("blurRadiusDp", s.blurRadiusDp)
      .putString("accent", s.accent)
      .putBoolean("strictSecurity", s.strictSecurity)
      .putBoolean("autonomous", s.autonomous)
      .putInt("terminalTimeoutSec", com.example.terminal.TimeoutConfig.sanitize(s.terminalTimeoutSec))
      .putBoolean("editorAutocomplete", s.editorAutocomplete)
      .putBoolean("haptics", s.haptics)
      .putString("voiceLanguage", s.voiceLanguage)
      .putFloat("voiceRate", s.voiceRate.coerceIn(0.5f, 2.0f))
      .putBoolean("voiceAutoContinue", s.voiceAutoContinue)
      .putString("outputLevel", s.outputLevel)
      .putString("agentRole", s.agentRole)
      .putString("backend", s.backendMode)
      .apply()
    secrets.put(S_URL, s.remoteUrl)
    secrets.put(S_MODEL, s.remoteModel)
    secrets.put(S_KEY, s.remoteKey)
  }

  // ---- v1.6 ----

  /** Hosts whose one-time "what is sent" notice the user has accepted. */
  fun isRemoteNoticeAcked(host: String): Boolean = host.lowercase() in (prefs.getStringSet("remoteNoticeAcked", emptySet()) ?: emptySet())

  fun ackRemoteNotice(host: String) {
    val cur = prefs.getStringSet("remoteNoticeAcked", emptySet()) ?: emptySet()
    prefs.edit().putStringSet("remoteNoticeAcked", cur + host.lowercase()).apply()
  }

  /** GitHub push: repo URL and branch are not secret; the token lives only in SecretCipher. */
  var githubRepo: String
    get() = prefs.getString("githubRepo", "") ?: ""
    set(v) { prefs.edit().putString("githubRepo", v.trim()).apply() }
  var githubBranch: String
    get() = prefs.getString("githubBranch", "main") ?: "main"
    set(v) { prefs.edit().putString("githubBranch", v.trim().ifEmpty { "main" }).apply() }
  var githubToken: String
    get() = secrets.get(S_PAT)
    set(v) = secrets.put(S_PAT, v.trim())

  /** Every saved secret value (for redaction of logs / History / exports). Never shown. */
  fun secretValues(): List<String> = listOf(secrets.get(S_KEY), secrets.get(S_PAT)).filter { it.isNotBlank() }

  private companion object {
    const val S_PAT = "githubPat"
    const val S_URL = "remoteUrl"
    const val S_MODEL = "remoteModel"
    const val S_KEY = "remoteKey"
  }
}
