package com.example.agent

/** v1.7.5: one agent run shown on the Agents screen. Pure Kotlin, unit-tested without Android. */
enum class RunKind(val label: String) { CHAT("Chat"), CODING("Coding"), PHONE("Phone") }
enum class RunStatus { WORKING, DONE, FAILED, STOPPED }

data class RunRecord(
  val id: String,
  val kind: RunKind,
  val title: String,
  val result: String = "",
  val status: RunStatus = RunStatus.WORKING,
  /** Project name or app name. */
  val tag: String = "",
  /** Builder, Debugger, Phone agent... */
  val agent: String = "",
  val startedAt: Long,
  val endedAt: Long = 0L,
  val steps: Int = 0,
  val archived: Boolean = false,
  val remote: Boolean = false
) {
  val durationMs: Long get() = if (endedAt > startedAt) endedAt - startedAt else 0L

  fun toJson(): String = MiniJson.encode(listOf(
    "id" to id, "kind" to kind.name, "title" to title, "result" to result, "status" to status.name, "tag" to tag,
    "agent" to agent, "start" to startedAt, "end" to endedAt, "steps" to steps, "archived" to archived, "remote" to remote
  ))

  companion object {
    fun fromJson(line: String): RunRecord? = runCatching {
      val m = MiniJson.parseObject(line)
      RunRecord(
        id = m["id"] as String,
        kind = RunKind.valueOf(m["kind"] as String),
        title = m["title"] as String,
        result = (m["result"] as? String).orEmpty(),
        status = RunStatus.valueOf(m["status"] as String),
        tag = (m["tag"] as? String).orEmpty(),
        agent = (m["agent"] as? String).orEmpty(),
        startedAt = (m["start"] as Number).toLong(),
        endedAt = (m["end"] as? Number)?.toLong() ?: 0L,
        steps = (m["steps"] as? Number)?.toInt() ?: 0,
        archived = m["archived"] == true,
        remote = m["remote"] == true
      )
    }.getOrNull()
  }
}

data class RunSections(val working: List<RunRecord>, val done: List<RunRecord>, val archived: List<RunRecord>)

data class RunStats(
  val total: Int,
  val byKind: Map<RunKind, Int>,
  val succeeded: Int,
  val failed: Int,
  val stopped: Int,
  val totalMs: Long,
  /** Runs per day, oldest first, ending today. */
  val last7: List<Int>
) {
  /** 0..1, finished runs only; null when nothing finished yet. */
  val successRate: Float? get() { val fin = succeeded + failed + stopped; return if (fin == 0) null else succeeded.toFloat() / fin }
}

object RunBoard {
  const val DAY = 86_400_000L

  fun sections(records: List<RunRecord>): RunSections {
    val sorted = records.sortedByDescending { it.startedAt }
    return RunSections(
      working = sorted.filter { it.status == RunStatus.WORKING && !it.archived },
      done = sorted.filter { it.status != RunStatus.WORKING && !it.archived },
      archived = sorted.filter { it.archived }
    )
  }

  /** "now", "1m ago", "2h ago", "3d ago". */
  fun ago(now: Long, t: Long): String {
    val s = ((now - t) / 1000).coerceAtLeast(0)
    return when {
      s < 45 -> "now"
      s < 3600 -> "${maxOf(1, (s / 60).toInt())}m ago"
      s < 86_400 -> "${(s / 3600).toInt()}h ago"
      else -> "${(s / 86_400).toInt()}d ago"
    }
  }

  fun duration(ms: Long): String {
    val s = ms / 1000
    return when {
      s < 1 -> "<1s"
      s < 60 -> "${s}s"
      s < 3600 -> "${s / 60}m ${s % 60}s"
      else -> "${s / 3600}h ${(s % 3600) / 60}m"
    }
  }

  fun statusOf(result: String, cancelled: Boolean, halted: Boolean): RunStatus = when {
    cancelled -> RunStatus.STOPPED
    halted -> RunStatus.FAILED
    else -> RunStatus.DONE
  }

  /** Phone agent result text to a status. */
  fun phoneStatus(result: String): RunStatus = when {
    result.startsWith("Stopped by you") || result.startsWith("Stopped before") -> RunStatus.STOPPED
    result.startsWith("Error") || result.startsWith("Stopped") -> RunStatus.FAILED
    else -> RunStatus.DONE
  }

  fun stats(records: List<RunRecord>, now: Long): RunStats {
    val startOfToday = now - (now % DAY)
    val buckets = IntArray(7)
    records.forEach { r ->
      val back = ((startOfToday - (r.startedAt - (r.startedAt % DAY))) / DAY).toInt()
      if (back in 0..6) buckets[6 - back]++
    }
    return RunStats(
      total = records.size,
      byKind = RunKind.values().associateWith { k -> records.count { it.kind == k } },
      succeeded = records.count { it.status == RunStatus.DONE },
      failed = records.count { it.status == RunStatus.FAILED },
      stopped = records.count { it.status == RunStatus.STOPPED },
      totalMs = records.sumOf { it.durationMs },
      last7 = buckets.toList()
    )
  }

  fun compactNumber(n: Long): String = when {
    n < 1_000 -> n.toString()
    n < 1_000_000 -> "%.1fK".format(java.util.Locale.US, n / 1000.0).replace(".0K", "K")
    else -> "%.1fM".format(java.util.Locale.US, n / 1_000_000.0).replace(".0M", "M")
  }
}
