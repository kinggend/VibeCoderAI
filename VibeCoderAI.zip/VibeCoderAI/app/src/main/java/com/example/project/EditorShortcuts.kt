package com.example.project

/** Hardware-keyboard shortcuts of the code editor (Ctrl, or Cmd on a Mac keyboard). Pure so it is unit-tested. */
enum class EditorAction { SAVE, UNDO, REDO, FIND }

object EditorShortcuts {
  /** Ctrl+S save, Ctrl+Z undo, Ctrl+Shift+Z or Ctrl+Y redo, Ctrl+F find. Anything else (or no Ctrl) is not a shortcut. */
  fun action(ctrl: Boolean, shift: Boolean, letter: Char): EditorAction? {
    if (!ctrl) return null
    return when (letter.lowercaseChar()) {
      's' -> if (shift) null else EditorAction.SAVE
      'z' -> if (shift) EditorAction.REDO else EditorAction.UNDO
      'y' -> if (shift) null else EditorAction.REDO
      'f' -> if (shift) null else EditorAction.FIND
      else -> null
    }
  }
}
