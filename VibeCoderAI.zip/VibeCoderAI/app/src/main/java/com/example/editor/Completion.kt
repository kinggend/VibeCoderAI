package com.example.editor

/**
 * v1.6 editor auto-complete: language keywords plus identifiers already in the file. No model, no network,
 * pure and unit tested. The prefix is the identifier part just before the cursor (at least 2 characters).
 */
object Completion {
  private val KOTLIN = listOf("fun", "val", "var", "class", "object", "interface", "data", "sealed", "enum", "override", "private", "internal", "public", "protected", "return", "when", "else", "while", "for", "import", "package", "companion", "suspend", "inline", "lateinit", "null", "true", "false", "this", "super", "throw", "try", "catch", "finally", "typealias", "listOf", "mutableListOf", "mapOf", "println", "remember", "Composable", "Modifier")
  private val JAVA = listOf("public", "private", "protected", "static", "final", "class", "interface", "extends", "implements", "return", "void", "new", "import", "package", "boolean", "String", "int", "long", "double", "float", "while", "for", "switch", "case", "break", "continue", "throws", "throw", "try", "catch", "finally", "null", "true", "false", "this", "super", "System.out.println", "Override")
  private val JS = listOf("function", "const", "let", "var", "return", "if", "else", "for", "while", "switch", "case", "break", "continue", "class", "extends", "import", "export", "default", "async", "await", "new", "this", "null", "undefined", "true", "false", "typeof", "instanceof", "document", "querySelector", "querySelectorAll", "getElementById", "addEventListener", "console.log", "localStorage", "JSON.stringify", "JSON.parse", "setTimeout", "setInterval", "requestAnimationFrame", "Math", "Array", "Object", "Promise", "fetch")
  private val TS = JS + listOf("interface", "type", "enum", "implements", "readonly", "private", "public", "protected", "string", "number", "boolean", "unknown", "never", "keyof", "as")
  private val PY = listOf("def", "class", "return", "import", "from", "as", "if", "elif", "else", "for", "while", "in", "not", "and", "or", "is", "None", "True", "False", "try", "except", "finally", "raise", "with", "lambda", "yield", "pass", "break", "continue", "global", "nonlocal", "self", "print", "range", "len", "dict", "list", "str", "int", "float", "async", "await")
  private val HTML = listOf("html", "head", "body", "div", "span", "button", "input", "label", "section", "header", "footer", "main", "nav", "script", "style", "link", "meta", "title", "canvas", "class", "id", "href", "src", "type", "placeholder", "viewport", "stylesheet", "textarea", "select", "option", "form", "table", "ul", "li", "img", "aria-label")
  private val CSS = listOf("display", "flex", "grid", "position", "absolute", "relative", "fixed", "margin", "padding", "border", "border-radius", "background", "background-color", "color", "font-size", "font-weight", "font-family", "width", "height", "max-width", "min-height", "justify-content", "align-items", "gap", "transition", "transform", "opacity", "box-shadow", "overflow", "z-index", "cursor", "@media", "hover", "none", "auto", "center", "inherit", "var(")

  fun keywordsFor(ext: String): List<String> = when (ext.lowercase()) {
    "kt", "kts" -> KOTLIN
    "java" -> JAVA
    "js", "mjs", "cjs", "jsx" -> JS
    "ts", "tsx" -> TS
    "py" -> PY
    "html", "htm" -> HTML + JS
    "css" -> CSS
    else -> emptyList()
  }

  private fun isIdent(c: Char, css: Boolean) = c.isLetterOrDigit() || c == '_' || (css && c == '-') || c == '$'

  /** The identifier part ending at [cursor], e.g. "docu" in "x = docu|". */
  fun prefixAt(text: String, cursor: Int, ext: String = ""): String {
    val css = ext.lowercase() in setOf("css", "html", "htm")
    val end = cursor.coerceIn(0, text.length)
    var start = end
    while (start > 0 && isIdent(text[start - 1], css)) start--
    return text.substring(start, end)
  }

  private val IDENT = Regex("[A-Za-z_\$][A-Za-z0-9_\$]{2,}")

  /**
   * Up to [limit] suggestions for the word before [cursor]: matches starting with the prefix (case-insensitive),
   * the exact prefix itself excluded. Identifiers used often in the file come first, then keywords.
   */
  fun suggest(text: String, cursor: Int, ext: String, limit: Int = 6): List<String> {
    val prefix = prefixAt(text, cursor, ext)
    if (prefix.length < 2 || prefix.first().isDigit()) return emptyList()
    val p = prefix.lowercase()
    // Count identifiers in the file, not counting the word being typed (only once at the cursor).
    val counts = HashMap<String, Int>()
    IDENT.findAll(text).forEach { counts[it.value] = (counts[it.value] ?: 0) + 1 }
    counts[prefix]?.let { if (it <= 1) counts.remove(prefix) else counts[prefix] = it - 1 }
    val idents = counts.entries.filter { it.key.lowercase().startsWith(p) && it.key != prefix }
      .sortedWith(compareByDescending<Map.Entry<String, Int>> { it.value }.thenBy { it.key.length }).map { it.key }
    val kws = keywordsFor(ext).filter { it.lowercase().startsWith(p) && it != prefix }.sortedBy { it.length }
    return (idents + kws).distinct().take(limit)
  }

  /** Inserts [word] replacing the prefix before [cursor]. Returns new text and new cursor. */
  fun apply(text: String, cursor: Int, word: String, ext: String = ""): Pair<String, Int> {
    val c = cursor.coerceIn(0, text.length)
    val prefix = prefixAt(text, c, ext)
    val start = c - prefix.length
    val out = text.substring(0, start) + word + text.substring(c)
    return out to (start + word.length)
  }
}
