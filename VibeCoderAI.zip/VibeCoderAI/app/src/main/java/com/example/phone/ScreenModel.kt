package com.example.phone

/**
 * v1.7.0 Phone agent: one on-screen element as the accessibility service read it. Pure data, so the
 * compaction the model sees is unit-tested without Android.
 */
data class UiNode(
  val id: Int,
  val text: String? = null,
  val desc: String? = null,
  val hint: String? = null,
  val resId: String? = null,
  val cls: String? = null,
  val left: Int = 0,
  val top: Int = 0,
  val right: Int = 0,
  val bottom: Int = 0,
  val clickable: Boolean = false,
  val longClickable: Boolean = false,
  val editable: Boolean = false,
  val scrollable: Boolean = false,
  val password: Boolean = false,
  val checked: Boolean? = null,
  val enabled: Boolean = true,
  val children: List<UiNode> = emptyList()
) {
  val centerX: Int get() = (left + right) / 2
  val centerY: Int get() = (top + bottom) / 2
  val width: Int get() = right - left
  val height: Int get() = bottom - top
}

/** One numbered element the model can act on, and the label the user sees in the step list. */
data class ScreenElement(
  val id: Int,
  val kind: String,
  val label: String,
  val clickable: Boolean,
  val editable: Boolean,
  val scrollable: Boolean,
  val password: Boolean,
  val centerX: Int,
  val centerY: Int,
  /** The label without the 60-character cut (scripts match on it). */
  val full: String = label
)

/** What the model reads for one step: [text] within the budget, and every element it lists. */
data class CompactScreen(val text: String, val elements: List<ScreenElement>, val dropped: Int) {
  fun element(id: Int): ScreenElement? = elements.firstOrNull { it.id == id }
}

object ScreenCompactor {
  private const val MAX_LABEL = 60

  /** Short, readable kind of a view class ("android.widget.EditText" becomes "edit"). */
  fun kindOf(n: UiNode): String {
    val c = n.cls.orEmpty().substringAfterLast('.').lowercase()
    return when {
      n.editable || "edittext" in c || "autocomplete" in c -> "edit"
      "switch" in c -> "switch"
      "checkbox" in c -> "checkbox"
      "radio" in c -> "radio"
      "imagebutton" in c -> "button"
      "button" in c -> "button"
      "image" in c -> "image"
      "recycler" in c || "listview" in c || "scrollview" in c || "gridview" in c || "pager" in c -> "list"
      "tab" in c -> "tab"
      "text" in c -> "text"
      n.clickable -> "button"
      else -> "view"
    }
  }

  private fun clean(s: String?, max: Int = MAX_LABEL): String? =
    s?.replace(Regex("\\s+"), " ")?.trim()?.takeIf { it.isNotEmpty() }?.let { if (it.length > max) it.take(max - 1) + "…" else it }

  private fun ownLabel(n: UiNode): String? =
    clean(n.text) ?: clean(n.desc) ?: clean(n.hint) ?: n.resId?.substringAfterLast('/')?.replace('_', ' ')?.let { clean(it) }

  /** Texts under [n] (for a clickable row without its own label: "Biryani House, 4.2, 30 min"). */
  private fun childText(n: UiNode, out: MutableList<String>, limit: Int = 4) {
    for (c in n.children) {
      if (out.size >= limit) return
      (clean(c.text) ?: clean(c.desc))?.let { if (it !in out) out += it }
      if (!c.clickable && !c.editable) childText(c, out, limit)
    }
  }

  /**
   * The elements worth showing, in screen order: anything clickable, editable or scrollable, plus
   * labelled text. A clickable row takes the text of its children so the model sees one element.
   */
  fun elements(root: List<UiNode>): List<ScreenElement> {
    val out = mutableListOf<ScreenElement>()
    fun visit(n: UiNode, coveredByParent: Boolean) {
      if (n.width <= 0 || n.height <= 0) { n.children.forEach { visit(it, coveredByParent) }; return }
      val actionable = n.clickable || n.longClickable || n.editable || n.scrollable
      var label = ownLabel(n)
      var mergedChildren = false
      if ((n.clickable || n.longClickable) && !n.editable && clean(n.text) == null && clean(n.desc) == null) {
        val parts = mutableListOf<String>()
        childText(n, parts)
        if (parts.isNotEmpty()) { label = clean(parts.joinToString(", ")); mergedChildren = true }
      }
      val show = actionable || (!coveredByParent && (clean(n.text) != null || clean(n.desc) != null))
      if (show && (label != null || n.editable || n.scrollable)) {
        out += ScreenElement(
          id = n.id, kind = kindOf(n), label = label.orEmpty(),
          clickable = n.clickable || n.longClickable, editable = n.editable, scrollable = n.scrollable,
          password = n.password, centerX = n.centerX, centerY = n.centerY,
          full = if (mergedChildren) label.orEmpty() else (clean(n.text, 600) ?: clean(n.desc, 600) ?: label.orEmpty())
        )
      }
      n.children.forEach { visit(it, coveredByParent || mergedChildren) }
    }
    root.forEach { visit(it, false) }
    return out
  }

  fun line(e: ScreenElement): String = buildString {
    append('#').append(e.id).append(' ').append(e.kind)
    if (e.label.isNotEmpty()) append(" \"").append(e.label.replace("\"", "'")).append('"')
    val acts = buildList {
      if (e.clickable) add("tap")
      if (e.editable) add(if (e.password) "password" else "type")
      if (e.scrollable) add("scroll")
    }
    if (acts.isNotEmpty()) append(" [").append(acts.joinToString(",")).append(']')
  }

  /**
   * The screen as numbered lines within [budgetChars]. When it does not fit, plain text goes first,
   * then the elements furthest down the screen; the model is told how many were left out.
   */
  fun compact(appLabel: String, pkg: String, root: List<UiNode>, budgetChars: Int): CompactScreen {
    val all = elements(root)
    val header = "App: $appLabel ($pkg)\nScreen elements (#id kind \"label\" [actions]):\n"
    val budget = (budgetChars - header.length - 40).coerceAtLeast(200)
    fun size(list: List<ScreenElement>) = list.sumOf { line(it).length + 1 }
    var keep = all
    if (size(keep) > budget) keep = all.filter { it.clickable || it.editable || it.scrollable }
    if (size(keep) > budget) {
      // Editable fields are kept first (search boxes), then the rest in screen order.
      val (edits, rest) = keep.partition { it.editable }
      val picked = edits.toMutableList()
      var used = size(picked)
      for (e in rest) {
        val l = line(e).length + 1
        if (used + l > budget) break
        picked += e; used += l
      }
      keep = all.filter { it in picked }
    }
    val dropped = all.size - keep.size
    val text = header + keep.joinToString("\n") { line(it) } +
      (if (dropped > 0) "\n… $dropped more elements not shown (scroll to see more)" else "") +
      (if (keep.isEmpty()) "(no readable elements: the app may draw its own UI, or the screen is still loading)" else "")
    return CompactScreen(text, keep, dropped)
  }

  /** Changes when what is on screen changes; used to tell the model that its action did nothing. */
  fun signature(screen: CompactScreen): Int = screen.elements.joinToString("|") { "${it.kind}:${it.label}" }.hashCode()
}
