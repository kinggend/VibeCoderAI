package com.example.llama

/**
 * v1.4: rough RAM need of a GGUF model before loading it: weights x 1.2 (runtime buffers on top of the
 * file) + KV cache for the context + a fixed compute/scratch overhead. The KV size per token is scaled
 * from the file size (about 32 KB per GB of weights, at least 12 KB: 0.5B models need ~12 KB/token,
 * 1B ~32 KB, 8B ~128 KB with f16 KV). Deliberately conservative. Pure, unit tested.
 */
object MemoryEstimator {
  private const val MB = 1024L * 1024L
  private const val GB = 1024L * MB
  const val OVERHEAD_BYTES = 150L * MB

  /** Safe context to fall back to when the requested one does not fit. */
  const val SAFE_FALLBACK = 1024

  /** The context the engine will really use and whether it had to be lowered to fit free RAM. */
  data class Guarded(val contextTokens: Int, val lowered: Boolean, val neededBytes: Long)

  /** A context that exceeds free RAM falls back to the largest standard size that fits, else [SAFE_FALLBACK]. */
  fun guard(fileBytes: Long, requested: Int, availableBytes: Long): Guarded {
    val need = neededBytes(fileBytes, requested)
    if (availableBytes <= 0 || need <= availableBytes) return Guarded(requested, false, need)
    return Guarded(suggestContext(fileBytes, requested, availableBytes) ?: SAFE_FALLBACK, true, need)
  }

  data class Verdict(val fits: Boolean, val neededBytes: Long, val availableBytes: Long, val suggestedContext: Int?)

  fun kvBytesPerToken(fileBytes: Long): Long =
    maxOf(12L * 1024, (32L * 1024 * fileBytes) / GB)

  fun neededBytes(fileBytes: Long, contextTokens: Int): Long =
    (fileBytes * 12) / 10 + contextTokens.toLong() * kvBytesPerToken(fileBytes) + OVERHEAD_BYTES

  /** Largest standard context below [contextTokens] that fits [availableBytes], or null when none does. */
  fun suggestContext(fileBytes: Long, contextTokens: Int, availableBytes: Long): Int? =
    listOf(8192, 6144, 4096, 3072, 2048, 1024, 512)
      .filter { it < contextTokens }
      .firstOrNull { neededBytes(fileBytes, it) <= availableBytes }

  fun check(fileBytes: Long, contextTokens: Int, availableBytes: Long): Verdict {
    val need = neededBytes(fileBytes, contextTokens)
    val fits = availableBytes <= 0 || need <= availableBytes // unknown memory: do not block
    return Verdict(fits, need, availableBytes, if (fits) null else suggestContext(fileBytes, contextTokens, availableBytes))
  }
}

/** What the Models screen needs to draw the RAM bar: model (+ image helper) size, free RAM and any forced minimum context. */
data class ModelMemory(val fileBytes: Long, val freeBytes: Long, val minContext: Int = 0)
