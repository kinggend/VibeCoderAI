package com.example.terminal

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.InputStream

/** What to do with a command that seems to wait for input. Never decided by the app: only by the user. */
sealed class InputAnswer {
  data class Send(val text: String) : InputAnswer()
  object Stop : InputAnswer()
  object KeepWaiting : InputAnswer()
}

/**
 * v1.6: one running shell command. stdout/stderr are read as they arrive (not line by line, so prompts
 * without a newline show up), stdin stays open for [send], and the process is always ended on timeout,
 * Stop or cancellation (the v1.5 manager's timeout left the process running).
 */
class TerminalSession internal constructor(val command: String, private val process: Process?) {
  private val started = System.currentTimeMillis()
  private val out = StringBuilder()
  private val err = StringBuilder()
  private val all = StringBuilder()
  private val _output = MutableStateFlow("")
  /** Combined stdout + stderr so far (last [MAX_CHARS] characters). */
  val output: StateFlow<String> = _output.asStateFlow()
  private val _running = MutableStateFlow(process != null)
  val running: StateFlow<Boolean> = _running.asStateFlow()
  @Volatile var lastOutputAt: Long = started
    private set
  @Volatile private var stoppedByUser = false
  private var finishedResult: TerminalExecutionResult? = null
  private val stdin = process?.outputStream
  private val readers: List<Thread>

  init {
    readers = if (process == null) emptyList() else listOf(pump(process.inputStream, out), pump(process.errorStream, err))
  }

  private fun pump(stream: InputStream, target: StringBuilder): Thread = Thread {
    val buf = CharArray(2048)
    try {
      stream.reader().use { r ->
        while (true) {
          val n = r.read(buf)
          if (n < 0) break
          val chunk = String(buf, 0, n)
          synchronized(this) {
            target.append(chunk)
            all.append(chunk)
            if (all.length > MAX_CHARS) all.delete(0, all.length - MAX_CHARS)
            if (target.length > MAX_CHARS) target.delete(0, target.length - MAX_CHARS)
            _output.value = all.toString()
          }
          lastOutputAt = System.currentTimeMillis()
        }
      }
    } catch (_: Exception) {}
  }.apply { isDaemon = true; start() }

  private fun alive(): Boolean = process != null && try { process.exitValue(); false } catch (_: IllegalThreadStateException) { true }

  /** Writes [text] to the process's stdin (add "\n" for Enter). False when it has already ended. */
  fun send(text: String): Boolean = runCatching {
    if (!alive()) return false
    stdin?.write(text.toByteArray())
    stdin?.flush()
    true
  }.getOrDefault(false)

  /** Ctrl+C: SIGINT when Android lets us find the pid, otherwise (or if it ignores SIGINT) the process is ended. */
  fun interrupt() {
    stoppedByUser = true
    val pid = pidOf(process)
    if (pid != null) runCatching { android.os.Process.sendSignal(pid, 2) }
    Thread {
      Thread.sleep(1500)
      if (alive()) kill()
    }.apply { isDaemon = true; start() }
    if (pid == null) kill()
  }

  /** Stop button: ends the process now. */
  fun stop() {
    stoppedByUser = true
    kill()
  }

  private fun kill() {
    runCatching { process?.destroy() }
    if (android.os.Build.VERSION.SDK_INT >= 26) runCatching { if (alive()) process?.destroyForcibly() }
  }

  /**
   * Waits for the end. [timeoutMs] null = no limit. [onWaitingForInput] is called when the process has been
   * quiet for [IDLE_MS] and its last output looks like a prompt; time spent waiting for that answer does not
   * count against the timeout. Cancelling the caller ends the process.
   */
  suspend fun await(
    timeoutMs: Long?,
    onWaitingForInput: (suspend (tail: String) -> InputAnswer)? = null
  ): TerminalExecutionResult {
    finishedResult?.let { return it }
    val p = process ?: return finishedResult!!
    var paused = 0L
    var askedAt = -1L
    var timedOut = false
    try {
      withContext(Dispatchers.IO) {
        while (alive()) {
          delay(100)
          val now = System.currentTimeMillis()
          if (timeoutMs != null && now - started - paused > timeoutMs) {
            timedOut = true
            kill()
            break
          }
          val text = _output.value
          if (onWaitingForInput != null && now - lastOutputAt >= IDLE_MS && lastOutputAt != askedAt && text.isNotEmpty() && Prompts.looksLikePrompt(text)) {
            askedAt = lastOutputAt
            val t0 = System.currentTimeMillis()
            val answer = onWaitingForInput(text.takeLast(400))
            paused += System.currentTimeMillis() - t0
            when (answer) {
              is InputAnswer.Send -> send(answer.text)
              InputAnswer.Stop -> interrupt()
              InputAnswer.KeepWaiting -> {}
            }
          }
        }
      }
    } catch (e: CancellationException) {
      withContext(NonCancellable) { stop() }
      throw e
    }
    readers.forEach { it.join(500) }
    runCatching { stdin?.close() }
    val code = runCatching { p.exitValue() }.getOrDefault(if (timedOut) 124 else 130)
    val res = synchronized(this) {
      TerminalExecutionResult(
        command = command,
        exitCode = if (timedOut) 124 else code,
        stdout = out.toString().trimEnd(),
        stderr = (err.toString().trimEnd() + when {
          timedOut -> "\nStopped: the command ran longer than the ${TimeoutConfig.label(((timeoutMs ?: 0) / 1000).toInt())} timeout (Settings › Agent › Terminal)."
          stoppedByUser -> "\nStopped by you."
          else -> ""
        }).trim(),
        durationMs = System.currentTimeMillis() - started,
        timedOut = timedOut
      )
    }
    _running.value = false
    finishedResult = res
    return res
  }

  companion object {
    const val MAX_CHARS = 200_000
    const val IDLE_MS = 2500L

    fun finished(result: TerminalExecutionResult): TerminalSession =
      TerminalSession(result.command, null).also {
        it.finishedResult = result
        it._output.value = listOf(result.stdout, result.stderr).filter { s -> s.isNotEmpty() }.joinToString("\n")
      }

    private fun pidOf(p: Process?): Int? = p?.let {
      runCatching { it.javaClass.getDeclaredField("pid").apply { isAccessible = true }.getInt(it) }.getOrNull()
    }
  }
}

/** Pure prompt heuristics (unit tested). */
object Prompts {
  private val PROMPT = Regex("""(\?|:|>|\]|\)|\$|#)\s*$|\[y/n]|\(y/n\)|\[Y/n]|\[y/N]|press (enter|any key)|password""", RegexOption.IGNORE_CASE)

  /** True when output stops mid-line, or its last line ends like a question / prompt. */
  fun looksLikePrompt(output: String): Boolean {
    if (output.isEmpty()) return false
    if (!output.endsWith("\n")) return true
    val last = output.trimEnd('\n', '\r').substringAfterLast('\n')
    return PROMPT.containsMatchIn(last) && (last.contains("?") || last.contains("y/n", ignoreCase = true) || last.contains("press", ignoreCase = true) || last.trimEnd().endsWith(":"))
  }
}

/** v1.6 terminal timeout setting (seconds; 0 = no limit). Pure, unit tested. */
object TimeoutConfig {
  const val DEFAULT_SEC = 60
  const val MIN_SEC = 10
  const val MAX_SEC = 1800
  val OPTIONS_SEC = listOf(10, 30, 60, 120, 300, 600, 1800, 0)

  fun sanitize(sec: Int): Int = if (sec <= 0) 0 else sec.coerceIn(MIN_SEC, MAX_SEC)

  /** "45", "45s", "5m", "5 min", "1h" (capped at 30 min), "no limit" / "none" / "off" / "0" = no limit. Bad input = default. */
  fun parse(raw: String?): Int {
    val t = raw?.trim()?.lowercase() ?: return DEFAULT_SEC
    if (t.isEmpty()) return DEFAULT_SEC
    if (t in setOf("no limit", "nolimit", "none", "off", "unlimited", "∞", "0")) return 0
    val m = Regex("""^(\d+)\s*(s|sec|secs|seconds?|m|min|mins|minutes?|h|hr|hours?)?$""").find(t) ?: return DEFAULT_SEC
    val n = m.groupValues[1].toLongOrNull() ?: return DEFAULT_SEC
    val unit = m.groupValues[2]
    val sec = when {
      unit.startsWith("h") -> n * 3600
      unit.startsWith("m") -> n * 60
      else -> n
    }
    return if (sec <= 0) 0 else sec.coerceAtMost(MAX_SEC.toLong()).toInt().coerceAtLeast(MIN_SEC)
  }

  fun toMillis(sec: Int): Long? = if (sec <= 0) null else sec * 1000L

  fun label(sec: Int): String = when {
    sec <= 0 -> "no limit"
    sec < 60 -> "$sec s"
    sec % 60 == 0 -> "${sec / 60} min"
    else -> "${sec / 60} min ${sec % 60} s"
  }
}
