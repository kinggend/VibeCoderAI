package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.RowScope
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ButtonElevation
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.IconButtonColors
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.SelectableChipColors
import androidx.compose.material3.SelectableChipElevation
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Shape

/*
 * v1.2: drop-in replacements for the Material 3 buttons and chips used across the app. Same parameters
 * as Material, plus: the Material ripple (unchanged), a cheap press-down scale to 0.97 (graphicsLayer
 * only, driven by the button's own InteractionSource) and a light haptic tick on every tap.
 * Screens import these instead of androidx.compose.material3.Button & co.
 */

@Composable
private fun rememberTapSource(interactionSource: MutableInteractionSource?): MutableInteractionSource =
  interactionSource ?: remember { MutableInteractionSource() }

@Composable
private fun withTick(onClick: () -> Unit): () -> Unit {
  val haptics = rememberHaptics()
  return {
    haptics.tick()
    onClick()
  }
}

@Composable
fun Button(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  shape: Shape = ButtonDefaults.shape,
  colors: ButtonColors = ButtonDefaults.buttonColors(),
  elevation: ButtonElevation? = ButtonDefaults.buttonElevation(),
  border: BorderStroke? = null,
  contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
  interactionSource: MutableInteractionSource? = null,
  content: @Composable RowScope.() -> Unit
) {
  val source = rememberTapSource(interactionSource)
  androidx.compose.material3.Button(
    onClick = withTick(onClick),
    modifier = modifier.pressScale(source),
    enabled = enabled,
    shape = shape,
    colors = colors,
    elevation = elevation,
    border = border,
    contentPadding = contentPadding,
    interactionSource = source,
    content = content
  )
}

@Composable
fun FilledTonalButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  shape: Shape = ButtonDefaults.filledTonalShape,
  colors: ButtonColors = ButtonDefaults.filledTonalButtonColors(),
  elevation: ButtonElevation? = ButtonDefaults.filledTonalButtonElevation(),
  border: BorderStroke? = null,
  contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
  interactionSource: MutableInteractionSource? = null,
  content: @Composable RowScope.() -> Unit
) {
  val source = rememberTapSource(interactionSource)
  androidx.compose.material3.FilledTonalButton(
    onClick = withTick(onClick),
    modifier = modifier.pressScale(source),
    enabled = enabled,
    shape = shape,
    colors = colors,
    elevation = elevation,
    border = border,
    contentPadding = contentPadding,
    interactionSource = source,
    content = content
  )
}

@Composable
fun OutlinedButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  shape: Shape = ButtonDefaults.outlinedShape,
  colors: ButtonColors = ButtonDefaults.outlinedButtonColors(),
  elevation: ButtonElevation? = null,
  border: BorderStroke? = ButtonDefaults.outlinedButtonBorder(enabled),
  contentPadding: PaddingValues = ButtonDefaults.ContentPadding,
  interactionSource: MutableInteractionSource? = null,
  content: @Composable RowScope.() -> Unit
) {
  val source = rememberTapSource(interactionSource)
  androidx.compose.material3.OutlinedButton(
    onClick = withTick(onClick),
    modifier = modifier.pressScale(source),
    enabled = enabled,
    shape = shape,
    colors = colors,
    elevation = elevation,
    border = border,
    contentPadding = contentPadding,
    interactionSource = source,
    content = content
  )
}

@Composable
fun TextButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  shape: Shape = ButtonDefaults.textShape,
  colors: ButtonColors = ButtonDefaults.textButtonColors(),
  elevation: ButtonElevation? = null,
  border: BorderStroke? = null,
  contentPadding: PaddingValues = ButtonDefaults.TextButtonContentPadding,
  interactionSource: MutableInteractionSource? = null,
  content: @Composable RowScope.() -> Unit
) {
  val source = rememberTapSource(interactionSource)
  androidx.compose.material3.TextButton(
    onClick = withTick(onClick),
    modifier = modifier.pressScale(source),
    enabled = enabled,
    shape = shape,
    colors = colors,
    elevation = elevation,
    border = border,
    contentPadding = contentPadding,
    interactionSource = source,
    content = content
  )
}

@Composable
fun IconButton(
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  colors: IconButtonColors = IconButtonDefaults.iconButtonColors(),
  interactionSource: MutableInteractionSource? = null,
  content: @Composable () -> Unit
) {
  val source = rememberTapSource(interactionSource)
  androidx.compose.material3.IconButton(
    onClick = withTick(onClick),
    modifier = modifier.pressScale(source),
    enabled = enabled,
    colors = colors,
    interactionSource = source,
    content = content
  )
}

@Composable
fun FilterChip(
  selected: Boolean,
  onClick: () -> Unit,
  label: @Composable () -> Unit,
  modifier: Modifier = Modifier,
  enabled: Boolean = true,
  leadingIcon: @Composable (() -> Unit)? = null,
  trailingIcon: @Composable (() -> Unit)? = null,
  shape: Shape = FilterChipDefaults.shape,
  colors: SelectableChipColors = FilterChipDefaults.filterChipColors(),
  elevation: SelectableChipElevation? = FilterChipDefaults.filterChipElevation(),
  border: BorderStroke? = FilterChipDefaults.filterChipBorder(enabled, selected),
  interactionSource: MutableInteractionSource? = null
) {
  val source = rememberTapSource(interactionSource)
  androidx.compose.material3.FilterChip(
    selected = selected,
    onClick = withTick(onClick),
    label = label,
    modifier = modifier.pressScale(source),
    enabled = enabled,
    leadingIcon = leadingIcon,
    trailingIcon = trailingIcon,
    shape = shape,
    colors = colors,
    elevation = elevation,
    border = border,
    interactionSource = source
  )
}
