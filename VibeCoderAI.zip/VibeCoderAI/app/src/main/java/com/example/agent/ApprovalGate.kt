package com.example.agent

import com.example.data.model.DiffLine
import com.example.data.model.SettingsState
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import java.util.UUID

/** What the agent wants to do. */
enum class ActionKind { NEW_FILE, EDIT_FILE, DELETE_FILE, COMMAND, REPAIR_PATCH }

/**
 * v1.4 approval rules (pure, unit tested). Agent-proposed commands, deletes and self-repair patches
 * always ask. New files skip approval only with "Auto-approve new files" (default on); edits of
 * existing files skip it only with "Auto-approve safe edits" (default off).
 */
object ApprovalPolicy {
  /** v1.5: Strict Security makes every kind ask, ignoring both auto-approve switches. */
  fun needsApproval(kind: ActionKind, settings: SettingsState): Boolean = settings.strictSecurity || when (kind) {
    ActionKind.NEW_FILE -> !settings.autoApproveNewFiles
    ActionKind.EDIT_FILE -> !settings.autoApproveSafeEdits
    ActionKind.DELETE_FILE, ActionKind.COMMAND, ActionKind.REPAIR_PATCH -> true
  }
}

/** One item shown in the approval dialog: a file with its diff, or a command with its text. */
data class ApprovalItem(
  val kind: ActionKind,
  val path: String? = null,
  val command: String? = null,
  val diff: List<DiffLine> = emptyList()
)

data class ApprovalRequest(
  val id: String = UUID.randomUUID().toString(),
  val title: String,
  val reason: String,
  val items: List<ApprovalItem>,
  /** Chat message whose file card mirrors this request (Apply/Discard there resolve it too). */
  val messageId: String? = null
)

/**
 * Suspends the agent until the user approves or rejects. Requests are serialised (one dialog at a time).
 * Waiting is cancellable: Stop cancels the agent job, the request is cleared and nothing is applied,
 * so the flow can never deadlock on a dialog that is gone.
 */
class ApprovalGate {
  private val _pending = MutableStateFlow<ApprovalRequest?>(null)
  val pending: StateFlow<ApprovalRequest?> = _pending.asStateFlow()

  private val mutex = Mutex()
  @Volatile private var deferred: CompletableDeferred<Boolean>? = null

  suspend fun request(req: ApprovalRequest): Boolean = mutex.withLock {
    val d = CompletableDeferred<Boolean>()
    deferred = d
    _pending.value = req
    try {
      d.await()
    } finally {
      deferred = null
      if (_pending.value?.id == req.id) _pending.value = null
    }
  }

  /** Answers the open request. Returns false when [id] is not the open one (already answered). */
  fun resolve(id: String, approved: Boolean): Boolean {
    val req = _pending.value ?: return false
    if (req.id != id) return false
    _pending.value = null
    return deferred?.complete(approved) ?: false
  }

  /** Answers the open request that belongs to chat message [messageId], if any. */
  fun resolveForMessage(messageId: String, approved: Boolean): Boolean {
    val req = _pending.value ?: return false
    return if (req.messageId == messageId) resolve(req.id, approved) else false
  }

  /** Rejects whatever is open (used on Stop / new chat). */
  fun rejectAll() {
    _pending.value?.let { resolve(it.id, false) }
  }
}
