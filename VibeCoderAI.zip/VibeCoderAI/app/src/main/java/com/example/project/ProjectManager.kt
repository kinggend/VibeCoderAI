package com.example.project

import android.content.Context
import com.example.data.model.FileItem
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.security.SecurityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class ProjectManager(
  private val context: Context,
  private val securityManager: SecurityManager = SecurityManager()
) {

  private val baseProjectsDir: File by lazy {
    File(context.filesDir, "vibecoder_projects").apply {
      if (!exists()) mkdirs()
    }
  }

  private val _projects = MutableStateFlow<List<Project>>(emptyList())
  val projects: StateFlow<List<Project>> = _projects.asStateFlow()

  private val _activeProject = MutableStateFlow<Project?>(null)
  val activeProject: StateFlow<Project?> = _activeProject.asStateFlow()

  suspend fun initialize() = withContext(Dispatchers.IO) {
    refreshProjects()
    if (_projects.value.isEmpty()) {
      // Create initial starter project
      createProject(
        name = "AndroidDemoApp",
        type = ProjectType.ANDROID_COMPOSE,
        description = "Jetpack Compose starter with Kotlin coroutines & Material 3"
      )
    } else if (_activeProject.value == null) {
      _activeProject.value = _projects.value.first()
    }
  }

  suspend fun refreshProjects() = withContext(Dispatchers.IO) {
    val dirs = baseProjectsDir.listFiles()?.filter { it.isDirectory } ?: emptyList()
    val list = dirs.map { dir ->
      val metaFile = File(dir, ".vibecoder_meta")
      val type = if (File(dir, "build.gradle.kts").exists() || File(dir, "build.gradle").exists()) {
        ProjectType.ANDROID_COMPOSE
      } else if (File(dir, "package.json").exists() && File(dir, "app.json").exists() && File(dir, "package.json").readText().contains("\"expo\"")) {
        ProjectType.REACT_NATIVE
      } else if (File(dir, "package.json").exists()) {
        ProjectType.NODE_CLI
      } else if (File(dir, "index.html").exists()) {
        ProjectType.WEB_HTML
      } else {
        ProjectType.PYTHON_SCRIPT
      }

      val desc = if (metaFile.exists()) metaFile.readText() else "Offline workspace project"
      Project(
        id = dir.name,
        name = dir.name,
        rootPath = dir.absolutePath,
        description = desc,
        type = type,
        createdAt = dir.lastModified(),
        updatedAt = dir.lastModified()
      )
    }
    _projects.value = list
    if (_activeProject.value == null && list.isNotEmpty()) {
      _activeProject.value = list.first()
    }
  }

  suspend fun selectProject(project: Project) {
    _activeProject.value = project
  }

  suspend fun createProject(
    name: String,
    type: ProjectType,
    description: String
  ): Project = withContext(Dispatchers.IO) {
    val sanitizedName = name.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    val projectDir = File(baseProjectsDir, sanitizedName)
    if (!projectDir.exists()) projectDir.mkdirs()

    File(projectDir, ".vibecoder_meta").writeText(description)

    // Populate templates
    when (type) {
      ProjectType.ANDROID_COMPOSE -> populateAndroidComposeTemplate(projectDir, sanitizedName)
      ProjectType.NODE_CLI -> populateNodeTemplate(projectDir, sanitizedName)
      ProjectType.WEB_HTML -> populateWebTemplate(projectDir, sanitizedName)
      ProjectType.PYTHON_SCRIPT -> populatePythonTemplate(projectDir, sanitizedName)
      ProjectType.REACT_NATIVE -> populateReactNativeTemplate(projectDir, sanitizedName)
    }

    val project = Project(
      id = sanitizedName,
      name = sanitizedName,
      rootPath = projectDir.absolutePath,
      description = description,
      type = type
    )

    refreshProjects()
    _activeProject.value = project
    project
  }

  suspend fun renameProject(project: Project, newName: String): Project = withContext(Dispatchers.IO) {
    val sanitized = newName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    val newDir = File(baseProjectsDir, sanitized)
    if (newDir.exists()) {
      throw IllegalArgumentException("A project named '$newName' already exists.")
    }
    project.rootDir.renameTo(newDir)
    val updated = project.copy(
      id = sanitized,
      name = sanitized,
      rootPath = newDir.absolutePath,
      updatedAt = System.currentTimeMillis()
    )
    refreshProjects()
    if (_activeProject.value?.id == project.id) {
      _activeProject.value = updated
    }
    updated
  }

  suspend fun deleteProject(project: Project) = withContext(Dispatchers.IO) {
    project.rootDir.deleteRecursively()
    refreshProjects()
    if (_activeProject.value?.id == project.id) {
      _activeProject.value = _projects.value.firstOrNull()
    }
  }

  fun getFileTree(rootDir: File): FileItem {
    return buildFileTreeItem(rootDir)
  }

  private fun buildFileTreeItem(file: File): FileItem {
    if (!file.isDirectory) {
      return FileItem(
        name = file.name,
        path = file.absolutePath,
        isDirectory = false,
        sizeBytes = file.length(),
        lastModified = file.lastModified()
      )
    }

    val children = file.listFiles()
      // v1.6: .vibecoder (History + undo backups) is app data, not project code: hidden from the explorer.
      ?.filter { !it.name.startsWith(".git") && !it.name.startsWith(".vibecoder_meta") && it.name != ".vibecoder" }
      ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
      ?.map { buildFileTreeItem(it) } ?: emptyList()

    return FileItem(
      name = file.name,
      path = file.absolutePath,
      isDirectory = true,
      sizeBytes = 0,
      lastModified = file.lastModified(),
      children = children
    )
  }

  /**
   * Safe ZIP export: Compresses the project directory into a .zip archive.
   */
  suspend fun exportProjectToZip(project: Project): File = withContext(Dispatchers.IO) {
    val exportDir = File(context.cacheDir, "exports").apply { if (!exists()) mkdirs() }
    val zipFile = File(exportDir, "${project.name}_export.zip")
    if (zipFile.exists()) zipFile.delete()

    ZipOutputStream(BufferedOutputStream(FileOutputStream(zipFile))).use { zos ->
      val projectRoot = project.rootDir
      projectRoot.walkTopDown().forEach { file ->
        if (file.isFile && !file.name.endsWith(".zip")) {
          val relPath = file.relativeTo(projectRoot).path
          zos.putNextEntry(ZipEntry(relPath))
          FileInputStream(file).use { fis ->
            fis.copyTo(zos)
          }
          zos.closeEntry()
        }
      }
    }
    zipFile
  }

  /**
   * Safe ZIP import with strict Zip Slip protection.
   */
  suspend fun importProjectFromZip(zipFile: File, projectName: String): Project = withContext(Dispatchers.IO) {
    val sanitized = projectName.replace(Regex("[^a-zA-Z0-9_-]"), "_")
    val targetDir = File(baseProjectsDir, sanitized)
    // v1.6 fix: importing under an existing name used to merge into (and overwrite files of) that project.
    if (targetDir.exists() && (targetDir.listFiles()?.isNotEmpty() == true)) {
      throw IllegalArgumentException("A project named '$sanitized' already exists. Choose another name.")
    }
    targetDir.mkdirs()

    // v1.4: validated + extracted by ZipImporter (unit tested Zip Slip rejection).
    try {
      ZipImporter.extract(zipFile, targetDir)
    } catch (e: Exception) {
      targetDir.deleteRecursively() // no half-imported project
      throw e
    }

    refreshProjects()
    val project = _projects.value.firstOrNull { it.id == sanitized } ?: Project(
      id = sanitized,
      name = sanitized,
      rootPath = targetDir.absolutePath,
      description = "Imported from ZIP archive",
      type = ProjectType.ANDROID_COMPOSE
    )
    _activeProject.value = project
    project
  }

  fun extractProjectAiContext(project: Project): String {
    val dir = project.rootDir
    val fileCount = dir.walkTopDown().filter { it.isFile }.count()
    val topFiles = dir.walkTopDown()
      .filter { it.isFile && (it.extension in listOf("kt", "java", "kts", "xml", "js", "ts", "py", "html")) }
      .take(15)
      .map { it.relativeTo(dir).path }
      .toList()

    return buildString {
      appendLine("Project: ${project.name} (${project.type.displayName})")
      appendLine("Files Indexed: $fileCount total")
      appendLine("Key Source Files:")
      topFiles.forEach { appendLine(" - $it") }
    }
  }

  private fun populateAndroidComposeTemplate(dir: File, name: String) {
    val srcDir = File(dir, "src/main/java/com/example/demo").apply { mkdirs() }
    val resDir = File(dir, "src/main/res/values").apply { mkdirs() }

    File(srcDir, "MainActivity.kt").writeText(
      """
      package com.example.demo

      import android.os.Bundle
      import androidx.activity.ComponentActivity
      import androidx.activity.compose.setContent
      import androidx.compose.foundation.layout.*
      import androidx.compose.material3.*
      import androidx.compose.runtime.*
      import androidx.compose.ui.Modifier
      import androidx.compose.ui.unit.dp

      class MainActivity : ComponentActivity() {
          override fun onCreate(savedInstanceState: Bundle?) {
              super.onCreate(savedInstanceState)
              setContent {
                  MaterialTheme {
                      Surface(modifier = Modifier.fillMaxSize()) {
                          GreetingScreen(appName = "$name")
                      }
                  }
              }
          }
      }

      @Composable
      fun GreetingScreen(appName: String) {
          var counter by remember { mutableStateOf(0) }
          Column(modifier = Modifier.padding(16.dp)) {
              Text(text = "Welcome to " + appName, style = MaterialTheme.typography.headlineMedium)
              Spacer(modifier = Modifier.height(8.dp))
              Text(text = "Built with VibeCoderAI Kotlin & Jetpack Compose.")
              Spacer(modifier = Modifier.height(16.dp))
              Button(onClick = { counter++ }) {
                  Text("Counter: " + counter)
              }
          }
      }
      """.trimIndent()
    )

    File(dir, "build.gradle.kts").writeText(
      """
      plugins {
          id("com.android.application")
          kotlin("android")
          kotlin("plugin.compose")
      }

      android {
          namespace = "com.example.demo"
          compileSdk = 36
          defaultConfig {
              applicationId = "com.example.demo"
              minSdk = 24
              targetSdk = 36
              versionCode = 1
              versionName = "1.0"
          }
      }

      dependencies {
          implementation(platform("androidx.compose:compose-bom:2024.09.00"))
          implementation("androidx.compose.material3:material3")
          implementation("androidx.compose.ui:ui")
          implementation("androidx.core:core-ktx:1.15.0")
      }
      """.trimIndent()
    )

    File(dir, "settings.gradle.kts").writeText("rootProject.name = \"$name\"\n")
  }

  /** Minimal Expo app: `npx expo start` runs it (this app edits the files; Expo runs on a computer or Expo Go). */
  private fun populateReactNativeTemplate(dir: File, name: String) {
    File(dir, "package.json").writeText(
      """
      {
        "name": "${name.lowercase()}",
        "version": "1.0.0",
        "main": "node_modules/expo/AppEntry.js",
        "scripts": { "start": "expo start", "android": "expo start --android" },
        "dependencies": { "expo": "~51.0.0", "react": "18.2.0", "react-native": "0.74.5" }
      }
      """.trimIndent()
    )
    File(dir, "app.json").writeText("""{ "expo": { "name": "$name", "slug": "${name.lowercase()}", "version": "1.0.0" } }""")
    File(dir, "babel.config.js").writeText(
      """
      module.exports = function (api) {
        api.cache(true);
        return { presets: ['babel-preset-expo'] };
      };
      """.trimIndent()
    )
    File(dir, "App.js").writeText(
      """
      import { useState } from 'react';
      import { StyleSheet, Text, View, Pressable } from 'react-native';

      export default function App() {
        const [count, setCount] = useState(0);
        return (
          <View style={styles.container}>
            <Text style={styles.title}>$name</Text>
            <Pressable style={styles.button} onPress={() => setCount(count + 1)}>
              <Text style={styles.buttonText}>Tapped {count} times</Text>
            </Pressable>
          </View>
        );
      }

      const styles = StyleSheet.create({
        container: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#111' },
        title: { color: '#fff', fontSize: 28, fontWeight: '700', marginBottom: 24 },
        button: { backgroundColor: '#0A84FF', paddingHorizontal: 24, paddingVertical: 14, borderRadius: 24 },
        buttonText: { color: '#fff', fontSize: 16, fontWeight: '600' },
      });
      """.trimIndent()
    )
    File(dir, "README.md").writeText("# $name\nExpo (React Native) app. Run `npm install` then `npx expo start`.\n")
  }

  private fun populateNodeTemplate(dir: File, name: String) {
    File(dir, "package.json").writeText(
      """
      {
        "name": "${name.lowercase()}",
        "version": "1.0.0",
        "description": "VibeCoderAI Node CLI tool",
        "main": "index.js",
        "scripts": {
          "start": "node index.js"
        }
      }
      """.trimIndent()
    )
    File(dir, "index.js").writeText(
      """
      console.log("Running $name CLI tool powered by VibeCoderAI!");
      console.log("Arguments:", process.argv.slice(2));
      """.trimIndent()
    )
    File(dir, "README.md").writeText("# $name\nA high-performance CLI utility.\n")
  }

  private fun populateWebTemplate(dir: File, name: String) {
    File(dir, "index.html").writeText(
      """
      <!DOCTYPE html>
      <html lang="en">
      <head>
          <meta charset="UTF-8">
          <title>$name</title>
          <link rel="stylesheet" href="styles.css">
      </head>
      <body>
          <div class="container">
              <h1>$name</h1>
              <p>Built with VibeCoderAI.</p>
              <button id="btn">Click Me</button>
              <div id="output"></div>
          </div>
          <script src="app.js"></script>
      </body>
      </html>
      """.trimIndent()
    )
    File(dir, "styles.css").writeText(
      """
      body { font-family: sans-serif; background: #0d1117; color: #f0f6fc; margin: 0; padding: 2rem; }
      .container { max-width: 600px; margin: auto; }
      button { background: #38bdf8; color: #000; border: none; padding: 10px 18px; border-radius: 6px; cursor: pointer; }
      """.trimIndent()
    )
    File(dir, "app.js").writeText(
      """
      document.getElementById('btn').addEventListener('click', () => {
          document.getElementById('output').textContent = 'VibeCoderAI Interactive JS initialized!';
      });
      """.trimIndent()
    )
  }

  private fun populatePythonTemplate(dir: File, name: String) {
    File(dir, "main.py").writeText(
      """
      # $name Automation Script
      import sys

      def main():
          print("Initializing $name via VibeCoderAI runtime...")
          print(f"Python interpreter: {sys.version}")

      if __name__ == '__main__':
          main()
      """.trimIndent()
    )
    File(dir, "requirements.txt").writeText("# Add dependencies here\n")
  }
}
