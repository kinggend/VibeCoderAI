package com.example.llama

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.asSharedFlow

/**
 * v1.4: bridge from Activity.onTrimMemory to the UI that owns the model. When Android reports
 * TRIM_MEMORY_RUNNING_CRITICAL or TRIM_MEMORY_COMPLETE the screen unloads the model (unless it is
 * generating) and tells the user, instead of letting the low-memory killer take the whole app.
 */
object MemoryPressure {
  private val _events = MutableSharedFlow<Int>(extraBufferCapacity = 4)
  val events: SharedFlow<Int> = _events.asSharedFlow()

  @Suppress("DEPRECATION")
  fun isCritical(level: Int): Boolean =
    level == android.content.ComponentCallbacks2.TRIM_MEMORY_RUNNING_CRITICAL ||
      level >= android.content.ComponentCallbacks2.TRIM_MEMORY_COMPLETE

  fun onTrimMemory(level: Int) {
    if (isCritical(level)) _events.tryEmit(level)
  }
}
