package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.sizeIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.Dp
import com.example.ui.theme.TextMuted
import com.example.ui.theme.UiTokens

/**
 * Icon-only action button with a guaranteed >= 44 dp touch target. Uses the app-wide press
 * indication (spring scale, opacity dip and haptic tick) instead of the Material ripple.
 */
@Composable
fun ActionIconButton(
  icon: ImageVector,
  contentDescription: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  tint: Color = TextMuted,
  enabled: Boolean = true,
  iconSize: Dp = UiTokens.ActionIconSize,
  containerColor: Color = Color.Transparent,
  size: Dp = UiTokens.MinTouchTarget
) {
  Box(
    modifier = modifier
      .sizeIn(minWidth = UiTokens.MinTouchTarget, minHeight = UiTokens.MinTouchTarget)
      .size(size)
      .clip(CircleShape)
      .background(containerColor)
      .clickable(enabled = enabled, role = Role.Button, onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(
      imageVector = icon,
      contentDescription = contentDescription,
      tint = if (enabled) tint else tint.copy(alpha = 0.38f),
      modifier = Modifier.size(iconSize)
    )
  }
}
