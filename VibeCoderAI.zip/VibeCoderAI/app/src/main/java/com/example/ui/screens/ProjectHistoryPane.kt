package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.HistoryEntry
import com.example.agent.ProjectBackups
import com.example.agent.ProjectHistory
import com.example.ui.components.Button
import com.example.ui.components.GlassAlertDialog
import com.example.ui.components.TextButton
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** v1.5: Files / History switch above the project workspace. */
@Composable
internal fun ProjectPaneSwitch(pane: Int, onChange: (Int) -> Unit, modifier: Modifier = Modifier) {
  val reduced = rememberReducedMotion()
  Row(
    modifier = modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).padding(3.dp),
    horizontalArrangement = Arrangement.spacedBy(3.dp)
  ) {
    // v1.6: Files / Search / History.
    listOf(0 to "Files", 1 to "Search", 2 to "History").forEach { (isHistory, label) ->
      val sel = pane == isHistory
      val bg by animateColorAsState(if (sel) CyberCyanPrimary else Color.Transparent, motion(reduced, 180), label = "paneBg")
      Box(
        modifier = Modifier
          .weight(1f)
          .heightIn(min = 48.dp)
          .clip(CircleShape)
          .background(bg)
          .semantics { selected = sel }
          .clickable(role = Role.Tab) { onChange(isHistory) },
        contentAlignment = Alignment.Center
      ) { Text(label, color = if (sel) Color.White else TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
  }
}

/**
 * v1.5: what the agent did to [root] (newest first) and "Undo last run", which restores the zip taken
 * before the latest autonomous run. [agentBusy] disables undo while the agent is still writing.
 */
@Composable
internal fun ProjectHistoryPane(root: File, agentBusy: Boolean, onRestored: () -> Unit, modifier: Modifier = Modifier) {
  val scope = rememberCoroutineScope()
  var refresh by remember { mutableIntStateOf(0) }
  var entries by remember(root) { mutableStateOf<List<HistoryEntry>?>(null) }
  var latest by remember(root) { mutableStateOf<File?>(null) }
  var confirm by remember { mutableStateOf(false) }
  var result by remember { mutableStateOf<String?>(null) }
  var restoring by remember { mutableStateOf(false) }
  LaunchedEffect(root, refresh, agentBusy) {
    val (e, l) = withContext(Dispatchers.IO) { ProjectHistory.read(root) to ProjectBackups.latest(root) }
    entries = e; latest = l
  }
  val time = remember { SimpleDateFormat("d MMM, HH:mm:ss", Locale.getDefault()) }

  Column(modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    Row(
      Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(ObsidianSurface).padding(12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(Modifier.weight(1f).padding(end = 8.dp)) {
        Text("Undo last run", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(
          when {
            agentBusy -> "Available when the agent finishes."
            latest != null -> "Restores files to ${time.format(Date(ProjectBackups.takenAt(latest!!)))}."
            else -> "No snapshot yet. One is saved before each autonomous run."
          },
          color = TextMuted, fontSize = 12.5.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight
        )
      }
      Button(
        onClick = { confirm = true },
        enabled = latest != null && !agentBusy && !restoring,
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
        modifier = Modifier.heightIn(min = 48.dp)
      ) { Text("Undo", fontWeight = FontWeight.SemiBold) }
    }

    val list = entries
    when {
      list == null -> Text("Loading…", color = TextMuted, fontSize = 13.sp)
      list.isEmpty() -> Text(
        "Nothing yet. Files the agent creates, changes or deletes, and the commands it runs, show up here.",
        color = TextMuted, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(8.dp)
      )
      else -> LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        items(list) { e -> HistoryRow(e, time.format(Date(e.ts))) }
      }
    }
  }

  if (confirm) {
    GlassAlertDialog(
      onDismissRequest = { confirm = false },
      title = { Text("Undo last run?") },
      text = { Text("Project files go back to how they were before the last autonomous run. Changes made since then, including your own edits, are lost.") },
      confirmButton = {
        TextButton(onClick = {
          confirm = false
          val snap = latest
          if (snap != null) scope.launch {
            restoring = true
            val ok = withContext(Dispatchers.IO) {
              ProjectBackups.restore(root, snap).also {
                ProjectHistory.record(root, HistoryEntry.UNDO, "Restored snapshot", it, snap.name)
              }
            }
            restoring = false
            result = if (ok) "Files restored." else "Could not restore the snapshot. Nothing was changed."
            if (ok) onRestored()
            refresh++
          }
        }) { Text("Undo run", color = CyberCoralError) }
      },
      dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel") } }
    )
  }
  result?.let {
    GlassAlertDialog(
      onDismissRequest = { result = null },
      title = { Text("Undo last run") },
      text = { Text(it) },
      confirmButton = { TextButton(onClick = { result = null }) { Text("OK") } }
    )
  }
}

@Composable
private fun HistoryRow(e: HistoryEntry, time: String) {
  val (label, tint) = when (e.type) {
    HistoryEntry.CREATED -> "Created" to CyberGreenSuccess
    HistoryEntry.MODIFIED -> "Modified" to CyberCyanPrimary
    HistoryEntry.DELETED -> "Deleted" to CyberAmberWarning
    HistoryEntry.COMMAND -> "Command" to TextSecondary
    HistoryEntry.RUN -> "Run started" to TextSecondary
    HistoryEntry.UNDO -> "Undo" to CyberAmberWarning
    HistoryEntry.TOOL -> "Agent looked" to TextSecondary
    HistoryEntry.RENAMED -> "Renamed" to CyberCyanPrimary
    HistoryEntry.MOVED -> "Moved" to CyberCyanPrimary
    HistoryEntry.REPLACE -> "Replace all" to CyberCyanPrimary
    HistoryEntry.PUSH -> "GitHub push" to CyberCyanPrimary
    else -> e.type to TextSecondary
  }
  Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.Top) {
    Box(Modifier.padding(top = 6.dp).size(8.dp).clip(CircleShape).background(tint))
    Column(Modifier.weight(1f).padding(start = 10.dp)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        e.ok?.let { ok ->
          Text(
            if (ok) "pass" else "fail",
            color = if (ok) CyberGreenSuccess else CyberCoralError,
            fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(start = 8.dp)
          )
        }
        Text(time, color = TextMuted, fontSize = 12.sp, modifier = Modifier.weight(1f).padding(start = 8.dp), maxLines = 1,
          textAlign = androidx.compose.ui.text.style.TextAlign.End)
      }
      if (e.target.isNotBlank()) Text(e.target, color = TextSecondary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, maxLines = 2, overflow = TextOverflow.Ellipsis)
      if (e.detail.isNotBlank()) Text(e.detail, color = TextMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
    }
  }
}
