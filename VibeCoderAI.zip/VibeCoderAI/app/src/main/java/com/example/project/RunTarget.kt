package com.example.project

/** What the chat's quick-run button does for a project. Pure so it is unit-tested. */
sealed class RunTarget {
  abstract val label: String
  /** A web page: open the in-app preview. */
  object Preview : RunTarget() { override val label = "Preview" }
  /** A program: run [command] in the project folder and show its output right in the chat. */
  data class Command(val command: String, override val label: String = "Run") : RunTarget()
}

object RunTargets {
  /** [files] are the project's top-level file names; [packageJson] is the text of package.json when present. */
  fun detect(files: Collection<String>, packageJson: String?): RunTarget? {
    val names = files.toSet()
    if ("index.html" in names) return RunTarget.Preview
    if ("package.json" in names && packageJson != null && Regex(""""start"\s*:""").containsMatchIn(packageJson)) {
      return RunTarget.Command("npm start")
    }
    for (js in listOf("index.js", "main.js", "app.js")) if (js in names) return RunTarget.Command("node $js")
    for (py in listOf("main.py", "app.py")) if (py in names) return RunTarget.Command("python3 $py")
    return null
  }
}
