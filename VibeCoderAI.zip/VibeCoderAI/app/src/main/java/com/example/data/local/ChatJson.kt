package com.example.data.local

import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import org.json.JSONArray
import org.json.JSONObject

/** v1.4: the message <-> JSON mapping shared by the old file store (migration source) and Room. */
object ChatJson {
  fun parseMessage(o: JSONObject): ChatMessage {
    val changes = o.optJSONArray("changes")?.let { ca ->
      (0 until ca.length()).map { j ->
        val c = ca.getJSONObject(j)
        FileChange(
          path = c.getString("path"),
          content = c.optString("content"),
          isNew = c.optBoolean("isNew"),
          status = ChangeStatus.valueOf(c.optString("status", "APPLIED")),
          savedLines = c.optInt("lines", 0)
        )
      }
    } ?: emptyList()
    return ChatMessage(
      id = o.getString("id"),
      sender = MessageSender.valueOf(o.getString("sender")),
      content = o.getString("content"),
      timestamp = o.optLong("ts"),
      thoughts = if (o.optBoolean("note")) "note" else null,
      reasoning = o.optString("reasoning").ifEmpty { null },
      fileChanges = changes
    )
  }

  fun toJson(m: ChatMessage): JSONObject {
    val o = JSONObject()
      .put("id", m.id)
      .put("sender", m.sender.name)
      .put("content", m.content)
      .put("ts", m.timestamp)
    if (m.thoughts == "note") o.put("note", true)
    m.reasoning?.let { o.put("reasoning", it) }
    if (m.fileChanges.isNotEmpty()) {
      val ca = JSONArray()
      m.fileChanges.forEach { c ->
        val co = JSONObject().put("path", c.path).put("isNew", c.isNew).put("status", c.status.name).put("lines", c.lineCount)
        if (c.status == ChangeStatus.PENDING) co.put("content", c.content) // needed to apply later
        ca.put(co)
      }
      o.put("changes", ca)
    }
    return o
  }

  /** File changes only, as stored in Room's changes_json column (pending ones keep their content). */
  fun changesToJson(changes: List<FileChange>): String? {
    if (changes.isEmpty()) return null
    val ca = JSONArray()
    changes.forEach { c ->
      val co = JSONObject().put("path", c.path).put("isNew", c.isNew).put("status", c.status.name).put("lines", c.lineCount)
      if (c.status == ChangeStatus.PENDING) co.put("content", c.content)
      ca.put(co)
    }
    return ca.toString()
  }

  fun changesFromJson(json: String?): List<FileChange> {
    if (json.isNullOrBlank()) return emptyList()
    return runCatching {
      val ca = JSONArray(json)
      (0 until ca.length()).map { j ->
        val c = ca.getJSONObject(j)
        FileChange(
          path = c.getString("path"),
          content = c.optString("content"),
          isNew = c.optBoolean("isNew"),
          status = runCatching { ChangeStatus.valueOf(c.optString("status", "APPLIED")) }.getOrDefault(ChangeStatus.APPLIED),
          savedLines = c.optInt("lines", 0)
        )
      }
    }.getOrDefault(emptyList())
  }
}
