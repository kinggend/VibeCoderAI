package com.example.agent

/**
 * v1.6.3: deterministic cross-file check. Finds ids and classes the JavaScript looks up
 * (getElementById, querySelector, getElementsByClassName) that index.html never defines and the
 * script never creates. Pure logic so it is unit-tested.
 */
object DomCheck {
  data class Problem(val file: String, val line: Int, val kind: Char, val name: String) {
    /** "app.js:25 uses #board but index.html has no id="board"" */
    val message: String
      get() = if (kind == '#') "$file:$line uses #$name but index.html has no id=\"$name\""
      else "$file:$line uses .$name but index.html has no class=\"$name\""
  }

  private val HTML_ID = Regex("""\bid\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
  private val HTML_CLASS = Regex("""\bclass\s*=\s*["']([^"']+)["']""", RegexOption.IGNORE_CASE)
  private val BY_ID = Regex("""getElementById\(\s*(["'`])((?:(?!\1)[^$\n])+)\1\s*\)""")
  private val BY_CLASS = Regex("""getElementsByClassName\(\s*(["'`])((?:(?!\1)[^$\n])+)\1\s*\)""")
  private val QUERY = Regex("""querySelector(?:All)?\(\s*(["'`])((?:(?!\1)[^$\n])+)\1\s*\)""")
  private val SEL_TOKEN = Regex("""([#.])([A-Za-z_][\w-]*)""")
  // Ids / classes the script creates itself, so a lookup of them is not a missing element.
  private val JS_ID_SET = Regex("""\.id\s*=\s*["'`]([\w-]+)["'`]|setAttribute\(\s*["']id["']\s*,\s*["'`]([\w-]+)["'`]""")
  private val JS_CLASS_SET = Regex("""classList\.(?:add|toggle)\(([^)]*)\)|className\s*=\s*["'`]([^"'`]+)["'`]|setAttribute\(\s*["']class["']\s*,\s*["'`]([^"'`]+)["'`]""")
  private val QUOTED = Regex("""["'`]([\w-]+)["'`]""")

  fun ids(html: String): Set<String> = HTML_ID.findAll(html).map { it.groupValues[1].trim() }.filter { it.isNotEmpty() }.toSet()

  fun classes(html: String): Set<String> =
    HTML_CLASS.findAll(html).flatMap { it.groupValues[1].trim().split(Regex("\\s+")).asSequence() }.filter { it.isNotEmpty() }.toSet()

  /** Ids and classes the script defines on its own (including id="x" inside template strings). */
  private fun created(js: String): Pair<Set<String>, Set<String>> {
    val idSet = mutableSetOf<String>()
    val clsSet = mutableSetOf<String>()
    JS_ID_SET.findAll(js).forEach { m -> (m.groupValues[1].ifEmpty { m.groupValues[2] }).takeIf { it.isNotEmpty() }?.let { idSet += it } }
    JS_CLASS_SET.findAll(js).forEach { m ->
      if (m.groupValues[1].isNotEmpty()) QUOTED.findAll(m.groupValues[1]).forEach { clsSet += it.groupValues[1] }
      (m.groupValues[2].ifEmpty { m.groupValues[3] }).split(Regex("\\s+")).filter { it.isNotEmpty() }.forEach { clsSet += it }
    }
    idSet += ids(js)
    clsSet += classes(js)
    return idSet to clsSet
  }

  /** Every lookup in [js] (named [jsName]) of an id or class missing from [html]. One problem per name. */
  fun check(html: String, js: String, jsName: String = "app.js"): List<Problem> {
    val htmlIds = ids(html)
    val htmlClasses = classes(html)
    val (jsIds, jsClasses) = created(js)
    val out = linkedMapOf<String, Problem>()
    js.lines().forEachIndexed { i, line ->
      val n = i + 1
      fun add(kind: Char, name: String) {
        val known = if (kind == '#') name in htmlIds || name in jsIds else name in htmlClasses || name in jsClasses
        if (!known) out.putIfAbsent("$kind$name", Problem(jsName, n, kind, name))
      }
      BY_ID.findAll(line).forEach { add('#', it.groupValues[2].trim()) }
      BY_CLASS.findAll(line).forEach { m -> m.groupValues[2].trim().split(Regex("\\s+")).filter { it.isNotEmpty() }.forEach { add('.', it) } }
      QUERY.findAll(line).forEach { m ->
        // Only the first compound of each selector part ("#board .cell" checks #board and .cell).
        SEL_TOKEN.findAll(m.groupValues[2].replace(Regex("""\[[^\]]*]|:[\w-]+(\([^)]*\))?"""), "")).forEach { t -> add(t.groupValues[1][0], t.groupValues[2]) }
      }
    }
    return out.values.toList()
  }
}

/**
 * v1.6.3: repair prompt for an existing project. Small enough for a 2048-token context: the test
 * errors, the cross-file problems, index.html's ids and classes, and the failing lines ±10 with line
 * numbers, instead of whole files.
 */
object RepairPrompt {
  private val LINE = Regex("""\(line (\d+)\)""")
  private val FILE_LINE = Regex("""([\w./-]+\.(?:js|mjs|html)):(\d+)""")

  /** Line numbers (1-based) the test errors and DOM problems point at, per file. */
  fun targets(errors: List<String>, problems: List<DomCheck.Problem>, mainJs: String): Map<String, List<Int>> {
    val out = linkedMapOf<String, MutableList<Int>>()
    for (e in errors) {
      val fl = FILE_LINE.find(e)
      if (fl != null) { out.getOrPut(fl.groupValues[1].substringAfterLast('/')) { mutableListOf() } += fl.groupValues[2].toInt(); continue }
      LINE.find(e)?.let { out.getOrPut(mainJs) { mutableListOf() } += it.groupValues[1].toInt() }
    }
    for (p in problems) out.getOrPut(p.file) { mutableListOf() } += p.line
    return out.mapValues { it.value.distinct() }
  }

  /** Lines [line]-[radius]..[line]+[radius] of [text], numbered ("25| board.innerHTML = ..."). */
  fun window(text: String, line: Int, radius: Int = 10): String {
    val lines = text.lines()
    if (lines.isEmpty() || line < 1) return ""
    val from = (line - radius).coerceAtLeast(1)
    val to = (line + radius).coerceAtMost(lines.size)
    if (from > to) return ""
    return (from..to).joinToString("\n") { n -> "$n| ${lines[n - 1]}" }
  }

  private val NUM_PREFIX = Regex("""^\s*\d+\|\s?""")

  /**
   * Small models copy the "25| " line numbers of the prompt into <find>/<replace>. When every
   * non-blank line carries one, they are removed.
   */
  fun stripLineNumbers(text: String): String {
    val lines = text.lines()
    val nonBlank = lines.filter { it.isNotBlank() }
    if (nonBlank.isEmpty() || !nonBlank.all { NUM_PREFIX.containsMatchIn(it) }) return text
    return lines.joinToString("\n") { it.replaceFirst(NUM_PREFIX, "") }
  }

  /**
   * The exact text of [original] that [find] means when it only differs in indentation or trailing
   * spaces (each line compared trimmed). Returns it only when there is exactly one such place.
   */
  fun looseFind(original: String, find: String): String? {
    val want = find.lines().map { it.trim() }.dropWhile { it.isEmpty() }.dropLastWhile { it.isEmpty() }
    if (want.isEmpty() || want.joinToString("").length < 4) return null
    val lines = original.lines()
    val hits = (0..lines.size - want.size).filter { i -> want.indices.all { k -> lines[i + k].trim() == want[k] } }
    if (hits.size != 1) return null
    return lines.subList(hits[0], hits[0] + want.size).joinToString("\n")
  }

  /** The JavaScript file index.html loads first, else app.js. */
  fun mainJs(html: String): String = PlanCheck.referencedLocal(html).firstOrNull { it.endsWith(".js") || it.endsWith(".mjs") } ?: "app.js"

  /**
   * Builds the repair task. [files] maps project paths to their text; [budget] is the character budget
   * (lower-priority parts are dropped first: extra windows, then the class list).
   */
  fun build(complaint: String?, errors: List<String>, files: Map<String, String>, budget: Int = 3600): String {
    val html = files["index.html"].orEmpty()
    val js = mainJs(html)
    val problems = files.filterKeys { it.endsWith(".js") || it.endsWith(".mjs") }.flatMap { (name, text) -> DomCheck.check(html, text, name) }
    val head = buildString {
      append("Repair mode. Fix the EXISTING project. Do not plan, redesign or rewrite whole files. ")
      append("Change only the lines that cause these problems.\n")
      if (!complaint.isNullOrBlank()) append("User: ").append(complaint.lineSequence().first().take(200)).append("\n")
      if (errors.isNotEmpty()) append("Test errors:\n").append(errors.take(5).joinToString("\n") { "- " + it.take(220) }).append("\n")
      if (problems.isNotEmpty()) append("Cross-file problems:\n").append(problems.take(6).joinToString("\n") { "- " + it.message }).append("\n")
      append("index.html ids: ").append(DomCheck.ids(html).take(40).joinToString(", ").ifEmpty { "(none)" }).append("\n")
    }
    val classes = "index.html classes: " + DomCheck.classes(html).take(30).joinToString(", ").ifEmpty { "(none)" } + "\n"
    val tail = "Answer with EditFile tools only, one per change, find text copied exactly from the lines above (without the line numbers):\n" +
      "<tool name=\"EditFile\" path=\"$js\"><find>exact current text</find><replace>new text</replace></tool>\n" +
      "If an element is missing, either fix the id in the script or add the element to index.html with EditFile."
    val windows = targets(errors, problems, js).flatMap { (file, lines) ->
      val text = files[file] ?: return@flatMap emptyList()
      lines.take(3).map { "$file lines around $it:\n" + window(text, it) + "\n" }
    }
    val sb = StringBuilder(head)
    var used = head.length + tail.length
    if (used + classes.length < budget) { sb.append(classes); used += classes.length }
    for (w in windows) {
      if (used + w.length > budget) {
        // Always keep at least the first failing window, trimmed to ±5 lines if needed.
        if (w === windows.first()) {
          val small = w.lines().let { l -> if (l.size > 12) (listOf(l.first()) + l.drop(1).drop(5).dropLast(6)).joinToString("\n") + "\n" else w }
          sb.append(small.take((budget - used).coerceAtLeast(300))); used += small.length
        }
        continue
      }
      sb.append(w); used += w.length
    }
    return sb.append(tail).toString()
  }
}

/** v1.6.3: an edit that throws away a large part of a file is never written without the user seeing it. */
object ShrinkGuard {
  const val MAX_SHRINK = 0.40
  private const val MIN_LINES = 10

  /** A warning when [new] has more than 40% fewer lines than [old] (files under 10 lines are ignored). */
  fun warning(path: String, old: String, new: String): String? {
    if (old.isBlank()) return null
    val a = old.trimEnd().lines().size
    val b = if (new.isBlank()) 0 else new.trimEnd().lines().size
    if (a < MIN_LINES || b >= a) return null
    val drop = (a - b).toDouble() / a
    if (drop <= MAX_SHRINK) return null
    return "$path would shrink from $a to $b lines (-${(drop * 100).toInt()}%). Check the diff before approving: code may be lost."
  }
}
