package com.example.agent

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.AppGraph
import com.example.MainActivity
import com.example.R
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

/**
 * v1.6.2: keeps a running agent alive while the app is in the background. Shows an ongoing
 * notification ("VibeCoder is building <project> · step x of y") with Stop; tapping it opens the chat.
 * Holds a partial wake lock only while a run is going, so on-device generation keeps going with the
 * screen off. Started when a run starts (always from the foreground), stopped when it ends, errors or
 * is cancelled. It never approves anything: an approval while the app is hidden posts "Needs your
 * approval" and the run waits.
 */
class AgentRunService : Service() {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
  private var wakeLock: PowerManager.WakeLock? = null
  private var watching = false
  @Volatile private var lastStartId = 0

  override fun onBind(intent: Intent?): IBinder? = null

  override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
    val g = AppGraph.get(this)
    lastStartId = startId
    if (intent?.action == ACTION_STOP) {
      g.orchestrator.stop()
      // Still running for a moment while the run unwinds; the watcher below stops the service then.
      if (!g.orchestrator.runs.isRunning) stopSelf(startId)
      if (!watching) return START_NOT_STICKY
    }
    ServiceCompat.startForeground(
      this, ID_RUN, runNotification(this, g.orchestrator.runs.state.value),
      if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
    )
    refreshWakeLock()
    if (!watching) {
      watching = true
      scope.launch {
        g.orchestrator.runs.state.collectLatest { p ->
          if (!p.running) {
            // Only stops when no newer start (a new run) arrived meanwhile.
            stopSelf(lastStartId)
            return@collectLatest
          }
          refreshWakeLock()
          notify(this@AgentRunService, ID_RUN, runNotification(this@AgentRunService, p))
          delay(700) // Android drops notification updates sent faster than this
        }
      }
    }
    // Not restarted by Android after a kill: the run (and its coroutine) died with the process.
    return START_NOT_STICKY
  }

  /** Timed partial wake lock, renewed on every progress update, so a stuck run cannot hold it forever. */
  private fun refreshWakeLock() {
    val lock = wakeLock ?: (getSystemService(Context.POWER_SERVICE) as PowerManager)
      .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "VibeCoder:agentRun").apply { setReferenceCounted(false) }
      .also { wakeLock = it }
    runCatching { lock.acquire(WAKE_MS) }
  }

  override fun onDestroy() {
    scope.cancel()
    runCatching { wakeLock?.takeIf { it.isHeld }?.release() }
    wakeLock = null
    ServiceCompat.stopForeground(this, ServiceCompat.STOP_FOREGROUND_REMOVE)
    super.onDestroy()
  }

  companion object {
    const val ACTION_STOP = "com.example.agent.action.STOP_RUN"
    const val EXTRA_OPEN_CHAT = "com.example.extra.OPEN_CHAT"
    private const val CH_RUN = "agent_run"
    private const val CH_APPROVAL = "agent_approval"
    private const val ID_RUN = 4201
    private const val ID_APPROVAL = 4202
    private const val WAKE_MS = 20 * 60 * 1000L

    /**
     * Called once per process (AppGraph): starts the service when a run starts and posts or clears
     * the approval notification while the app is hidden.
     */
    fun watch(g: AppGraph) {
      val app = g.app
      g.scope.launch {
        g.orchestrator.runs.state.map { it.running }.distinctUntilChanged().collect { running ->
          if (running) runCatching {
            ContextCompat.startForegroundService(app, Intent(app, AgentRunService::class.java))
          }.onFailure { com.example.llama.LlamaBridge.safeLog("Agent run service did not start (run continues while the app is open)", it) }
          else cancel(app, ID_APPROVAL)
        }
      }
      g.scope.launch {
        combine(g.orchestrator.approvals.pending, g.orchestrator.inputs.pending, g.visibleFlow) { a, i, visible ->
          Triple(a?.title, i != null, visible)
        }.collect { (approvalTitle, needsInput, visible) ->
          if (!visible && (approvalTitle != null || needsInput)) {
            notify(app, ID_APPROVAL, approvalNotification(app, approvalTitle ?: "The agent is asking you a question"))
          } else cancel(app, ID_APPROVAL)
        }
      }
    }

    private fun channels(ctx: Context) {
      if (Build.VERSION.SDK_INT < 26) return
      val nm = ctx.getSystemService(NotificationManager::class.java)
      if (nm.getNotificationChannel(CH_RUN) == null) nm.createNotificationChannel(
        NotificationChannel(CH_RUN, "Agent runs", NotificationManager.IMPORTANCE_LOW).apply {
          description = "Shows what the agent is doing while it builds in the background."
        }
      )
      if (nm.getNotificationChannel(CH_APPROVAL) == null) nm.createNotificationChannel(
        NotificationChannel(CH_APPROVAL, "Agent approvals", NotificationManager.IMPORTANCE_HIGH).apply {
          description = "The agent is waiting for you to approve a change or answer a question."
        }
      )
    }

    private fun openChat(ctx: Context): PendingIntent = PendingIntent.getActivity(
      ctx, 0,
      Intent(ctx, MainActivity::class.java)
        .putExtra(EXTRA_OPEN_CHAT, true)
        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP),
      PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    internal fun runNotification(ctx: Context, p: AgentRunManager.Progress): Notification {
      channels(ctx)
      val (title, text) = p.notificationText()
      val stop = PendingIntent.getService(
        ctx, 1, Intent(ctx, AgentRunService::class.java).setAction(ACTION_STOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
      )
      return NotificationCompat.Builder(ctx, CH_RUN)
        .setSmallIcon(R.drawable.ic_stat_agent)
        .setContentTitle(title)
        .setContentText(text)
        .setStyle(NotificationCompat.BigTextStyle().bigText(text))
        .setOngoing(true)
        .setOnlyAlertOnce(true)
        .setSilent(true)
        .setCategory(NotificationCompat.CATEGORY_PROGRESS)
        .setForegroundServiceBehavior(NotificationCompat.FOREGROUND_SERVICE_IMMEDIATE)
        .setProgress(p.total.coerceAtLeast(0), p.step.coerceAtMost(p.total), p.total <= 1)
        .setContentIntent(openChat(ctx))
        .addAction(0, "Stop", stop)
        .build()
    }

    private fun approvalNotification(ctx: Context, title: String): Notification {
      channels(ctx)
      return NotificationCompat.Builder(ctx, CH_APPROVAL)
        .setSmallIcon(R.drawable.ic_stat_agent)
        .setContentTitle("Needs your approval")
        .setContentText(title)
        .setStyle(NotificationCompat.BigTextStyle().bigText("$title\nThe run waits until you answer. Nothing is approved automatically."))
        .setPriority(NotificationCompat.PRIORITY_HIGH)
        .setCategory(NotificationCompat.CATEGORY_REMINDER)
        .setAutoCancel(true)
        .setContentIntent(openChat(ctx))
        .build()
    }

    /** Posting without POST_NOTIFICATIONS (Android 13+) is a no-op; never crash the run over it. */
    private fun notify(ctx: Context, id: Int, n: Notification) {
      runCatching { ctx.getSystemService(NotificationManager::class.java).notify(id, n) }
    }

    private fun cancel(ctx: Context, id: Int) {
      runCatching { ctx.getSystemService(NotificationManager::class.java).cancel(id) }
    }
  }
}
