package com.example.patch

/** Outcome of a pure text edit: the new text, or why the edit was refused. */
sealed class EditResult {
  data class Ok(val text: String, val line: Int) : EditResult()
  data class Fail(val reason: String) : EditResult()
}

/**
 * v1.4 EditFile: exact find/replace. Refuses when [find] is empty, missing, or matches more than once,
 * so an edit can never land somewhere the model did not mean. Pure: no I/O, unit tested.
 */
object EditFileEngine {

  /** Non-overlapping occurrences of [needle] in [hay]. */
  fun countOccurrences(hay: String, needle: String): Int {
    if (needle.isEmpty()) return 0
    var count = 0
    var from = 0
    while (true) {
      val i = hay.indexOf(needle, from)
      if (i < 0) return count
      count++
      from = i + needle.length
    }
  }

  fun apply(original: String, find: String, replace: String): EditResult {
    if (find.isEmpty()) return EditResult.Fail("EditFile needs non-empty <find> text.")
    var f = find
    var r = replace
    var n = countOccurrences(original, f)
    // Files saved with CRLF: the model writes LF. Retry with CRLF line endings.
    if (n == 0 && original.contains("\r\n") && f.contains('\n') && !f.contains("\r\n")) {
      f = f.replace("\n", "\r\n")
      r = r.replace("\r\n", "\n").replace("\n", "\r\n")
      n = countOccurrences(original, f)
    }
    return when {
      n == 0 -> EditResult.Fail("Find text not found. Read the file and copy the exact text.")
      n > 1 -> EditResult.Fail("Find text matches $n places. Include more surrounding lines so it is unique.")
      else -> {
        val idx = original.indexOf(f)
        val line = original.substring(0, idx).count { it == '\n' } + 1
        EditResult.Ok(original.substring(0, idx) + r + original.substring(idx + f.length), line)
      }
    }
  }
}
