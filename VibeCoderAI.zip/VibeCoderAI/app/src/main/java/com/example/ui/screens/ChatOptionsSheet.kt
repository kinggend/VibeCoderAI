package com.example.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentRoles
import com.example.data.model.OutputLevel
import com.example.data.model.SettingsState
import com.example.data.model.withLevel
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * v1.6.1: one sheet for the four chat settings that used to be separate composer chips: agent, Think,
 * output size and model. Every change is saved at once; Model and Voice close this sheet first.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun ChatOptionsSheet(
  settings: SettingsState,
  modelLabel: String,
  onSettingsChange: (SettingsState) -> Unit,
  onOpenModelPicker: () -> Unit,
  onOpenVoice: () -> Unit,
  onDismiss: () -> Unit,
  /** v1.7.0: Phone agent row; [phoneOn] shows its state. */
  phoneOn: Boolean = false,
  onOpenPhone: () -> Unit = {}
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  fun closeThen(after: () -> Unit) {
    scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss(); after() }
  }
  val level = OutputLevel.from(settings.outputLevel)
  val role = AgentRoles.from(settings.agentRole)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    modifier = Modifier.border(1.dp, com.example.ui.components.GlassPopupColors.rim(), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    scrimColor = Color.Black.copy(alpha = if (com.example.ui.theme.Palette.dark) 0.45f else 0.25f),
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 20.dp)
        .padding(bottom = 16.dp)
        .navigationBarsPadding()
    ) {
      Text("Chat options", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(14.dp))

      SectionLabel("AGENT")
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AgentRoles.all.forEach { r ->
          OptionPill(r.name, selected = r.id == settings.agentRole) { onSettingsChange(settings.copy(agentRole = r.id)) }
        }
      }
      Text(role.blurb, color = TextMuted, fontSize = 12.5.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 6.dp))
      Spacer(Modifier.height(16.dp))

      SectionLabel("OUTPUT SIZE")
      FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        OutputLevel.values().forEach { l ->
          OptionPill(l.label, selected = l == level) { onSettingsChange(settings.withLevel(l)) }
        }
      }
      Text("${level.blurb} ${level.context} ctx · up to ${level.maxOut} tokens out.", color = TextMuted, fontSize = 12.5.sp, lineHeight = 16.sp, modifier = Modifier.padding(top = 6.dp))
      Spacer(Modifier.height(12.dp))

      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(14.dp))
          .toggleable(value = settings.thinking, role = Role.Switch) { onSettingsChange(settings.copy(thinking = it)) }
          .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
          .padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        RowIcon(Icons.Default.Psychology)
        Column(Modifier.weight(1f)) {
          Text("Think", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
          Text("Reason step by step before answering. Slower.", color = TextMuted, fontSize = 12.sp)
        }
        Switch(
          checked = settings.thinking,
          onCheckedChange = null, // the whole row toggles, so TalkBack reads one switch
          colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White)
        )
      }
      OptDivider()
      NavRowSimple(Icons.Default.Memory, "Model", modelLabel) { closeThen(onOpenModelPicker) }
      OptDivider()
      NavRowSimple(Icons.Default.HeadsetMic, "Voice mode", "Talk hands-free") { closeThen(onOpenVoice) }
      OptDivider()
      NavRowSimple(Icons.Default.PhoneAndroid, "Phone agent", if (phoneOn) "On" else "Off") { closeThen(onOpenPhone) }
    }
  }
}

@Composable
private fun SectionLabel(text: String) {
  Text(text, color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(bottom = 8.dp))
}

@Composable
private fun OptDivider() {
  Box(Modifier.fillMaxWidth().padding(start = 40.dp).height(0.5.dp).background(ObsidianBorder))
}

@Composable
private fun RowIcon(icon: ImageVector) {
  Icon(icon, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(22.dp))
  Spacer(Modifier.width(18.dp))
}

@Composable
private fun NavRowSimple(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(14.dp))
      .clickable(onClickLabel = "Open $title", onClick = onClick)
      .heightIn(min = 52.dp)
      .padding(vertical = 6.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    RowIcon(icon)
    Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    Spacer(Modifier.width(12.dp))
    Text(
      value, color = TextSecondary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
      modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End
    )
    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
  }
}

/** Selectable pill: accent fill when selected, 48 dp tall touch target, 180 ms ease-out colour change. */
@Composable
private fun OptionPill(text: String, selected: Boolean, onClick: () -> Unit) {
  val fill by animateColorAsState(if (selected) CyberCyanPrimary else ObsidianSurfaceVariant, tween(180, easing = androidx.compose.animation.core.LinearOutSlowInEasing), label = "optFill")
  val fg by animateColorAsState(if (selected) Color.White else TextSecondary, tween(180), label = "optText")
  Box(
    modifier = Modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .selectable(selected = selected, role = Role.RadioButton, onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Box(
      Modifier
        .clip(CircleShape)
        .background(fill)
        .border(1.dp, if (selected) Color.White.copy(alpha = 0.25f) else ObsidianBorder, CircleShape)
        .padding(horizontal = 14.dp, vertical = 9.dp)
    ) {
      Text(text, color = fg, fontSize = 13.5.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1)
    }
  }
}
