package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.shrinkVertically
import androidx.compose.material.icons.filled.Check
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.toggleable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.HeadsetMic
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.TextButton
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.rotate
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentRoles
import com.example.data.model.OutputLevel
import com.example.data.model.SettingsState
import com.example.data.model.withLevel
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch

/**
 * v1.7.4: simplified sheet. Top: Agent chips + Model (primary). Everything else sits in a collapsed
 * "Advanced settings" section. Long descriptions moved behind an (i) icon that opens a small dialog.
 * Every change is saved at once; Model, Voice and Phone close this sheet first.
 */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
internal fun ChatOptionsSheet(
  settings: SettingsState,
  modelLabel: String,
  onSettingsChange: (SettingsState) -> Unit,
  onOpenModelPicker: () -> Unit,
  onOpenVoice: () -> Unit,
  onDismiss: () -> Unit,
  phoneOn: Boolean = false,
  onOpenPhone: () -> Unit = {}
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  fun closeThen(after: () -> Unit) {
    scope.launch { sheetState.hide() }.invokeOnCompletion { onDismiss(); after() }
  }
  val level = OutputLevel.from(settings.outputLevel)
  val role = AgentRoles.from(settings.agentRole)
  var advanced by rememberSaveable { mutableStateOf(false) }
  var info by remember { mutableStateOf<Pair<String, String>?>(null) }

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    modifier = Modifier.border(1.dp, com.example.ui.components.GlassPopupColors.rim(), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    scrimColor = Color.Black.copy(alpha = if (com.example.ui.theme.Palette.dark) 0.45f else 0.25f),
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .animateContentSize(spring(dampingRatio = 0.9f, stiffness = Spring.StiffnessMediumLow))
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 16.dp)
        .padding(bottom = 12.dp)
        .navigationBarsPadding()
    ) {
      // ---- Primary: Agent ----
      TitleWithInfo("Agent", "Agent: ${role.name}", role.blurb) { info = it }
      FlowRow(
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        modifier = Modifier.padding(top = 6.dp, bottom = 10.dp)
      ) {
        AgentRoles.choices.forEach { r ->
          AnimatedChip(r.name, r.id == settings.agentRole) { onSettingsChange(settings.copy(agentRole = r.id)) }
        }
      }
      Hairline()

      // ---- Primary: Model ----
      NavRow(Icons.Default.Memory, "Model", modelLabel) { closeThen(onOpenModelPicker) }
      Hairline()

      // ---- Advanced (collapsed by default) ----
      val turn by animateFloatAsState(if (advanced) 180f else 0f, label = "advTurn")
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(12.dp))
          .clickable(onClickLabel = if (advanced) "Collapse advanced settings" else "Expand advanced settings") { advanced = !advanced }
          .heightIn(min = 48.dp)
          .padding(horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Advanced settings", color = TextSecondary, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        Icon(Icons.Default.ExpandMore, contentDescription = null, tint = TextMuted, modifier = Modifier.rotate(turn))
      }
      AnimatedVisibility(
        visible = advanced,
        enter = expandVertically(tween(300, easing = FastOutSlowInEasing)) + fadeIn(tween(260, delayMillis = 60)),
        exit = shrinkVertically(tween(240, easing = FastOutSlowInEasing)) + fadeOut(tween(140))
      ) {
        Column {
          // Output size
          TitleWithInfo(
            "Output size", "Output size: ${level.label}",
            "${level.blurb} ${level.context} ctx, up to ${level.maxOut} tokens out."
          ) { info = it }
          FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.padding(top = 6.dp, bottom = 6.dp)
          ) {
            OutputLevel.values().forEach { l ->
              AnimatedChip(l.label, l == level) { onSettingsChange(settings.withLevel(l)) }
            }
          }
          Hairline()
          // Think
          SwitchRow(Icons.Default.Psychology, "Think", "Think", "Reasons step by step before answering. Slower.", settings.thinking, { info = it }) {
            onSettingsChange(settings.copy(thinking = it))
          }
          Hairline()
          NavRow(Icons.Default.HeadsetMic, "Voice mode", "") { closeThen(onOpenVoice) }
          Hairline()
          NavRow(Icons.Default.PhoneAndroid, "Phone agent", if (phoneOn) "On" else "Off") { closeThen(onOpenPhone) }
        }
      }
    }
  }

  info?.let { (title, text) ->
    AlertDialog(
      onDismissRequest = { info = null },
      title = { Text(title) },
      text = { Text(text) },
      confirmButton = { TextButton(onClick = { info = null }) { Text("OK") } }
    )
  }
}

@Composable
private fun Hairline() {
  Box(Modifier.fillMaxWidth().height(0.5.dp).background(ObsidianBorder))
}

/** Short title with a small (i) button; the long text opens in a dialog only on request. */
@Composable
private fun TitleWithInfo(title: String, dialogTitle: String, dialogText: String, onInfo: (Pair<String, String>) -> Unit) {
  Row(Modifier.padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
    Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
    InfoIcon(title) { onInfo(dialogTitle to dialogText) }
  }
}

@Composable
private fun InfoIcon(what: String, onClick: () -> Unit) {
  Box(
    Modifier.size(40.dp).clip(CircleShape).clickable(onClickLabel = "About $what", onClick = onClick),
    contentAlignment = Alignment.Center
  ) {
    Icon(Icons.Default.Info, contentDescription = null, tint = TextMuted, modifier = Modifier.size(16.dp))
  }
}

@Composable
private fun SwitchRow(
  icon: ImageVector, title: String, dialogTitle: String, dialogText: String,
  checked: Boolean, onInfo: (Pair<String, String>) -> Unit, onChange: (Boolean) -> Unit
) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .heightIn(min = 52.dp)
      .padding(horizontal = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(20.dp))
    Spacer(Modifier.width(14.dp))
    Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    InfoIcon(title) { onInfo(dialogTitle to dialogText) }
    Spacer(Modifier.weight(1f))
    Switch(
      checked = checked,
      onCheckedChange = onChange,
      colors = SwitchDefaults.colors(checkedTrackColor = CyberCyanPrimary, checkedThumbColor = Color.White)
    )
  }
}

@Composable
private fun NavRow(icon: ImageVector, title: String, value: String, onClick: () -> Unit) {
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(12.dp))
      .clickable(onClickLabel = "Open $title", onClick = onClick)
      .heightIn(min = 52.dp)
      .padding(horizontal = 4.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Icon(icon, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(20.dp))
    Spacer(Modifier.width(14.dp))
    Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    Spacer(Modifier.width(12.dp))
    Text(
      value, color = TextSecondary, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
      modifier = Modifier.weight(1f), textAlign = androidx.compose.ui.text.style.TextAlign.End
    )
    Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, contentDescription = null, tint = TextMuted)
  }
}

/** Chip whose check mark slides in and out and whose colours fade, so a change reads as motion, not a jump. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AnimatedChip(text: String, selected: Boolean, onClick: () -> Unit) {
  val container by androidx.compose.animation.animateColorAsState(
    if (selected) CyberCyanPrimary else ObsidianSurfaceVariant, tween(220, easing = FastOutSlowInEasing), label = "chipFill"
  )
  val label by androidx.compose.animation.animateColorAsState(
    if (selected) Color.White else TextSecondary, tween(220), label = "chipText"
  )
  FilterChip(
    selected = selected,
    onClick = onClick,
    label = { Text(text, maxLines = 1, fontSize = 13.sp) },
    leadingIcon = {
      AnimatedVisibility(
        visible = selected,
        enter = expandHorizontally(tween(200)) + fadeIn(tween(200)),
        exit = shrinkHorizontally(tween(160)) + fadeOut(tween(120))
      ) { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
    },
    shape = CircleShape,
    colors = FilterChipDefaults.filterChipColors(
      containerColor = container, selectedContainerColor = container,
      labelColor = label, selectedLabelColor = label,
      iconColor = label, selectedLeadingIconColor = label
    ),
    border = FilterChipDefaults.filterChipBorder(
      enabled = true, selected = selected, borderColor = ObsidianBorder, selectedBorderColor = Color.Transparent
    )
  )
}
