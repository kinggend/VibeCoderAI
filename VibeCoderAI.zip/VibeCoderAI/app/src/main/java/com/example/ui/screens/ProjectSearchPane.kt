package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.toggleableState
import androidx.compose.ui.state.ToggleableState
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.HistoryEntry
import com.example.agent.ProjectBackups
import com.example.agent.ProjectHistory
import com.example.project.ProjectSearch
import com.example.ui.components.TextButton
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

/**
 * v1.6 project-wide search & replace. Replace all asks first (count + files), takes an undo snapshot
 * (v1.5 ProjectBackups) and writes a History line. Files with unsaved editor changes are skipped and named.
 */
@Composable
internal fun ProjectSearchPane(
  root: File,
  /** Relative paths open in the editor with unsaved changes. */
  dirtyPaths: Set<String>,
  onOpen: (File, Int) -> Unit,
  onChanged: (Set<String>) -> Unit,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  var query by remember { mutableStateOf("") }
  var replacement by remember { mutableStateOf("") }
  var opts by remember { mutableStateOf(ProjectSearch.Options()) }
  var results by remember { mutableStateOf<List<ProjectSearch.FileMatches>>(emptyList()) }
  var error by remember { mutableStateOf<String?>(null) }
  var refresh by remember { mutableStateOf(0) }
  var confirm by remember { mutableStateOf(false) }
  var status by remember { mutableStateOf<String?>(null) }

  LaunchedEffect(root, query, opts, refresh) {
    if (query.isEmpty()) { results = emptyList(); error = null; return@LaunchedEffect }
    delay(250) // debounce typing
    withContext(Dispatchers.IO) { ProjectSearch.search(root, query, opts) }
      .onSuccess { results = it; error = null }
      .onFailure { results = emptyList(); error = it.message }
  }
  val total = results.sumOf { it.matches.size }

  Column(modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
    SearchField(query, { query = it }, "Search in project", "Search text")
    SearchField(replacement, { replacement = it }, "Replace with", "Replacement text")
    Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
      OptionChip("Aa", "Match case", opts.caseSensitive) { opts = opts.copy(caseSensitive = it) }
      OptionChip("W", "Whole word", opts.wholeWord) { opts = opts.copy(wholeWord = it) }
      OptionChip(".*", "Regular expression", opts.regex) { opts = opts.copy(regex = it) }
      Spacer(Modifier.weight(1f))
      TextButton(onClick = { confirm = true }, enabled = total > 0, modifier = Modifier.heightIn(min = 48.dp)) {
        Text("Replace all", color = if (total > 0) CyberCyanPrimary else TextMuted, fontWeight = FontWeight.SemiBold)
      }
    }
    Text(
      when {
        error != null -> error!!
        query.isEmpty() -> "Type to search every text file in this project (hidden folders and build output are skipped)."
        total == 0 -> "No matches. Check the spelling, or turn off Match case / Whole word."
        else -> "$total match${if (total == 1) "" else "es"} in ${results.size} file${if (results.size == 1) "" else "s"}" + if (total >= ProjectSearch.MAX_RESULTS) " (first ${ProjectSearch.MAX_RESULTS} shown)" else ""
      },
      color = if (error != null) CyberCoralError else TextMuted, fontSize = 12.sp
    )
    status?.let { Text(it, color = TextSecondary, fontSize = 12.sp) }
    LazyColumn(Modifier.fillMaxWidth().weight(1f, fill = false), verticalArrangement = Arrangement.spacedBy(6.dp)) {
      results.forEach { fm ->
        item(key = "h:" + fm.path) {
          Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(top = 6.dp)) {
            Text(fm.path, color = TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${fm.matches.size}", color = TextMuted, fontSize = 12.sp)
            if (fm.path in dirtyPaths) Text("  unsaved: skipped", color = CyberCoralError, fontSize = 11.sp)
          }
        }
        items(fm.matches, key = { "m:" + fm.path + ":" + it.offset }) { m ->
          Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(ObsidianSurface)
              .clickable(onClickLabel = "Open ${fm.path} at line ${m.line}") { onOpen(File(root, fm.path), m.line) }
              .heightIn(min = 48.dp).padding(start = 10.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text("${m.line}", color = TextMuted, fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.width(34.dp))
            Text(m.preview, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            TextButton(
              onClick = {
                scope.launch {
                  val res = withContext(Dispatchers.IO) {
                    runCatching {
                      val f = File(root, fm.path)
                      require(com.example.project.FileOps.inside(root, f)) { "Outside the project." }
                      val rx = ProjectSearch.pattern(query, opts).getOrThrow()
                      val (out, n) = ProjectSearch.replaceIn(f.readText(), rx, replacement, opts, onlyOffset = m.offset)
                      if (n == 1) {
                        f.writeText(out)
                        ProjectHistory.record(root, HistoryEntry.MODIFIED, fm.path, true, "replace one by you (line ${m.line})")
                      }
                      n
                    }
                  }
                  status = res.fold({ if (it == 1) "Replaced 1 match in ${fm.path}." else "That match changed; search again." }, { "Replace failed: ${it.message}" })
                  onChanged(setOf(fm.path)); refresh++
                }
              },
              enabled = fm.path !in dirtyPaths,
              modifier = Modifier.heightIn(min = 48.dp)
            ) { Text("Replace", fontSize = 12.sp, color = if (fm.path in dirtyPaths) TextMuted else CyberCyanPrimary) }
          }
        }
      }
    }
  }

  if (confirm) {
    val skip = results.map { it.path }.filter { it in dirtyPaths }
    val count = results.filter { it.path !in dirtyPaths }.sumOf { it.matches.size }
    val files = results.count { it.path !in dirtyPaths }
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { confirm = false },
      title = { Text("Replace $count match${if (count == 1) "" else "es"} in $files file${if (files == 1) "" else "s"}?") },
      text = {
        Text(
          "\"$query\" → \"$replacement\". A backup of the project is saved first, so Projects › History › Undo last run can put it back." +
            (if (skip.isNotEmpty()) "\n\nSkipped (unsaved in the editor): ${skip.joinToString()}" else "")
        )
      },
      confirmButton = {
        TextButton(onClick = {
          confirm = false
          scope.launch {
            val r = withContext(Dispatchers.IO) {
              val snap = ProjectBackups.snapshot(root)
              val changed = ProjectSearch.replaceAll(root, query, replacement, opts, skip.toSet())
              changed.onSuccess { m ->
                ProjectHistory.record(root, HistoryEntry.REPLACE, "\"${query.take(60)}\" → \"${replacement.take(60)}\"", true,
                  "${m.values.sum()} in ${m.size} file(s) by you" + if (snap is ProjectBackups.Outcome.Skipped) "; no backup: ${snap.reason}" else "")
              }
              changed to snap
            }
            val (changed, snap) = r
            status = changed.fold(
              { m -> "Replaced ${m.values.sum()} in ${m.size} file(s)." + if (snap is ProjectBackups.Outcome.Skipped) " No backup was taken: ${snap.reason}" else " Backup saved." },
              { "Replace failed: ${it.message}" }
            )
            changed.onSuccess { onChanged(it.keys) }
            refresh++
          }
        }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Replace all", color = CyberCyanPrimary) }
      },
      dismissButton = { TextButton(onClick = { confirm = false }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Cancel") } }
    )
  }
}

@Composable
private fun SearchField(value: String, onChange: (String) -> Unit, hint: String, desc: String) {
  Box(Modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).heightIn(min = 48.dp).padding(horizontal = 14.dp), contentAlignment = Alignment.CenterStart) {
    if (value.isEmpty()) Text(hint, color = TextMuted, fontSize = 14.sp)
    BasicTextField(
      value, onChange, singleLine = true,
      textStyle = TextStyle(color = TextPrimary, fontSize = 14.sp, fontFamily = FontFamily.Monospace),
      cursorBrush = SolidColor(CyberCyanPrimary),
      modifier = Modifier.fillMaxWidth().semantics { contentDescription = desc }
    )
  }
}

@Composable
private fun OptionChip(label: String, desc: String, on: Boolean, onChange: (Boolean) -> Unit) {
  Box(
    Modifier.heightIn(min = 48.dp).clip(CircleShape)
      .background(if (on) CyberCyanPrimary else ObsidianSurfaceVariant)
      .semantics { contentDescription = desc; toggleableState = if (on) ToggleableState.On else ToggleableState.Off }
      .clickable(role = Role.Checkbox) { onChange(!on) }
      .padding(horizontal = 14.dp),
    contentAlignment = Alignment.Center
  ) { Text(label, color = if (on) Color.White else TextPrimary, fontSize = 13.sp, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold) }
}
