@file:OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)

package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material.icons.filled.History
import androidx.compose.foundation.layout.heightIn
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.luminance
import com.example.ui.components.ActionIconButton
import com.example.ui.components.TextButton
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import com.example.ui.components.SyntaxHighlighter
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.input.key.isCtrlPressed
import androidx.compose.ui.input.key.isMetaPressed
import androidx.compose.ui.input.key.isShiftPressed
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.type
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Archive
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Unarchive
import androidx.compose.material3.AlertDialog
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import com.example.ui.components.IconButton
import androidx.compose.material3.MaterialTheme
import com.example.ui.components.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.FileItem
import com.example.data.model.Project
import com.example.data.model.ProjectType
import com.example.project.ProjectManager
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.launch
import java.io.File

@Composable
fun ProjectScreen(
  projectManager: ProjectManager,
  modifier: Modifier = Modifier,
  /** v1.5: true while the agent runs (disables Undo last run). */
  agentBusy: Boolean = false,
  /** v1.6: editor suggestion bar (Settings › Agent › Editor suggestions). */
  autocomplete: Boolean = true,
  /** v1.6: "Push to GitHub" dialog for the active project. */
  onPushToGitHub: (() -> Unit)? = null
) {
  // v1.6: 0 = Files, 1 = Search, 2 = History.
  var pane by remember { mutableStateOf(0) }
  // v1.6 explorer long-press actions.
  var fileMenu by remember { mutableStateOf<FileItem?>(null) }
  var nameDialog by remember { mutableStateOf<Pair<String, FileItem>?>(null) } // "rename" | "file" | "folder"
  var moveDialog by remember { mutableStateOf<FileItem?>(null) }
  var deleteDialog by remember { mutableStateOf<FileItem?>(null) }
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  val projects by projectManager.projects.collectAsState()
  val activeProject by projectManager.activeProject.collectAsState()

  var showNewProjectDialog by remember { mutableStateOf(false) }
  var showRenameDialog by remember { mutableStateOf(false) }
  var showDeleteDialog by remember { mutableStateOf(false) }
  var showImportZipDialog by remember { mutableStateOf(false) }

  val openTabs = remember { mutableStateListOf<String>() }
  val buffers = remember { mutableStateMapOf<String, String>() }
  val dirty = remember { mutableStateMapOf<String, Boolean>() }
  val undoStack = remember { mutableStateMapOf<String, List<String>>() }
  val redoStack = remember { mutableStateMapOf<String, List<String>>() }
  var activePath by remember { mutableStateOf<String?>(null) }
  var lastEditAt by remember { mutableStateOf(0L) }
  var showFind by remember { mutableStateOf(false) }
  var findText by remember { mutableStateOf("") }
  var replaceText by remember { mutableStateOf("") }
  var confirmClose by remember { mutableStateOf<String?>(null) }
  var showNewFileDialog by remember { mutableStateOf(false) }
  var treeVersion by remember { mutableStateOf(0) }

  // v1.4: per-file editor value (text + cursor), so code from chat can be inserted at the cursor.
  val editorValues = remember { mutableStateMapOf<String, androidx.compose.ui.text.input.TextFieldValue>() }

  LaunchedEffect(activeProject?.id) {
    openTabs.clear(); buffers.clear(); dirty.clear(); undoStack.clear(); redoStack.clear(); editorValues.clear()
    activePath = null
    if (com.example.project.EditorBridge.projectId != activeProject?.id) {
      com.example.project.EditorBridge.projectId = activeProject?.id
      com.example.project.EditorBridge.openFile = null
      com.example.project.EditorBridge.cursor = null
    }
  }

  fun openFile(file: File) {
    val path = file.absolutePath
    if (path !in buffers) {
      if (file.length() > 512 * 1024) {
        Toast.makeText(context, "File is larger than 512 KB.", Toast.LENGTH_SHORT).show()
        return
      }
      buffers[path] = runCatching { file.readText() }.getOrDefault("")
    }
    if (path !in openTabs) openTabs.add(path)
    activePath = path
    RecentFiles.touch(path)
  }

  fun closeTab(path: String) {
    val idx = openTabs.indexOf(path)
    openTabs.remove(path)
    buffers.remove(path); dirty.remove(path); undoStack.remove(path); redoStack.remove(path); editorValues.remove(path)
    if (activePath == path) activePath = openTabs.getOrNull((idx - 1).coerceAtLeast(0))
    if (openTabs.isEmpty()) {
      com.example.project.EditorBridge.openFile = null
      com.example.project.EditorBridge.cursor = null
    }
  }

  fun saveFile(path: String) {
    runCatching { File(path).writeText(buffers[path] ?: "") }
      .onSuccess {
        dirty[path] = false
        Toast.makeText(context, "Saved ${File(path).name}", Toast.LENGTH_SHORT).show()
      }
      .onFailure { Toast.makeText(context, "Save failed: ${it.message}", Toast.LENGTH_LONG).show() }
  }

  fun editFile(path: String, new: String) {
    val old = buffers[path] ?: ""
    if (new == old) return
    val now = System.currentTimeMillis()
    // Typing bursts count as one undo step.
    if (now - lastEditAt > 700 || undoStack[path].isNullOrEmpty()) {
      undoStack[path] = (undoStack[path] ?: emptyList()).takeLast(99) + old
    }
    lastEditAt = now
    redoStack.remove(path)
    buffers[path] = new
    dirty[path] = true
  }

  fun undoEdit(path: String) {
    val st = undoStack[path] ?: return
    if (st.isEmpty()) return
    redoStack[path] = (redoStack[path] ?: emptyList()) + (buffers[path] ?: "")
    buffers[path] = st.last()
    undoStack[path] = st.dropLast(1)
    dirty[path] = true
    lastEditAt = 0L
  }

  fun redoEdit(path: String) {
    val st = redoStack[path] ?: return
    if (st.isEmpty()) return
    undoStack[path] = (undoStack[path] ?: emptyList()) + (buffers[path] ?: "")
    buffers[path] = st.last()
    redoStack[path] = st.dropLast(1)
    dirty[path] = true
    lastEditAt = 0L
  }

  val expandedFolders = remember { mutableStateMapOf<String, Boolean>() }

  // v1.4: publish the open file for "Insert" in chat; clear it when every tab is closed.
  LaunchedEffect(activePath) {
    val p = activePath ?: return@LaunchedEffect
    com.example.project.EditorBridge.openFile = p
    editorValues[p]?.let { com.example.project.EditorBridge.cursor = it.selection.start }
  }

  // v1.4: reopen the last edited file when coming back to Projects, then apply a pending Insert.
  val editorRequest by com.example.project.EditorBridge.requests.collectAsState()
  LaunchedEffect(activeProject?.id, editorRequest?.id) {
    val req = editorRequest
    val lastOpen = com.example.project.EditorBridge.openFile
    if (req == null) {
      if (activePath == null && lastOpen != null && File(lastOpen).isFile) {
        val keepCursor = com.example.project.EditorBridge.cursor
        openFile(File(lastOpen))
        keepCursor?.let { c ->
          val t = buffers[lastOpen] ?: ""
          editorValues[lastOpen] = androidx.compose.ui.text.input.TextFieldValue(t, androidx.compose.ui.text.TextRange(c.coerceIn(0, t.length)))
        }
      }
      return@LaunchedEffect
    }
    com.example.project.EditorBridge.consume(req.id)
    val file = File(req.path)
    if (!file.isFile) {
      Toast.makeText(context, "${file.name} no longer exists.", Toast.LENGTH_SHORT).show()
      return@LaunchedEffect
    }
    val cursorBefore = if (req.path == com.example.project.EditorBridge.openFile) com.example.project.EditorBridge.cursor else null
    openFile(file)
    if (req.openOnly) {
      treeVersion++
      Toast.makeText(context, "Created ${file.name}", Toast.LENGTH_SHORT).show()
      return@LaunchedEffect
    }
    val path = file.absolutePath
    val current = buffers[path] ?: return@LaunchedEffect
    val cursorNow = editorValues[path]?.selection?.start ?: cursorBefore
    val (newText, newCursor) = com.example.project.EditorBridge.insertAt(current, cursorNow, req.code)
    editFile(path, newText)
    editorValues[path] = androidx.compose.ui.text.input.TextFieldValue(newText, androidx.compose.ui.text.TextRange(newCursor))
    com.example.project.EditorBridge.cursor = newCursor
    Toast.makeText(context, "Inserted into ${file.name}. Tap Save to keep it.", Toast.LENGTH_LONG).show()
  }

  /** Creates [relativePath] inside the active project (folders included), refreshes the explorer and opens it. */
  fun createNewFile(relativePath: String) {
    val project = activeProject
    if (project == null) {
      Toast.makeText(context, "Create or select a project first.", Toast.LENGTH_SHORT).show()
      return
    }
    val clean = relativePath.trim().trimStart('/', '\\')
    if (clean.isEmpty()) {
      Toast.makeText(context, "Enter a file name.", Toast.LENGTH_SHORT).show()
      return
    }
    val root = project.rootDir
    val target = File(root, clean)
    val rootCanonical = runCatching { root.canonicalPath }.getOrDefault(root.absolutePath)
    val targetCanonical = runCatching { target.canonicalPath }.getOrDefault(target.absolutePath)
    if (!targetCanonical.startsWith(rootCanonical + File.separator)) {
      Toast.makeText(context, "The file must stay inside the project folder.", Toast.LENGTH_SHORT).show()
      return
    }
    runCatching {
      target.parentFile?.mkdirs()
      if (target.exists()) {
        if (target.isDirectory) error("A folder with that name already exists.")
        false
      } else {
        target.createNewFile()
      }
    }.onSuccess { created ->
      if (!created) Toast.makeText(context, "${target.name} already exists, opened it.", Toast.LENGTH_SHORT).show()
      var dir: File? = target.parentFile
      while (dir != null) {
        val d: File = dir
        val c = runCatching { d.canonicalPath }.getOrDefault("")
        if (!c.startsWith(rootCanonical)) break
        expandedFolders[d.absolutePath] = true
        if (c == rootCanonical) break
        dir = d.parentFile
      }
      treeVersion++
      showNewFileDialog = false
      openFile(target)
    }.onFailure {
      Toast.makeText(context, "Could not create the file: ${it.message}", Toast.LENGTH_LONG).show()
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
  ) {
    // Project Header Toolbar
    ProjectToolbar(
      activeProject = activeProject,
      projects = projects,
      onSelectProject = { scope.launch { projectManager.selectProject(it) } },
      onNewProject = { showNewProjectDialog = true },
      onImportZip = { showImportZipDialog = true },
      onRenameProject = { showRenameDialog = true },
      onDeleteProject = { showDeleteDialog = true },
      onPushToGitHub = onPushToGitHub,
      onExportZip = {
        activeProject?.let { proj ->
          scope.launch {
            try {
              val zip = projectManager.exportProjectToZip(proj)
              Toast.makeText(context, "Exported ZIP: ${zip.name} (${zip.length()} bytes)", Toast.LENGTH_LONG).show()
            } catch (e: Exception) {
              Toast.makeText(context, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
            }
          }
        }
      }
    )

    // v1.5: Files / History (agent action log + Undo last run).
    ProjectPaneSwitch(pane, { pane = it }, Modifier.padding(horizontal = 12.dp).padding(top = 4.dp))
    if (pane == 0) {
    // Workspace: explorer + tabbed, syntax-highlighted editor
    Row(
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Column(
        modifier = Modifier
          .weight(0.4f)
          .fillMaxSize()
          .clip(RoundedCornerShape(14.dp))
          .background(ObsidianSurface)
          .padding(10.dp)
      ) {
        Row(
          modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
            text = "EXPLORER",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            modifier = Modifier.weight(1f)
          )
          if (activeProject != null) {
            ActionIconButton(
              icon = Icons.Default.Add,
              contentDescription = "New file",
              onClick = { showNewFileDialog = true },
              tint = CyberCyanPrimary,
              iconSize = 20.dp
            )
          }
        }
        if (activeProject != null) {
          val rootItem = remember(activeProject?.rootPath, activeProject?.updatedAt, treeVersion) {
            projectManager.getFileTree(activeProject!!.rootDir)
          }
          LaunchedEffect(rootItem.path) { expandedFolders[rootItem.path] = true }
          LazyColumn(modifier = Modifier.fillMaxSize()) {
            item {
              FileTreeItemView(
                item = rootItem,
                level = 0,
                expandedMap = expandedFolders,
                selectedFilePath = activePath,
                onFileClick = { item ->
                  if (!item.isDirectory) {
                    openFile(File(item.path))
                  } else {
                    expandedFolders[item.path] = !(expandedFolders[item.path] ?: false)
                  }
                },
                onLongPress = { fileMenu = it }
              )
            }
          }
        } else {
          Text(text = "No project yet. Tap + above to create one, or import a ZIP.", color = TextMuted, fontSize = 12.sp)
        }
      }

      Column(
        modifier = Modifier
          .weight(0.6f)
          .fillMaxSize()
          .clip(RoundedCornerShape(14.dp))
          .background(com.example.ui.theme.CodeBackground)
      ) {
        val path = activePath
        if (path == null) {
          val project = activeProject
          val recent = RecentFiles.paths.filter { p ->
            project != null && p.startsWith(project.rootDir.absolutePath + File.separator) && File(p).isFile
          }
          EditorEmptyState(
            hasProject = project != null,
            recent = recent,
            onNewFile = { showNewFileDialog = true },
            onOpenRecent = { openFile(File(it)) },
            onQuickStart = { type, base ->
              scope.launch { projectManager.createProject("$base-${(100..999).random()}", type, type.displayName) }
            }
          )
        } else {
          val text = buffers[path] ?: ""
          val isDirty = dirty[path] == true

          // Tabs
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
              .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
          ) {
            openTabs.toList().forEach { tab ->
              val selected = tab == path
              Row(
                modifier = Modifier
                  .clip(CircleShape)
                  .background(if (selected) CyberCyanPrimary else ObsidianSurfaceVariant)
                  .clickable { activePath = tab }
                  .padding(start = 12.dp, end = 4.dp),
                verticalAlignment = Alignment.CenterVertically
              ) {
                Text(
                  text = File(tab).name + if (dirty[tab] == true) " \u2022" else "",
                  color = if (selected) Color.White else TextPrimary,
                  fontSize = 12.sp,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                  modifier = Modifier.widthIn(max = 140.dp)
                )
                IconButton(
                  onClick = { if (dirty[tab] == true) confirmClose = tab else closeTab(tab) },
                  modifier = Modifier.size(26.dp)
                ) {
                  Icon(
                    Icons.Default.Close,
                    contentDescription = "Close tab",
                    tint = if (selected) Color.White else TextMuted,
                    modifier = Modifier.size(13.dp)
                  )
                }
              }
            }
          }

          // Toolbar
          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "${text.count { it == '\n' } + 1} lines",
              color = TextMuted,
              fontSize = 11.sp,
              fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
              modifier = Modifier.weight(1f).padding(start = 4.dp)
            )
            ActionIconButton(
              icon = Icons.Default.Undo,
              contentDescription = "Undo",
              onClick = { undoEdit(path) },
              enabled = !undoStack[path].isNullOrEmpty(),
              tint = TextPrimary
            )
            ActionIconButton(
              icon = Icons.Default.Redo,
              contentDescription = "Redo",
              onClick = { redoEdit(path) },
              enabled = !redoStack[path].isNullOrEmpty(),
              tint = TextPrimary
            )
            ActionIconButton(
              icon = Icons.Default.Search,
              contentDescription = "Find and replace",
              onClick = { showFind = !showFind },
              tint = if (showFind) CyberCyanPrimary else TextMuted
            )
            ActionIconButton(
              icon = Icons.Default.Save,
              contentDescription = "Save",
              onClick = { saveFile(path) },
              enabled = isDirty,
              tint = if (isDirty) Color.White else TextMuted,
              containerColor = if (isDirty) CyberGreenSuccess else Color.Transparent,
              modifier = Modifier.testTag("save_file_button")
            )
          }

          if (showFind) {
            val matches = if (findText.isEmpty()) 0 else Regex.escape(findText).toRegex().findAll(text).count()
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
              EditorField(findText, { findText = it }, "Find ($matches)")
              Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Box(modifier = Modifier.weight(1f)) { EditorField(replaceText, { replaceText = it }, "Replace with") }
                Button(
                  onClick = { editFile(path, text.replace(findText, replaceText)) },
                  enabled = matches > 0,
                  contentPadding = androidx.compose.foundation.layout.PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                  colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
                  shape = CircleShape,
                  modifier = Modifier.height(32.dp)
                ) { Text("Replace all", fontSize = 12.sp) }
              }
            }
          }

          // Editor with line numbers and syntax highlighting
          val lang = remember(path) { path.substringAfterLast('.', "").lowercase() }
          // v1.6: suggestion bar (keywords + names in this file). Tap a chip or press Tab for the first one.
          val cursorNow = editorValues[path]?.takeIf { it.text == text }?.selection?.start ?: -1
          val suggestions = remember(text, cursorNow, autocomplete, lang) {
            if (!autocomplete || cursorNow < 0 || text.length > 200_000) emptyList() else com.example.editor.Completion.suggest(text, cursorNow, lang)
          }
          fun acceptSuggestion(word: String) {
            val (nt, nc) = com.example.editor.Completion.apply(text, cursorNow, word, lang)
            editFile(path, nt)
            editorValues[path] = androidx.compose.ui.text.input.TextFieldValue(nt, androidx.compose.ui.text.TextRange(nc))
            com.example.project.EditorBridge.cursor = nc
          }
          if (suggestions.isNotEmpty()) {
            Row(
              Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp),
              horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
              suggestions.forEachIndexed { i, w ->
                Box(
                  Modifier.heightIn(min = 48.dp).clickable(onClickLabel = "Insert $w") { acceptSuggestion(w) },
                  contentAlignment = Alignment.Center
                ) {
                  Text(
                    w + if (i == 0) "  ⇥" else "",
                    color = if (i == 0) CyberCyanPrimary else TextPrimary, fontSize = 12.sp, fontFamily = FontFamily.Monospace,
                    modifier = Modifier.clip(CircleShape).background(ObsidianSurfaceVariant).padding(horizontal = 10.dp, vertical = 6.dp)
                  )
                }
              }
            }
          }
          val transformation = remember(lang) { HighlightTransformation(lang) }
          val lineCount = text.count { it == '\n' } + 1
          val gutter = remember(lineCount) { (1..lineCount).joinToString("\n") }
          val codeStyle = TextStyle(
            color = TextPrimary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            lineHeight = 18.sp
          )
          Row(
            modifier = Modifier
              .fillMaxSize()
              .verticalScroll(rememberScrollState())
              .padding(start = 6.dp, end = 6.dp, top = 4.dp, bottom = 12.dp)
          ) {
            Text(
              text = gutter,
              style = codeStyle.copy(color = TextMuted, textAlign = TextAlign.End),
              modifier = Modifier.widthIn(min = 28.dp).padding(end = 8.dp)
            )
            Box(modifier = Modifier.horizontalScroll(rememberScrollState())) {
              // v1.4: TextFieldValue keeps the cursor (published for chat "Insert"); the IME composition is
              // kept whenever the text did not change from outside (undo, replace, insert).
              val stored = editorValues[path]
              val fieldValue = if (stored != null && stored.text == text) stored
              else androidx.compose.ui.text.input.TextFieldValue(
                text,
                androidx.compose.ui.text.TextRange((stored?.selection?.start ?: text.length).coerceIn(0, text.length))
              )
              BasicTextField(
                value = fieldValue,
                onValueChange = { v ->
                  editorValues[path] = v
                  com.example.project.EditorBridge.cursor = v.selection.start
                  if (v.text != text) editFile(path, v.text)
                },
                textStyle = codeStyle,
                cursorBrush = SolidColor(CyberCyanPrimary),
                visualTransformation = transformation,
                modifier = Modifier
                  .defaultMinSize(minWidth = 240.dp, minHeight = 200.dp)
                  .onPreviewKeyEvent { e ->
                    // External keyboard: Ctrl+S save, Ctrl+Z undo, Ctrl+Shift+Z / Ctrl+Y redo, Ctrl+F find.
                    if (e.type == androidx.compose.ui.input.key.KeyEventType.KeyDown && (e.isCtrlPressed || e.isMetaPressed)) {
                      val letter = when (e.key) {
                        androidx.compose.ui.input.key.Key.S -> 's'
                        androidx.compose.ui.input.key.Key.Z -> 'z'
                        androidx.compose.ui.input.key.Key.Y -> 'y'
                        androidx.compose.ui.input.key.Key.F -> 'f'
                        else -> null
                      }
                      val action = letter?.let { com.example.project.EditorShortcuts.action(true, e.isShiftPressed, it) }
                      if (action != null) {
                        when (action) {
                          com.example.project.EditorAction.SAVE -> saveFile(path)
                          com.example.project.EditorAction.UNDO -> undoEdit(path)
                          com.example.project.EditorAction.REDO -> redoEdit(path)
                          com.example.project.EditorAction.FIND -> showFind = !showFind
                        }
                        return@onPreviewKeyEvent true
                      }
                    }
                    if (e.key == androidx.compose.ui.input.key.Key.Tab && e.type == androidx.compose.ui.input.key.KeyEventType.KeyDown && suggestions.isNotEmpty()) {
                      acceptSuggestion(suggestions.first()); true
                    } else false
                  }
                  .testTag("code_editor_field")
              )
            }
          }
        }
      }
    }
    } else if (pane == 1) {
      val proj = activeProject
      if (proj != null) {
        val root = proj.rootDir
        ProjectSearchPane(
          root = root,
          dirtyPaths = openTabs.filter { dirty[it] == true }.map { File(it).relativeTo(root).invariantSeparatorsPath }.toSet(),
          onOpen = { f, line ->
            openFile(f)
            val p = f.absolutePath
            val t = buffers[p] ?: ""
            var off = 0
            repeat((line - 1).coerceAtLeast(0)) { val n = t.indexOf('\n', off); if (n >= 0) off = n + 1 }
            editorValues[p] = androidx.compose.ui.text.input.TextFieldValue(t, androidx.compose.ui.text.TextRange(off.coerceIn(0, t.length)))
            pane = 0
          },
          onChanged = { rels ->
            // Reload open, unsaved-free tabs whose files changed on disk.
            rels.map { File(root, it).absolutePath }.filter { it in buffers && dirty[it] != true }.forEach { p ->
              buffers[p] = runCatching { File(p).readText() }.getOrDefault(buffers[p] ?: "")
              editorValues.remove(p)
              undoStack.remove(p); redoStack.remove(p)
            }
            treeVersion++
          },
          modifier = Modifier.weight(1f)
        )
      } else {
        Text("No active project.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
      }
    } else {
      val proj = activeProject
      if (proj != null) {
        ProjectHistoryPane(proj.rootDir, agentBusy, onRestored = {
          // Restored files replace what the editor holds: close every tab so nothing stale is saved back.
          openTabs.clear(); buffers.clear(); dirty.clear(); undoStack.clear(); redoStack.clear(); editorValues.clear()
          activePath = null
          com.example.project.EditorBridge.openFile = null
          treeVersion++
        }, modifier = Modifier.weight(1f))
      } else {
        Text("No active project.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(16.dp))
      }
    }
  }

  // ---- v1.6 explorer actions ----
  val proj6 = activeProject
  fun afterPathChange(old: String) {
    // Tabs under a renamed / moved / deleted path would save to the old place: close them.
    openTabs.toList().filter { it == old || it.startsWith(old + File.separator) }.forEach { closeTab(it) }
    treeVersion++
  }
  fun report(r: Result<*>, ok: String) {
    Toast.makeText(context, r.fold({ ok }, { it.message ?: "That did not work." }), Toast.LENGTH_SHORT).show()
  }
  if (proj6 != null) {
    val root = proj6.rootDir
    fileMenu?.let { item ->
      val isRoot = runCatching { File(item.path).canonicalPath == root.canonicalPath }.getOrDefault(false)
      com.example.ui.components.GlassAlertDialog(
        onDismissRequest = { fileMenu = null },
        title = { Text(if (isRoot) proj6.name else item.name) },
        text = {
          Column {
            if (item.isDirectory) {
              MenuRow("New file here") { fileMenu = null; nameDialog = "file" to item }
              MenuRow("New folder here") { fileMenu = null; nameDialog = "folder" to item }
            }
            if (!isRoot) {
              MenuRow("Rename") { fileMenu = null; nameDialog = "rename" to item }
              MenuRow("Move to…") { fileMenu = null; moveDialog = item }
              MenuRow("Delete", danger = true) { fileMenu = null; deleteDialog = item }
            }
          }
        },
        confirmButton = { TextButton(onClick = { fileMenu = null }) { Text("Close") } }
      )
    }
    nameDialog?.let { (mode, item) ->
      var name by remember(item.path, mode) { mutableStateOf(if (mode == "rename") item.name else "") }
      val err = if (name.isEmpty()) null else com.example.project.FileOps.nameError(name)
      com.example.ui.components.GlassAlertDialog(
        onDismissRequest = { nameDialog = null },
        title = { Text(when (mode) { "rename" -> "Rename ${item.name}"; "folder" -> "New folder"; else -> "New file" }) },
        text = {
          Column {
            EditorField(name, { name = it }, if (mode == "folder") "folder-name" else "file-name.js")
            err?.let { Text(it, color = com.example.ui.theme.CyberCoralError, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
          }
        },
        confirmButton = {
          TextButton(enabled = name.isNotBlank() && err == null, onClick = {
            val f = File(item.path)
            when (mode) {
              "rename" -> com.example.project.FileOps.rename(root, f, name).also { r -> report(r, "Renamed to ${name.trim()}"); if (r.isSuccess) afterPathChange(f.absolutePath) }
              else -> com.example.project.FileOps.create(root, f, name, mode == "folder").also { r ->
                report(r, "Created ${name.trim()}")
                if (r.isSuccess) { expandedFolders[f.absolutePath] = true; treeVersion++; r.getOrNull()?.takeIf { it.isFile }?.let { openFile(it) } }
              }
            }
            nameDialog = null
          }) { Text(if (mode == "rename") "Rename" else "Create") }
        },
        dismissButton = { TextButton(onClick = { nameDialog = null }) { Text("Cancel") } }
      )
    }
    moveDialog?.let { item ->
      val folders = remember(item.path, treeVersion) { com.example.project.FileOps.folders(root) }
      com.example.ui.components.GlassAlertDialog(
        onDismissRequest = { moveDialog = null },
        title = { Text("Move ${item.name} to") },
        text = {
          LazyColumn(Modifier.heightIn(max = 320.dp)) {
            items(folders.size) { i ->
              val rel = folders[i]
              MenuRow(if (rel.isEmpty()) "/ (project root)" else "/$rel") {
                val f = File(item.path)
                com.example.project.FileOps.move(root, f, if (rel.isEmpty()) root else File(root, rel))
                  .also { r -> report(r, "Moved ${item.name}"); if (r.isSuccess) afterPathChange(f.absolutePath) }
                moveDialog = null
              }
            }
          }
        },
        confirmButton = { TextButton(onClick = { moveDialog = null }) { Text("Cancel") } }
      )
    }
    deleteDialog?.let { item ->
      com.example.ui.components.GlassAlertDialog(
        onDismissRequest = { deleteDialog = null },
        title = { Text("Delete ${item.name}?") },
        text = { Text(if (item.isDirectory) "The folder and everything in it (${item.children.size} item(s) at the top level) is deleted. This cannot be undone." else "The file is deleted from this phone. This cannot be undone.") },
        confirmButton = {
          TextButton(onClick = {
            val f = File(item.path)
            com.example.project.FileOps.delete(root, f).also { r -> report(r, "Deleted ${item.name}"); if (r.isSuccess) afterPathChange(f.absolutePath) }
            deleteDialog = null
          }) { Text("Delete", color = com.example.ui.theme.CyberCoralError) }
        },
        dismissButton = { TextButton(onClick = { deleteDialog = null }) { Text("Cancel") } }
      )
    }
  }

  confirmClose?.let { tab ->
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { confirmClose = null },
      title = { Text("Unsaved changes") },
      text = { Text("${File(tab).name} has changes that are not saved.") },
      confirmButton = {
        TextButton(onClick = {
          saveFile(tab)
          closeTab(tab)
          confirmClose = null
        }) { Text("Save and close") }
      },
      dismissButton = {
        Row {
          TextButton(onClick = { confirmClose = null }) { Text("Cancel") }
          TextButton(onClick = {
            closeTab(tab)
            confirmClose = null
          }) { Text("Discard", color = com.example.ui.theme.CyberCoralError) }
        }
      }
    )
  }

  // New File Dialog
  if (showNewFileDialog && activeProject != null) {
    NewFileDialog(
      onDismiss = { showNewFileDialog = false },
      onCreate = { createNewFile(it) }
    )
  }

  // New Project Dialog
  if (showNewProjectDialog) {
    NewProjectDialog(
      onDismiss = { showNewProjectDialog = false },
      onCreate = { name, type, desc ->
        scope.launch {
          projectManager.createProject(name, type, desc)
          showNewProjectDialog = false
        }
      }
    )
  }

  // Rename Dialog
  if (showRenameDialog && activeProject != null) {
    RenameProjectDialog(
      currentName = activeProject!!.name,
      onDismiss = { showRenameDialog = false },
      onRename = { newName ->
        scope.launch {
          try {
            projectManager.renameProject(activeProject!!, newName)
            showRenameDialog = false
          } catch (e: Exception) {
            Toast.makeText(context, e.message, Toast.LENGTH_SHORT).show()
          }
        }
      }
    )
  }

  // Delete Dialog
  if (showDeleteDialog && activeProject != null) {
    DeleteProjectDialog(
      projectName = activeProject!!.name,
      onDismiss = { showDeleteDialog = false },
      onConfirm = {
        scope.launch {
          projectManager.deleteProject(activeProject!!)
          showDeleteDialog = false
        }
      }
    )
  }

  // Import ZIP Dialog
  if (showImportZipDialog) {
    ImportZipDialog(
      onDismiss = { showImportZipDialog = false },
      onImport = { path, projName ->
        scope.launch {
          try {
            val file = File(path)
            if (!file.exists()) {
              Toast.makeText(context, "ZIP file not found: $path", Toast.LENGTH_SHORT).show()
              return@launch
            }
            projectManager.importProjectFromZip(file, projName)
            Toast.makeText(context, "Imported project '$projName'", Toast.LENGTH_SHORT).show()
            showImportZipDialog = false
          } catch (e: Exception) {
            Toast.makeText(context, "Import error: ${e.message}", Toast.LENGTH_LONG).show()
          }
        }
      }
    )
  }
}

@Composable
fun ProjectToolbar(
  activeProject: Project?,
  projects: List<Project>,
  onSelectProject: (Project) -> Unit,
  onNewProject: () -> Unit,
  onImportZip: () -> Unit,
  onRenameProject: () -> Unit,
  onDeleteProject: () -> Unit,
  onExportZip: () -> Unit,
  onPushToGitHub: (() -> Unit)? = null
) {
  var showDropdown by remember { mutableStateOf(false) }
  var showMore by remember { mutableStateOf(false) }

  Row(
    modifier = Modifier
      .fillMaxWidth()
      .background(ObsidianSurfaceVariant)
      .padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
    verticalAlignment = Alignment.CenterVertically,
    horizontalArrangement = Arrangement.spacedBy(8.dp)
  ) {
    Box(modifier = Modifier.weight(1f, fill = false)) {
      Row(
        modifier = Modifier
          .clip(RoundedCornerShape(10.dp))
          .background(ObsidianSurface)
          .clickable { showDropdown = true }
          .heightIn(min = 40.dp)
          .padding(horizontal = 10.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(imageVector = Icons.Default.FolderOpen, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = activeProject?.name ?: "Select Project",
          color = TextPrimary,
          fontSize = 13.sp,
          fontWeight = FontWeight.Bold,
          fontFamily = FontFamily.Monospace,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
        )
      }

      com.example.ui.components.GlassDropdownMenu(
        expanded = showDropdown,
        onDismissRequest = { showDropdown = false }
      ) {
        projects.forEach { proj ->
          DropdownMenuItem(
            text = { Text(proj.name, fontFamily = FontFamily.Monospace, maxLines = 1, overflow = TextOverflow.Ellipsis) },
            onClick = {
              onSelectProject(proj)
              showDropdown = false
            }
          )
        }
      }
    }

    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
      ActionIconButton(Icons.Default.Add, "New Project", onNewProject, tint = CyberCyanPrimary, iconSize = 24.dp)
      ActionIconButton(Icons.Default.Unarchive, "Import ZIP", onImportZip, tint = CyberCyanPrimary)
      ActionIconButton(Icons.Default.Archive, "Export ZIP", onExportZip, tint = TextPrimary)
      // v1.6: rename / delete / push live in a More menu so every icon keeps a 48 dp target on phones.
      Box {
        ActionIconButton(Icons.Default.MoreVert, "More project actions", { showMore = true }, tint = TextPrimary)
        com.example.ui.components.GlassDropdownMenu(expanded = showMore, onDismissRequest = { showMore = false }) {
          DropdownMenuItem(text = { Text("Rename project") }, onClick = { showMore = false; onRenameProject() }, modifier = Modifier.heightIn(min = 48.dp))
          if (onPushToGitHub != null && activeProject != null) {
            DropdownMenuItem(text = { Text("Push to GitHub…") }, onClick = { showMore = false; onPushToGitHub() }, modifier = Modifier.heightIn(min = 48.dp))
          }
          DropdownMenuItem(text = { Text("Delete project", color = Color(0xFFF85149)) }, onClick = { showMore = false; onDeleteProject() }, modifier = Modifier.heightIn(min = 48.dp))
        }
      }
    }
  }
}

@Composable
fun FileTreeItemView(
  item: FileItem,
  level: Int,
  expandedMap: Map<String, Boolean>,
  selectedFilePath: String?,
  onFileClick: (FileItem) -> Unit,
  onLongPress: (FileItem) -> Unit = {}
) {
  val isExpanded = expandedMap[item.path] ?: false
  val isSelected = selectedFilePath == item.path

  Column {
    val badge = if (item.isDirectory) null else languageBadge(item.name)
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
        .clip(RoundedCornerShape(8.dp))
        .background(
          when {
            isSelected -> CyberCyanPrimary.copy(alpha = 0.16f)
            item.isDirectory && isExpanded -> CyberCyanPrimary.copy(alpha = 0.06f)
            else -> Color.Transparent
          }
        )
        // v1.6: long-press opens rename / move / delete / new.
        .combinedClickable(onLongClickLabel = "Actions for ${item.name}", onLongClick = { onLongPress(item) }) { onFileClick(item) }
        .padding(start = (4 + level * 10).dp, top = 2.dp, bottom = 2.dp, end = 4.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      if (item.isDirectory) {
        Text(
          text = if (isExpanded) "\u25BE" else "\u25B8",
          color = TextMuted,
          fontSize = 10.sp,
          modifier = Modifier.width(10.dp)
        )
      } else {
        Spacer(modifier = Modifier.width(10.dp))
      }
      Icon(
        imageVector = if (item.isDirectory) {
          if (isExpanded) Icons.Default.FolderOpen else Icons.Default.Folder
        } else Icons.Default.Description,
        contentDescription = if (item.isDirectory) "Folder" else "File",
        tint = when {
          item.isDirectory -> com.example.ui.theme.CyberAmberWarning
          badge != null -> badge.second.copy(alpha = 0.9f)
          else -> TextMuted
        },
        modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      // v1.2: long file names are cut in the middle so the extension stays visible.
      com.example.ui.components.MiddleEllipsisText(
        text = item.name,
        color = if (isSelected) CyberCyanPrimary else TextPrimary,
        fontSize = 12.sp,
        fontFamily = FontFamily.Monospace,
        fontWeight = if (item.isDirectory) FontWeight.SemiBold else FontWeight.Normal,
        modifier = Modifier.weight(1f)
      )
      if (item.isDirectory) {
        if (item.children.isNotEmpty()) {
          Text(
            text = item.children.size.toString(),
            color = TextMuted,
            fontSize = 10.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier
              .padding(start = 4.dp)
              .clip(CircleShape)
              .background(ObsidianSurfaceVariant)
              .padding(horizontal = 6.dp, vertical = 1.dp)
          )
        }
      } else if (badge != null) {
        LanguageBadge(badge.first, badge.second, modifier = Modifier.padding(start = 4.dp))
      }
    }

    if (item.isDirectory && isExpanded) {
      item.children.forEach { child ->
        FileTreeItemView(
          item = child,
          level = level + 1,
          expandedMap = expandedMap,
          selectedFilePath = selectedFilePath,
          onFileClick = onFileClick,
          onLongPress = onLongPress
        )
      }
    }
  }
}

@Composable
fun NewProjectDialog(
  onDismiss: () -> Unit,
  onCreate: (name: String, type: ProjectType, description: String) -> Unit
) {
  var name by remember { mutableStateOf("MyAwesomeApp") }
  var selectedType by remember { mutableStateOf(ProjectType.ANDROID_COMPOSE) }
  var description by remember { mutableStateOf("Android Jetpack Compose project") }

  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Create New Project", color = TextPrimary, fontWeight = FontWeight.Bold) },
    text = {
      Column {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Project Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(12.dp))
        Text("Starter Template:", color = TextMuted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)

        ProjectType.values().forEach { type ->
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
              .fillMaxWidth()
              .clickable {
                selectedType = type
                description = "${type.displayName} project"
              }
              .padding(vertical = 2.dp)
          ) {
            RadioButton(
              selected = selectedType == type,
              onClick = { selectedType = type }
            )
            Spacer(modifier = Modifier.width(4.dp))
            Column {
              Text(type.displayName, color = TextPrimary, fontSize = 13.sp)
              Text("Extension: .${type.extensionHint}", color = TextMuted, fontSize = 10.sp)
            }
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { if (name.isNotBlank()) onCreate(name, selectedType, description) },
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
      ) {
        Text("Create Project", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss) { Text("Cancel") }
    }
  )
}

@Composable
fun RenameProjectDialog(
  currentName: String,
  onDismiss: () -> Unit,
  onRename: (String) -> Unit
) {
  var newName by remember { mutableStateOf(currentName) }
  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Rename Project", color = TextPrimary) },
    text = {
      OutlinedTextField(
        value = newName,
        onValueChange = { newName = it },
        label = { Text("New Name") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
      )
    },
    confirmButton = {
      Button(onClick = { if (newName.isNotBlank()) onRename(newName) }) { Text("Rename") }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}

@Composable
fun DeleteProjectDialog(
  projectName: String,
  onDismiss: () -> Unit,
  onConfirm: () -> Unit
) {
  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Delete Project?", color = Color(0xFFF85149)) },
    text = { Text("Are you sure you want to permanently delete project '$projectName'? This cannot be undone.", color = TextPrimary) },
    confirmButton = {
      Button(
        onClick = onConfirm,
        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF85149), contentColor = Color.White)
      ) {
        Text("Delete Permanently")
      }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}

@Composable
fun ImportZipDialog(
  onDismiss: () -> Unit,
  onImport: (zipPath: String, projectName: String) -> Unit
) {
  // v1.6: the ZIP is picked with the system file picker and copied into the app cache (no typed paths,
  // so the dialog can no longer be pointed at the app's own private files).
  val context = LocalContext.current
  val scope = rememberCoroutineScope()
  var projectName by remember { mutableStateOf("ImportedProject") }
  var picked by remember { mutableStateOf<Pair<String, String>?>(null) } // display name to cached path
  var error by remember { mutableStateOf<String?>(null) }
  val picker = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
  ) { uri ->
    if (uri == null) return@rememberLauncherForActivityResult
    scope.launch {
      val r = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        runCatching {
          var name = "project.zip"
          context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) name = c.getString(i) ?: name
          }
          val dir = File(context.cacheDir, "imports").apply { mkdirs() }
          val out = File(dir, "import.zip")
          context.contentResolver.openInputStream(uri)?.use { input -> out.outputStream().use { input.copyTo(it) } } ?: error("Could not open the file.")
          name to out.absolutePath
        }
      }
      r.onSuccess {
        picked = it; error = null
        if (projectName == "ImportedProject") projectName = it.first.substringBeforeLast('.').replace(Regex("[^a-zA-Z0-9_-]"), "_").ifBlank { "ImportedProject" }
      }.onFailure { error = it.message ?: "Could not read the ZIP." }
    }
  }

  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Import ZIP Project", color = TextPrimary, fontWeight = FontWeight.Bold) },
    text = {
      Column {
        Text("Pick a .zip from your phone. Entries that try to escape the project folder (Zip Slip) or unpack to more than 200 MB are refused.", color = TextMuted, fontSize = 12.sp)
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = projectName,
          onValueChange = { projectName = it },
          label = { Text("Project Name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        OutlinedButton(onClick = { picker.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) }, modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)) {
          Text(picked?.first?.let { "Chosen: $it" } ?: "Choose ZIP…", maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        error?.let { Text(it, color = com.example.ui.theme.CyberCoralError, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp)) }
      }
    },
    confirmButton = {
      Button(
        onClick = { picked?.let { if (projectName.isNotBlank()) onImport(it.second, projectName) } },
        enabled = picked != null && projectName.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
      ) {
        Text("Import", fontWeight = FontWeight.Bold)
      }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}

private class HighlightTransformation(lang: String) : VisualTransformation {
  private val language = when (lang) {
    "htm" -> "html"
    "mjs", "cjs" -> "js"
    else -> lang
  }

  override fun filter(text: AnnotatedString): TransformedText =
    TransformedText(SyntaxHighlighter.highlight(text.text, language, TextPrimary), OffsetMapping.Identity)
}

@Composable
private fun EditorField(value: String, onChange: (String) -> Unit, hint: String) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .clip(CircleShape)
      .background(ObsidianSurfaceVariant)
      .padding(horizontal = 12.dp, vertical = 8.dp)
  ) {
    if (value.isEmpty()) Text(hint, color = TextMuted, fontSize = 13.sp)
    BasicTextField(
      value = value,
      onValueChange = onChange,
      singleLine = true,
      textStyle = TextStyle(color = TextPrimary, fontSize = 13.sp),
      cursorBrush = SolidColor(CyberCyanPrimary),
      modifier = Modifier.fillMaxWidth()
    )
  }
}

/** Remembers the most recently opened files for the whole app session (newest first). */
internal object RecentFiles {
  private const val MAX = 8
  val paths = mutableStateListOf<String>()

  fun touch(path: String) {
    paths.remove(path)
    paths.add(0, path)
    while (paths.size > MAX) paths.removeAt(paths.lastIndex)
  }
}

/** Short colored language label for a file name, or null when the type is not recognised. */
internal fun languageBadge(fileName: String): Pair<String, Color>? {
  val lower = fileName.lowercase()
  if (lower.endsWith(".gradle.kts")) return "KTS" to Color(0xFF7F52FF)
  return when (lower.substringAfterLast('.', "")) {
    "kt" -> "KT" to Color(0xFFA97BFF)
    "kts" -> "KTS" to Color(0xFF7F52FF)
    "java" -> "JAVA" to Color(0xFFE76F00)
    "js", "mjs", "cjs", "jsx" -> "JS" to Color(0xFFF7DF1E)
    "ts", "tsx" -> "TS" to Color(0xFF3178C6)
    "html", "htm" -> "HTML" to Color(0xFFE34F26)
    "css" -> "CSS" to Color(0xFF2F74E0)
    "scss", "sass" -> "SCSS" to Color(0xFFCD6799)
    "json" -> "JSON" to Color(0xFFF5A623)
    "md" -> "MD" to Color(0xFF6E8FAE)
    "xml" -> "XML" to Color(0xFF2EA043)
    "py" -> "PY" to Color(0xFF3776AB)
    "gradle" -> "GRDL" to Color(0xFF02303A)
    "sh" -> "SH" to Color(0xFF4EAA25)
    "yml", "yaml" -> "YML" to Color(0xFFCB171E)
    "toml" -> "TOML" to Color(0xFF9C4221)
    "svg" -> "SVG" to Color(0xFFFFB13B)
    "png", "jpg", "jpeg", "webp", "gif" -> "IMG" to Color(0xFF26A69A)
    "txt" -> "TXT" to Color(0xFF8E8E93)
    "c", "h" -> "C" to Color(0xFF555FB0)
    "cpp", "cc", "hpp" -> "C++" to Color(0xFFF34B7D)
    else -> null
  }
}

@Composable
internal fun LanguageBadge(label: String, color: Color, modifier: Modifier = Modifier) {
  val onColor = if (color.luminance() > 0.5f) Color(0xFF1A1A1A) else Color.White
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(4.dp))
      .background(color)
      .padding(horizontal = 4.dp, vertical = 1.dp),
    contentAlignment = Alignment.Center
  ) {
    Text(
      text = label,
      color = onColor,
      fontSize = 8.5.sp,
      lineHeight = 10.sp,
      fontWeight = FontWeight.Bold,
      fontFamily = FontFamily.Monospace,
      maxLines = 1
    )
  }
}

/** Editor placeholder: a small vector illustration plus New File / Open Recent actions. */
@Composable
private fun EditorEmptyState(
  hasProject: Boolean,
  recent: List<String>,
  onNewFile: () -> Unit,
  onOpenRecent: (String) -> Unit,
  onQuickStart: (com.example.data.model.ProjectType, String) -> Unit
) {
  var recentMenu by remember { mutableStateOf(false) }
  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(rememberScrollState())
      .padding(horizontal = 14.dp, vertical = 20.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center
  ) {
    EmptyEditorIllustration(modifier = Modifier.size(width = 132.dp, height = 104.dp))
    Spacer(modifier = Modifier.height(14.dp))
    Text(
      "No file open",
      color = TextPrimary,
      fontSize = 16.sp,
      fontWeight = FontWeight.SemiBold,
      textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      if (hasProject) "Pick a file in the explorer, or start a new one." else "Create or select a project first.",
      color = com.example.ui.theme.TextSecondary,
      fontSize = 12.5.sp,
      lineHeight = 17.sp,
      fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
      textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(16.dp))
    Button(
      onClick = onNewFile,
      enabled = hasProject,
      shape = CircleShape,
      colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
      modifier = Modifier
        .fillMaxWidth()
        .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
    ) {
      Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("New File", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
    Spacer(modifier = Modifier.height(4.dp))
    Text(
      "Create JS, HTML, CSS…",
      color = TextMuted,
      fontSize = 11.5.sp,
      fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
      textAlign = TextAlign.Center
    )
    Spacer(modifier = Modifier.height(10.dp))
    Box(modifier = Modifier.fillMaxWidth()) {
      com.example.ui.components.FilledTonalButton(
        onClick = {
          if (recent.size == 1) onOpenRecent(recent.first()) else recentMenu = true
        },
        enabled = recent.isNotEmpty(),
        shape = CircleShape,
        colors = ButtonDefaults.filledTonalButtonColors(
          containerColor = CyberCyanPrimary.copy(alpha = 0.16f),
          contentColor = CyberCyanPrimary
        ),
        modifier = Modifier
          .fillMaxWidth()
          .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      ) {
        Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Open Recent", fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
      }
      com.example.ui.components.GlassDropdownMenu(expanded = recentMenu, onDismissRequest = { recentMenu = false }) {
        recent.take(6).forEach { p ->
          val f = File(p)
          DropdownMenuItem(
            text = {
              Row(verticalAlignment = Alignment.CenterVertically) {
                languageBadge(f.name)?.let { (label, color) ->
                  LanguageBadge(label, color)
                  Spacer(modifier = Modifier.width(8.dp))
                }
                Text(f.name, fontFamily = FontFamily.Monospace, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
              }
            },
            onClick = {
              recentMenu = false
              onOpenRecent(p)
            }
          )
        }
      }
    }
    // Quick start: one tap makes a project with working starter files and opens it.
    Spacer(modifier = Modifier.height(18.dp))
    Text("Start something new", color = com.example.ui.theme.TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    Spacer(modifier = Modifier.height(8.dp))
    listOf(
      Triple("New HTML/CSS App", com.example.data.model.ProjectType.WEB_HTML, "html-app"),
      Triple("Python Script", com.example.data.model.ProjectType.PYTHON_SCRIPT, "python-script"),
      Triple("React Native", com.example.data.model.ProjectType.REACT_NATIVE, "react-native-app")
    ).forEach { (label, type, base) ->
      com.example.ui.components.FilledTonalButton(
        onClick = { onQuickStart(type, base) },
        shape = CircleShape,
        colors = ButtonDefaults.filledTonalButtonColors(
          containerColor = CyberCyanPrimary.copy(alpha = 0.16f),
          contentColor = CyberCyanPrimary
        ),
        modifier = Modifier.fillMaxWidth().heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      ) {
        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
      }
      Spacer(modifier = Modifier.height(6.dp))
    }
    if (recent.isEmpty()) {
      Spacer(modifier = Modifier.height(6.dp))
      Text(
        "Files you open will show up here.",
        color = TextMuted,
        fontSize = 11.5.sp,
        fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
        textAlign = TextAlign.Center
      )
    }
  }
}

/** Folder with a code sheet and </> brackets, drawn in accent tones (no image assets). */
@Composable
private fun EmptyEditorIllustration(modifier: Modifier = Modifier) {
  val accent = CyberCyanPrimary
  val violet = com.example.ui.theme.CyberVioletSecondary
  val sheet = ObsidianSurfaceVariant
  val line = TextMuted
  androidx.compose.foundation.Canvas(modifier = modifier) {
    val w = size.width
    val h = size.height
    // Soft halo
    drawCircle(
      brush = androidx.compose.ui.graphics.Brush.radialGradient(
        listOf(accent.copy(alpha = 0.22f), Color.Transparent),
        center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.55f),
        radius = w * 0.6f
      ),
      radius = w * 0.6f,
      center = androidx.compose.ui.geometry.Offset(w * 0.5f, h * 0.55f)
    )
    // Code sheet peeking out of the folder
    val sheetTopLeft = androidx.compose.ui.geometry.Offset(w * 0.30f, h * 0.06f)
    val sheetSize = androidx.compose.ui.geometry.Size(w * 0.46f, h * 0.62f)
    drawRoundRect(
      color = sheet,
      topLeft = sheetTopLeft,
      size = sheetSize,
      cornerRadius = androidx.compose.ui.geometry.CornerRadius(8.dp.toPx())
    )
    val stroke = 2.5.dp.toPx()
    listOf(0.16f, 0.26f, 0.36f).forEachIndexed { i, fy ->
      val x0 = sheetTopLeft.x + sheetSize.width * 0.14f
      val x1 = sheetTopLeft.x + sheetSize.width * (if (i == 1) 0.62f else 0.82f)
      drawLine(
        color = line.copy(alpha = 0.7f),
        start = androidx.compose.ui.geometry.Offset(x0, h * fy + h * 0.02f),
        end = androidx.compose.ui.geometry.Offset(x1, h * fy + h * 0.02f),
        strokeWidth = stroke,
        cap = androidx.compose.ui.graphics.StrokeCap.Round
      )
    }
    // Folder back with tab
    val back = androidx.compose.ui.graphics.Path().apply {
      moveTo(w * 0.10f, h * 0.36f)
      lineTo(w * 0.10f, h * 0.30f)
      quadraticBezierTo(w * 0.10f, h * 0.26f, w * 0.14f, h * 0.26f)
      lineTo(w * 0.36f, h * 0.26f)
      lineTo(w * 0.42f, h * 0.34f)
      lineTo(w * 0.86f, h * 0.34f)
      quadraticBezierTo(w * 0.90f, h * 0.34f, w * 0.90f, h * 0.38f)
      lineTo(w * 0.90f, h * 0.44f)
      close()
    }
    drawPath(back, color = violet.copy(alpha = 0.85f))
    // Folder front
    drawRoundRect(
      brush = androidx.compose.ui.graphics.Brush.linearGradient(
        listOf(accent, violet),
        start = androidx.compose.ui.geometry.Offset(w * 0.1f, h * 0.4f),
        end = androidx.compose.ui.geometry.Offset(w * 0.9f, h * 0.96f)
      ),
      topLeft = androidx.compose.ui.geometry.Offset(w * 0.06f, h * 0.40f),
      size = androidx.compose.ui.geometry.Size(w * 0.88f, h * 0.56f),
      cornerRadius = androidx.compose.ui.geometry.CornerRadius(10.dp.toPx())
    )
    // </> on the folder
    val cy = h * 0.68f
    val bw = w * 0.09f
    val bh = h * 0.12f
    val white = Color.White
    val sw = 3.dp.toPx()
    val cap = androidx.compose.ui.graphics.StrokeCap.Round
    val lx = w * 0.34f
    drawLine(white, androidx.compose.ui.geometry.Offset(lx, cy - bh), androidx.compose.ui.geometry.Offset(lx - bw, cy), sw, cap)
    drawLine(white, androidx.compose.ui.geometry.Offset(lx - bw, cy), androidx.compose.ui.geometry.Offset(lx, cy + bh), sw, cap)
    val rx = w * 0.66f
    drawLine(white, androidx.compose.ui.geometry.Offset(rx, cy - bh), androidx.compose.ui.geometry.Offset(rx + bw, cy), sw, cap)
    drawLine(white, androidx.compose.ui.geometry.Offset(rx + bw, cy), androidx.compose.ui.geometry.Offset(rx, cy + bh), sw, cap)
    drawLine(
      white.copy(alpha = 0.9f),
      androidx.compose.ui.geometry.Offset(w * 0.54f, cy - bh * 1.05f),
      androidx.compose.ui.geometry.Offset(w * 0.46f, cy + bh * 1.05f),
      sw, cap
    )
  }
}

@Composable
private fun NewFileDialog(
  onDismiss: () -> Unit,
  onCreate: (String) -> Unit
) {
  var name by remember { mutableStateOf("") }
  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("New File", color = TextPrimary, fontWeight = FontWeight.Bold) },
    text = {
      Column {
        Text(
          "Path inside the project, for example index.html or js/app.js. Missing folders are created.",
          color = com.example.ui.theme.TextSecondary,
          fontSize = 12.5.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight
        )
        Spacer(modifier = Modifier.height(10.dp))
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("File name") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth()
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { if (name.isNotBlank()) onCreate(name) },
        enabled = name.isNotBlank(),
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
      ) { Text("Create", fontWeight = FontWeight.Bold) }
    },
    dismissButton = { OutlinedButton(onClick = onDismiss) { Text("Cancel") } }
  )
}


/** v1.6: one 48 dp row in the explorer action dialogs. */
@Composable
private fun MenuRow(label: String, danger: Boolean = false, onClick: () -> Unit) {
  Box(
    Modifier.fillMaxWidth().heightIn(min = 48.dp).clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 8.dp),
    contentAlignment = Alignment.CenterStart
  ) { Text(label, color = if (danger) com.example.ui.theme.CyberCoralError else TextPrimary, fontSize = 15.sp) }
}
