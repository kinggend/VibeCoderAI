package com.example.project

import java.io.File

/**
 * v1.6 global search & replace across a project. Pure engine (unit tested): case, regex and whole-word
 * options, results grouped by file with line previews. Dot folders (.vibecoder history/backups, .git),
 * build output and binary or very large files are never searched or changed.
 */
object ProjectSearch {
  data class Options(val caseSensitive: Boolean = false, val regex: Boolean = false, val wholeWord: Boolean = false)

  /** One hit: 1-based [line], 0-based [column] in that line, match [length], and the trimmed [preview]. */
  data class Match(val line: Int, val column: Int, val length: Int, val preview: String, val offset: Int)

  data class FileMatches(val path: String, val matches: List<Match>)

  const val MAX_FILE_BYTES = 1_000_000L
  const val MAX_RESULTS = 2000
  private val SKIP_DIRS = setOf("build", "node_modules")

  /** The pattern for [query], or an error message for an invalid regex / empty query. */
  fun pattern(query: String, opts: Options): Result<Regex> = runCatching {
    require(query.isNotEmpty()) { "Type something to search for." }
    val body = if (opts.regex) query else Regex.escape(query)
    val full = if (opts.wholeWord) "(?<![A-Za-z0-9_])(?:$body)(?![A-Za-z0-9_])" else body
    val set = if (opts.caseSensitive) emptySet() else setOf(RegexOption.IGNORE_CASE)
    try {
      Regex(full, set)
    } catch (e: Exception) {
      throw IllegalArgumentException("Invalid regular expression: ${e.message?.lineSequence()?.firstOrNull()}")
    }
  }

  /** All matches in [text]. Zero-length regex matches (like "^") are skipped so nothing loops. */
  fun findIn(text: String, rx: Regex, limit: Int = MAX_RESULTS): List<Match> {
    val out = mutableListOf<Match>()
    val lineStarts = mutableListOf(0)
    text.forEachIndexed { i, c -> if (c == '\n') lineStarts += i + 1 }
    for (m in rx.findAll(text)) {
      if (m.range.isEmpty()) continue
      val start = m.range.first
      var li = lineStarts.binarySearch(start)
      if (li < 0) li = -li - 2
      val ls = lineStarts[li]
      val le = text.indexOf('\n', ls).let { if (it < 0) text.length else it }
      out += Match(li + 1, start - ls, m.value.length, text.substring(ls, le).trim().take(160), start)
      if (out.size >= limit) break
    }
    return out
  }

  /**
   * Replaces matches in [text]. [onlyOffset] replaces just the match starting there (Replace one).
   * With regex on, "$1" style groups in [replacement] work; otherwise it is literal. Returns text and count.
   */
  fun replaceIn(text: String, rx: Regex, replacement: String, opts: Options, onlyOffset: Int? = null): Pair<String, Int> {
    var count = 0
    val sb = StringBuilder()
    var last = 0
    for (m in rx.findAll(text)) {
      if (m.range.isEmpty()) continue
      if (onlyOffset != null && m.range.first != onlyOffset) continue
      sb.append(text, last, m.range.first)
      sb.append(if (opts.regex) expand(m, replacement) else replacement)
      last = m.range.last + 1
      count++
      if (onlyOffset != null) break
    }
    sb.append(text, last, text.length)
    return sb.toString() to count
  }

  /** "$1" / "${name}" group references; "\$" is a literal dollar. */
  private fun expand(m: MatchResult, repl: String): String {
    val sb = StringBuilder()
    var i = 0
    while (i < repl.length) {
      val c = repl[i]
      if (c == '\\' && i + 1 < repl.length) { sb.append(repl[i + 1]); i += 2; continue }
      if (c == '$' && i + 1 < repl.length && repl[i + 1].isDigit()) {
        var j = i + 1
        while (j < repl.length && repl[j].isDigit()) j++
        val g = repl.substring(i + 1, j).toInt()
        sb.append(m.groupValues.getOrNull(g).orEmpty())
        i = j
        continue
      }
      sb.append(c)
      i++
    }
    return sb.toString()
  }

  /** Files that may be searched: text-like, not hidden, not build output, not too big. */
  fun searchable(root: File): List<File> =
    root.walkTopDown()
      .onEnter { it == root || (!it.name.startsWith(".") && it.name !in SKIP_DIRS) }
      .filter { it.isFile && !it.name.startsWith(".") && it.length() <= MAX_FILE_BYTES }
      .toList()

  private fun readText(f: File): String? = runCatching {
    val bytes = f.readBytes()
    if (bytes.any { it == 0.toByte() }) null else String(bytes, Charsets.UTF_8)
  }.getOrNull()

  fun search(root: File, query: String, opts: Options): Result<List<FileMatches>> = pattern(query, opts).map { rx ->
    var total = 0
    searchable(root).mapNotNull { f ->
      if (total >= MAX_RESULTS) return@mapNotNull null
      val t = readText(f) ?: return@mapNotNull null
      val ms = findIn(t, rx, MAX_RESULTS - total)
      total += ms.size
      if (ms.isEmpty()) null else FileMatches(f.relativeTo(root).invariantSeparatorsPath, ms)
    }
  }

  /** Writes the replacement into every searchable file; [skip] are relative paths left alone (unsaved in the editor). */
  fun replaceAll(root: File, query: String, replacement: String, opts: Options, skip: Set<String> = emptySet()): Result<Map<String, Int>> =
    pattern(query, opts).map { rx ->
      val changed = linkedMapOf<String, Int>()
      for (f in searchable(root)) {
        val rel = f.relativeTo(root).invariantSeparatorsPath
        if (rel in skip) continue
        val t = readText(f) ?: continue
        val (out, n) = replaceIn(t, rx, replacement, opts)
        if (n > 0) {
          f.writeText(out)
          changed[rel] = n
        }
      }
      changed
    }
}
