package com.example.phone

import com.example.agent.MiniJson

/** v1.7.0: one thing the phone agent can do. The model picks exactly one per step. */
sealed class PhoneAction {
  data class Tap(val id: Int) : PhoneAction()
  data class LongPress(val id: Int) : PhoneAction()
  data class Type(val id: Int?, val text: String) : PhoneAction()
  object Enter : PhoneAction()
  data class Scroll(val direction: String, val id: Int?) : PhoneAction()
  /** Coordinates in the attached screenshot. For apps with no readable elements (3D, video editors, games). */
  data class TapXY(val x: Int, val y: Int, val label: String) : PhoneAction()
  data class LongPressXY(val x: Int, val y: Int, val label: String) : PhoneAction()
  data class Swipe(val x1: Int, val y1: Int, val x2: Int, val y2: Int) : PhoneAction()
  object Back : PhoneAction()
  object Home : PhoneAction()
  object Recents : PhoneAction()
  object Notifications : PhoneAction()
  /** The quick-settings panel (flashlight, Wi-Fi, Bluetooth, brightness tiles). */
  object QuickSettings : PhoneAction()
  data class OpenApp(val name: String) : PhoneAction()
  data class OpenUrl(val url: String) : PhoneAction()
  data class YouTubeSearch(val query: String) : PhoneAction()
  data class Wait(val ms: Long) : PhoneAction()
  data class Done(val summary: String) : PhoneAction()
  data class Ask(val question: String) : PhoneAction()

  /** What the step list and History show for this action. */
  fun describe(screen: CompactScreen?): String {
    fun el(id: Int?) = id?.let { i -> screen?.element(i)?.let { e -> if (e.label.isNotBlank()) "\"${e.label}\"" else "#$i ${e.kind}" } ?: "#$i" }
    return when (this) {
      is Tap -> "Tap ${el(id)}"
      is LongPress -> "Long-press ${el(id)}"
      is Type -> "Type \"${text.take(40)}\"" + (id?.let { " into ${el(it)}" } ?: "")
      Enter -> "Press Enter"
      is Scroll -> "Scroll $direction" + (id?.let { " in ${el(it)}" } ?: "")
      is TapXY -> "Tap \"${label.take(40)}\" at ($x,$y)"
      is LongPressXY -> "Long-press \"${label.take(40)}\" at ($x,$y)"
      is Swipe -> "Swipe ($x1,$y1) to ($x2,$y2)"
      Back -> "Back"
      Home -> "Home"
      Recents -> "Recent apps"
      Notifications -> "Open notifications"
      QuickSettings -> "Open quick settings"
      is OpenApp -> "Open $name"
      is OpenUrl -> "Open $url"
      is YouTubeSearch -> "Search YouTube for \"$query\""
      is Wait -> "Wait ${ms / 1000.0}s"
      is Done -> "Done: $summary"
      is Ask -> "Question: $question"
    }
  }
}

object PhoneActionParser {
  /** The tool list given to the model, one JSON object per line. */
  const val TOOLS = """{"action":"tap","id":12}
{"action":"long_press","id":12}
{"action":"type","id":5,"text":"telugu songs"}
{"action":"enter"}
{"action":"scroll","direction":"down"}   (up, down, left, right; optional "id" of a list)
{"action":"swipe","x1":360,"y1":900,"x2":360,"y2":300}   (screen pixels, or screenshot pixels when one is attached)
{"action":"tap_xy","x":210,"y":640,"label":"Add clip button"}   (only with a screenshot; label = what you tap)
{"action":"long_press_xy","x":210,"y":640,"label":"clip on timeline"}
{"action":"back"}  {"action":"home"}  {"action":"recents"}  {"action":"notifications"}  {"action":"quick_settings"}
{"action":"open_app","name":"YouTube"}
{"action":"open_url","url":"https://example.com"}
{"action":"wait","ms":1500}
{"action":"done","summary":"Playing Telugu songs on YouTube"}
{"action":"ask","question":"Which address should I use?"}"""

  class ParseError(message: String) : Exception(message)

  private val OBJECT = Regex("\\{[^{}]*\\}", RegexOption.DOT_MATCHES_ALL)

  private fun int(v: Any?): Int? = when (v) {
    is Number -> v.toInt()
    is String -> v.trim().removePrefix("#").toIntOrNull()
    else -> null
  }

  private fun str(v: Any?): String? = (v as? String)?.trim()?.takeIf { it.isNotEmpty() }

  /**
   * The first JSON action in [reply]. Code fences, thinking text and words around the object are
   * ignored. Throws [ParseError] with a message the model can act on.
   */
  fun parse(reply: String): PhoneAction {
    val text = com.example.agent.Thinking.split(reply).second.ifBlank { reply }
    val candidates = OBJECT.findAll(text).map { it.value }.toList()
    if (candidates.isEmpty()) throw ParseError("No JSON action found. Reply with one JSON object like {\"action\":\"tap\",\"id\":3}.")
    var last: String? = null
    for (c in candidates) {
      val map = try { MiniJson.parseObject(c) } catch (e: Exception) { last = e.message; continue }
      return fromMap(map)
    }
    throw ParseError("The JSON action could not be read ($last).")
  }

  fun fromMap(m: Map<String, Any?>): PhoneAction {
    val name = (str(m["action"]) ?: str(m["tool"]) ?: str(m["type"]) ?: throw ParseError("The JSON has no \"action\"."))
      .lowercase().replace('-', '_').replace(' ', '_')
    val id = int(m["id"]) ?: int(m["element"]) ?: int(m["target"]) ?: int(m["index"])
    fun need(v: Int?, what: String) = v ?: throw ParseError("\"$name\" needs \"$what\" (the #number of an element).")
    return when (name) {
      "tap", "click", "press" -> PhoneAction.Tap(need(id, "id"))
      "long_press", "longpress", "long_click", "hold" -> PhoneAction.LongPress(need(id, "id"))
      "type", "input", "set_text", "write" -> PhoneAction.Type(id, (m["text"] as? String) ?: throw ParseError("\"type\" needs \"text\"."))
      "enter", "submit", "search_key", "ime_enter" -> PhoneAction.Enter
      "scroll" -> {
        val d = (str(m["direction"]) ?: str(m["dir"]) ?: "down").lowercase()
        if (d !in setOf("up", "down", "left", "right")) throw ParseError("\"scroll\" direction must be up, down, left or right.")
        PhoneAction.Scroll(d, id)
      }
      "tap_xy", "tap_at", "click_xy", "tap_point" -> PhoneAction.TapXY(
        int(m["x"]) ?: throw ParseError("\"tap_xy\" needs x and y."), int(m["y"]) ?: throw ParseError("\"tap_xy\" needs y."),
        str(m["label"]) ?: throw ParseError("\"tap_xy\" needs \"label\": a few words for what you are tapping.")
      )
      "long_press_xy", "longpress_xy", "hold_xy" -> PhoneAction.LongPressXY(
        int(m["x"]) ?: throw ParseError("\"long_press_xy\" needs x and y."), int(m["y"]) ?: throw ParseError("\"long_press_xy\" needs y."),
        str(m["label"]) ?: throw ParseError("\"long_press_xy\" needs \"label\".")
      )
      "swipe" -> PhoneAction.Swipe(
        int(m["x1"]) ?: throw ParseError("\"swipe\" needs x1, y1, x2, y2."), int(m["y1"]) ?: throw ParseError("\"swipe\" needs y1."),
        int(m["x2"]) ?: throw ParseError("\"swipe\" needs x2."), int(m["y2"]) ?: throw ParseError("\"swipe\" needs y2.")
      )
      "back" -> PhoneAction.Back
      "home" -> PhoneAction.Home
      "recents", "recent_apps" -> PhoneAction.Recents
      "notifications", "open_notifications" -> PhoneAction.Notifications
      "quick_settings", "quicksettings", "open_quick_settings", "settings_panel" -> PhoneAction.QuickSettings
      "open_app", "launch", "open", "launch_app" -> PhoneAction.OpenApp(str(m["name"]) ?: str(m["app"]) ?: throw ParseError("\"open_app\" needs \"name\"."))
      "open_url", "url", "browse" -> PhoneAction.OpenUrl(str(m["url"]) ?: throw ParseError("\"open_url\" needs \"url\"."))
      "youtube_search", "youtube" -> PhoneAction.YouTubeSearch(str(m["query"]) ?: str(m["text"]) ?: throw ParseError("\"youtube_search\" needs \"query\"."))
      "wait", "sleep" -> PhoneAction.Wait(((m["ms"] as? Number)?.toLong() ?: 1500L).coerceIn(300L, 8000L))
      "done", "finish", "complete" -> PhoneAction.Done(str(m["summary"]) ?: str(m["text"]) ?: "Task finished")
      "ask", "question", "ask_user" -> PhoneAction.Ask(str(m["question"]) ?: str(m["text"]) ?: "I need more details to continue.")
      else -> throw ParseError("Unknown action \"$name\". Use one of: tap, long_press, type, enter, scroll, swipe, tap_xy, long_press_xy, back, home, open_app, open_url, youtube_search, wait, done, ask.")
    }
  }
}
