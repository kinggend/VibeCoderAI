package com.example.agent

/**
 * What the agent shows when the MODEL cannot run (not enough RAM, engine error, server unreachable).
 * These are hardware / setup limits, not code bugs, so the repair loop must never try to "fix" them.
 * Pure Kotlin so it is unit-tested.
 */
data class EngineHalt(
  val kind: Kind,
  val title: String,
  val message: String,
  val neededMb: Long = 0,
  val availableMb: Long = 0,
  /** A context size that would fit in the free RAM, or null when even a small one does not. */
  val suggestedContext: Int? = null
) {
  enum class Kind { MEMORY, ENGINE }
}

object EngineFailure {
  private val NOTICE_PREFIXES = listOf(
    "Offline model was not loaded", "Offline model is not ready", "Cannot reach the remote server",
    "[Engine error", "[Generation error", "[No progress"
  )

  /** A reply the engine wrote in place of a model answer. */
  fun isEngineNotice(text: String): Boolean {
    val t = text.trimStart()
    return NOTICE_PREFIXES.any { t.startsWith(it) }
  }

  /** An exception line like "[Error: OutOfMemoryError: ...]" (never plain model prose that mentions memory). */
  fun isResourceError(text: String): Boolean = RESOURCE.containsMatchIn(text)

  /** True when retrying the repair loop is pointless: the model itself could not run. */
  fun isHalting(text: String): Boolean = isEngineNotice(text) || isResourceError(text)

  /** Memory limit: say it plainly and offer the fixes that can work. */
  fun memory(neededBytes: Long, availableBytes: Long, suggestedContext: Int?): EngineHalt {
    val need = neededBytes / 1048576
    val free = availableBytes / 1048576
    val fix = if (suggestedContext != null)
      "Please reduce Context Window to $suggestedContext, or switch to a smaller model."
    else
      "Even a small context does not fit. Please switch to a smaller model."
    return EngineHalt(
      EngineHalt.Kind.MEMORY, "Insufficient RAM",
      "$fix\n\nThis model needs about $need MB but only $free MB is free. " +
        "More retries cannot fix a hardware limit, so the agent stopped.",
      need, free, suggestedContext
    )
  }

  /** Halt for any engine notice; a memory notice becomes the RAM dialog (numbers come from [verdict]). */
  fun fromNotice(text: String, verdict: Triple<Long, Long, Int?>?): EngineHalt {
    if (verdict != null && (text.contains("not enough", ignoreCase = true) || isResourceError(text) || text.contains("Offline model was not loaded"))) {
      return memory(verdict.first, verdict.second, verdict.third)
    }
    if (isResourceError(text)) return memory(0, 0, 1024)
    return EngineHalt(
      EngineHalt.Kind.ENGINE, "The model could not run",
      text.trim().lineSequence().firstOrNull { it.isNotBlank() }.orEmpty().take(240) +
        "\n\nThis is a setup problem, not a code problem, so the agent stopped instead of retrying."
    )
  }

  /** Remaining fix attempts, never negative; 0 when the engine is halted. */
  fun attemptsLeft(max: Int, used: Int, halted: Boolean): Int = if (halted) 0 else (max - used).coerceAtLeast(0)

  private val RESOURCE = Regex(
    """\[(?:Error|Engine error|Generation error)[^\]]*(?:outofmemory|out of memory|bad_alloc|failed to allocate|unable to allocate|not enough (?:free )?memory)""",
    RegexOption.IGNORE_CASE
  )
}
