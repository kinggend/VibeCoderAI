package com.example.phone

/** A short script that runs without a model call; [next] returns null when the model should decide. */
interface ScriptedFlow {
  val gaveUp: Boolean
  fun next(screen: CompactScreen, pkg: String): PhoneAction?
}

/**
 * v1.7.5: "WhatsApp lo Ravi ki hello ani msg pettu" as a script: search the contact, open the chat,
 * type the message, tap Send. The Send tap still goes through RiskGuard, so the user approves it.
 * Pure Kotlin: unit-tested without Android.
 */
class MessageFlow(val contact: String, val text: String) : ScriptedFlow {
  private var typedContact = false
  private var picked = false
  private var typedMsg = false
  private var sent = false
  private var waits = 0
  private var misses = 0
  private var backs = 0

  override val gaveUp: Boolean get() = misses >= 3 || waits > 10 || backs > 2

  override fun next(screen: CompactScreen, pkg: String): PhoneAction? {
    if (!pkg.startsWith("com.whatsapp")) return null
    val els = screen.elements
    if (sent) return PhoneAction.Done("Sent \"${text.take(40)}\" to $contact on WhatsApp")
    if (els.size < 3) return PhoneAction.Wait(800)

    val box = els.firstOrNull { it.editable && !it.password && isMessageBox(it) }
    if (box != null) {
      // A chat that was already open could be the wrong person: go back to the list first.
      if (!picked) { backs++; return PhoneAction.Back }
      if (!typedMsg) { typedMsg = true; return PhoneAction.Type(box.id, text) }
      els.firstOrNull { it.clickable && !it.editable && isSend(it) }?.let { sent = true; return PhoneAction.Tap(it.id) }
      waits++
      return PhoneAction.Wait(500)
    }

    if (!typedContact) {
      els.firstOrNull { it.editable && !it.password }?.let { typedContact = true; return PhoneAction.Type(it.id, contact) }
      els.firstOrNull { it.clickable && !it.editable && it.label.lowercase().contains("search") }?.let { return PhoneAction.Tap(it.id) }
      misses++
      return null
    }
    if (!picked) {
      val c = contact.lowercase()
      val hit = els.firstOrNull { it.clickable && !it.editable && !it.label.lowercase().startsWith("search") && c in it.full.lowercase() }
      if (hit != null) { picked = true; return PhoneAction.Tap(hit.id) }
      waits++
      return PhoneAction.Wait(900)
    }
    // Chat is opening.
    waits++
    return PhoneAction.Wait(600)
  }

  companion object {
    fun isMessageBox(e: ScreenElement): Boolean = e.label.lowercase().contains("message")
    fun isSend(e: ScreenElement): Boolean = e.label.trim().lowercase().let { it == "send" || it == "send message" }
  }
}
