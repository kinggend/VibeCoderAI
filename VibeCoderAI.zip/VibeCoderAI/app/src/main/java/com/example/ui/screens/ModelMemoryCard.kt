package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.llama.MemoryEstimator
import com.example.llama.ModelMemory
import com.example.ui.components.RamBar
import com.example.ui.theme.CyberAmberWarning
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

/**
 * Models screen: "Free RAM vs Required RAM" for the selected model at the chosen context window.
 * A context that does not fit free RAM is lowered automatically (largest standard size that fits, else 1024)
 * and the reason is shown, so a load never fails for a setting the user can see.
 */
@Composable
internal fun ModelMemoryCard(
  memory: ModelMemory?,
  contextLength: Int,
  onContextChange: (Int) -> Unit
) {
  var notice by remember { mutableStateOf<String?>(null) }
  if (memory == null) {
    ModelSurface {
      Text("Select a downloaded model to see how much RAM it needs.", color = TextSecondary, fontSize = 13.sp)
    }
    return
  }
  fun requiredMb(ctx: Int) = MemoryEstimator.neededBytes(memory.fileBytes, maxOf(ctx, memory.minContext)) / 1048576
  val freeMb = memory.freeBytes / 1048576

  // Opened with a context that is already too big: lower it now and say so.
  LaunchedEffect(memory.fileBytes, memory.freeBytes, contextLength) {
    val g = MemoryEstimator.guard(memory.fileBytes, maxOf(contextLength, memory.minContext), memory.freeBytes)
    if (g.lowered && g.contextTokens < contextLength) {
      notice = "A $contextLength-token context needs about ${g.neededBytes / 1048576} MB but only $freeMb MB is free, so it was lowered to ${g.contextTokens}."
      onContextChange(g.contextTokens)
    }
  }

  ModelSurface {
    Text("Memory", color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
    Spacer(Modifier.height(10.dp))
    RamBar(requiredMb(contextLength), freeMb)
    Spacer(Modifier.height(14.dp))
    Text("Context window", color = TextSecondary, fontSize = 12.sp)
    Spacer(Modifier.height(6.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      listOf(1024, 2048, 4096, 8192).forEach { ctx ->
        val selected = ctx == contextLength
        Text(
          "$ctx",
          color = if (selected) Color.White else TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Medium,
          modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) CyberCyanPrimary else ObsidianSurfaceVariant)
            .clickable(onClickLabel = "Use a $ctx token context") {
              val g = MemoryEstimator.guard(memory.fileBytes, maxOf(ctx, memory.minContext), memory.freeBytes)
              if (g.lowered) {
                notice = "$ctx tokens needs about ${g.neededBytes / 1048576} MB but only $freeMb MB is free. Using ${g.contextTokens} instead."
                onContextChange(g.contextTokens)
              } else {
                notice = null
                onContextChange(ctx)
              }
            }
            .heightIn(min = 40.dp)
            .padding(horizontal = 16.dp, vertical = 10.dp)
        )
      }
    }
    notice?.let {
      Spacer(Modifier.height(10.dp))
      Row(verticalAlignment = Alignment.Top) {
        Text("Warning", color = CyberAmberWarning, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      }
      Text(it, color = CyberAmberWarning, fontSize = 12.sp, lineHeight = 17.sp)
    }
    if (memory.minContext > 0) {
      Spacer(Modifier.height(8.dp))
      Text("Vision models keep at least ${memory.minContext} tokens for image data.", color = TextMuted, fontSize = 12.sp)
    }
  }
}
