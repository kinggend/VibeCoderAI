package com.example.data.downloader

import org.json.JSONArray
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class HfModel(val id: String, val downloads: Long, val likes: Long)
data class HfFile(val name: String, val sizeBytes: Long)

/** Minimal Hugging Face Hub client (public models only). Blocking: call from a background thread. */
object HuggingFaceApi {
  const val BASE = "https://huggingface.co"
  const val USER_AGENT = "VibeCoderAI/1.0"

  fun search(query: String): List<HfModel> {
    val q = URLEncoder.encode(query.trim(), "UTF-8")
    val json = JSONArray(get("$BASE/api/models?search=$q&filter=gguf&sort=downloads&direction=-1&limit=20"))
    return (0 until json.length()).map { i ->
      val o = json.getJSONObject(i)
      HfModel(
        id = o.optString("id", o.optString("modelId")),
        downloads = o.optLong("downloads"),
        likes = o.optLong("likes")
      )
    }.filter { it.id.isNotBlank() }
  }

  fun listGguf(modelId: String): List<HfFile> {
    val json = JSONArray(get("$BASE/api/models/$modelId/tree/main"))
    return (0 until json.length()).mapNotNull { i ->
      val o = json.getJSONObject(i)
      val path = o.optString("path")
      if (o.optString("type") != "file" || !path.endsWith(".gguf", ignoreCase = true)) return@mapNotNull null
      val size = o.optJSONObject("lfs")?.optLong("size") ?: o.optLong("size")
      HfFile(path, size)
    }.sortedBy { it.sizeBytes }
  }

  private fun get(url: String): String {
    val c = URL(url).openConnection() as HttpURLConnection
    c.connectTimeout = 15_000
    c.readTimeout = 20_000
    c.setRequestProperty("User-Agent", USER_AGENT)
    try {
      if (c.responseCode !in 200..299) throw IOException("Hugging Face returned HTTP ${c.responseCode}")
      return c.inputStream.bufferedReader().use { it.readText() }
    } finally {
      c.disconnect()
    }
  }
}
