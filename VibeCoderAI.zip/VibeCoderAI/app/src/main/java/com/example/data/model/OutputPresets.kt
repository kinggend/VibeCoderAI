package com.example.data.model

import kotlin.math.abs

/**
 * v1.5: one-tap sampling presets. [topK] null = the preset leaves Top-K as it is.
 * v1.6: a preset may also set [maxTokens] and [context]. Only "Fast" does, and only to smaller values,
 * so applying it can never push the model past the memory it already had.
 */
data class SamplingPreset(
  val id: String,
  val label: String,
  val temperature: Float,
  val topP: Float,
  val topK: Int? = null,
  val maxTokens: Int? = null,
  val context: Int? = null,
  val blurb: String = ""
)

object OutputPresets {
  val all = listOf(
    SamplingPreset("coding", "Coding", 0.2f, 0.95f, 40, blurb = "Steady and exact."),
    SamplingPreset("balanced", "Balanced", 0.6f, 0.9f, blurb = "Some variety."),
    SamplingPreset("creative", "Creative", 0.8f, 1.0f, blurb = "Most varied."),
    SamplingPreset("fast", "Fast", 0.3f, 0.9f, 40, maxTokens = 512, context = 2048, blurb = "Short answers, 2048 context, 512 output tokens. Quickest on a phone.")
  )

  private fun same(a: Float, b: Float) = abs(a - b) < 0.001f

  /** The preset the current values equal, or null ("Custom"). Checked in list order. */
  fun match(temperature: Float, topP: Float, topK: Int, maxTokens: Int? = null, context: Int? = null): SamplingPreset? =
    all.firstOrNull { p ->
      same(p.temperature, temperature) && same(p.topP, topP) && (p.topK == null || p.topK == topK) &&
        (p.maxTokens == null || maxTokens == null || p.maxTokens == maxTokens) &&
        (p.context == null || context == null || context <= p.context)
    }

  fun match(s: SettingsState): SamplingPreset? = match(s.temperature, s.topP, s.topK, s.maxOutputTokens, s.contextLength)

  fun label(s: SettingsState): String = match(s)?.label ?: "Custom"

  /** Context is only ever lowered by a preset ("where safe"); max output never exceeds context minus a prompt reserve. */
  fun apply(s: SettingsState, p: SamplingPreset): SettingsState {
    val ctx = p.context?.let { minOf(it, s.contextLength) } ?: s.contextLength
    val out = p.maxTokens?.let { minOf(it, (ctx - 512).coerceAtLeast(256)) } ?: s.maxOutputTokens
    return s.copy(temperature = p.temperature, topP = p.topP, topK = p.topK ?: s.topK, maxOutputTokens = out, contextLength = ctx)
  }
}
