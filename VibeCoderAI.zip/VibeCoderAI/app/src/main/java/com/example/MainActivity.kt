package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import com.example.ui.MainScreen
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    com.example.data.SettingsStore(this).load().let {
      com.example.ui.theme.ThemeController.mode = it.themeMode
      com.example.ui.theme.ThemeController.blur = it.glassBlur
      com.example.ui.theme.ThemeController.blurRadiusDp = it.blurRadiusDp
      com.example.ui.theme.ThemeController.accent = it.accent
    }
    requestHighRefreshRate()
    handleOpenChat(intent)
    setContent {
      MyApplicationTheme {
        MainScreen()
      }
    }
  }

  /** v1.4: critical memory pressure unloads the model (see MemoryPressure / MainScreen). */
  override fun onTrimMemory(level: Int) {
    super.onTrimMemory(level)
    com.example.llama.MemoryPressure.onTrimMemory(level)
  }

  // v1.6.2: the run notification opens the chat; visibility decides whether approvals also notify.
  override fun onNewIntent(intent: android.content.Intent) {
    super.onNewIntent(intent)
    handleOpenChat(intent)
  }

  private fun handleOpenChat(intent: android.content.Intent?) {
    if (intent?.getBooleanExtra(com.example.agent.AgentRunService.EXTRA_OPEN_CHAT, false) == true) {
      AppGraph.get(this).openChatRequests.value = System.currentTimeMillis()
    }
  }

  override fun onStart() {
    super.onStart()
    AppGraph.get(this).visibleFlow.value = true
  }

  override fun onStop() {
    AppGraph.get(this).visibleFlow.value = false
    super.onStop()
  }

  override fun onResume() {
    super.onResume()
    requestHighRefreshRate()
  }

  /** Asks the system for the highest refresh rate the screen supports (90/120/144 Hz). The system may still lower it (battery saver, adaptive mode). */
  private fun requestHighRefreshRate() {
    runCatching {
      val disp = if (android.os.Build.VERSION.SDK_INT >= 30) display else @Suppress("DEPRECATION") windowManager.defaultDisplay
      disp ?: return
      val cur = disp.mode
      val best = disp.supportedModes
        .filter { it.physicalWidth == cur.physicalWidth && it.physicalHeight == cur.physicalHeight }
        .maxByOrNull { it.refreshRate } ?: return
      window.attributes = window.attributes.also {
        it.preferredDisplayModeId = best.modeId
        it.preferredRefreshRate = best.refreshRate
      }
    }
  }
}
