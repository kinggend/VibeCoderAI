package com.example.data.model

import java.io.File

enum class ProjectType(val displayName: String, val extensionHint: String) {
  ANDROID_COMPOSE("Android Jetpack Compose", "kt"),
  NODE_CLI("Node.js CLI Tool", "js"),
  WEB_HTML("Web Frontend (HTML/JS)", "html"),
  PYTHON_SCRIPT("Python Automation", "py"),
  REACT_NATIVE("React Native (Expo)", "js")
}

data class Project(
  val id: String,
  val name: String,
  val rootPath: String,
  val description: String,
  val type: ProjectType,
  val createdAt: Long = System.currentTimeMillis(),
  val updatedAt: Long = System.currentTimeMillis(),
  val activeFilePath: String? = null
) {
  val rootDir: File get() = File(rootPath)
}

data class FileItem(
  val name: String,
  val path: String,
  val isDirectory: Boolean,
  val sizeBytes: Long = 0,
  val lastModified: Long = 0,
  val children: List<FileItem> = emptyList()
)
