package com.example.data.model

data class CompilationError(
  val filePath: String,
  val lineNumber: Int,
  val columnNumber: Int = 1,
  val errorMessage: String,
  val errorType: String = "error", // error, warning
  val snippet: String = ""
)

enum class BuildStatus {
  IDLE,
  BUILDING,
  SUCCESS,
  FAILED
}

data class BuildResult(
  val status: BuildStatus,
  val logs: List<String> = emptyList(),
  val errors: List<CompilationError> = emptyList(),
  val durationMs: Long = 0,
  val apkPath: String? = null,
  val buildTime: Long = System.currentTimeMillis()
)
