# VibeCoder security audit, v1.9.17

Method: static review of the manifest, WebView, network, secrets, archives, downloads, terminal/agent execution, intents and logging; Android-only regex lint; host tests for the new rules (tools/icu_lint.py, kt/h18, kt/h19, kt/h20). Not run on a device.

## Fixed in this version
| # | Severity | Finding | Fix |
|---|----------|---------|-----|
| 1 | High | Terminal/agent sandbox escape: `cd ..` (no slash) was not caught, so a command chain could leave the project folder. | `..` as a whole path part is blocked (SecurityManager.PARENT_DIR). `a..b` and `...` still allowed. |
| 2 | High | Commands could read the app's private data and shared storage (`/data`, `/storage`, `/sdcard`, `/mnt`, ...): other projects, chat database. | Those roots are blocked. The workspace's own full path (what `pwd` prints) is still allowed. |
| 3 | Medium | Path denylist skipped paths that follow `<`, `>`, `(`, `;`, `&`, `|`, `,` (`cat</etc/hosts`, `(cat /etc/x)`). | Those characters now start a path in the check. |
| 4 | Medium | A symlink (`ln -s / x`) would walk around every path check. | Symlink creation is blocked. |
| 5 | Low | Crash log (new in 1.9.9) stored the raw stack trace; an exception message could contain a key. | Trace passes through `Redact.text` (sk-, ghp_, hf_, gsk_, AIza, Bearer). |
| 6 | Low | `.vibecoder_backups` grew without limit (every file write/patch) and nothing reads it. | Capped to the newest 10 per project; older ones removed. |
| 7 | Low | Old self-test files left in user projects (`test_integration.txt`, `patch_target.txt`). | Removed at app start, only when the content is exactly what the test wrote. User files with the same name are kept. |
| 8 | Low | Release lint: `onRenderProcessGone` (API 26) override without API annotation. | `@TargetApi(26)`. |
| 10 | Medium | All Preview pages shared one file:// origin, so a page generated for project A could read project B's localStorage. | Each project previews on its own https origin (`p<hash>.vibecoder.test`) answered by the app itself (ProjectOrigin). Storage is per project; the preview needs no file:// access; dot folders and anything outside the project are refused. |
| 11 | High | Terminal guard searched the raw text, so `cat /da""ta/x`, `cat /d\ata/x`, `cat /e*c/passwd`, `cat {/etc/hosts,x}` slipped past it. | Commands are now read like the shell reads them (ShellWords: quotes, escapes, heredocs, brace lists) and every word is checked (CommandGuard). Agent-proposed commands are also refused when they name a real absolute path outside the project or use `~`. |
| 12 | Medium | The approval dialog showed only the command text, so `sh setup.sh` (a script the agent just wrote) or `node app.js` looked harmless. | The dialog now states what runs: the script/code file and its line count, or eval, `bash -c`, wrappers (env, xargs, nohup), `find -exec`, `./program`, variables and `$(...)`. |
| 13 | Medium | Apps you build with "Build APK" could be taken over by a link: a tapped http(s) link replaced the app's own page with a website inside the app (looks like part of the app, e.g. a fake sign-in), and the WebView had content:// and file:// access flags at their defaults. | The WebView shell now keeps only its own `assets/www` pages in the app, opens tapped web/mail/phone links in the browser or the matching app, refuses other file:// locations and unknown schemes, and turns off content access, file-URL access, mixed content and geolocation. (Needs the next CI build of `webshell` to take effect.) |
| 9 | Crash | Android regex rejected an unescaped `}` in PreviewFixer (app died on Preview). | Escaped; `tools/icu_lint.py` checks all 219 regexes and can run in CI. |

## Already in place (checked, no change)
- API keys and GitHub token: AES-256-GCM in Android Keystore (SecretCipher); excluded from backup; never in settings export.
- API key sent only over https, or http to this phone / private LAN (UrlPolicy); redirects off so the key cannot follow one.
- GitHub push: fixed host, owner/repo/branch validated, redirects off, dot folders and build output never pushed.
- ZIP import: Zip Slip check on every entry before anything is written, entry-count and size caps.
- Model download: file name must end in .gguf, no hidden or backslash names, https only.
- PendingIntents immutable; phone agent opens only http(s) URLs; one exported activity.
- WebView preview: file access limited to the project root, external links blocked, renderer-crash handler.

Also checked, no change needed: APKs you build are signed with a key generated on your phone in the Android Keystore (not one shared by all users); the phone agent refuses banking/payment apps, never types passwords/OTP/PIN/card numbers, and asks before payments and account changes.

## Open (accepted or needs your call)
- **Cleartext HTTP is allowed app-wide** (needed for Ollama / LM Studio on a LAN IP; Android cannot whitelist IP ranges). Keys are protected at app level (see above).
- **Terminal is a guard, not an OS sandbox.** The agent's commands always need your approval, are read the way the shell reads them and checked, and scripts/interpreters are flagged in the dialog. But once you approve `node x.js` or `sh x.sh`, that code runs with the app's own rights and can read the app's private data. Android gives no unprivileged way to confine one process inside an app; the real protection is reading the warning before you approve.
- **Release build is not minified** (isMinifyEnabled = false). Deliberately left off: R8 only obfuscates (not a security control for an open-source app), and the app has 18 JNI methods, reflection in TerminalSession and apksig, which need keep-rules that can only be proven by running the release APK on a device. A blind change risks a release build that crashes at start for no security gain. Revisit when you can test the release APK.
- `allowBackup=true`: project files can go to Google backup. Secrets and the chat database are excluded.

## v1.9.18 addendum: voice routing

Voice mode can now switch the Phone agent on for one task. Conditions, all required: Agent chip is Auto, the Chat tab is not selected, the spoken text is a clear phone command ("open YouTube", "call mom"; stricter than the typed-text router), and VibeCoder's Accessibility service is already on. It never turns Accessibility on itself, never skips the remote-screen notice, and the Phone agent's own approvals (sensitive apps, secret fields, risky actions) still apply. When voice mode closes and the run is over, the tab switch is undone. A phone command with Accessibility off is refused with a spoken-screen message instead of being sent to the coding pipeline (which used to create a blank project).
