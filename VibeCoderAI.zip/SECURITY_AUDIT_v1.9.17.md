# VibeCoder security audit, v1.9.17

Method: static review of the manifest, WebView, network, secrets, archives, downloads, terminal/agent execution, intents and logging; Android-only regex lint; host tests for the new rules (tools/icu_lint.py, kt/h18, kt/h19, kt/h20). Not run on a device.

## Fixed in this version
| # | Severity | Finding | Fix |
|---|----------|---------|-----|
| 1 | High | Terminal/agent sandbox escape: `cd ..` (no slash) was not caught, so a command chain could leave the project folder. | `..` as a whole path part is blocked (SecurityManager.PARENT_DIR). `a..b` and `...` still allowed. |
| 2 | High | Commands could read the app's private data and shared storage (`/data`, `/storage`, `/sdcard`, `/mnt`, ...): other projects, chat database. | Those roots are blocked. The workspace's own full path (what `pwd` prints) is still allowed. |
| 3 | Medium | Path denylist skipped paths that follow `<`, `>`, `(`, `;`, `&`, `|`, `,` (`cat</etc/hosts`, `(cat /etc/x)`). | Those characters now start a path in the check. |
| 4 | Medium | A symlink (`ln -s / x`) would walk around every path check. | Symlink creation is blocked. |
| 5 | Low | Crash log (new in 1.9.9) stored the raw stack trace; an exception message could contain a key. | Trace passes through `Redact.text` (sk-, ghp_, hf_, gsk_, AIza, Bearer). |
| 6 | Low | `.vibecoder_backups` grew without limit (every file write/patch) and nothing reads it. | Capped to the newest 10 per project; older ones removed. |
| 7 | Low | Old self-test files left in user projects (`test_integration.txt`, `patch_target.txt`). | Removed at app start, only when the content is exactly what the test wrote. User files with the same name are kept. |
| 8 | Low | Release lint: `onRenderProcessGone` (API 26) override without API annotation. | `@TargetApi(26)`. |
| 10 | Medium | All Preview pages shared one file:// origin, so a page generated for project A could read project B's localStorage. | Each project previews on its own https origin (`p<hash>.vibecoder.test`) answered by the app itself (ProjectOrigin). Storage is per project; the preview needs no file:// access; dot folders and anything outside the project are refused. |
| 11 | High | Terminal guard searched the raw text, so `cat /da""ta/x`, `cat /d\ata/x`, `cat /e*c/passwd`, `cat {/etc/hosts,x}` slipped past it. | Commands are now read like the shell reads them (ShellWords: quotes, escapes, heredocs, brace lists) and every word is checked (CommandGuard). Agent-proposed commands are also refused when they name a real absolute path outside the project or use `~`. |
| 12 | Medium | The approval dialog showed only the command text, so `sh setup.sh` (a script the agent just wrote) or `node app.js` looked harmless. | The dialog now states what runs: the script/code file and its line count, or eval, `bash -c`, wrappers (env, xargs, nohup), `find -exec`, `./program`, variables and `$(...)`. |
| 13 | Medium | Apps you build with "Build APK" could be taken over by a link: a tapped http(s) link replaced the app's own page with a website inside the app (looks like part of the app, e.g. a fake sign-in), and the WebView had content:// and file:// access flags at their defaults. | The WebView shell now keeps only its own `assets/www` pages in the app, opens tapped web/mail/phone links in the browser or the matching app, refuses other file:// locations and unknown schemes, and turns off content access, file-URL access, mixed content and geolocation. (Needs the next CI build of `webshell` to take effect.) |
| 9 | Crash | Android regex rejected an unescaped `}` in PreviewFixer (app died on Preview). | Escaped; `tools/icu_lint.py` checks all 219 regexes and can run in CI. |

## Already in place (checked, no change)
- API keys and GitHub token: AES-256-GCM in Android Keystore (SecretCipher); excluded from backup; never in settings export.
- API key sent only over https, or http to this phone / private LAN (UrlPolicy); redirects off so the key cannot follow one.
- GitHub push: fixed host, owner/repo/branch validated, redirects off, dot folders and build output never pushed.
- ZIP import: Zip Slip check on every entry before anything is written, entry-count and size caps.
- Model download: file name must end in .gguf, no hidden or backslash names, https only.
- PendingIntents immutable; phone agent opens only http(s) URLs; one exported activity.
- WebView preview: file access limited to the project root, external links blocked, renderer-crash handler.

Also checked, no change needed: APKs you build are signed with a key generated on your phone in the Android Keystore (not one shared by all users); the phone agent refuses banking/payment apps, never types passwords/OTP/PIN/card numbers, and asks before payments and account changes.

## Open (accepted or needs your call)
- **Cleartext HTTP is allowed app-wide** (needed for Ollama / LM Studio on a LAN IP; Android cannot whitelist IP ranges). Keys are protected at app level (see above).
- **Terminal is a guard, not an OS sandbox.** The agent's commands always need your approval, are read the way the shell reads them and checked, and scripts/interpreters are flagged in the dialog. But once you approve `node x.js` or `sh x.sh`, that code runs with the app's own rights and can read the app's private data. Android gives no unprivileged way to confine one process inside an app; the real protection is reading the warning before you approve.
- **Release build is not minified** (isMinifyEnabled = false). Deliberately left off: R8 only obfuscates (not a security control for an open-source app), and the app has 18 JNI methods, reflection in TerminalSession and apksig, which need keep-rules that can only be proven by running the release APK on a device. A blind change risks a release build that crashes at start for no security gain. Revisit when you can test the release APK.
- `allowBackup=true`: project files can go to Google backup. Secrets and the chat database are excluded.

## v1.9.18 addendum: voice routing

Voice mode can now switch the Phone agent on for one task. Conditions, all required: Agent chip is Auto, the Chat tab is not selected, the spoken text is a clear phone command ("open YouTube", "call mom"; stricter than the typed-text router), and VibeCoder's Accessibility service is already on. It never turns Accessibility on itself, never skips the remote-screen notice, and the Phone agent's own approvals (sensitive apps, secret fields, risky actions) still apply. When voice mode closes and the run is over, the tab switch is undone. A phone command with Accessibility off is refused with a spoken-screen message instead of being sent to the coding pipeline (which used to create a blank project).

## v1.9.19 addendum: agent browser, project check, run alerts

Agent browser (Settings > Background and web, off by default). Read-only: one public https page in a hidden WebView, returns text and up to 8 links. Controls: the user approves every site (once per site and run) and the dialog says which model receives the text; https only, no IP literals (decimal/octal/hex forms included), no single-label or .local/.lan/.internal/.test hosts, no credentials in the URL, port 443 only; the host name is resolved first and refused if any address is private, loopback, link-local, CGNAT, multicast or IPv4-mapped/NAT64 of those; every request the page makes goes through the same check; a redirect to another site is cancelled (the agent must ask again, which asks the user again); no JS bridge, no file or content access, no downloads, no pop-ups, no third-party cookies, no cache; max 4 pages per run. Page text is wrapped as untrusted and `<` `>` are replaced so a page cannot print a tool call or file block. Known limits: a hostname that changes its DNS answer after the check (rebinding) is not fully excluded; WebView storage for visited sites persists in the app profile (origin-isolated from project previews); only the Debugger, Reviewer and Designer agents have the tool.

Project check (off by default). Static, read-only scan of the 12 most recently changed projects every 12 hours when the battery is not low. No model, WebView or network, and it changes no file. Alerts once per distinct set of problems and not while the app is on screen.

Run alerts (on by default, Settings toggle). One notification when a run finishes or fails while the app is hidden; runs that were already finished at app start never notify.

## Addendum v1.9.20 (image send, first project check)

- Composer: an attached image, file or @mention is now a sendable message on its own (`ComposeSend`). With no typed text the model gets one fixed line ("Look at the attached image."). Nothing new leaves the phone: the existing VisionSupport block and the remote-host notice still run first, and a text-only model still never receives the image. When the only content is an image the dialog offers "Remove image" instead of "Send text only".
- Project check: turning it on schedules one extra run about two minutes later (retries every 30 s or longer while the app is on screen). Same static, read-only scan as before; no model, no network.
- Page probe (`PageProbe`): a fixed, read-only script that Preview and the agent's own test run inside the project's page after it loads. It only reads layout and text sizes (no network, no storage, no file access, no bridge) and returns up to three short messages. Preview shows them in a banner; the agent's test feeds them to the repair loop. The script text is a constant in the app, never built from page content.

## Addendum v1.9.21 (run timeline, one Preview, dark palette)

- UI only. One agent run is now drawn as one timeline card (`RunTimeline` builds it from the existing progress notes and file results; `RunTimelineCard` draws it). No new network call, permission, file access or data flow.
- The privacy information is not removed: the header keeps the destination chip (On-device / Remote: host) and the card's Details row shows the same destination and the context size, with the same "What the AI sees" action. The per-step chips were duplicates of it.
- The code preview inside a file row shows text already held in the chat message (first 24 lines); "Copy file" copies that text to the clipboard only when the person taps it.
- Stop is shown only while a run is live, Retry and Undo only when it is not, and Preview only in the header, so the card cannot show contradictory actions.
- Dark palette retuned to the redesign spec; light mode and the four accent colours are unchanged. Default accent is purple for new installs.

## Addendum v1.9.22 (redesign Phase 2: header, tabs, composer, dock)

- Styling only. New `flatSurface` modifier (solid theme surface + hairline border); header buttons, the composer, suggestion cards and the dock use it instead of the glass rim and sheen. No new data flow, permission or network call.
- The header no longer repeats the agent and size line when idle (it is in the composer chip); the destination chip (On-device / Remote host) stays visible at all times. "New chat" moved into the more menu.
- Send, Stop and Mic share one button position; touch targets stay 48 dp (40 dp visuals).

## Addendum v1.9.23 (redesign Phase 3: Settings, Projects switch, Preview, type scale)

- Styling and layout only. No new network call, permission, file access or data flow.
- Settings groups and the grouped lists now use the same flat surface as the rest of the app (solid theme surface and a hairline border, shadow capped at 3 dp). All settings, toggles and their behaviour are unchanged.
- The Files / Search / History switch in Projects is calmer (flat track, accent-tinted selected segment). Same three panes, same actions.
- Preview: a loading bar, a Refresh button that reloads the same page, and a full-screen toggle with a floating exit button. The page still loads only through the per-project origin and the existing web guard. The project name was removed from the Preview toolbar to make room; it is still shown in the header of the chat.
- Text sizes snapped to a fixed scale (10 to 34 sp) so no screen uses a one-off size. No text was removed.

## Addendum v1.9.24 (remote Speed test)

- New "Speed test" button on the Remote server card. It is user-started only (never automatic) and sends one chat request to the server the person already configured, with the same URL policy (https required for internet hosts), the same Authorization header and no redirect following as every other remote request.
- The request body is a fixed prompt ("Count from 1 to 80 ...") with max_tokens 400. Nothing from the person's projects, chats or files is sent. The stream is read for at most 120 chunks or 20 seconds, then closed, so the cost is a few hundred tokens at most.
- The result is one sentence shown on the card (first-token delay, tokens per second). It is not stored or logged. Server error text is redacted by the existing `errorText` (it can echo part of a key).
- `RemoteClient.stream` gained an optional per-chunk callback used only by this test; the chat path passes none and behaves as before.

## Addendum v1.9.25 (speed test accuracy, Preview toolbar padding)

- The remote Speed test now asks for a longer answer ("Count from 1 to 400", max_tokens 1000) and reads for at least 1.5 s and 24 chunks after the first one, at most 600 chunks or 20 s. Same destination (the server the person configured), same fixed prompt with nothing from projects or chats, same URL policy and key handling; the worst case is about a thousand tokens instead of a few hundred.
- Preview toolbar: end padding only. No data flow change.

## Addendum v1.9.26 (mixture-of-experts models bigger than free RAM)

- New `GgufExperts` reads the header of a model file that is already in the app's own models folder (key/value metadata and the tensor list, a few MB) to tell attention weights from routed-expert weights. No network, no new permission, nothing written. The parser is bounded (string length 1 MB, at most 100,000 tensors and key/value pairs, array skipping capped) and every failure returns "unknown", which keeps the old behaviour (the memory check blocks the model).
- Only a model that is a mixture of experts and does not fit free RAM as a whole takes the new path. Dense models, vision models and models that fit are unchanged. Everything else about loading (the "Load anyway" dialog, the pre-flight check) is unchanged.
- Native: a new JNI call `nativeSetStreamingLoad` sets a flag that turns llama.cpp's weight repacking off for that one load, so the weights stay memory-mapped instead of being copied into RAM. It is reset on every load. CPU only for such a load (GPU layers 0).
- The streaming model is read from the same file through the OS page cache; nothing is sent anywhere. The result of the automatic speed test after a load is shown on screen only.

## Addendum v1.9.27 (labels for streaming models)

- UI only. The Models screen now shows a mixture-of-experts model that streams from storage as "Streams" (not "Too big") and counts only the part that stays in RAM in its RAM percentage. For the rows of the installed-models list it reads the header of a big local model file once (cached, same bounded parser as v1.9.26). No network, no new permission, no data written.

## Addendum v1.9.28 (faster prompt processing for streaming models)

- Native only, and only for the streaming load of v1.9.26. A model that streams its experts from storage now uses a batch of up to 1024 tokens (it was 512) and decodes the prompt in full batches (it was 32-token chunks), so the experts it needs are read from storage once per batch instead of once per 32 tokens. A model that fits in RAM keeps exactly the old values (batch 512, 32-token prompt chunks). The numbers live in a small header, `batch_plan.h`, that has no dependencies and is unit tested on the host.
- The streaming flag is now read and cleared by the load that uses it, so a later load (the small router model) is never affected by it.
- The memory estimate for a streaming model adds 200 MB for the larger compute buffers, so the check stays on the safe side. Other models are unchanged.
- The "no progress" debug message after 25 s waits 300 s while a streaming model decodes its first batch.
- No network call, permission, file access or data flow was added.

## Addendum v1.9.29 (true generation benchmark, steadier prompt prefix)

- The Speed test button on the Models screen now runs a real benchmark: a fixed synthetic prompt (128 tokens) is processed, then 32 tokens are generated one at a time with greedy sampling, and prompt speed, first-token time, generation speed and per-token median / P95 are reported separately. The short test that runs after a model loads is unchanged except for its label ("Prompt batch": it times one prompt batch, not generation; the earlier "1.5 tok/s" reading of it was a misreading).
- New read-only counters of the app's own process: `getrusage` (major and minor page faults) and `/proc/self/io` (`read_bytes`). A platform that hides them shows "not available". No new permission, no network call, no file outside the app is read, and the benchmark text is fixed (no user data is used).
- `no_perf` is now false on the llama context so llama.cpp's own timers can be shown as a cross-check; this adds two clock reads per decode call and changes no output.
- For the standard chat and build requests the phone clock moved from the end of the system prompt to the end of the user message (`PromptClock`). The model still gets the same date and time; the local KV cache and remote prompt caches can now reuse the system prompt and the project files across requests. Requests that bring their own system prompt (the phone agent, the router, internal tools) keep the old placement byte for byte. The manifest ("what the AI sees") shows the clock where it is sent.
- The project snapshot lists files in a stable order (oldest edit first) instead of an order that depends on the task text. Which files get their full text is unchanged (still relevance first, same budget).
- Unit tests: `V1929PromptCacheTest` (12), native `bench_stats.h` and `batch_plan.h` tests on the host.

## Addendum v1.9.30 (speed history and device state)

- New file `speed_history.jsonl` in the app's private files folder: one flat JSON object per line, newest 100 kept, rewritten atomically, never throws. Each record holds numbers and labels only: time, local or remote, source (real reply or Speed test), model display name (file name or remote model id, never a path or URL), token counts, first-token time, prompt and generation speed, threads, context length, storage read and page-fault counts (Speed test only), thermal status before and after, battery temperature, anonymous and file-backed memory (local only). No prompt, reply, file path, URL, host or key is stored. Listed on the Privacy page; shown, and cleared with one button, in Settings > Speed history. Clearing chats leaves it, like token usage.
- Recorded for normal chat and build requests only (the standard system prompt). The phone agent, router and internal tools are not logged. Recording happens on a low-priority background thread after the reply, so a reply never waits for it.
- Device state is read, never changed: `PowerManager.currentThermalStatus` (Android 10+), the sticky battery broadcast (temperature, level, charging) and `/proc/self/smaps_rollup` of the app's own process. A value the platform hides stays empty. The memory reading is taken after a run, not sampled during it, and is called "after the run", never "peak". File-backed memory (the memory-mapped model) is labeled as such and not counted as heap use.
- Prompt reuse is a direct count, never an estimate: llama.cpp's C API has no prefix-cache hit counter, so the app's own prompt cache (`llama_jni.cpp`) reports how many prompt tokens it processed, how many of them kept their KV entries (not decoded again; zero if the cache was cleared or a partial removal failed) and how many oldest tokens were cut to fit. The history uses the processed count as the denominator (not the earlier pre-count, which differs when a prompt is cut). If these cannot be read the reuse is stored as "not measured" (null) and left out of every percentage, never counted as 0. Remote replies and Speed tests carry no reuse figure (remote servers do not report it to the app). A cut prompt is flagged in the recent list because it drops the oldest tokens, which is where the system prompt sits.
- The detailed Speed test result now starts (internally) with one machine-readable line; the app removes it before showing the text and reads the same numbers into the history. Prompt speed and generation speed are never averaged together, and Speed tests are never mixed into the summary of real replies.
- No new permission, no network call, no Room schema change (the database stays at version 2).
- Unit tests: `V1930SpeedHistoryTest` (31).

## Addendum v1.9.31 (experimental prompt-lookup decoding, off by default)

- New setting `lookupDecoding` (Settings > Lookup decoding, experimental), default OFF, also listed in the settings export. When on, the next tokens of a local reply are guessed from text already in the context (the last 3 to 5 tokens are looked up earlier in the prompt and reply; up to 8 following tokens become the guess) and checked in ONE batched decode. At every position the sampler picks the token from the real logits; a guess is kept only when the sampler picked the same token, and the first difference ends the round and the sampler's own token is used. The sampler (including the repeat penalty) records only tokens that were really chosen, in order.
- What is and is not guaranteed: the token sequence comes from the sampler at every position, so output correctness is preserved; speed is NOT guaranteed (a batch costs more than one token and a wrong guess wastes it), and a batched decode can round floats differently from a one-token decode, so a greedy choice between two nearly equal tokens can very rarely flip. The app says so in Settings and in the test report, and the test reports where two outputs first differ instead of hiding it.
- Never used when it is unsafe: not for a mixture-of-experts model that streams from storage (a batch of guesses would read many more experts), not for recurrent or hybrid memory, not for sliding-window attention, not when the memory does not report support for removing its newest tokens (`llama_memory_can_shift`). This is decided at model load in native code and cannot be switched on from Kotlin. If a rollback ever fails (not expected), the KV cache is cleared, lookup stays off until the model is reloaded and the reply ends with an error rather than continuing on a cache that holds unaccepted tokens. Image replies use their own path and never use lookup.
- Speed protection is measured, not assumed: the app times its own plain steps and its own batched rounds on the running phone and stops guessing when rounds are not faster than plain steps (3 plain steps first, a verdict after 4 rounds, then a pause of 32 plain tokens that doubles after each repeated slow verdict up to 512). With nothing to copy this costs a few probe rounds (in a cost model with a round 3.4 times a plain step, about 3% over plain decoding), not a slowdown for the whole reply. Those are model numbers for the gate, not phone measurements.
- Lookup test (Models > Lookup test, experimental): four short greedy code-edit runs in the order off, on, on, off with a fixed prompt, the cache dropped before each run. It reports tokens per second per run, guesses accepted (a direct count), tokens per batch, pauses, whether the text was identical in both pairs (with the first differing position if not) and a verdict that says "no clear difference" when the gap is smaller than 5% or than the gap between two runs of the same setting. A 240 s limit ends the test with no verdict. It is blocked with an explanation for a streaming model. The prompt is fixed text; no user data is used. The Speed test is unaffected (it never uses lookup).
- Speed history: a reply made with lookup carries `lookup: true`; those replies are counted and tagged ("lookup on") but kept out of the medians, so turning the setting on does not silently change the numbers of replies made without it. Old lines read as lookup off.
- Verified on the host with the real `llama_jni.cpp` built against llama.cpp b12020 and tiny random-weight models (`tools/lookup_e2e`): 3360 generations (greedy, with and without repeat penalty, 1 to 200 tokens, multi-turn on the same cache, callback stops, a 256-token context, streaming load) gave byte-identical text and token counts with lookup off and on; one family of models accepted 5% of guesses, another 90% (24620 of 27366 guesses in 9927 rounds), so both rollback and full acceptance ran. Host tests: `ngram_lookup.h` (guess search, verification, gate, an equivalence simulation of 6043 rounds) and `V1931LookupTest` (22). These models say nothing about phone speed: no speed-up is claimed until the Lookup test is run on a device.
- No new permission, no network call, no new stored data beyond the one setting and the history flag.

## Addendum v1.9.32 (chat history cleaning, thread-count test, timers-line self-check)

- Chat history cleaning (`ChatHistory.kt`, used by `recentExchanges()`, which feeds the last exchanges of a Chat-mode request to the model, local or remote). Before this version the app's own status text was stored as the assistant's message and sent back: "[Stopped]", "[Error: ...]", "[The model returned no text.]", "[The model only wrote its reasoning...]", "[Stopped: the model started repeating itself...]", "[Generation error...]", "[Engine error...]", "[No progress...]". Small models copied these markers, so a reply could end as a bare "[Stopped]" again and again. Now those trailing markers are removed before the history is built (a marker counts only when it starts a line and the text ends with "]"); an assistant message that is nothing but a marker is dropped together with the question it answered; app notes (`thoughts == "note"`), engine notices, streaming and blank messages are skipped. Nothing is added to the history, and the chat on screen and in storage is unchanged (the markers are still shown to the person). The window rule (last 4 messages, 500 characters each) is unchanged and is applied after cleaning, so the model now sees up to 4 real messages. This is the most likely cause of the replies that stopped by themselves in the screen recording; it is verified on the host by unit tests only, not on a phone.
- Thread test (Models > Thread test (4 / 6 / 8), `ThreadBench.kt`, `LlamaEngine.threadBenchmark`). Runs the existing detailed Speed test at 4, 6 and 8 threads (never above the core count) plus the current setting, in the order a b c c b a after one uncounted warm-up run, so heat and cache drift show up as a difference between a setting's two runs. A 240 s limit and a thermal stop (status Severe or worse before a run) end it without a suggestion. The current thread count is restored in a `finally` block; the setting is never changed by the test. The result is a table plus, only when some count is faster than the current one by more than the noise (at least 5% and at least the widest gap between two runs of one setting), a suggestion for the fewest threads within that noise of the best; the "Use N threads" button then writes the same setting the Settings screen writes. Otherwise it says "No clear difference ... Keep it". Not run for a streaming model (storage-bound; each run takes minutes). Not written to the speed history. No new permission, no network call, no new stored data.
- Timers line in the detailed Speed test: on one phone the line "llama.cpp timers ... 144 tokens" appeared for a 128-token prompt. The cause is NOT established (the host test with the same native code reported 128, before and after this change; an earlier explanation that the counters were cumulative or that the first batch read weights from storage was not supported by that test and is withdrawn). The detailed test now calls `llama_synchronize` before resetting llama.cpp's counters (defensive; llama.cpp updates them there) and adds " These counts do not match this run, so ignore this line." to the line when the counts differ from the app's own count. The app's own timing, not this line, remains the source of every number shown.
- Unit tests: `V1932ChatHistoryTest` (16), `V1932ThreadBenchTest` (17). Host run of V1930 + V1931 + V1932 together: 86 tests, 0 failed. The Android build of v1.9.24 to v1.9.32 has not been compiled here; CI is the check.
