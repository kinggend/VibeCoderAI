# VibeCoder v1.8.0

An on-device AI coding assistant and phone-control agent. Models run offline with llama.cpp, or through your own OpenAI-compatible server.

## Highlights
- **Chat / Coding / Agent tabs** at the top of the chat screen. Chat answers questions only, Coding builds and fixes projects, Agent controls the phone.
- **Agents and Usage screen.** Every chat, coding and phone-control run is listed under Working, Done and Archived, with a progress ring, task, agent and time. The Usage tab shows runs, success rate, a 7-day chart and token totals.
- **Auto agent.** Pick Auto in Chat options and the task decides: Builder, Debugger, Reviewer, Designer or Phone agent.
- **Simpler Chat options sheet.** Agent chips and Model on top, everything else under a collapsed Advanced settings section, with smooth animations.

## Phone agent
- Looks at the screen each step, opens apps like a person (home page, swipe, icon), types live, and shows an edge glow in your accent colour plus a cursor where it taps.
- Message box on the overlay, so you can steer it while it works.
- New `quick_settings` action for flashlight, Wi-Fi, Bluetooth and similar switches, plus hints when the screen stops changing.
- Opt-in only. It needs the accessibility service, and sending, paying and deleting always ask first.

## Memory and stability
- **Fixed the endless "Fixing, attempt N of 3" loop** when the model could not load. Engine and memory failures now stop the agent at once.
- Pre-flight RAM check before a local run, a non-dismissible "Insufficient RAM" dialog, and a Free RAM vs Required RAM bar on the Models screen.
- Stop Agent button while a run is going. Undo last changes after a coding run.
- Image upload fixed. Vision models can read chat images.

## Editor and projects
- Quick start buttons: HTML/CSS app, Python script, React Native (Expo template).
- Ctrl+S, Ctrl+Z, Ctrl+Shift+Z and Ctrl+F in the code editor.
- Run or Preview button next to the chat input. The terminal shows "Still running…" after 5 seconds.
- Settings export as JSON, without API keys.

## Security
- API keys are only sent over https, or http on this phone and your local network. Redirects no longer carry credentials to another host.
- The phone agent opens only http and https links.
- Terminal safety checks cover chained commands (`a; rm x`), every spelling of `rm -rf /`, and `curl | sh`. Harmless commands such as `npm run format` and `2>/dev/null` are no longer blocked.
- Chat history, the run log and phone history are excluded from cloud backup. API keys stay encrypted with the Android Keystore (AES-256-GCM).

## Known limits
- The phone agent depends on the model. Small local models can stall on long tasks; a remote vision model is more reliable.
- Canvas apps (Blender, games) have no accessibility tree, so touch control there is unreliable.
- Release builds are not minified yet.

## Install
Download the APK from the assets below. Allow "Install unknown apps" when asked. Turn on the Phone agent only if you want it, in Chat options.
