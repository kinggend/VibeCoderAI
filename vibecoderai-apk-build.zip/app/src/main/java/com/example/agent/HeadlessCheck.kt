package com.example.agent

import android.annotation.SuppressLint
import android.content.Context
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.File

/** Opens index.html in an invisible WebView and reports JavaScript errors and missing files, so the agent can verify its own work. */
object HeadlessCheck {
  /** v1.5: each check is logged in the project's History as a pass/fail command. */
  suspend fun run(context: Context, root: File): List<String> = check(context, root).also { errs ->
    ProjectHistory.record(root, HistoryEntry.COMMAND, "Headless app check", errs.isEmpty(), if (errs.isEmpty()) "" else "${errs.size} problem(s): ${errs.first()}")
  }

  @SuppressLint("SetJavaScriptEnabled")
  private suspend fun check(context: Context, root: File): List<String> {
    val index = File(root, "index.html")
    PreviewFixer.prepare(root)
    if (!index.isFile) return listOf("index.html is missing. Create index.html, styles.css and app.js.")
    return withContext(Dispatchers.Main) {
      val errors = mutableListOf<String>()
      val loaded = CompletableDeferred<Unit>()
      val wv = WebView(context.applicationContext)
      try {
        wv.settings.javaScriptEnabled = true
        wv.settings.domStorageEnabled = true
        wv.settings.allowFileAccess = true
        wv.webChromeClient = object : WebChromeClient() {
          override fun onConsoleMessage(m: ConsoleMessage): Boolean {
            if (m.messageLevel() == ConsoleMessage.MessageLevel.ERROR) errors.add("${m.message()} (line ${m.lineNumber()})")
            return true
          }
        }
        wv.webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            if (!loaded.isCompleted) loaded.complete(Unit)
          }

          override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
            errors.add("Missing or unreadable file: ${request?.url?.lastPathSegment ?: "?"}")
          }
        }
        wv.loadUrl("file://" + index.absolutePath)
        withTimeoutOrNull(8000) { loaded.await() }
        delay(1500) // let timers and startup scripts run
        val probe = CompletableDeferred<String?>()
        wv.evaluateJavascript(PROBE) { probe.complete(it) }
        val raw = withTimeoutOrNull(3000) { probe.await() }
        runCatching {
          val arr = org.json.JSONArray(org.json.JSONTokener(raw).nextValue() as? String ?: "[]")
          for (i in 0 until arr.length()) errors.add(arr.getString(i))
        }
      } finally {
        wv.destroy()
      }
      errors.distinct()
    }
  }

  /** Catches "loaded fine but shows nothing": blank page, zero-size canvas, visible board/grid containers left empty. */
  private const val PROBE = """(function(){var o=[];var b=document.body;
if(!b||(!b.innerText.trim()&&!b.querySelector('canvas,img,svg,video')))o.push('The page is blank: nothing is rendered.');
document.querySelectorAll('canvas').forEach(function(c){if(c.width<2||c.height<2)o.push('A canvas element has zero size.');});
var els=document.querySelectorAll('[id],[class]');
for(var i=0;i<els.length&&o.length<3;i++){var e=els[i];var k=((e.id||'')+' '+(typeof e.className==='string'?e.className:'')).toLowerCase();
if(/(board|grid|stage|cells)/.test(k)&&e.offsetParent!==null&&e.children.length===0&&!e.textContent.trim())o.push('The element '+(e.id?'#'+e.id:'.'+String(e.className).split(' ')[0])+' is empty: JavaScript never drew anything inside it.');}
return JSON.stringify(o.slice(0,3));})()"""
}
