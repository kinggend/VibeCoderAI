package com.example.agent

import com.example.data.model.OutputLevel
import com.example.data.model.SettingsState
import java.io.File

/**
 * v1.6.2: checks that a build run really produced every file it planned, instead of declaring done
 * after the step loop. Pure logic so it is unit-tested.
 */
object PlanCheck {
  private val FILE_NAME = Regex("""(?<![\w/.-])((?:[\w-]+/)*[\w.-]+\.(?:html|htm|css|js|mjs|json|svg|txt|md))\b""", RegexOption.IGNORE_CASE)
  private val LOCAL_REF = Regex("""<(?:script|link|img)\b[^>]*?\b(?:src|href)\s*=\s*["']([^"'#?]+)["']""", RegexOption.IGNORE_CASE)
  private val MISSING_ERR = Regex("""^Missing or unreadable file: (\S+)""")

  /** File names a plan's steps name ("1. index.html: page structure" -> index.html), in plan order, no repeats. */
  fun plannedFiles(steps: List<String>): List<String> =
    steps.flatMap { s -> FILE_NAME.findAll(s).map { it.groupValues[1].trim() }.toList() }.distinct()

  /** Local files index.html points at (script src, stylesheet href, img src). Web links and data URLs are skipped. */
  fun referencedLocal(html: String): List<String> =
    LOCAL_REF.findAll(html).map { it.groupValues[1].trim().removePrefix("./") }
      .filter { it.isNotBlank() && !it.contains(':') && !it.startsWith("//") && !it.startsWith("/") && !it.contains("..") }
      .distinct().toList()

  /** Of [files], the ones that do not exist in [root] or are blank. */
  fun missing(root: File, files: List<String>): List<String> = files.filter { rel ->
    val f = ProjectFiles.resolve(root, rel)
    f == null || !f.isFile || f.length() == 0L || runCatching { f.readText().isBlank() }.getOrDefault(true)
  }

  /** Every file the run should have produced: the plan's files plus whatever index.html loads. */
  fun expected(root: File, steps: List<String>): List<String> {
    val index = File(root, "index.html")
    val refs = if (index.isFile) referencedLocal(runCatching { index.readText() }.getOrDefault("")) else emptyList()
    return (plannedFiles(steps) + refs).distinct()
  }

  /** "Missing or unreadable file: app.js" errors from the headless check, as file names. */
  fun missingFromErrors(errors: List<String>): List<String> =
    errors.mapNotNull { MISSING_ERR.find(it.trim())?.groupValues?.get(1) }.filter { it != "?" }.distinct()
}

/**
 * v1.6.2: output that stopped before it was finished (token limit reached, or an unclosed file block)
 * and stitching a continuation back on.
 */
object Truncation {
  /** [start] is where the unfinished block begins in the reply text. */
  data class Cut(val path: String, val partial: String, val start: Int = 0)

  private val OPEN = Regex("""<file\s+(?:path|name)\s*=\s*["']?([^"'<>\s]+)["']?\s*>\r?\n?""")
  private val FENCE_OPEN = Regex("""(?m)^```[ \t]*([A-Za-z]*)[ \t]*$""")
  private const val CLOSE = "</file>"

  /** The last file block that was opened but never closed, with what was written of it. */
  fun openFile(text: String): Cut? {
    val last = OPEN.findAll(text).lastOrNull()
    if (last != null) {
      val body = text.substring(last.range.last + 1)
      if (body.contains(CLOSE)) return null
      return Cut(last.groupValues[1].trim(), stripOpenFence(body), last.range.first)
    }
    // Replies without file tags: an odd number of ``` fences means the last code block was cut.
    val fences = FENCE_OPEN.findAll(text).toList()
    if (fences.size % 2 == 1) {
      val f = fences.last()
      val path = when (f.groupValues[1].lowercase()) {
        "html" -> "index.html"
        "css" -> "styles.css"
        "js", "javascript" -> "app.js"
        else -> return null
      }
      return Cut(path, text.substring(f.range.last + 1).trimStart('\r', '\n'), f.range.first)
    }
    return null
  }

  /** True when the generation stopped early: the server/engine said "length", or a file block is left open. */
  fun isCut(finishReason: String?, text: String): Boolean = finishReason == "length" || openFile(text) != null

  /**
   * Cleans a continuation reply: drops a leading code fence or repeated file tag and anything after
   * `</file>` or a closing fence. Returns the text and whether the file was closed.
   */
  fun cleanContinuation(raw: String): Pair<String, Boolean> {
    var s = raw
    OPEN.find(s)?.let { if (s.substring(0, it.range.first).isBlank()) s = s.substring(it.range.last + 1) }
    s = stripOpenFence(s)
    var closed = false
    val close = s.indexOf(CLOSE)
    if (close >= 0) { s = s.substring(0, close); closed = true }
    val fence = Regex("""(?m)^```[ \t]*$""").find(s)
    if (fence != null) { s = s.substring(0, fence.range.first); closed = true }
    return s to closed
  }

  /**
   * [existing] + [continuation], with any overlap removed: models often repeat the last line or two
   * before going on. The longest suffix of [existing] (up to 400 chars) that starts [continuation] is dropped once.
   */
  fun merge(existing: String, continuation: String): String {
    if (continuation.isEmpty()) return existing
    if (existing.isEmpty()) return continuation
    val max = minOf(400, existing.length, continuation.length)
    for (len in max downTo 8) {
      if (existing.regionMatches(existing.length - len, continuation, 0, len)) return existing + continuation.substring(len)
    }
    // Re-sent last line without exact whitespace match: drop a first line equal to the last line written.
    val lastLine = existing.trimEnd().substringAfterLast('\n').trim()
    val firstLine = continuation.trimStart('\r', '\n').substringBefore('\n').trim()
    if (lastLine.length >= 8 && firstLine == lastLine) {
      return existing.trimEnd() + "\n" + continuation.trimStart('\r', '\n').substringAfter('\n', "")
    }
    return existing + continuation
  }

  private fun stripOpenFence(s: String): String {
    val t = s.trimStart('\r', '\n')
    return if (t.startsWith("```")) t.substringAfter('\n', "") else t
  }
}

/**
 * v1.6.2: context and output budget for remote (OpenAI-compatible) models. The on-device context
 * setting (often 2048 on phones) is no longer applied to cloud models.
 */
object RemoteContext {
  /** Used when the server's /models answer has no context size. */
  const val DEFAULT_CTX = 32768

  /** Context window the server reported, else [DEFAULT_CTX]. Nonsense values are ignored. */
  fun resolve(serverCtx: Int?): Int = serverCtx?.takeIf { it in 1024..10_000_000 } ?: DEFAULT_CTX

  /** max_tokens for an output level on a remote model; never more than half the context. */
  fun maxOut(level: OutputLevel, ctx: Int): Int {
    val want = when (level) {
      OutputLevel.LOW -> 1024
      OutputLevel.MEDIUM -> 2048
      OutputLevel.HIGH -> 4096
      OutputLevel.ULTRA -> 8192
      OutputLevel.MAX -> 16384
    }
    return minOf(want, (ctx / 2).coerceAtLeast(256))
  }

  /** Settings as a remote request uses them: real context and output size. On-device settings are returned unchanged. */
  fun effective(s: SettingsState, serverCtx: Int?): SettingsState {
    if (s.backendMode != "remote") return s
    val ctx = resolve(serverCtx)
    return s.copy(contextLength = ctx, maxOutputTokens = maxOut(OutputLevel.from(s.outputLevel), ctx))
  }

  /**
   * On-device: output tokens that still leave room for a prompt inside the loaded context
   * (a 2048 context cannot hold 4096 output tokens). Never raises the setting.
   */
  fun localMaxOut(s: SettingsState): Int =
    minOf(s.maxOutputTokens, (s.contextLength - 600).coerceAtLeast(256))
}
