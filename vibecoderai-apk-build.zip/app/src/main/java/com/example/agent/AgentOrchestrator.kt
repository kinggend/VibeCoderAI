package com.example.agent

import android.content.Context
import com.example.data.model.ChangeStatus
import com.example.data.model.ChatMessage
import com.example.data.model.FileChange
import com.example.data.model.MessageSender
import com.example.data.model.PatchProposal
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.data.model.TokenUsage
import com.example.data.model.ToolCallInfo
import com.example.llama.LlamaEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class AgentOrchestrator(
  private val context: Context,
  private val llamaEngine: LlamaEngine,
  private val contextManager: ContextManager = ContextManager(),
  private val selfRepairEngine: SelfRepairEngine = SelfRepairEngine(),
  private val terminalManager: com.example.terminal.TerminalManager = com.example.terminal.TerminalManager(),
  private val buildRunner: com.example.build.BuildRunner = com.example.build.BuildRunner(),
  /** v1.4: called after every local/remote generation with its token usage (logged to Room). */
  private val onUsage: (TokenUsage) -> Unit = {}
) {

  /** v1.4: every overwrite/edit/delete and every agent command waits here for the user's answer. */
  val approvals = ApprovalGate()
  /** v1.6: agent commands that wait for keyboard input ask the user here. */
  val inputs = InputGate()
  /** v1.5: settings of the request being worked on, so tool approvals see Strict Security too. */
  @Volatile private var currentSettings: SettingsState = SettingsState()
  private val toolExecutor: ToolExecutor = ToolExecutor(approve = { approvals.request(it) }, settings = { currentSettings })

  private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
  val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

  private val _telemetry = MutableStateFlow(TelemetryData())
  val telemetry: StateFlow<TelemetryData> = _telemetry.asStateFlow()

  private val _pendingPatch = MutableStateFlow<PatchProposal?>(null)
  val pendingPatch: StateFlow<PatchProposal?> = _pendingPatch.asStateFlow()

  private val _isGenerating = MutableStateFlow(false)
  val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

  private val _activity = MutableStateFlow<List<String>>(emptyList())
  /** Live feed of what the agent is doing right now (cleared at the start of every request). */
  val activity: StateFlow<List<String>> = _activity.asStateFlow()
  private fun log(line: String) {
    _activity.value = (_activity.value + line).takeLast(200)
    runs.label(line)
  }

  /**
   * v1.6.2: runs live in this app-wide scope, not in a screen's scope, so switching tabs, rotating or
   * leaving the app no longer cancels them. Only Stop (or the notification's Stop) cancels a run.
   */
  private val ioScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
  val runs = AgentRunManager(ioScope)

  /** v1.6: files and images attached to the request being worked on. Images go with the first generation only. */
  @Volatile private var runFiles: List<com.example.transparency.AttachedFile> = emptyList()
  @Volatile private var runImages: List<com.example.chat.ImagePayload> = emptyList()

  /** v1.6: builds the "What the AI sees" manifest from the exact messages the engine reported. */
  private fun manifest(
    msgs: List<Pair<String, String>>,
    exact: Int?,
    settings: SettingsState,
    chatOnly: Boolean,
    images: List<com.example.chat.ImagePayload>,
    maxTokens: Int,
    customSystem: Boolean
  ): com.example.transparency.ContextManifest {
    val dest = com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl)
    val model = if (dest.isRemote) settings.remoteModel.ifBlank { "first model the server lists" }
      else llamaEngine.resolveModelFile(settings).name
    return com.example.transparency.ContextManifest(
      destination = dest,
      model = model,
      messages = msgs.map { com.example.transparency.SentMessage(it.first, it.second) },
      // A role/plan prompt replaces the default one; role prompts append skills themselves.
      skills = if (customSystem && msgs.firstOrNull()?.second?.contains("\nSkills:\n") != true) emptyList() else Skills.activeNames(chatOnly),
      files = runFiles,
      images = images.map { com.example.transparency.AttachedImage(it.name, it.width, it.height, it.bytes, sent = true) },
      temperature = settings.temperature,
      topP = settings.topP,
      topK = if (dest.isRemote) null else settings.topK,
      maxTokens = maxTokens,
      contextLength = settings.contextLength, // v1.6.2: remote shows its real context too

      exactPromptTokens = exact
    )
  }

  init {
    com.example.data.GenerationStats.init(context)
    _messages.value = listOf(
      ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Say hi or ask me anything. Describe an app and I will build it."
      )
    )
  }

  private var job: Job? = null

  /** Id of the conversation on screen; each conversation is saved under its own id. */
  @Volatile
  var chatId: String = UUID.randomUUID().toString()
    private set

  /** False in a fresh chat: its first build request gets its own new project instead of overwriting the last one. */
  @Volatile
  var useActiveProject: Boolean = false

  private val snapIds = java.util.concurrent.ConcurrentHashMap<String, String>()

  fun canUndo(messageId: String): Boolean = snapIds.containsKey(messageId)

  /** Restores the project files to how they were before this reply changed them. */
  fun undoChanges(messageId: String, project: Project) {
    val snap = snapIds[messageId] ?: return
    if (Snapshots.restore(project.rootDir, snap)) {
      snapIds.remove(messageId)
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = m.fileChanges.map { it.copy(status = ChangeStatus.DISCARDED) }) else m
      }
    }
  }

  /** Drops the last reply and asks again. */
  fun regenerate(project: Project?, settings: SettingsState) {
    if (_isGenerating.value) return
    val msgs = _messages.value
    val idx = msgs.indexOfLast { it.sender == MessageSender.USER }
    if (idx < 0) return
    val text = msgs[idx].content
    _messages.value = msgs.take(idx)
    sendMessage(text, project, settings)
  }

  /** Adds an assistant note to the chat (e.g. "Project created from template"). */
  fun addNote(text: String, context: com.example.transparency.ContextManifest? = null) {
    log(text.lineSequence().first().take(120))
    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(), sender = MessageSender.AGENT, content = text, thoughts = "note",
      context = context, destination = context?.destination
    )
  }

  /** Starts a fresh conversation (keeps the welcome message). The old one stays in history. */
  fun newChat() {
    if (_isGenerating.value) return
    useActiveProject = false
    chatId = UUID.randomUUID().toString()
    _messages.value = _messages.value.take(1)
  }

  /** Shows a saved conversation. */
  fun openChat(id: String, history: List<ChatMessage>) {
    if (_isGenerating.value) return
    val welcome = _messages.value[0].content
    val clean = history.filter { !(it.sender == MessageSender.AGENT && (it.content == welcome || it.content.isBlank() && it.fileChanges.isEmpty())) }
    chatId = id
    useActiveProject = true
    _messages.value = _messages.value.take(1) + clean.map { it.copy(isStreaming = false) }
  }

  /** Cancels the running generation (also stops the native model). */
  fun stop() {
    llamaEngine.stopNow()
    approvals.rejectAll()
    inputs.cancelAll()
    job?.cancel()
    runs.cancel()
    // Do not wait for the native thread: the UI becomes usable immediately.
    _isGenerating.value = false
  }

  fun sendMessage(
    userText: String,
    project: Project?,
    settings: SettingsState,
    displayText: String? = null,
    attachments: com.example.chat.RunAttachments = com.example.chat.RunAttachments()
  ) {
    if (userText.isBlank() || _isGenerating.value) return
    if (runs.isRunning) {
      // The stopped run is still unwinding (native thread or network read): say so instead of dropping the message silently.
      addNote("Still stopping the last run. Send again in a moment.")
      return
    }
    runFiles = attachments.files
    runImages = attachments.images

    val raw = displayText ?: userText
    // "continue" / "retry" re-runs the last real request instead of being answered as small talk.
    val redo = raw.trim().lowercase().trimEnd('.', '!') in setOf("continue", "retry", "try again", "again", "go on", "resume")
    val previous = if (redo) _messages.value.lastOrNull { it.sender == MessageSender.USER && it.content.length > 20 }?.content else null
    val task = previous ?: userText
    val mode = Intent.classify(previous ?: raw)
    val history = if (mode == Intent.Mode.CHAT) recentExchanges() else emptyList()

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.USER,
      content = displayText ?: userText,
      destination = com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl),
      images = attachments.images.map { it.localPath },
      attachedFiles = attachments.files.map { it.path }
    )
    _activity.value = emptyList()
    log("Request received")
    _isGenerating.value = true
    currentSettings = settings
    val role = AgentRoles.from(settings.agentRole)
    job = runs.start(project?.name) {
      try {
        val s = runSettings(settings)
        currentSettings = s
        if (role.id != "builder" && project != null && raw.trim().length > 12) {
          runAgentLoop(role, task, project, s)
        } else if (project != null && Intent.isFixRequest(raw) && java.io.File(project.rootDir, "index.html").isFile) {
          runFix(raw, project, s)
        } else if (mode == Intent.Mode.BUILD && project != null && s.autonomous) {
          runAutonomous(task, project, s)
        } else {
          processAgentResponse(task, if (mode == Intent.Mode.BUILD) project else null, s, mode, history)
        }
      } finally {
        _isGenerating.value = false
      }
    }
    if (job == null) _isGenerating.value = false
  }

  /**
   * v1.6.2: the settings a run really uses. Remote: the model's real context window (from /models,
   * else 32768) and an output size that matches the chosen level, instead of the phone's context
   * setting. On-device: output is capped so a prompt still fits in the loaded context.
   */
  private fun runSettings(settings: SettingsState): SettingsState {
    if (settings.backendMode == "remote") {
      com.example.llama.RemoteClient.ensureContext(settings.remoteUrl, settings.remoteKey, settings.remoteModel)
      val ctx = com.example.llama.RemoteClient.contextWindows.value[settings.remoteModel]
      val s = RemoteContext.effective(settings, ctx)
      log("Remote context ${s.contextLength} tokens" + (if (ctx == null) " (default, server did not say)" else "") + ", output up to ${s.maxOutputTokens}")
      return s
    }
    val out = RemoteContext.localMaxOut(settings)
    if (out < settings.maxOutputTokens) log("Output capped at $out tokens so the prompt fits the ${settings.contextLength}-token context")
    return settings.copy(maxOutputTokens = out)
  }

  /** Short build plan (2 to 4 steps) from the model; empty if it cannot make one. */
  @Volatile private var lastPlanManifest: com.example.transparency.ContextManifest? = null

  private suspend fun planSteps(goal: String, settings: SettingsState): List<String> {
    val text = StringBuilder()
    log("Asking the model for a short plan")
    runCatching {
      llamaEngine.generateCompletionStream(
        prompt = goal,
        settings = settings.copy(maxOutputTokens = 220),
        onTelemetryUpdate = { data -> _telemetry.value = data },
        chatOnly = true,
        history = emptyList(),
        systemOverride = PLAN_PROMPT,
        onRequest = { msgs, exact -> lastPlanManifest = manifest(msgs, exact, settings, true, emptyList(), minOf(220, 1024), customSystem = true) }
      ).collect { text.append(it) }
    }.onFailure { if (it is kotlinx.coroutines.CancellationException) throw it }
    return Regex("""(?m)^\s*\d+[.)]\s*(.{4,160})$""").findAll(text)
      .map { it.groupValues[1].trim() }
      .filter { !it.contains("test", ignoreCase = true) }
      .take(3).toList()
  }

  /** Plan, build every step, check every planned file exists, run the app headlessly, and repair until clean or out of attempts. */
  private suspend fun runAutonomous(goal: String, project: Project, settings: SettingsState) {
    // v1.4: no auto-approve. Overwrites still wait for the user (ApprovalPolicy).
    val auto = settings
    try {
      missingTries.clear()
      beforeRun(project, "Build: $goal")
      addNote("Working on it. I will plan, build, then test the app myself.")
      val steps = planSteps(goal, settings)
      val list = if (steps.size >= 2) steps else listOf(goal)
      val planText = steps.mapIndexed { i, st -> "${i + 1}. $st" }.joinToString("\n")
      addNote(
        if (steps.size >= 2) "Plan:\n$planText"
        else "No usable plan came back, so I will build it in one step.",
        lastPlanManifest
      )
      list.forEachIndexed { i, step ->
        runs.step(i + 1, list.size, step)
        if (list.size > 1) addNote("Step ${i + 1} of ${list.size}: $step")
        // v1.6.2: every step carries the plan, so a small context still knows what the other files are for.
        val prompt = if (list.size > 1) "Overall goal: $goal\nPlan:\n$planText\nDo only this step (${i + 1} of ${list.size}): $step\nOutput the complete file(s) for this step in <file path=\"...\"> blocks." else goal
        processAgentResponse(prompt, project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true)
        if (lastApprovalDeclined) addNote("You declined the changes for step ${i + 1}. Going on with the next step.")
      }
      // v1.6.2: never declare done while a planned (or index.html-loaded) file is missing or empty.
      completePlan(goal, planText, PlanCheck.expected(project.rootDir, steps), project, auto)
      testAndRepair(goal, planText, project, auto, settings)
    } finally {
      _isGenerating.value = false
    }
  }

  /** Files written for missing planned files in this run, so a file the model cannot produce is not retried forever. */
  private val missingTries = java.util.concurrent.ConcurrentHashMap<String, Int>()

  /**
   * v1.6.2: writes each file in [files] that is missing or empty (two tries per file per run). Returns
   * the files still missing afterwards.
   */
  private suspend fun completePlan(goal: String, planText: String, files: List<String>, project: Project, settings: SettingsState): List<String> {
    var missing = PlanCheck.missing(project.rootDir, files)
    if (missing.isEmpty()) return emptyList()
    for (path in missing) {
      val tries = missingTries.merge(path, 1) { a, b -> a + b } ?: 1
      if (tries > 2) continue
      addNote("Planned file $path is missing or empty. Writing it now.")
      runs.label("Writing missing $path")
      processAgentResponse(
        "Overall goal: $goal\n" + (if (planText.isNotBlank()) "Plan:\n$planText\n" else "") +
          "The file $path is missing. Write the complete $path now so it works with the other project files. " +
          "Output it in one <file path=\"$path\"> block.",
        project, settings, Intent.Mode.BUILD, emptyList(), keepBusy = true
      )
    }
    missing = PlanCheck.missing(project.rootDir, files)
    if (missing.isNotEmpty()) addNote("Still missing after trying: ${missing.joinToString(", ")}.")
    return missing
  }

  private suspend fun testAndRepair(goal: String, planText: String, project: Project, auto: SettingsState, settings: SettingsState) {
    var attempt = 0
    var bonus = 0
    var lastCount = Int.MAX_VALUE
    while (true) {
      addNote("Testing the app...")
      runs.label("Testing the app")
      val errors = HeadlessCheck.run(context, project.rootDir)
      if (errors.isEmpty()) {
        addNote("Done. The app loaded with no errors. Tap Preview to try it.")
        return
      }
      // v1.6.2: a missing file is written, not "fixed" by editing the others. Does not use a fix attempt.
      val missingFiles = PlanCheck.missingFromErrors(errors).filter { (missingTries[it] ?: 0) < 2 }
      if (missingFiles.isNotEmpty()) {
        completePlan(goal, planText, missingFiles, project, auto)
        continue
      }
      // Up to 2 extra attempts while each attempt still reduces the number of problems.
      if (errors.size < lastCount && attempt >= settings.maxRepairRetries && attempt > 0 && bonus < 2) bonus++
      lastCount = errors.size
      if (attempt >= settings.maxRepairRetries + bonus) {
        addNote("Stopped after $attempt fix attempts. Remaining problems:\n" + errors.take(3).joinToString("\n") + "\nTap Regenerate or describe what to fix.")
        return
      }
      attempt++
      addNote("Found ${errors.size} problem(s). Fixing, attempt $attempt of ${settings.maxRepairRetries + bonus}.")
      runs.label("Fixing, attempt $attempt")
      processAgentResponse(
        "Fix these errors in the app. Output only the files that change.\n" + errors.take(5).joinToString("\n"),
        project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true
      )
      if (lastApprovalDeclined) {
        addNote("Fix not applied because you declined it. Stopping here.")
        return
      }
    }
  }

  /** "app not working": test the current project first so the model fixes real problems, then verify again. */
  private suspend fun runFix(complaint: String, project: Project, settings: SettingsState) {
    val auto = settings
    try {
      missingTries.clear()
      beforeRun(project, "Fix: $complaint")
      addNote("Checking the app to find what is wrong...")
      val errors = HeadlessCheck.run(context, project.rootDir)
      addNote(if (errors.isEmpty()) "No script errors, so I will look for display and logic problems." else "Found ${errors.size} problem(s). Fixing.")
      val found = if (errors.isEmpty())
        "Testing found no JavaScript errors, so find why nothing shows or works: empty containers, missing render calls, wrong element ids, missing event listeners."
      else "Problems found by testing:\n" + errors.take(5).joinToString("\n")
      processAgentResponse(
        "The user says: \"$complaint\".\n$found\nFix the app. Output only the files that change.",
        project, auto, Intent.Mode.BUILD, emptyList(), keepBusy = true
      )
      testAndRepair(complaint, "", project, auto, settings)
    } finally {
      _isGenerating.value = false
    }
  }

  /** Token-lean prompt: the task plus the current project files (which already hold all state, so no chat history). */
  private fun buildPrompt(userText: String, project: Project?, settings: SettingsState): String {
    val promptTokens = (settings.contextLength - settings.maxOutputTokens - 350).coerceAtLeast(300)
    val snapshotBudget = (promptTokens * 3 - userText.length - 100).coerceIn(0, 9000)
    val snapshot = if (project != null && snapshotBudget > 200) ProjectFiles.snapshot(project.rootDir, snapshotBudget, userText) else ""
    return buildString {
      if (snapshot.isNotBlank()) append("Current project files:\n").append(snapshot).append("\n")
      append("Task: ").append(userText)
    }
  }

  /** Last two exchanges (trimmed) so follow-up questions in plain chat keep their context. */
  /** Engine/status notices are shown in chat but never sent back to the model as history. */
  private fun isEngineNotice(text: String): Boolean {
    val t = text.trimStart()
    return t.startsWith("Offline model was not loaded") || t.startsWith("Offline model is not ready") ||
      t.startsWith("Cannot reach the remote server") || t.startsWith("[Engine error") ||
      t.startsWith("[Generation error") || t.startsWith("[No progress")
  }

  private fun recentExchanges(): List<Pair<String, String>> =
    _messages.value.drop(1)
      .filter { it.content.isNotBlank() && !it.isStreaming && !isEngineNotice(it.content) }
      .takeLast(4)
      .map { m ->
        val role = if (m.sender == MessageSender.USER) "user" else "assistant"
        role to com.example.llama.StopFilter.MARKERS.fold(FileBlocks.displayText(m.content)) { acc, mk -> acc.replace(mk, "") }.trim().take(500)
      }

  private suspend fun processAgentResponse(
    userText: String,
    project: Project?,
    settings: SettingsState,
    mode: Intent.Mode,
    history: List<Pair<String, String>>,
    keepBusy: Boolean = false,
    systemOverride: String? = null,
    rawPrompt: Boolean = false,
    /** v1.6.2: continue a file block the model left unfinished (off for the continuation requests themselves). */
    allowContinue: Boolean = true
  ): String {
    val agentMsgId = UUID.randomUUID().toString()
    lastReplyId = agentMsgId
    _messages.value = _messages.value + ChatMessage(
      id = agentMsgId,
      sender = MessageSender.AGENT,
      content = "",
      isStreaming = true,
      destination = com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl)
    )
    // v1.6: images ride with the first generation of a request only.
    val images = runImages
    runImages = emptyList()
    val chatOnly = mode == Intent.Mode.CHAT
    val sentMax = if (chatOnly) minOf(settings.maxOutputTokens, 1024) else settings.maxOutputTokens

    val buffer = StringBuilder()
    var lastUiUpdate = 0L
    var loggedFiles = 0
    var thinkStart = 0L
    var thinkLogged = false
    log(if (_telemetry.value.outputTokens == 0) "Reading prompt" else "Generating")
    var cancelled: kotlinx.coroutines.CancellationException? = null
    val genStart = System.currentTimeMillis()
    val telemetryBefore = _telemetry.value
    try {
      llamaEngine.generateCompletionStream(
        prompt = if (mode == Intent.Mode.CHAT || rawPrompt) userText else buildPrompt(userText, project, settings),
        settings = settings,
        onTelemetryUpdate = { data -> _telemetry.value = data },
        chatOnly = mode == Intent.Mode.CHAT,
        history = history,
        systemOverride = systemOverride,
        images = images.map { it.dataUrl },
        onRequest = { msgs, exact ->
          val m = manifest(msgs, exact, settings, chatOnly, images, sentMax, systemOverride != null)
          _messages.value = _messages.value.map { if (it.id == agentMsgId) it.copy(context = m, destination = m.destination) else it }
          log("Sent ${m.promptTokensLabel} to ${m.destination.label}")
        }
      ).collect { chunk ->
        buffer.append(chunk)
        if (buffer.length > 120 && buffer.length % 16 == 0 && isLooping(buffer)) throw LoopStop()
        // Redrawing and re-parsing markdown on every token is what makes the UI stutter: update ~10x/second.
        val now = System.currentTimeMillis()
        if (now - lastUiUpdate >= (if (buffer.length > 1500) 250L else 100L)) {
          lastUiUpdate = now
          val (th, ans) = Thinking.split(buffer.toString())
          if (th != null && !thinkLogged) { thinkLogged = true; thinkStart = now; log("Thinking") }
          if (th != null && ans.isNotEmpty() && thinkStart > 0) { log("Thought for ${(now - thinkStart) / 1000}s"); thinkStart = 0 }
          val fc = FILE_OPEN.findAll(ans).count()
          if (fc > loggedFiles) {
            FILE_OPEN.findAll(ans).drop(loggedFiles).forEach { log("Writing ${it.groupValues[1]}") }
            loggedFiles = fc
          }
          updateMessageContent(agentMsgId, ans, isStreaming = true, reasoning = th)
        }
      }
    } catch (e: LoopStop) {
      val keep = buffer.lastIndexOf(" ", maxOf(0, buffer.length - 60)).coerceAtLeast(0)
      buffer.setLength(minOf(buffer.length, maxOf(keep, 40)))
      buffer.append("\n\n[Stopped: the model started repeating itself. Try a bigger model or a shorter prompt.]")
    } catch (e: kotlinx.coroutines.CancellationException) {
      buffer.append(if (buffer.isEmpty()) "[Stopped]" else "\n\n[Stopped]")
      cancelled = e
    } catch (t: Throwable) {
      val msg = if (t is java.net.ConnectException || t is java.net.UnknownHostException || t is java.net.SocketTimeoutException)
        "Cannot reach the remote server (${t.message}). Open Models and switch to \"On this phone\", or start your server."
      else "${t.javaClass.simpleName}: ${t.message}"
      buffer.append("\n\n[Error: $msg]")
    }
    val finish = llamaEngine.lastFinishReason
    val looped = buffer.contains("[Stopped: the model started repeating")
    // v1.4: no `return` inside finally any more (it swallowed CancellationException, so Stop did not
    // really stop multi-step flows). The message is finalised, then cancellation is re-thrown.
    val (th, ans) = Thinking.split(buffer.toString())
    val answer = if (ans.isEmpty() && th != null) "[The model only wrote its reasoning. Try again or turn Thinking off.]" else if (ans.isEmpty()) "[The model returned no text.]" else ans
    val needApproval = finishMessage(agentMsgId, answer, project, settings, th)
    log("Reply done")
    // Log usage only when this generation produced telemetry (not the previous reply's numbers again).
    if (_telemetry.value !== telemetryBefore) recordUsage(genStart)
    if (cancelled != null) {
      if (!keepBusy) _isGenerating.value = false
      throw cancelled
    }
    lastApprovalDeclined = false
    try {
      if (project != null && needApproval.isNotEmpty()) awaitFileApproval(agentMsgId, project, needApproval)
      if (project != null) reportWriteFailures(agentMsgId)
      // v1.6.2: output cut off (token limit or unclosed file block): continue the same file instead of losing it.
      if (allowContinue && project != null && mode == Intent.Mode.BUILD && !looped) {
        val cut = Truncation.openFile(ans)
        if (cut != null) continueCutFile(agentMsgId, ans, cut, userText, project, settings)
        else if (finish == "length") log("Output reached the token limit after its last complete file")
      }
    } finally {
      if (!keepBusy) _isGenerating.value = false
    }
    return answer
  }

  /** Id of the chat message the last [processAgentResponse] created. */
  @Volatile private var lastReplyId: String = ""
  private val reportedFailures = java.util.Collections.synchronizedSet(mutableSetOf<String>())

  /** v1.6.2: a file that could not be written is said in chat with the real error, not only in the file card. */
  private fun reportWriteFailures(messageId: String) {
    val failed = _messages.value.firstOrNull { it.id == messageId }?.fileChanges.orEmpty().filter { it.status == ChangeStatus.FAILED }
    for (c in failed) {
      if (reportedFailures.add(messageId + "|" + c.path)) addNote("Could not write ${c.path}: ${c.error ?: "unknown error"}")
    }
  }

  /**
   * v1.6.2: asks the model to go on with [cut] where it stopped (up to [MAX_CONTINUATIONS] times),
   * stitches the parts together, then writes the file through the normal approval rules.
   */
  private suspend fun continueCutFile(msgId: String, original: String, cut: Truncation.Cut, task: String, project: Project, settings: SettingsState) {
    var content = cut.partial
    var finished = false
    for (part in 1..MAX_CONTINUATIONS) {
      addNote("Continuing ${cut.path} (output was cut off), part $part of $MAX_CONTINUATIONS.")
      runs.label("Continuing ${cut.path} (output was cut off)")
      val reply = processAgentResponse(
        "Task: ${task.take(600)}\nYou were writing ${cut.path} and your output was cut off. These are its last lines:\n" +
          content.takeLast(1500) +
          "\n\nContinue ${cut.path} exactly where it stops. Output only the rest of the file. Do not repeat what is above. No explanation. Finish with </file>.",
        null, settings, Intent.Mode.BUILD, emptyList(), keepBusy = true,
        systemOverride = CONTINUE_PROMPT, rawPrompt = true, allowContinue = false
      )
      val replyId = lastReplyId
      val finish = llamaEngine.lastFinishReason
      val err = ERROR_MARK.find(reply)
      val body = if (err != null) reply.substring(0, err.range.first) else reply
      val (more, closed) = Truncation.cleanContinuation(body)
      val before = content.lines().size
      content = Truncation.merge(content, more)
      updateMessageContent(
        replyId,
        "Continued ${cut.path}: +${content.lines().size - before} lines" + (if (closed) ", file finished." else ".") +
          (err?.let { "\n" + reply.substring(it.range.first).trim() } ?: ""),
        isStreaming = false
      )
      if (err != null) break
      if (closed || finish != "length") { finished = true; break }
    }
    if (!finished) addNote("${cut.path} may still be incomplete: it was cut off ${MAX_CONTINUATIONS + 1} times. Writing what was produced.")
    val target = ProjectFiles.resolve(project.rootDir, cut.path)
    val change = FileChange(path = cut.path, content = content.trimEnd() + "\n", isNew = target == null || !target.exists())
    val shown = original.substring(0, cut.start.coerceIn(0, original.length)) + "<file path=\"${cut.path}\">\n" + change.content + "</file>"
    _messages.value = _messages.value.map { m ->
      if (m.id == msgId) m.copy(content = shown, fileChanges = m.fileChanges + change) else m
    }
    val kind = if (change.isNew) ActionKind.NEW_FILE else ActionKind.EDIT_FILE
    if (ApprovalPolicy.needsApproval(kind, settings)) awaitFileApproval(msgId, project, listOf(change))
    else writeApproved(msgId, project)
    reportWriteFailures(msgId)
  }

  /** True when the user declined the last file approval (autonomous repair stops instead of looping). */
  @Volatile
  private var lastApprovalDeclined = false

  /**
   * v1.5: before an autonomous run, zip the project for "Undo last run" (Projects, History) and log the
   * run start. A skipped snapshot (too big, low storage) is said in chat; the run still goes ahead.
   */
  private fun beforeRun(project: Project, label: String) {
    val root = project.rootDir
    when (val r = ProjectBackups.snapshot(root)) {
      is ProjectBackups.Outcome.Saved -> ProjectHistory.record(root, HistoryEntry.RUN, label.take(120), null, "Undo snapshot saved")
      is ProjectBackups.Outcome.Skipped -> {
        ProjectHistory.record(root, HistoryEntry.RUN, label.take(120), null, r.reason)
        if (ProjectBackups.list(root).isNotEmpty() || !r.reason.startsWith("Nothing")) addNote(r.reason)
      }
    }
  }

  private fun recordUsage(start: Long) {
    val t = _telemetry.value
    if (t.outputTokens <= 0 && t.inputTokens <= 0) return
    // v1.5: rolling speed for the Max output tokens estimate (on-device and remote kept apart).
    com.example.data.GenerationStats.recordSpeed(t.activeBackend.startsWith("Remote"), t.tokensPerSecond, t.outputTokens)
    runCatching {
      onUsage(
        TokenUsage(
          promptTokens = t.inputTokens,
          outputTokens = t.outputTokens,
          tokensPerSecond = t.tokensPerSecond,
          cachedTokens = t.cachedTokens,
          exact = t.promptExact,
          model = t.modelName.ifBlank { t.activeBackend },
          timestamp = System.currentTimeMillis(),
          durationMs = System.currentTimeMillis() - start
        )
      )
    }
  }

  /**
   * Shows the approval dialog for file changes that need it and waits. Approve writes them (with an
   * undo snapshot); reject marks them discarded. Cancellation (Stop) leaves them pending in the card.
   */
  private suspend fun awaitFileApproval(messageId: String, project: Project, changes: List<FileChange>) {
    log("Waiting for your approval")
    val items = changes.map { c ->
      val f = ProjectFiles.resolve(project.rootDir, c.path)
      val old = if (f != null && f.isFile) runCatching { f.readText() }.getOrDefault("") else ""
      ApprovalItem(if (c.isNew) ActionKind.NEW_FILE else ActionKind.EDIT_FILE, path = c.path, diff = com.example.patch.LineDiff.diff(old, c.content))
    }
    val approved = approvals.request(
      ApprovalRequest(
        title = if (changes.size == 1) "Apply changes to ${changes[0].path}?" else "Apply changes to ${changes.size} files?",
        reason = "The agent wants to change existing files.",
        items = items,
        messageId = messageId
      )
    )
    if (approved) {
      writeApproved(messageId, project)
    } else {
      lastApprovalDeclined = true
      discardPending(messageId)
      log("Changes declined")
    }
  }

  private fun writeApproved(messageId: String, project: Project) {
    // Keep the earliest snapshot of this reply, so Undo restores the state before any of its writes.
    Snapshots.take(project.rootDir)?.let { snapIds.putIfAbsent(messageId, it) }
    _messages.value = _messages.value.map { m ->
      if (m.id == messageId) m.copy(fileChanges = writeChanges(project, m.fileChanges)) else m
    }
    PreviewFixer.prepare(project.rootDir)
  }

  /**
   * Specialist agent loop: the model may call tools (read_file, search, run_check...) one at a time;
   * each result is fed back until it gives a final answer or the turn limit is reached.
   */
  private suspend fun runAgentLoop(role: AgentRole, task: String, project: Project, settings: SettingsState) {
    val env = ToolEnv(
      settings, terminalManager, buildRunner, role.canWrite,
      approve = { approvals.request(it) },
      onStep = { log(it) },
      askInput = { inputs.ask(it) }
    )
    try {
      if (role.canWrite) beforeRun(project, "${role.name}: $task")
      addNote("${role.name} agent is working.")
      val results = StringBuilder()
      val maxTurns = 5
      for (turn in 1..maxTurns) {
        val files = AgentTools.execute(context, project, ToolCall("ListFiles", ""), env)
        val prompt = buildString {
          append("Task: ").append(task).append("\n\nProject files:\n").append(files)
          if (results.isNotEmpty()) append("\n\nTool results so far:\n").append(results)
          if (turn == maxTurns) append("\n\nNo more tools. Give your final answer now.")
        }
        val text = processAgentResponse(
          prompt, if (role.canWrite) project else null, settings, Intent.Mode.BUILD, emptyList(),
          keepBusy = true, systemOverride = role.system + Skills.promptFor(false), rawPrompt = true
        )
        val call = ToolCalls.parse(text)
        if (call == null || turn == maxTurns) break
        addNote("Tool: " + AgentTools.stepLabel(ToolCalls.canonical(call.name), call))
        val out = AgentTools.execute(context, project, call, env)
        results.append("[").append(call.name).append(" ").append(call.arg.trim()).append("]\n").append(out.take(2500)).append("\n\n")
        if (results.length > 5000) results.delete(0, results.length - 5000)
      }
      if (role.canWrite) {
        val errors = HeadlessCheck.run(context, project.rootDir)
        addNote(if (errors.isEmpty()) "Tested the app: no errors." else "Still ${errors.size} problem(s): " + errors.take(2).joinToString(" | "))
      }
    } finally {
      _isGenerating.value = false
    }
  }

  /**
   * Extracts file blocks from the reply. v1.4: changes that ApprovalPolicy allows (new files with
   * "Auto-approve new files", edits with "Auto-approve safe edits") are written now; the rest stay
   * PENDING and are returned so the caller can wait for the user's approval.
   */
  private fun finishMessage(id: String, text: String, project: Project?, settings: SettingsState, reasoning: String? = null): List<FileChange> {
    val changes = if (project == null) emptyList() else FileBlocks.parse(text).map { p ->
      val target = ProjectFiles.resolve(project.rootDir, p.path)
      FileChange(path = p.path, content = p.content, isNew = target == null || !target.exists())
    }
    val auto = changes.filter { !ApprovalPolicy.needsApproval(if (it.isNew) ActionKind.NEW_FILE else ActionKind.EDIT_FILE, settings) }
    val ask = changes.filter { it !in auto }
    var finalChanges = changes
    if (project != null && auto.isNotEmpty()) {
      Snapshots.take(project.rootDir)?.let { snapIds[id] = it }
      val written = writeChanges(project, auto)
      finalChanges = changes.map { c -> written.getOrNull(auto.indexOf(c)) ?: c }
      PreviewFixer.prepare(project.rootDir)
    }
    _messages.value = _messages.value.map { m ->
      if (m.id == id) m.copy(content = text, isStreaming = false, fileChanges = finalChanges, reasoning = reasoning) else m
    }
    return ask
  }

  private fun writeChanges(project: Project, changes: List<FileChange>): List<FileChange> =
    changes.map { c ->
      if (c.status != ChangeStatus.PENDING) c
      else ProjectFiles.write(project.rootDir, c).fold(
        onSuccess = { c.copy(status = ChangeStatus.APPLIED) },
        onFailure = { e -> c.copy(status = ChangeStatus.FAILED, error = e.message) }
      )
    }

  fun applyChanges(messageId: String, project: Project) {
    // The agent is waiting on this message's approval: answering it lets the agent write and continue.
    if (approvals.resolveForMessage(messageId, true)) return
    ioScope.launch {
      Snapshots.take(project.rootDir)?.let { snapIds.putIfAbsent(messageId, it) }
      _messages.value = _messages.value.map { m ->
        if (m.id == messageId) m.copy(fileChanges = writeChanges(project, m.fileChanges)) else m
      }
      PreviewFixer.prepare(project.rootDir)
    }
  }

  fun discardChanges(messageId: String) {
    if (approvals.resolveForMessage(messageId, false)) return
    discardPending(messageId)
  }

  private fun discardPending(messageId: String) {
    _messages.value = _messages.value.map { m ->
      if (m.id == messageId) {
        m.copy(fileChanges = m.fileChanges.map { c ->
          if (c.status == ChangeStatus.PENDING) c.copy(status = ChangeStatus.DISCARDED) else c
        })
      } else m
    }
  }

  private suspend fun runBuildWorkflow(project: Project) {
    val buildMsgId = UUID.randomUUID().toString()
    _messages.value = _messages.value + ChatMessage(
      id = buildMsgId,
      sender = MessageSender.TOOL,
      content = "Executing Gradle build verification for '${project.name}'...",
      toolCall = ToolCallInfo("project_build", mapOf("project" to project.name), "running")
    )

    val toolResult = toolExecutor.executeTool("project_build", emptyMap(), project)
    val updatedToolCall = ToolCallInfo(
      toolName = "project_build",
      arguments = mapOf("project" to project.name),
      status = if (toolResult.success) "success" else "error",
      resultSummary = if (toolResult.success) "Build Successful" else "Build Failed"
    )

    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = if (toolResult.success) {
        "Build succeeded!\n${toolResult.output}"
      } else {
        "Build failed. Found errors:\n${toolResult.error}\n\nSay 'repair' to run the 10-step Self-Repair Engine."
      },
      toolCall = updatedToolCall
    )
  }

  private suspend fun runSelfRepairWorkflow(project: Project, settings: SettingsState) {
    val buildRes = selfRepairEngine.rebuildAndVerify(project)

    if (buildRes.errors.isEmpty()) {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: No errors found in workspace. All source files compiled cleanly!"
      )
      return
    }

    val activeError = buildRes.errors.first()
    val patch = selfRepairEngine.generateTargetedPatch(activeError, project)

    if (patch != null) {
      _pendingPatch.value = patch
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Diagnosed error in ${patch.relativePath} at line ${patch.startLine}:\n" +
            "Error: ${activeError.errorMessage}\n" +
            "Rationale: ${patch.rationale}\n\n" +
            "I have prepared a targeted surgical patch. Please review the diff below and approve to apply:",
        patchProposal = patch
      )
    } else {
      _messages.value = _messages.value + ChatMessage(
        id = UUID.randomUUID().toString(),
        sender = MessageSender.AGENT,
        content = "Self-Repair Engine: Detected error '${activeError.errorMessage}', but unable to generate safe surgical patch automatically."
      )
    }
  }

  fun approveAndApplyPatch(proposal: PatchProposal, project: Project) {
    ioScope.launch {
      val success = selfRepairEngine.applyPatch(proposal, project)
      _pendingPatch.value = null

      if (success) {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Patch successfully applied to ${proposal.relativePath}. Rebuilding to verify..."
        )
        // Verify rebuild
        val verifyBuild = selfRepairEngine.rebuildAndVerify(project)
        if (verifyBuild.errors.isEmpty()) {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification PASSED: Project built cleanly without errors!"
          )
        } else {
          _messages.value = _messages.value + ChatMessage(
            id = UUID.randomUUID().toString(),
            sender = MessageSender.AGENT,
            content = "Verification FAILED: ${verifyBuild.errors.size} remaining error(s). Unresolved: ${verifyBuild.errors.first().errorMessage}"
          )
        }
      } else {
        _messages.value = _messages.value + ChatMessage(
          id = UUID.randomUUID().toString(),
          sender = MessageSender.AGENT,
          content = "Failed to apply patch to ${proposal.relativePath}."
        )
      }
    }
  }

  fun rejectPatch(proposal: PatchProposal) {
    _pendingPatch.value = null
    _messages.value = _messages.value + ChatMessage(
      id = UUID.randomUUID().toString(),
      sender = MessageSender.AGENT,
      content = "Patch proposal for ${proposal.relativePath} was declined by user."
    )
  }

  private fun updateMessageContent(id: String, newContent: String, isStreaming: Boolean, reasoning: String? = null) {
    _messages.value = _messages.value.map { msg ->
      if (msg.id == id) msg.copy(content = newContent, isStreaming = isStreaming, reasoning = reasoning ?: msg.reasoning) else msg
    }
  }

  companion object {
    private val FILE_OPEN = Regex("<file\\s+path=\"([^\"]+)\"")
    /** v1.6.2: how many times one cut-off file is continued. */
    const val MAX_CONTINUATIONS = 4
    private val ERROR_MARK = Regex("""\n*\[(?:Error|Engine error|Generation error|No progress)""")
    private const val CONTINUE_PROMPT =
      "You continue a file that was cut off. Output only the remaining raw file content, starting exactly where it stopped. " +
        "No explanation, no markdown fences, no repeated lines. End with </file>."
    private const val PLAN_PROMPT =
      "You plan small web apps made of index.html, styles.css and app.js. " +
        "Break the request into 2 or 3 build steps. Each step is one short line that names the file it writes, " +
        "for example: 1. index.html: page structure. " +
        "Output only the numbered list. No code and no testing step."
  }
}

private class LoopStop : RuntimeException()

/** True when the tail of the text is the same short chunk repeated 4+ times (small models do this). */
private fun isLooping(b: CharSequence): Boolean {
  val n = b.length
  for (len in intArrayOf(4, 8, 14, 24, 40)) {
    if (n < len * 4) continue
    val tail = b.subSequence(n - len, n).toString()
    var ok = true
    for (k in 2..4) if (b.subSequence(n - len * k, n - len * (k - 1)).toString() != tail) { ok = false; break }
    if (ok) return true
  }
  return false
}
