package com.example.llama

import com.example.data.model.SettingsState
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.IOException
import java.io.InputStreamReader
import java.net.HttpURLConnection
import java.net.URL

/** Talks to any OpenAI-compatible server: Ollama (:11434/v1), llama-server (:8080/v1), LM Studio (:1234/v1), a PC on the same Wi-Fi. */
object RemoteClient {
  private fun base(url: String) = url.trim().trimEnd('/')

  private fun open(url: String, key: String, method: String): HttpURLConnection =
    (URL(url).openConnection() as HttpURLConnection).apply {
      requestMethod = method
      connectTimeout = 10_000
      readTimeout = 180_000
      setRequestProperty("Content-Type", "application/json")
      if (key.isNotBlank()) setRequestProperty("Authorization", "Bearer ${key.trim()}")
    }

  /** v1.6: server error bodies can echo part of the key, so they are redacted before anyone sees them. */
  private fun errorText(c: HttpURLConnection, key: String = ""): String =
    com.example.transparency.Redact.text(runCatching { c.errorStream?.bufferedReader()?.readText()?.take(300) }.getOrNull().orEmpty(), listOf(key))

  /** Model ids the server offers. */
  fun models(url: String, key: String): List<String> {
    val c = open(base(url) + "/models", key, "GET")
    try {
      if (c.responseCode != 200) throw IOException("HTTP ${c.responseCode} ${errorText(c, key)}")
      val data = JSONObject(c.inputStream.bufferedReader().readText()).optJSONArray("data") ?: JSONArray()
      return (0 until data.length()).map { data.getJSONObject(it).optString("id") }.filter { it.isNotBlank() }
    } finally {
      c.disconnect()
    }
  }

  /** Human-readable connection test. */
  fun test(url: String, key: String): String = try {
    val m = models(url, key)
    if (m.isEmpty()) "Connected, but the server lists no models." else "Connected. Models: " + m.take(6).joinToString(", ")
  } catch (e: Exception) {
    "Could not connect: ${e.message ?: e.javaClass.simpleName}"
  }

  /**
   * Streams the reply. [onPiece] returns false to stop. Blocking: call from an IO dispatcher.
   */
  fun stream(settings: SettingsState, messages: List<Pair<String, String>>, maxTokens: Int, images: List<String> = emptyList(), onPiece: (String) -> Boolean) {
    val model = settings.remoteModel.ifBlank { models(settings.remoteUrl, settings.remoteKey).let { all -> all.firstOrNull { !Regex("whisper|tts|embed|guard|moderation|dall-e|playai|orpheus|transcribe|speech|image|rerank", RegexOption.IGNORE_CASE).containsMatchIn(it) } ?: all.firstOrNull() } ?: throw IOException("No model on the server") }
    // v1.4.4: some models cap max_tokens below our output level (Groq allam-2-7b: 512).
    // Use the cap we learned before, else retry once with the limit the server names.
    var tokens = tokenCaps[model]?.let { minOf(it, maxTokens) } ?: maxTokens
    var attempt = 0
    while (true) {
      attempt++
      val body = JSONObject()
        .put("model", model)
        .put("stream", true)
        .put("temperature", settings.temperature.toDouble())
        .put("top_p", settings.topP.toDouble())
        .put("max_tokens", tokens)
        .put("messages", JSONArray().apply {
          messages.forEachIndexed { i, (role, content) ->
            // v1.6: images ride on the last user message as OpenAI-style content parts.
            if (images.isNotEmpty() && i == messages.lastIndex && role == "user") {
              val parts = JSONArray().put(JSONObject().put("type", "text").put("text", content))
              images.forEach { url -> parts.put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", url))) }
              put(JSONObject().put("role", role).put("content", parts))
            } else put(JSONObject().put("role", role).put("content", content))
          }
        })
      val c = open(base(settings.remoteUrl) + "/chat/completions", settings.remoteKey, "POST")
      try {
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        if (c.responseCode != 200) {
          val err = errorText(c, settings.remoteKey)
          val cap = if (c.responseCode == 400 && err.contains("max_tokens", ignoreCase = true))
            CAP_RE.find(err)?.groupValues?.get(1)?.toIntOrNull() else null
          if (cap != null && cap in 1 until tokens && attempt < 3) {
            tokenCaps[model] = cap
            tokens = cap
            continue
          }
          throw IOException("HTTP ${c.responseCode} $err")
        }
        BufferedReader(InputStreamReader(c.inputStream)).use { r ->
          while (true) {
            val line = r.readLine() ?: break
            if (!line.startsWith("data:")) continue
            val payload = line.removePrefix("data:").trim()
            if (payload == "[DONE]") break
            val piece = runCatching {
              JSONObject(payload).optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("delta")?.optString("content", "")
            }.getOrNull().orEmpty()
            if (piece.isNotEmpty() && !onPiece(piece)) break
          }
        }
        return
      } finally {
        c.disconnect()
      }
    }
  }

  /** Learned per-model max_tokens caps for this app session. */
  private val tokenCaps = java.util.concurrent.ConcurrentHashMap<String, Int>()
  private val CAP_RE = Regex("(?:less than or equal to|at most|<=|maximum[^0-9]{0,40})\\s*`?(\\d{2,7})")
}
