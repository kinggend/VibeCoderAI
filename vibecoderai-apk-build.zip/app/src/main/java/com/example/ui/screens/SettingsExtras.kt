@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.example.ui.screens

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Estimate
import com.example.data.GenerationStats
import com.example.data.model.OutputPresets
import com.example.data.model.SettingsState
import com.example.ui.components.Button
import com.example.ui.components.GroupedSection
import com.example.ui.components.TextButton
import com.example.ui.components.rememberHaptics
import com.example.ui.theme.Accents
import com.example.ui.theme.CyberCoralError
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.Palette
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.launch
import java.io.File

/** v1.5 motion: strong ease-out, short durations, and an instant cut when the phone has animations off. */
internal object Motion {
  val EaseOut = CubicBezierEasing(0.23f, 1f, 0.32f, 1f)
}

@Composable
internal fun rememberReducedMotion(): Boolean {
  val context = LocalContext.current
  return remember {
    runCatching {
      android.provider.Settings.Global.getFloat(context.contentResolver, android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f
    }.getOrDefault(false)
  }
}

internal fun <T> motion(reduced: Boolean, ms: Int): AnimationSpec<T> = if (reduced) snap() else tween(ms, easing = Motion.EaseOut)

/** v1.5: one plain sentence per tunable setting, shown from its "?" button. */
internal object SettingInfo {
  val text = mapOf(
    "Context window" to "How much text the model can keep in mind at once (your request, project files and its reply); bigger needs more RAM and is slower to start.",
    "Temperature" to "How adventurous the wording is: low values give the same safe answer every time, high values give more varied and surprising output.",
    "Top-P" to "The model only picks from the most likely words whose chances add up to this share; lower keeps it focused, 1.0 lets every word compete.",
    "Top-K" to "The model only picks from this many most likely next words; a smaller number is more predictable.",
    "CPU threads" to "How many processor cores the on-device model uses; around the number of fast cores (often 4) is usually quickest.",
    "Repetition penalty" to "Makes the model less likely to repeat the same words; 1.00 is off, and small values help tiny models that loop."
  )
}

/** 48dp "?" button that opens the info sheet. */
@Composable
internal fun InfoButton(title: String, onClick: () -> Unit) {
  Box(
    modifier = Modifier
      .size(48.dp)
      .clip(CircleShape)
      .clickable(role = Role.Button, onClickLabel = "Explain $title", onClick = onClick)
      .semantics { contentDescription = "What is $title?" },
    contentAlignment = Alignment.Center
  ) {
    Box(
      modifier = Modifier.size(20.dp).border(1.5.dp, TextMuted, CircleShape),
      contentAlignment = Alignment.Center
    ) { Text("?", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold, lineHeight = 12.sp) }
  }
}

/** Small glass bottom sheet with one sentence about a setting. */
@Composable
internal fun InfoSheet(title: String, onDismiss: () -> Unit) {
  val state = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  val scope = rememberCoroutineScope()
  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = state,
    modifier = Modifier.border(1.dp, com.example.ui.components.GlassPopupColors.rim(), RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp)),
    shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
    containerColor = com.example.ui.components.GlassPopupColors.container,
    contentColor = TextPrimary,
    tonalElevation = 0.dp,
    scrimColor = Color.Black.copy(alpha = if (Palette.dark) 0.45f else 0.25f),
    dragHandle = { com.example.ui.components.GlassSheetHandle() }
  ) {
    Column(Modifier.fillMaxWidth().padding(horizontal = 20.dp).padding(bottom = 16.dp).navigationBarsPadding()) {
      Text(title, color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
      Spacer(Modifier.height(8.dp))
      Text(SettingInfo.text[title].orEmpty(), color = TextSecondary, fontSize = 16.sp, lineHeight = 23.sp)
      Spacer(Modifier.height(16.dp))
      Button(
        onClick = { scope.launch { state.hide() }.invokeOnCompletion { onDismiss() } },
        shape = CircleShape,
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White),
        modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp)
      ) { Text("Got it", fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }
    }
  }
}

/** Coding / Balanced / Creative chips plus the active preset (or Custom). */
@Composable
internal fun PresetChips(settings: SettingsState, onUpdate: (SettingsState) -> Unit) {
  val reduced = rememberReducedMotion()
  val haptics = rememberHaptics()
  val active = OutputPresets.match(settings.temperature, settings.topP, settings.topK)
  Row(
    modifier = Modifier.fillMaxWidth().clip(CircleShape).background(ObsidianSurfaceVariant).padding(3.dp),
    horizontalArrangement = Arrangement.spacedBy(3.dp)
  ) {
    OutputPresets.all.forEach { p ->
      val selected = active?.id == p.id
      val bg by animateColorAsState(if (selected) CyberCyanPrimary else Color.Transparent, motion(reduced, 180), label = "presetBg")
      val fg by animateColorAsState(if (selected) Color.White else TextPrimary, motion(reduced, 180), label = "presetFg")
      Box(
        modifier = Modifier
          .weight(1f)
          .heightIn(min = 48.dp)
          .clip(CircleShape)
          .background(bg)
          .semantics { this.selected = selected }
          .clickable(role = Role.RadioButton) { haptics.tick(); onUpdate(OutputPresets.apply(settings, p)) },
        contentAlignment = Alignment.Center
      ) { Text(p.label, color = fg, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1) }
    }
  }
  Spacer(Modifier.height(8.dp))
  Text(
    (if (active != null) "Active: ${active.label}" else "Active: Custom") +
      " · Temp %.2f · Top-P %.2f · Top-K %d".format(settings.temperature, settings.topP, settings.topK),
    color = TextMuted, fontSize = 12.5.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight
  )
}

/** Collapsed-by-default "Advanced" block with an animated chevron. */
@Composable
internal fun AdvancedSection(content: @Composable ColumnScope.() -> Unit) {
  var open by remember { mutableStateOf(false) }
  val reduced = rememberReducedMotion()
  val turn by animateFloatAsState(if (open) 180f else 0f, motion(reduced, 200), label = "advChevron")
  Row(
    modifier = Modifier
      .fillMaxWidth()
      .heightIn(min = 48.dp)
      .clip(RoundedCornerShape(10.dp))
      .clickable(role = Role.Button, onClickLabel = if (open) "Hide advanced settings" else "Show advanced settings") { open = !open },
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text("Advanced", color = TextPrimary, fontSize = 16.sp, modifier = Modifier.weight(1f))
    Text(if (open) "Hide" else "Manual values", color = TextMuted, fontSize = 13.sp)
    Icon(Icons.Default.KeyboardArrowDown, contentDescription = null, tint = TextMuted, modifier = Modifier.padding(start = 4.dp).size(22.dp).rotate(turn))
  }
  AnimatedVisibility(
    visible = open,
    enter = if (reduced) EnterTransition.None else expandVertically(tween(220, easing = Motion.EaseOut)) + fadeIn(tween(180, easing = Motion.EaseOut)),
    exit = if (reduced) ExitTransition.None else shrinkVertically(tween(180, easing = Motion.EaseOut)) + fadeOut(tween(120))
  ) { Column(content = content) }
}

/** Four accent swatches, 48dp targets, ring on the chosen one. */
@Composable
internal fun AccentPicker(current: String, onPick: (String) -> Unit) {
  val reduced = rememberReducedMotion()
  val haptics = rememberHaptics()
  Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
    Accents.all.forEach { a ->
      val selected = a.key == current
      val color = Color(if (Palette.dark) a.dark else a.light)
      val ring by animateColorAsState(if (selected) TextPrimary else Color.Transparent, motion(reduced, 160), label = "accentRing")
      Column(
        modifier = Modifier
          .weight(1f)
          .clip(RoundedCornerShape(12.dp))
          .semantics { this.selected = selected }
          .clickable(role = Role.RadioButton, onClickLabel = "Use ${a.label} accent") { haptics.tick(); onPick(a.key) }
          .padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(Modifier.size(48.dp).border(2.dp, ring, CircleShape).padding(5.dp).clip(CircleShape).background(color))
        Text(a.label, color = if (selected) TextPrimary else TextMuted, fontSize = 12.5.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium, modifier = Modifier.padding(top = 4.dp))
      }
    }
  }
}

/** Live preview for the blur radius: sample content blurred at the chosen radius (Android 12+). */
@Composable
internal fun BlurPreview(radiusDp: Int) {
  val reduced = rememberReducedMotion()
  val r by animateDpAsState(radiusDp.dp, motion(reduced, 160), label = "blurPreview")
  Box(
    modifier = Modifier.fillMaxWidth().height(88.dp).clip(RoundedCornerShape(14.dp)).background(Color.Black).border(1.dp, ObsidianBorder, RoundedCornerShape(14.dp))
  ) {
    // The "content behind the glass": the same shapes the app shows, blurred live.
    Row(
      modifier = Modifier.fillMaxWidth().height(88.dp).blur(r * 0.5f).padding(14.dp),
      horizontalArrangement = Arrangement.spacedBy(10.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(Modifier.size(44.dp).clip(CircleShape).background(CyberCyanPrimary))
      Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("const app = build()", color = Color.White, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
        Box(Modifier.width(140.dp).height(8.dp).clip(CircleShape).background(Color(0xFFFF9F0A)))
        Box(Modifier.width(90.dp).height(8.dp).clip(CircleShape).background(Color(0xFF64D2FF)))
      }
    }
    Text(
      "$radiusDp dp",
      color = Color.White,
      fontSize = 13.sp,
      fontWeight = FontWeight.SemiBold,
      modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)).padding(horizontal = 10.dp, vertical = 4.dp)
    )
  }
}

internal val canBlur: Boolean get() = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

/** Model key for prices: remote model id, or the local GGUF file name. */
internal fun priceKey(s: SettingsState): String =
  if (s.backendMode == "remote") s.remoteModel.trim() else s.customModelPath?.let { File(it).name }.orEmpty()

/** "≈ 42 s · ≈ $0.0012" next to Max output tokens. */
@Composable
internal fun OutputEstimate(settings: SettingsState, onSetPrice: (String) -> Unit) {
  GenerationStats.version // re-read on change
  val remote = settings.backendMode == "remote"
  val tps = GenerationStats.averageSpeed(remote)
  val model = priceKey(settings)
  val secs = Estimate.seconds(settings.maxOutputTokens, tps)
  val cost = Estimate.cost(settings.maxOutputTokens, model.takeIf { it.isNotBlank() }?.let { GenerationStats.price(it) })
  Row(
    modifier = Modifier.fillMaxWidth().padding(top = 2.dp),
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(
      if (secs != null) "≈ ${Estimate.formatSeconds(secs)} at %.1f tok/s (%s avg)".format(tps, if (remote) "remote" else "on-device")
      else "Time shows after the first ${if (remote) "remote" else "on-device"} reply",
      color = TextMuted, fontSize = 12.5.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
      modifier = Modifier.weight(1f)
    )
    if (cost != null) {
      Box(
        modifier = Modifier.heightIn(min = 48.dp).clip(CircleShape).clickable(onClickLabel = "Edit price") { onSetPrice(model) }.padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
      ) { Text("≈ ${Estimate.formatCost(cost)}", color = TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
    } else if (model.isNotBlank()) {
      TextButton(onClick = { onSetPrice(model) }, modifier = Modifier.heightIn(min = 48.dp)) {
        Text("Set price", color = CyberCyanPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

/** User-editable $ per 1M output tokens, one row per model. Nothing is preset. */
@Composable
internal fun PriceTableSection(settings: SettingsState, onEdit: (String) -> Unit) {
  GenerationStats.version
  val prices = GenerationStats.prices().toSortedMap()
  val current = priceKey(settings)
  GroupedSection("Prices ($ per 1M output tokens)", footer = "No prices are built in. Add your provider's price to see a cost estimate next to Max output tokens.") {
    if (prices.isEmpty()) Text("No prices set.", color = TextMuted, fontSize = 14.sp, modifier = Modifier.padding(vertical = 6.dp))
    prices.forEach { (model, price) ->
      Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(com.example.ui.components.friendlyModelName(model).ifBlank { model }, color = TextPrimary, fontSize = 15.sp, maxLines = 1,
          overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        Text("$" + price.toBigDecimal().stripTrailingZeros().toPlainString(), color = TextSecondary, fontSize = 15.sp, fontFamily = FontFamily.Monospace)
        TextButton(onClick = { onEdit(model) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Edit", color = CyberCyanPrimary, fontSize = 14.sp) }
        TextButton(onClick = { GenerationStats.setPrice(model, null) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Remove", color = CyberCoralError, fontSize = 14.sp) }
      }
    }
    if (current.isNotBlank() && current !in prices) {
      TextButton(onClick = { onEdit(current) }, modifier = Modifier.heightIn(min = 48.dp)) {
        Text("+ Price for current model", color = CyberCyanPrimary, fontWeight = FontWeight.SemiBold)
      }
    }
  }
}

/** Dialog to enter one model's price. Empty clears it. */
@Composable
internal fun PriceDialog(model: String, onDismiss: () -> Unit) {
  var text by remember(model) { mutableStateOf(GenerationStats.price(model)?.toBigDecimal()?.stripTrailingZeros()?.toPlainString().orEmpty()) }
  val value = text.trim().replace(',', '.').toDoubleOrNull()
  val error = when {
    text.isBlank() -> null
    value == null || !value.isFinite() -> "Enter a number, e.g. 0.60"
    value < 0 || value > 10_000 -> "Use a price between 0 and 10000"
    else -> null
  }
  com.example.ui.components.GlassAlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Price per 1M output tokens") },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(com.example.ui.components.friendlyModelName(model).ifBlank { model }, color = TextSecondary, fontSize = 14.sp)
        OutlinedTextField(
          text, { text = it.take(12) },
          label = { Text("US dollars") },
          prefix = { Text("$") },
          singleLine = true,
          isError = error != null,
          supportingText = { Text(error ?: "Leave empty to remove the price.") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
        )
      }
    },
    confirmButton = {
      TextButton(enabled = error == null, onClick = {
        GenerationStats.setPrice(model, if (text.isBlank()) null else value)
        onDismiss()
      }) { Text("Save") }
    },
    dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
  )
}
