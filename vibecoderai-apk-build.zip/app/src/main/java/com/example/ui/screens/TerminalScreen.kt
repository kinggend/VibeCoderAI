package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.text.style.TextOverflow
import com.example.ui.components.ActionIconButton
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material3.CircularProgressIndicator
import com.example.ui.components.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import com.example.ui.components.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Project
import com.example.terminal.TerminalExecutionResult
import com.example.terminal.TerminalManager
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.CyberGreenSuccess
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class TerminalLogEntry(
  val command: String,
  val result: TerminalExecutionResult?,
  val isRunning: Boolean = false
)

@Composable
fun TerminalScreen(
  terminalManager: TerminalManager,
  activeProject: Project?,
  modifier: Modifier = Modifier
) {
  val scope = rememberCoroutineScope()
  var inputCommand by remember { mutableStateOf("") }
  val history = remember { mutableStateListOf<TerminalLogEntry>() }
  var currentJob by remember { mutableStateOf<Job?>(null) }
  val listState = rememberLazyListState()

  LaunchedEffect(history.size) {
    if (history.isNotEmpty()) {
      listState.animateScrollToItem(history.size - 1)
    }
  }

  val context = androidx.compose.ui.platform.LocalContext.current
  val workspaceLabel = remember(activeProject?.rootPath) {
    activeProject?.rootPath?.let { shortenWorkspacePath(it, context.filesDir) } ?: "~"
  }

  fun runCommand(cmd: String) {
    if (cmd.isBlank() || activeProject == null || currentJob?.isActive == true) return
    terminalManager.recordCommand(cmd)
    val entry = TerminalLogEntry(command = cmd, result = null, isRunning = true)
    history.add(entry)
    val entryIdx = history.lastIndex

    currentJob = scope.launch {
      val res = terminalManager.executeCommand(cmd, activeProject.rootDir)
      history[entryIdx] = TerminalLogEntry(command = cmd, result = res, isRunning = false)
      currentJob = null
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(Color(0xFF101012))
  ) {
    // Terminal Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .background(ObsidianSurface)
        .padding(start = 12.dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      Icon(
        imageVector = Icons.Default.Terminal,
        contentDescription = null,
        tint = CyberCyanPrimary,
        modifier = Modifier.size(18.dp)
      )
      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = "Sandboxed Terminal",
            color = TextPrimary,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Monospace,
            maxLines = 1
          )
          Spacer(modifier = Modifier.width(8.dp))
          Text(
            text = "• ${activeProject?.name ?: "No Workspace"}",
            color = com.example.ui.theme.TextSecondary,
            fontSize = 11.sp,
            fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
            fontFamily = FontFamily.Monospace,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
          )
        }
        Text(
          text = workspaceLabel,
          color = TextMuted,
          fontSize = 11.sp,
          lineHeight = 14.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
          fontFamily = FontFamily.Monospace,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis
        )
      }

      if (currentJob?.isActive == true) {
        ActionIconButton(
          icon = Icons.Default.Stop,
          contentDescription = "Cancel",
          onClick = {
            currentJob?.cancel()
            currentJob = null
          },
          tint = Color(0xFFF85149)
        )
      }
      ActionIconButton(
        icon = Icons.Default.ClearAll,
        contentDescription = "Clear",
        onClick = { history.clear() },
        tint = TextMuted
      )
    }

    // Scrollback Console Output
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      if (history.isEmpty()) {
        item {
          Text(
            text = "VibeCoderAI Sandboxed Shell [Version 1.0.0]\nWorkspace restricted to: $workspaceLabel",
            color = TextMuted,
            fontSize = 11.sp,
            fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight,
            fontFamily = FontFamily.Monospace,
            lineHeight = 16.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
          )
        }
        val recent = terminalManager.recentCommands
        if (recent.isNotEmpty()) {
          item {
            Text(
              text = "RECENT COMMANDS",
              color = TextMuted,
              fontSize = 11.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier.padding(top = 6.dp)
            )
          }
          items(recent.take(8)) { cmd ->
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(ObsidianSurface)
                .clickable { inputCommand = cmd }
                .padding(start = 12.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = "$ ",
                color = CyberCyanPrimary,
                fontWeight = FontWeight.Bold,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace
              )
              Text(
                text = cmd,
                color = TextPrimary,
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
              )
              ActionIconButton(
                icon = Icons.Default.PlayArrow,
                contentDescription = "Run $cmd again",
                onClick = { runCommand(cmd) },
                enabled = activeProject != null && currentJob?.isActive != true,
                tint = CyberCyanPrimary,
                iconSize = 20.dp
              )
            }
          }
        } else {
          item {
            Column(
              modifier = Modifier
                .fillMaxWidth()
                .padding(top = 4.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(ObsidianSurface)
                // v1.2: tighter tips card leaves room for recent commands.
                .padding(horizontal = 12.dp, vertical = 8.dp),
              verticalArrangement = Arrangement.spacedBy(3.dp)
            ) {
              Text("Tips", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
              listOf(
                "Tap a quick command below to run it in the project folder.",
                "Commands run inside the project only; risky commands are blocked.",
                "ls -la lists files, cat <file> prints one, find . shows the tree.",
                "Commands stop automatically after 10 seconds.",
                "Your recent commands will appear here."
              ).forEach { tip ->
                Row {
                  Text("•  ", color = CyberCyanPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                  Text(
                    tip,
                    color = com.example.ui.theme.TextSecondary,
                    fontSize = 12.sp,
                    lineHeight = 15.sp,
                    fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight
                  )
                }
              }
            }
          }
        }
      }

      items(history) { entry ->
        Column(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(4.dp))
            .background(ObsidianSurface)
            .padding(8.dp)
        ) {
          // Command Line Prompt
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = "$ ",
              color = CyberCyanPrimary,
              fontWeight = FontWeight.Bold,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )
            Text(
              text = entry.command,
              color = TextPrimary,
              fontWeight = FontWeight.SemiBold,
              fontSize = 12.sp,
              fontFamily = FontFamily.Monospace
            )
            Spacer(modifier = Modifier.weight(1f))
            if (entry.isRunning) {
              CircularProgressIndicator(
                modifier = Modifier.size(12.dp),
                strokeWidth = 1.5.dp,
                color = CyberCyanPrimary
              )
            } else entry.result?.let { res ->
              val isOk = res.exitCode == 0
              Text(
                text = "exit ${res.exitCode} (${res.durationMs}ms)",
                color = if (isOk) CyberGreenSuccess else Color(0xFFF85149),
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace
              )
            }
          }

          // Stdout Output
          entry.result?.stdout?.takeIf { it.isNotEmpty() }?.let { out ->
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = out,
              color = Color(0xFFE6EDF3),
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              lineHeight = 15.sp
            )
          }

          // Stderr Output
          entry.result?.stderr?.takeIf { it.isNotEmpty() }?.let { err ->
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = err,
              color = Color(0xFFFFA198),
              fontSize = 11.sp,
              fontFamily = FontFamily.Monospace,
              lineHeight = 15.sp
            )
          }
        }
      }
    }

    // Bottom area: quick commands + input. imePadding keeps both visible above the keyboard.
    Column(modifier = Modifier.fillMaxWidth().imePadding()) {
      // Quick Command Suggestions (horizontally scrollable)
      LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        val suggestions = listOf("ls -la", "pwd", "git status", "find .", "cat build.gradle.kts")
        items(suggestions) { cmd ->
          FilterChip(
            selected = false,
            onClick = {
              inputCommand = cmd
              runCommand(cmd)
            },
            label = { Text(cmd, fontSize = 12.sp, fontFamily = FontFamily.Monospace, color = TextPrimary, maxLines = 1) },
            colors = FilterChipDefaults.filterChipColors(containerColor = ObsidianSurfaceVariant),
            border = FilterChipDefaults.filterChipBorder(enabled = true, selected = false, borderColor = ObsidianBorder),
            modifier = Modifier.heightIn(min = 36.dp)
          )
        }
      }

      // Input Execution Line
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .background(ObsidianSurface)
          .padding(start = 12.dp, end = 6.dp, top = 4.dp, bottom = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(
          text = "~$",
          color = CyberCyanPrimary,
          fontSize = 13.sp,
          fontFamily = FontFamily.Monospace,
          fontWeight = FontWeight.Bold
        )
        OutlinedTextField(
          value = inputCommand,
          onValueChange = { inputCommand = it },
          placeholder = { Text("enter command...", fontSize = 12.sp, color = TextMuted) },
          singleLine = true,
          modifier = Modifier
            .weight(1f)
            .testTag("terminal_input_field"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = Color.Transparent,
            unfocusedContainerColor = Color.Transparent,
            focusedBorderColor = Color.Transparent,
            unfocusedBorderColor = Color.Transparent,
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          textStyle = MaterialTheme.typography.bodySmall.copy(
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp
          ),
          keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(imeAction = androidx.compose.ui.text.input.ImeAction.Go),
          keyboardActions = androidx.compose.foundation.text.KeyboardActions(onGo = {
            val cmd = inputCommand
            if (cmd.isNotBlank() && currentJob?.isActive != true) {
              inputCommand = ""
              runCommand(cmd)
            }
          })
        )
        // Compact run button: 44 dp touch target, small visual circle.
        val canRun = inputCommand.isNotBlank() && currentJob?.isActive != true
        Box(
          modifier = Modifier
            .size(com.example.ui.theme.UiTokens.MinTouchTarget)
            .clip(CircleShape)
            .clickable(enabled = canRun) {
              val cmd = inputCommand
              inputCommand = ""
              runCommand(cmd)
            }
            .testTag("terminal_run_button"),
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier
              .size(34.dp)
              .clip(CircleShape)
              .background(if (inputCommand.isNotBlank()) CyberCyanPrimary else ObsidianSurfaceVariant),
            contentAlignment = Alignment.Center
          ) {
            Icon(
              imageVector = Icons.Default.PlayArrow,
              contentDescription = "Execute",
              tint = if (inputCommand.isNotBlank()) Color.White else TextMuted,
              modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }
}

/** Replaces the app's private data prefix with "~" so the workspace path fits, e.g. ~/vibecoder_projects/app. */
internal fun shortenWorkspacePath(path: String, filesDir: java.io.File): String {
  val prefixes = listOfNotNull(
    filesDir.absolutePath,
    filesDir.parentFile?.absolutePath,
    runCatching { filesDir.canonicalPath }.getOrNull(),
    runCatching { filesDir.parentFile?.canonicalPath }.getOrNull()
  ).filter { it.isNotEmpty() }.distinct().sortedByDescending { it.length }
  for (prefix in prefixes) {
    if (path == prefix) return "~"
    if (path.startsWith("$prefix/")) return "~" + path.substring(prefix.length)
  }
  return path
}
