package com.example.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color

/** Set once per composition by [MyApplicationTheme]. The activity is recreated when the system theme changes. */
object Palette {
  var dark: Boolean by androidx.compose.runtime.mutableStateOf(true)
}

/** "system", "light" or "dark". Read by the theme, changed from Settings. */
object ThemeController {
  var mode: String by androidx.compose.runtime.mutableStateOf("system")
  /** Real backdrop blur: prettier, but redraws the whole screen into a layer every frame. Off by default. */
  var blur: Boolean by androidx.compose.runtime.mutableStateOf(true)
  /** True while the model is writing or the keyboard is open: blur is paused so the UI stays at 60 fps. */
  var busy: Boolean by androidx.compose.runtime.mutableStateOf(false)
  val blurActive: Boolean get() = blur && !busy
  /** v1.5: glass blur radius in dp (Android 12+). */
  var blurRadiusDp: Int by androidx.compose.runtime.mutableIntStateOf(24)
  /** v1.5: accent key, see [Accents]. */
  var accent: String by androidx.compose.runtime.mutableStateOf("blue")
}

/**
 * v1.5: user accent colours (dark, light). Only the accent role changes: buttons, active tabs,
 * sliders, switches and focus rings. Background, error and success colours never follow it.
 * Each shade keeps white labels at >= 3.4:1 and the accent itself at >= 4.7:1 on OLED black.
 */
object Accents {
  data class Accent(val key: String, val label: String, val dark: Long, val light: Long)
  val all = listOf(
    Accent("blue", "Blue", 0xFF0A84FF, 0xFF007AFF),
    Accent("green", "Green", 0xFF1E9E4A, 0xFF218A3F),
    Accent("purple", "Purple", 0xFFA855F7, 0xFF8E44D9),
    Accent("pink", "Pink", 0xFFE8336B, 0xFFD30F45)
  )
  fun of(key: String): Accent = all.firstOrNull { it.key == key } ?: all[0]
}

private fun c(dark: Long, light: Long): Color = Color(if (Palette.dark) dark else light)

// Cupertino grouped surfaces. (Constant names kept so every screen picks the palette up.)
val ObsidianBackground: Color get() = c(0xFF000000, 0xFFF2F2F7)
// Glass: translucent so the ambient backdrop shows through every card.
val ObsidianSurface: Color get() = c(0x8C1C1C1E, 0x6BFFFFFF)
val ObsidianSurfaceSolid: Color get() = c(0xFF121214, 0xFFFFFFFF)
val ObsidianSurfaceVariant: Color get() = c(0xFF1C1C1E, 0xFFE9E9EE)
val ObsidianBorder: Color get() = c(0xFF2A2A2C, 0xFFE5E5EA)

// iOS system blue
// v1.5: follows the user's accent (blue by default). Container = accent mixed into the background.
val CyberCyanPrimary: Color get() = Accents.of(ThemeController.accent).let { c(it.dark, it.light) }
val CyberCyanContainer: Color get() = androidx.compose.ui.graphics.lerp(
  if (Palette.dark) Color.Black else Color.White, CyberCyanPrimary, if (Palette.dark) 0.30f else 0.18f
)
val CyberOnCyan: Color get() = Color.White

val CyberVioletSecondary: Color get() = c(0xFF5E5CE6, 0xFF5856D6)
val CyberVioletContainer: Color get() = c(0xFF25244D, 0xFFE4E3FA)

// System green / orange / red
val CyberGreenSuccess: Color get() = c(0xFF30D158, 0xFF34C759)
val CyberGreenContainer: Color get() = c(0xFF12301B, 0xFFD9F5E0)

val CyberAmberWarning: Color get() = c(0xFFFF9F0A, 0xFFFF9500)
val CyberAmberContainer: Color get() = c(0xFF3A2A0A, 0xFFFFEBCC)

val CyberCoralError: Color get() = c(0xFFFF453A, 0xFFFF3B30)
val CyberCoralContainer: Color get() = c(0xFF3D1512, 0xFFFFDAD7)

// Labels
val TextPrimary: Color get() = c(0xFFFFFFFF, 0xFF000000)
// v1.1: higher contrast for secondary labels on dark (>= ~72% white) and darker greys on light.
val TextSecondary: Color get() = c(0xFFD1D1D6, 0xFF48484D)
val TextMuted: Color get() = c(0xFFB4B4BA, 0xFF5E5E63)

// Code and diffs
val CodeBackground: Color get() = c(0xFF0A0A0B, 0xFFF5F5F7)
val DiffAddedBg: Color get() = c(0xFF14261C, 0xFFE3F6E8)
val DiffRemovedBg: Color get() = c(0xFF2B181B, 0xFFFDE6E4)
val DiffAddedText: Color get() = c(0xFF8FD6A1, 0xFF1E7B34)
val DiffRemovedText: Color get() = c(0xFFF0A0A8, 0xFFC4281C)
