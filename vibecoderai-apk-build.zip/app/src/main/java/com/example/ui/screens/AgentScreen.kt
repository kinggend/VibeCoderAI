package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.material.icons.filled.Tune
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.heightIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.ui.graphics.Brush
import com.example.data.model.OutputLevel
import com.example.data.model.withLevel
import com.example.ui.components.rememberHaptics
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Image
import com.example.ui.components.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import com.example.ui.components.IconButton
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import com.example.ui.components.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.agent.AgentOrchestrator
import com.example.agent.FileBlocks
import com.example.data.model.ChatMessage
import com.example.data.model.MessageSender
import com.example.data.model.Project
import com.example.data.model.SettingsState
import com.example.data.model.TelemetryData
import com.example.data.model.promptLabel
import com.example.project.ProjectManager
import com.example.project.createBlankWebProject
import com.example.project.createFromTemplate
import androidx.compose.foundation.horizontalScroll
import com.example.ui.components.DiffViewer
import com.example.ui.components.FileChangesCard
import com.example.ui.components.MarkdownText
import com.example.ui.components.PatchApprovalDialog
import com.example.ui.components.TelemetryBar
import com.example.ui.theme.CyberCyanPrimary
import com.example.ui.theme.ObsidianBorder
import com.example.ui.components.liquidGlass
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val SUGGESTIONS = listOf(
  "Build a todo list with local storage",
  "Build a scientific calculator",
  "Build a pomodoro timer with sound",
  "Build an expense tracker with a bar chart"
)

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class) // combinedClickable (mic long-press)
@Composable
fun AgentScreen(
  orchestrator: AgentOrchestrator,
  projectManager: ProjectManager,
  activeProject: Project?,
  settings: SettingsState,
  onPreview: () -> Unit,
  onOpenBuild: () -> Unit = {},
  onOpenHistory: () -> Unit = {},
  onSettingsChange: (SettingsState) -> Unit = {},
  bottomInset: androidx.compose.ui.unit.Dp = 0.dp,
  modifier: Modifier = Modifier,
  modelName: String? = null
) {
  val messages by orchestrator.messages.collectAsState()
  val telemetry by orchestrator.telemetry.collectAsState()
  val pendingPatch by orchestrator.pendingPatch.collectAsState()
  val isGenerating by orchestrator.isGenerating.collectAsState()
  val activity by orchestrator.activity.collectAsState()

  var inputText by remember { mutableStateOf("") }
  // v1.4.3: model picker (header model line and the composer's model pill).
  var modelPickerOpen by remember { mutableStateOf(false) }
  // v1.6.1: one chat options sheet (agent, Think, size, model) and hands-free voice mode.
  var optionsOpen by remember { mutableStateOf(false) }
  var voiceOpen by remember { mutableStateOf(false) }
  var voiceNoticeHost by remember { mutableStateOf<String?>(null) }
  val listState = rememberLazyListState()
  val scope = rememberCoroutineScope()

  val writtenCount = messages.count { m -> m.fileChanges.any { it.status == com.example.data.model.ChangeStatus.APPLIED } }
  val canPreview = remember(activeProject?.id, writtenCount) {
    activeProject != null && File(activeProject.rootDir, "index.html").isFile
  }

  val chat = messages.drop(1) // the welcome message is replaced by the hero screen
  val lastFileMsgId = chat.lastOrNull { it.fileChanges.isNotEmpty() }?.id
  val level = OutputLevel.from(settings.outputLevel)
  LaunchedEffect(chat.size) {
    if (chat.isNotEmpty()) listState.animateScrollToItem(chat.lastIndex)
  }
  LaunchedEffect(chat.lastOrNull()?.content?.length) {
    if (isGenerating && chat.isNotEmpty()) listState.scrollToItem(chat.lastIndex, 100_000)
  }

  pendingPatch?.let { patch ->
    if (activeProject != null) {
      PatchApprovalDialog(
        proposal = patch,
        onApprove = { orchestrator.approveAndApplyPatch(patch, activeProject) },
        onReject = { orchestrator.rejectPatch(patch) }
      )
    }
  }

  val context = androidx.compose.ui.platform.LocalContext.current
  var attachment by remember { mutableStateOf<Pair<String, String>?>(null) }
  // v1.6: @mentioned project files (path -> text actually sent), images, and the transparency sheets.
  var mentionFiles by remember { mutableStateOf<List<com.example.transparency.AttachedFile>>(emptyList()) }
  val mentionText = remember { mutableMapOf<String, String>() }
  var images by remember { mutableStateOf<List<com.example.chat.ImagePayload>>(emptyList()) }
  var shownContext by remember { mutableStateOf<com.example.transparency.ContextManifest?>(null) }
  var remoteNoticeFor by remember { mutableStateOf<Pair<String, Boolean>?>(null) } // text, images dropped
  var imageBlocked by remember { mutableStateOf<Pair<String, String>?>(null) }
  val settingsStore = remember { com.example.data.SettingsStore(context) }
  val view = androidx.compose.ui.platform.LocalView.current
  // v1.6: haptics when generation starts and finishes (skipped on first composition).
  var sawGenerating by remember { mutableStateOf(isGenerating) }
  LaunchedEffect(isGenerating) {
    if (isGenerating && !sawGenerating) com.example.ui.components.AppHaptics.start(view)
    if (!isGenerating && sawGenerating) {
      val last = messages.lastOrNull { it.sender == MessageSender.AGENT && it.thoughts != "note" }?.content.orEmpty()
      if (last.contains("[Error") || last.contains("[Engine error") || last.contains("Cannot reach")) com.example.ui.components.AppHaptics.error(view)
      else com.example.ui.components.AppHaptics.success(view)
    }
    sawGenerating = isGenerating
  }
  val imagePicker = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia()
  ) { uri: android.net.Uri? ->
    if (uri != null) scope.launch {
      withContext(Dispatchers.IO) { com.example.chat.ImageEncoder.load(context, uri) }
        .onSuccess { if (images.size < 4) images = images + it else android.widget.Toast.makeText(context, "Up to 4 images per message.", android.widget.Toast.LENGTH_SHORT).show() }
        .onFailure { android.widget.Toast.makeText(context, it.message ?: "Could not read the image. Try a PNG or JPEG.", android.widget.Toast.LENGTH_LONG).show() }
    }
  }

  /** v1.6: attach a project file picked from the "@" list, inside the token budget. */
  fun attachMention(rel: String) {
    val root = activeProject?.rootDir ?: return
    inputText = com.example.chat.Mentions.removeTrailing(inputText)
    scope.launch {
      val f = withContext(Dispatchers.IO) { com.example.agent.ProjectFiles.resolve(root, rel) }
      if (f == null || !f.isFile) {
        android.widget.Toast.makeText(context, "$rel cannot be attached (outside the project or hidden).", android.widget.Toast.LENGTH_LONG).show()
        return@launch
      }
      val text = withContext(Dispatchers.IO) { runCatching { f.readText() }.getOrNull() }
      if (text == null || text.contains('\u0000')) {
        android.widget.Toast.makeText(context, "$rel looks like a binary file, so it was not attached.", android.widget.Toast.LENGTH_LONG).show()
        return@launch
      }
      when (val c = com.example.chat.Mentions.check(mentionFiles, rel, text.length, settings.contextLength)) {
        is com.example.chat.Mentions.Check.Reject -> { android.widget.Toast.makeText(context, c.message, android.widget.Toast.LENGTH_LONG).show(); return@launch }
        is com.example.chat.Mentions.Check.Warn -> android.widget.Toast.makeText(context, c.message, android.widget.Toast.LENGTH_LONG).show()
        com.example.chat.Mentions.Check.Ok -> {}
      }
      val cut = text.length > com.example.chat.Mentions.MAX_FILE_CHARS
      val sent = if (cut) text.take(com.example.chat.Mentions.MAX_FILE_CHARS) + "\n[truncated]" else text
      mentionText[rel] = sent
      mentionFiles = mentionFiles + com.example.transparency.AttachedFile(rel, f.length(), sent.length, cut)
    }
  }

  val filePicker = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.OpenDocument()
  ) { uri: android.net.Uri? ->
    if (uri != null) {
      scope.launch {
        val loaded = withContext(Dispatchers.IO) {
          runCatching {
            var name = "file"
            context.contentResolver.query(uri, null, null, null, null)?.use { c ->
              val i = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
              if (c.moveToFirst() && i >= 0) name = c.getString(i) ?: name
            }
            val bytes = context.contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: ByteArray(0)
            val text = String(bytes, Charsets.UTF_8)
            if (text.contains('\u0000')) error("This looks like a binary file.")
            val clipped = if (text.length > MAX_ATTACH_CHARS) text.take(MAX_ATTACH_CHARS) + "\n[truncated]" else text
            name to clipped
          }
        }
        loaded
          .onSuccess { attachment = it }
          .onFailure { android.widget.Toast.makeText(context, it.message ?: "Could not read the file", android.widget.Toast.LENGTH_SHORT).show() }
      }
    }
  }

  val voiceLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
    androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
  ) { result ->
    val spoken = result.data
      ?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
      ?.firstOrNull()
    if (!spoken.isNullOrBlank()) inputText = if (inputText.isBlank()) spoken else "$inputText $spoken"
  }

  fun startVoice() {
    val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(android.speech.RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
      putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Describe your app")
    }
    try {
      voiceLauncher.launch(intent)
    } catch (e: android.content.ActivityNotFoundException) {
      android.widget.Toast.makeText(context, "No speech recognizer is installed on this phone.", android.widget.Toast.LENGTH_LONG).show()
    }
  }

  /** v1.6.1: voice mode. A remote host's one-time notice is shown first, so it never pops up mid-loop. */
  fun openVoice() {
    val dest = com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl)
    if (dest.isRemote && !settingsStore.isRemoteNoticeAcked(dest.remoteHost!!)) voiceNoticeHost = dest.remoteHost
    else voiceOpen = true
  }

  /**
   * v1.6: sends [raw] with every attachment. Remote hosts get a one-time notice first; images that the
   * selected model cannot read are never sent silently (the user chooses: send without them, or cancel).
   */
  fun submit(raw: String, skipChecks: Boolean = false, dropImages: Boolean = false) {
    val text = raw.trim()
    if (text.isEmpty() || isGenerating) return
    val dest = com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl)
    if (!skipChecks && images.isNotEmpty() && !dropImages) {
      val v = com.example.chat.VisionSupport.check(settings.backendMode, settings.remoteModel)
      if (v is com.example.chat.VisionSupport.Verdict.No) { imageBlocked = text to v.reason; return }
    }
    if (!skipChecks && dest.isRemote && !settingsStore.isRemoteNoticeAcked(dest.remoteHost!!)) {
      remoteNoticeFor = text to dropImages
      return
    }
    val file = attachment
    val files = mentionFiles
    val sentFiles = files.associateWith { mentionText[it.path].orEmpty() }
    val sendImages = if (dropImages) emptyList() else images
    inputText = ""
    attachment = null
    mentionFiles = emptyList()
    mentionText.clear()
    images = emptyList()
    scope.launch {
      val wantsBuild = com.example.agent.Intent.classify(text) == com.example.agent.Intent.Mode.BUILD
      val builder = settings.agentRole == "builder"
      val project = if (activeProject == null || (builder && wantsBuild && !orchestrator.useActiveProject)) {
        withContext(Dispatchers.IO) { projectManager.createBlankWebProject(text) }
      } else activeProject
      if (wantsBuild) orchestrator.useActiveProject = true
      val blocks = buildList {
        file?.let { add("Attached file ${it.first}:\n```\n${it.second}\n```") }
        sentFiles.forEach { (f, body) -> add(com.example.chat.Mentions.block(f.path, body)) }
      }
      val allFiles = sentFiles.keys.toList() + listOfNotNull(file?.let { com.example.transparency.AttachedFile(it.first, it.second.toByteArray().size.toLong(), it.second.length) })
      val atts = com.example.chat.RunAttachments(allFiles, sendImages)
      if (blocks.isEmpty()) {
        orchestrator.sendMessage(text, project, settings, attachments = atts)
      } else {
        val modelText = blocks.joinToString("\n\n") + "\n\n" + text
        val shown = text + (file?.let { "\n[Attached: ${it.first}]" } ?: "")
        orchestrator.sendMessage(modelText, project, settings, displayText = shown, attachments = atts)
      }
    }
  }

  remoteNoticeFor?.let { (pending, dropped) ->
    val host = com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl).remoteHost ?: "the server"
    RemoteNoticeDialog(
      host = host,
      onContinue = {
        settingsStore.ackRemoteNotice(host)
        remoteNoticeFor = null
        submit(pending, skipChecks = true, dropImages = dropped)
      },
      onCancel = { remoteNoticeFor = null }
    )
  }
  imageBlocked?.let { (pending, reason) ->
    com.example.ui.components.GlassAlertDialog(
      onDismissRequest = { imageBlocked = null },
      title = { Text("Image not sent") },
      text = { Text(reason) },
      confirmButton = {
        TextButton(onClick = { imageBlocked = null; submit(pending, skipChecks = false, dropImages = true) }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Send text only") }
      },
      dismissButton = { TextButton(onClick = { imageBlocked = null }, modifier = Modifier.heightIn(min = 48.dp)) { Text("Cancel") } }
    )
  }
  shownContext?.let { ContextSheet(it) { shownContext = null } }
  voiceNoticeHost?.let { host ->
    RemoteNoticeDialog(
      host = host,
      onContinue = { settingsStore.ackRemoteNotice(host); voiceNoticeHost = null; voiceOpen = true },
      onCancel = { voiceNoticeHost = null }
    )
  }
  if (voiceOpen) {
    val approvalPending by orchestrator.approvals.pending.collectAsState()
    val inputPending by orchestrator.inputs.pending.collectAsState()
    VoiceModeScreen(
      settings = settings,
      isGenerating = isGenerating,
      // Approvals and agent input questions stay with the user; voice mode only waits for them.
      needsUser = approvalPending != null || inputPending != null || pendingPatch != null,
      latestReply = {
        orchestrator.messages.value.lastOrNull { it.sender == MessageSender.AGENT && it.thoughts != "note" }?.content
      },
      onSend = { text -> if (isGenerating) false else { submit(text); true } },
      onStopGeneration = { orchestrator.stop() },
      onSettingsChange = onSettingsChange,
      onEnd = { voiceOpen = false }
    )
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .padding(bottom = bottomInset)
      .imePadding()
  ) {
    val subtitle = when {
      isGenerating && telemetry.outputTokens == 0 -> "Reading prompt · ${telemetry.promptLabel}"
      isGenerating -> "Writing · ${"%.1f".format(telemetry.tokensPerSecond)} tok/s"
      else -> com.example.chat.ChatOptionsLabels.headerLine(settings.backendMode == "remote", com.example.agent.AgentRoles.from(settings.agentRole).name, level.label, settings.thinking)
    }
    var menuOpen by remember { mutableStateOf(false) }
    if (optionsOpen) {
      val m = settings.remoteModel.trim()
      ChatOptionsSheet(
        settings = settings,
        modelLabel = when {
          settings.backendMode != "remote" -> modelName?.takeIf { it.isNotBlank() } ?: "On-device"
          m.isBlank() -> "Auto"
          else -> com.example.ui.components.friendlyModelName(m).ifBlank { m.substringAfterLast('/') }
        },
        onSettingsChange = onSettingsChange,
        onOpenModelPicker = { modelPickerOpen = true },
        onOpenVoice = { openVoice() },
        onDismiss = { optionsOpen = false }
      )
    }
    if (modelPickerOpen) {
      ModelPickerSheet(
        settings = settings,
        onPick = { id -> onSettingsChange(settings.copy(remoteModel = id)) },
        onDismiss = { modelPickerOpen = false }
      )
    }
    Row(
      modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      GlassIconButton(Icons.Default.History, "History", onOpenHistory)
      Column(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
        Text(
          activeProject?.name ?: "VibeCoder",
          color = TextPrimary, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
          maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
        // Always visible: which model answers and how much context it gets.
        val modelText = modelName?.takeIf { it.isNotBlank() } ?: "No model"
        // v1.6.2: remote models show their real context window (from /models), not the phone's setting.
        val windows by com.example.llama.RemoteClient.contextWindows.collectAsState()
        val remote = settings.backendMode == "remote"
        LaunchedEffect(remote, settings.remoteUrl, settings.remoteModel) {
          if (remote) withContext(Dispatchers.IO) { com.example.llama.RemoteClient.ensureContext(settings.remoteUrl, settings.remoteKey, settings.remoteModel) }
        }
        val serverCtx = windows[settings.remoteModel]
        val ctxLabel = if (!remote) "${settings.contextLength} ctx"
          else com.example.agent.RemoteContext.resolve(serverCtx).let { c ->
            (if (c >= 1024 && c % 1024 == 0) "${c / 1024}K" else "$c") + " ctx" + (if (serverCtx == null) " (default)" else "")
          }
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { modelPickerOpen = true }
        ) {
          Box(
            Modifier
              .size(6.dp)
              .clip(CircleShape)
              .background(if (modelText == "No model") TextMuted else com.example.ui.theme.CyberGreenSuccess)
          )
          Spacer(Modifier.width(5.dp))
          Text(
            "$modelText ▾ · $ctxLabel",
            color = if (modelText == "No model") TextMuted else CyberCyanPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
          )
        }
        Text(
          subtitle, color = TextMuted, fontSize = 11.5.sp,
          fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, maxLines = 1,
          overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
        )
      }
      if (canPreview) {
        Box(
          modifier = Modifier
            .clip(CircleShape)
            .background(CyberCyanPrimary)
            .clickable { onPreview() }
            .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
            .padding(horizontal = 16.dp, vertical = 9.dp),
          contentAlignment = Alignment.Center
        ) { Text("Preview", color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
      }
      if (messages.size > 1 && !isGenerating) {
        GlassIconButton(Icons.Default.Edit, "New chat") { orchestrator.newChat() }
      }
      Box {
        GlassIconButton(Icons.Default.MoreVert, "More") { menuOpen = true }
        if (menuOpen) GlassMenu(
          entries = listOf(MenuEntry("Build and APK", "Build, sign and install your app", false) { onOpenBuild() }),
          above = false, alignEnd = true, onDismiss = { menuOpen = false }
        )
      }
    }

    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(18.dp),
      contentPadding = PaddingValues(vertical = 8.dp)
    ) {
      // Only the newest progress note shimmers, and only while the agent is still working on it.
      val liveNoteId = if (isGenerating) chat.lastOrNull()?.takeIf { it.sender == MessageSender.AGENT && it.thoughts == "note" }?.id else null
      items(chat, key = { it.id }, contentType = { it.sender }) { message ->
        Box {
        MessageItem(
          message = message,
          telemetry = telemetry,
          canPreview = canPreview && message.id == lastFileMsgId,
          onApply = { if (activeProject != null) orchestrator.applyChanges(message.id, activeProject) },
          onDiscard = { orchestrator.discardChanges(message.id) },
          onPreview = onPreview,
          isLast = message.id == chat.lastOrNull()?.id,
          isBusy = isGenerating,
          liveNote = message.id == liveNoteId,
          canUndo = orchestrator.canUndo(message.id),
          onUndo = { if (activeProject != null) orchestrator.undoChanges(message.id, activeProject) },
          onRegenerate = { orchestrator.regenerate(activeProject, settings) },
          onApplyPatch = { patch ->
            if (activeProject != null) orchestrator.approveAndApplyPatch(patch, activeProject)
          },
          onShowContext = { shownContext = it }
        )
        }
      }
      if (chat.isEmpty() && !isGenerating) {
        item {
          Column(
            modifier = Modifier.fillMaxWidth().padding(top = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            Box(
              modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(com.example.ui.theme.AccentGradient) // v1.6.1: follows the accent
                .semantics { contentDescription = "VibeCoder logo" },
              contentAlignment = Alignment.Center
            ) { Text("</>", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace) }
            Text("What shall we build?", color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold, letterSpacing = (-0.4).sp)
            Text(if (settings.backendMode == "remote") "Using a remote model: messages go to ${com.example.transparency.Destination.of(settings.backendMode, settings.remoteUrl).remoteHost}." else "Runs fully offline on this phone.", color = TextSecondary, fontSize = 14.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight)
            Spacer(Modifier.height(8.dp))
            Text("START FROM A TEMPLATE", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Start).padding(start = 4.dp))
            // v1.2: more breathing room between template cards (12 dp) and suggestion rows (10 dp).
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            com.example.project.Templates.all.chunked(2).forEach { pair ->
              Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                pair.forEach { t ->
                  Column(
                    modifier = Modifier
                      .weight(1f)
                      .liquidGlass(RoundedCornerShape(20.dp), 6.dp)
                      .clickable {
                        scope.launch {
                          withContext(Dispatchers.IO) { projectManager.createFromTemplate(t) }
                          orchestrator.useActiveProject = true
                          orchestrator.addNote("Created the \"${t.name}\" project. Tap Preview to run it, or tell me what to change.")
                        }
                      }
                      .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(2.dp)
                  ) {
                    Text(t.name, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(t.blurb, color = TextSecondary, fontSize = 12.sp, lineHeight = 16.sp, fontWeight = com.example.ui.theme.UiTokens.SecondaryWeight, maxLines = 2)
                  }
                }
                if (pair.size == 1) Spacer(Modifier.weight(1f))
              }
            }
            }
            Spacer(Modifier.height(4.dp))
            Text("OR TRY", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.align(Alignment.Start).padding(start = 4.dp))
            Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            SUGGESTIONS.forEach { sug ->
              Box(
                modifier = Modifier
                  .fillMaxWidth()
                  .liquidGlass(RoundedCornerShape(18.dp), 4.dp)
                  .clickable { submit(sug) }
                  .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
                  .padding(horizontal = 16.dp, vertical = 11.dp),
                contentAlignment = Alignment.CenterStart
              ) { Text(sug, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.Medium) }
            }
            }
          }
        }
      }
    }

    // v1.6: the step list stays after a run (collapsed) until the next message, so nothing the agent did is hidden.
    if (activity.isNotEmpty() && (isGenerating || messages.size > 1)) ActivityFeed(activity, live = isGenerating)

    if (canPreview && !isGenerating && messages.size > 1 && inputText.isEmpty()) {
      Row(
        modifier = Modifier
          .horizontalScroll(androidx.compose.foundation.rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        listOf("Make it responsive", "Add dark mode", "Improve the design", "Fix errors", "Add animations").forEach { q ->
          Box(
            modifier = Modifier
              .clip(CircleShape)
              .background(ObsidianSurfaceVariant)
              .clickable { submit(q) }
              .heightIn(min = 36.dp)
              .padding(horizontal = 14.dp, vertical = 8.dp),
            contentAlignment = Alignment.Center
          ) { Text(q, color = TextSecondary, fontSize = 12.5.sp, fontWeight = FontWeight.Medium) }
        }
      }
    }

    attachment?.let { (name, _) ->
      Row(
        modifier = Modifier
          .padding(horizontal = 16.dp)
          .clip(CircleShape)
          .background(ObsidianSurfaceVariant)
          .padding(start = 12.dp, end = 4.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text(name, color = TextPrimary, fontSize = 12.sp, maxLines = 1)
        IconButton(onClick = { attachment = null }, modifier = Modifier.size(28.dp)) {
          Icon(Icons.Default.Close, contentDescription = "Remove attachment", tint = TextMuted, modifier = Modifier.size(14.dp))
        }
      }
    }

    AttachmentChips(
      files = mentionFiles,
      images = images,
      onRemoveFile = { p -> mentionFiles = mentionFiles.filter { it.path != p }; mentionText.remove(p) },
      onRemoveImage = { p -> images = images.filter { it.localPath != p } },
      modifier = Modifier.padding(horizontal = 16.dp, vertical = 2.dp)
    )
    val mentionQuery = com.example.chat.Mentions.trailingQuery(inputText)
    if (mentionQuery != null) {
      val root = activeProject?.rootDir
      val candidates by androidx.compose.runtime.produceState(emptyList<String>(), mentionQuery, root) {
        value = if (root == null) emptyList() else withContext(Dispatchers.IO) { com.example.chat.Mentions.candidates(root, mentionQuery) }
      }
      if (root == null) {
        Text("Open or create a project to attach its files with @.", color = TextMuted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp))
      } else MentionPicker(mentionQuery, candidates, onPick = { attachMention(it) })
    }
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(start = 14.dp, end = 14.dp, top = 8.dp, bottom = 10.dp)
        .liquidGlass(RoundedCornerShape(26.dp), 8.dp)
        .padding(start = 18.dp, end = 10.dp, top = 14.dp, bottom = 8.dp)
    ) {
      Box(modifier = Modifier.fillMaxWidth().padding(end = 8.dp, bottom = 12.dp)) {
        if (inputText.isEmpty()) Text("Message · @ to attach a file", color = TextMuted, fontSize = 16.sp)
        androidx.compose.foundation.text.BasicTextField(
          value = inputText,
          onValueChange = { inputText = it },
          textStyle = androidx.compose.ui.text.TextStyle(color = TextPrimary, fontSize = 16.sp, lineHeight = 22.sp),
          cursorBrush = androidx.compose.ui.graphics.SolidColor(CyberCyanPrimary),
          maxLines = 6,
          modifier = Modifier.fillMaxWidth()
        )
      }
      Row(
        modifier = Modifier.fillMaxWidth().padding(start = 0.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp) // 48 dp targets with 36 dp visuals, so icons still sit ~16 dp apart
      ) {
        Box(
          modifier = Modifier
            .size(com.example.ui.theme.UiTokens.MinTouchTarget)
            .clip(CircleShape)
            .clickable { filePicker.launch(arrayOf("*/*")) },
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier.size(36.dp).clip(CircleShape).background(ObsidianSurfaceVariant),
            contentAlignment = Alignment.Center
          ) { Icon(Icons.Default.Add, contentDescription = "Attach a text or code file", tint = TextSecondary, modifier = Modifier.size(20.dp)) }
        }
        // v1.6: screenshot / photo (Photo Picker, no storage permission). Sent only to vision models.
        Box(
          modifier = Modifier
            .size(com.example.ui.theme.UiTokens.MinTouchTarget)
            .clip(CircleShape)
            .clickable(onClickLabel = "Attach an image") {
              imagePicker.launch(androidx.activity.result.PickVisualMediaRequest(androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly))
            },
          contentAlignment = Alignment.Center
        ) {
          Box(
            modifier = Modifier.size(36.dp).clip(CircleShape).background(ObsidianSurfaceVariant),
            contentAlignment = Alignment.Center
          ) { Icon(androidx.compose.material.icons.Icons.Default.Image, contentDescription = "Attach an image", tint = TextSecondary, modifier = Modifier.size(20.dp)) }
        }

        // v1.6.1: agent, Think, output size and model live in one chip + sheet (model also in the header).
        val roleName = com.example.agent.AgentRoles.from(settings.agentRole).name
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
          OptionsChip(
            label = com.example.chat.ChatOptionsLabels.chip(roleName, level.label),
            thinking = settings.thinking,
            engaged = optionsOpen
          ) { optionsOpen = true }
        }
        val showMic = !isGenerating && inputText.isBlank()
        // Tap mic = dictate into the box (system recognizer). Long-press mic = hands-free voice mode.
        val fill by androidx.compose.animation.animateColorAsState(
          if (showMic) ObsidianSurfaceVariant else CyberCyanPrimary, tween(160), label = "sendFill"
        )
        Box(
          modifier = Modifier
            .size(com.example.ui.theme.UiTokens.MinTouchTarget)
            .clip(CircleShape)
            .background(fill)
            .combinedClickable(
              onClickLabel = when { isGenerating -> "Stop"; showMic -> "Dictate a message"; else -> "Send" },
              onLongClickLabel = if (showMic) "Start voice mode" else null,
              onLongClick = if (showMic) ({ openVoice() }) else null
            ) { if (isGenerating) orchestrator.stop() else if (showMic) startVoice() else submit(inputText) },
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = when {
              isGenerating -> Icons.Default.Stop
              showMic -> Icons.Default.Mic
              else -> Icons.AutoMirrored.Filled.Send
            },
            contentDescription = when {
              isGenerating -> "Stop"
              showMic -> "Voice input. Long-press for voice mode"
              else -> "Send"
            },
            tint = if (showMic) CyberCyanPrimary else Color.White
          )
        }
      }
    }
  }
}

/**
 * v1.6.1: the one composer chip for chat options. Shows "Agent · Size" and a small accent dot while Think
 * is on; opens [ChatOptionsSheet]. 48 dp touch target, label ellipsizes on narrow phones.
 */
@Composable
private fun OptionsChip(label: String, thinking: Boolean, engaged: Boolean, onClick: () -> Unit) {
  val fill by androidx.compose.animation.animateColorAsState(
    if (engaged) CyberCyanPrimary.copy(alpha = 0.28f) else CyberCyanPrimary.copy(alpha = 0.14f),
    tween(180, easing = androidx.compose.animation.core.LinearOutSlowInEasing), label = "optChip"
  )
  val dot by animateFloatAsState(if (thinking) 1f else 0f, tween(180, easing = androidx.compose.animation.core.LinearOutSlowInEasing), label = "thinkDot")
  Box(
    modifier = Modifier
      .heightIn(min = com.example.ui.theme.UiTokens.MinTouchTarget)
      .clip(CircleShape)
      .clickable(onClickLabel = "Open chat options", onClick = onClick)
      .semantics { contentDescription = "Chat options: $label" + if (thinking) ", Think on" else "" },
    contentAlignment = Alignment.Center
  ) {
    Row(
      modifier = Modifier
        .clip(CircleShape)
        .background(fill)
        .border(1.dp, CyberCyanPrimary.copy(alpha = 0.45f), CircleShape)
        .padding(start = 10.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(androidx.compose.material.icons.Icons.Default.Tune, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(16.dp))
      Spacer(Modifier.width(6.dp))
      Text(
        label, color = CyberCyanPrimary, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold,
        maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        modifier = Modifier.weight(1f, fill = false)
      )
      if (dot > 0f) {
        Spacer(Modifier.width((6f * dot).dp))
        Box(Modifier.size((6f * dot).dp).clip(CircleShape).background(CyberCyanPrimary))
      }
    }
  }
}

@Composable
private fun GlassIconButton(icon: androidx.compose.ui.graphics.vector.ImageVector, description: String, onClick: () -> Unit) {
  val haptics = rememberHaptics()
  Box(
    modifier = Modifier
      .size(com.example.ui.theme.UiTokens.MinTouchTarget)
      .liquidGlass(CircleShape, 4.dp)
      .clickable { onClick() },
    contentAlignment = Alignment.Center
  ) { Icon(icon, contentDescription = description, tint = TextPrimary, modifier = Modifier.size(20.dp)) }
}

private const val MAX_ATTACH_CHARS = 6000

@Composable
private fun MessageItem(
  message: ChatMessage,
  telemetry: TelemetryData,
  canPreview: Boolean,
  onApply: () -> Unit,
  onDiscard: () -> Unit,
  onPreview: () -> Unit,
  isLast: Boolean,
  isBusy: Boolean,
  canUndo: Boolean,
  onUndo: () -> Unit,
  onRegenerate: () -> Unit,
  onApplyPatch: (com.example.data.model.PatchProposal) -> Unit,
  liveNote: Boolean = false,
  onShowContext: (com.example.transparency.ContextManifest) -> Unit = {}
) {
  when (message.sender) {
    MessageSender.USER -> Column(modifier = Modifier.fillMaxWidth(), horizontalAlignment = Alignment.End, verticalArrangement = Arrangement.spacedBy(4.dp)) {
      if (message.images.isNotEmpty()) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { message.images.forEach { Thumbnail(it, 72) } }
      }
      if (message.attachedFiles.isNotEmpty()) {
        Text(message.attachedFiles.joinToString("  ") { "@$it" }, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace, maxLines = 2, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
      }
      Box(
        modifier = Modifier
          .widthIn(max = 300.dp)
          .clip(RoundedCornerShape(20.dp, 20.dp, 6.dp, 20.dp))
          .background(CyberCyanPrimary)
          .padding(horizontal = 14.dp, vertical = 9.dp)
      ) {
        val long = message.content.length > 400
        var expanded by remember(message.id) { mutableStateOf(false) }
        Column {
          Text(
            if (long && !expanded) message.content.take(400).trimEnd() + "…" else message.content,
            color = Color.White, fontSize = 14.sp, lineHeight = 20.sp
          )
          if (long) {
            Text(
              if (expanded) "Show less" else "Show more",
              color = Color.White.copy(alpha = 0.75f),
              fontSize = 12.sp,
              fontWeight = FontWeight.SemiBold,
              modifier = Modifier
                .padding(top = 4.dp)
                .clickable { expanded = !expanded }
            )
          }
        }
      }
      DestinationBadge(message.destination)
    }

    MessageSender.AGENT -> if (message.thoughts == "note") {
      Column {
        NoteLine(message.content, live = liveNote)
        message.context?.let { ctx -> Row(Modifier.padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) { ContextChip(ctx) { onShowContext(ctx) }; Spacer(Modifier.width(6.dp)); DestinationBadge(ctx.destination) } }
      }
    } else Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
      val thinkingLive = message.isStreaming && message.content.isBlank() && !message.reasoning.isNullOrBlank()
      message.reasoning?.takeIf { it.isNotBlank() }?.let { ThinkingBox(it, message.isStreaming && message.content.isBlank()) }
      val hasFiles = message.fileChanges.isNotEmpty()
      val full = remember(message.content, hasFiles) {
        val t = FileBlocks.displayText(message.content)
        if (hasFiles) FILE_CHIP.replace(t, "").trim() else t
      }
      // Trailing "[Stopped...]" / "[Error...]" markers become a small caption instead of looking like model text.
      val tagStart = remember(full) {
        val i = full.lastIndexOf("[")
        if (i >= 0 && full.trimEnd().endsWith("]") && (full.startsWith("[", i) && (full.substring(i).startsWith("[Stopped") || full.substring(i).startsWith("[Error") || full.substring(i).startsWith("[The model") || full.substring(i).startsWith("[No progress")))) i else -1
      }
      val shown = if (tagStart >= 0) full.substring(0, tagStart).trimEnd() else full
      val tag = if (tagStart >= 0) full.substring(tagStart).trim().removePrefix("[").removeSuffix("]") else null
      if (shown.isNotEmpty()) {
        Box(
          modifier = Modifier
            .fillMaxWidth(0.94f)
            .clip(RoundedCornerShape(20.dp, 20.dp, 20.dp, 6.dp))
            .background(ObsidianSurfaceVariant.copy(alpha = 0.85f))
            .padding(horizontal = 14.dp, vertical = 11.dp)
        ) { MarkdownText(shown) }
      }
      if (tag != null) {
        val isErr = tag.startsWith("Error") || tag.startsWith("No progress")
        Row(
          modifier = Modifier
            .clip(CircleShape)
            .background((if (isErr) com.example.ui.theme.CyberCoralError else TextMuted).copy(alpha = 0.14f))
            .padding(horizontal = 10.dp, vertical = 5.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Text(tag, color = if (isErr) com.example.ui.theme.CyberCoralError else TextSecondary, fontSize = 12.sp, lineHeight = 16.sp)
        }
      }
      if (message.isStreaming) StatusLine(telemetry, shimmer = !thinkingLive)
      if (!message.isStreaming && (shown.isNotEmpty() || canUndo)) {
        val clipboard = androidx.compose.ui.platform.LocalClipboardManager.current
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), modifier = Modifier.padding(start = 6.dp)) {
          if (shown.isNotEmpty()) Text("Copy", fontSize = 12.sp, color = TextMuted, modifier = Modifier.clickable { clipboard.setText(androidx.compose.ui.text.AnnotatedString(message.content)) }.padding(vertical = 4.dp))
          if (isLast && !isBusy && shown.isNotEmpty()) {
            Text("Regenerate", fontSize = 12.sp, color = TextMuted, modifier = Modifier.clickable { onRegenerate() }.padding(vertical = 4.dp))
          }
          if (canUndo) {
            Text("Undo changes", fontSize = 12.sp, color = CyberCyanPrimary, modifier = Modifier.clickable { onUndo() }.padding(vertical = 4.dp))
          }
        }
      }
      // v1.6: where the data went and what the model saw, under every reply.
      if (!message.isStreaming || message.context != null) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(start = 4.dp)) {
          message.context?.let { ctx -> ContextChip(ctx) { onShowContext(ctx) }; Spacer(Modifier.width(6.dp)) }
          DestinationBadge(message.destination)
        }
      }
      if (message.fileChanges.isNotEmpty()) {
        FileChangesCard(
          changes = message.fileChanges,
          canPreview = canPreview,
          onApply = onApply,
          onDiscard = onDiscard,
          onPreview = onPreview
        )
      }
      message.patchProposal?.let { patch ->
        Text(patch.relativePath, color = TextSecondary, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
        DiffViewer(diffLines = patch.diffLines)
        if (!patch.isApplied) {
          Button(
            onClick = { onApplyPatch(patch) },
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyanPrimary, contentColor = Color.White)
          ) { Text("Apply patch", fontSize = 13.sp) }
        }
      }
    }

    else -> {
      val label = message.toolCall?.let { "${it.toolName} · ${it.status}" } ?: message.content
      Text(label, color = TextMuted, fontSize = 12.sp, fontFamily = FontFamily.Monospace)
    }
  }
}

@Composable
private fun StatusLine(t: TelemetryData, shimmer: Boolean = true) {
  val text = if (t.outputTokens == 0) {
    "Reading prompt · ${t.promptLabel}"
  } else {
    "Writing · ${"%.1f".format(t.tokensPerSecond)} tok/s"
  }
  Row(verticalAlignment = Alignment.CenterVertically) {
    com.example.ui.components.SparkleSpinner(size = 12.dp)
    Spacer(modifier = Modifier.width(8.dp))
    // Crossfade only when the phase changes (reading -> writing), not on every token count update.
    com.example.ui.components.StatusCrossfade(text, contentKey = { it.substringBefore(" ·") }) { s ->
      com.example.ui.components.ShimmerText(s, active = shimmer, color = TextMuted, fontSize = 12.sp, maxLines = 1)
    }
  }
}

/** Rounded glass popup above the level pill: springs in from the pill, fades out when closed. */
private data class MenuEntry(val title: String, val blurb: String?, val selected: Boolean, val onClick: () -> Unit)

/**
 * Curved glass popup (v1.2.1: frosted liquid glass with real backdrop blur where available).
 * Same look and motion for level, role and "more" menus. Every close path plays the exit animation;
 * [onDismiss] runs only once it has finished.
 */
@Composable
private fun GlassMenu(entries: List<MenuEntry>, above: Boolean, alignEnd: Boolean, onDismiss: () -> Unit) {
  var open by remember { mutableStateOf(true) }
  com.example.ui.components.GlassPopup(
    expanded = open,
    onDismissRequest = { open = false },
    onClosed = onDismiss,
    above = above,
    alignEnd = alignEnd,
    modifier = Modifier.width(288.dp)
  ) {
    entries.forEach { e ->
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .clip(RoundedCornerShape(18.dp))
          .background(if (e.selected) CyberCyanPrimary.copy(alpha = 0.14f) else Color.Transparent)
          .clickable(enabled = open) {
            e.onClick()
            open = false
          }
          .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column(Modifier.weight(1f)) {
          Text(e.title, color = if (e.selected) CyberCyanPrimary else TextPrimary, fontSize = 16.sp, lineHeight = 20.sp, fontWeight = if (e.selected) FontWeight.SemiBold else FontWeight.Medium)
          if (e.blurb != null) {
            Spacer(Modifier.height(2.dp))
            Text(e.blurb, color = TextMuted, fontSize = 12.5.sp, lineHeight = 16.sp)
          }
        }
        if (e.selected) {
          Spacer(Modifier.width(10.dp))
          Icon(androidx.compose.material.icons.Icons.Default.Check, contentDescription = null, tint = CyberCyanPrimary, modifier = Modifier.size(18.dp))
        }
      }
    }
  }
}

/** Progress notes from the agent (plan, steps, test results): quiet status text, not a chat bubble. */
@Composable
private fun NoteLine(text: String, live: Boolean = false) {
  Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.Top) {
    if (live) {
      com.example.ui.components.SparkleSpinner(
        size = 12.dp,
        modifier = Modifier.padding(top = 3.dp, end = 7.dp)
      )
    } else {
      Box(
        modifier = Modifier
          .padding(top = 7.dp, end = 10.dp)
          .size(5.dp)
          .clip(CircleShape)
          .background(TextMuted.copy(alpha = 0.7f))
      )
    }
    com.example.ui.components.StatusCrossfade(text) { s ->
      com.example.ui.components.ShimmerText(s, active = live, color = TextMuted, fontSize = 12.5.sp, lineHeight = 18.sp)
    }
  }
}


/** Collapsible model reasoning (<think> text). Open while the model is still thinking. */
@Composable
private fun ThinkingBox(text: String, streaming: Boolean) {
  var open by remember { mutableStateOf(false) }
  val show = open || streaming
  Column(
    modifier = Modifier
      .fillMaxWidth(0.94f)
      .clip(RoundedCornerShape(16.dp))
      .background(ObsidianSurfaceVariant.copy(alpha = 0.5f))
      .clickable { open = !open }
      .padding(horizontal = 12.dp, vertical = 8.dp)
      .animateContentSize()
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      if (streaming) {
        com.example.ui.components.SparkleSpinner(size = 12.dp)
        Spacer(Modifier.width(7.dp))
      }
      com.example.ui.components.StatusCrossfade(streaming, modifier = Modifier.weight(1f)) { live ->
        com.example.ui.components.ShimmerText(
          if (live) "Thinking…" else "Thought process", active = live,
          color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Medium
        )
      }
      Text(if (show) "Hide" else "Show", color = TextMuted, fontSize = 12.sp)
    }
    if (show) Text(text, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp, modifier = Modifier.padding(top = 6.dp))
  }
}

/**
 * v1.6 live step list: every step (tool calls with full command text and exit codes, requests sent) is
 * listed. While running the newest step shimmers; afterwards it stays collapsed until the next message.
 */
@Composable
private fun ActivityFeed(lines: List<String>, live: Boolean) {
  var open by remember { mutableStateOf(false) }
  val reduced = rememberReducedMotion()
  Column(
    modifier = Modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 4.dp)
      .liquidGlass(RoundedCornerShape(18.dp), 4.dp)
      .clickable(onClickLabel = if (open) "Hide steps" else "Show all steps") { open = !open }
      .heightIn(min = 48.dp)
      .padding(horizontal = 14.dp, vertical = 9.dp)
      .then(if (reduced) Modifier else Modifier.animateContentSize(androidx.compose.animation.core.tween(200, easing = androidx.compose.animation.core.FastOutSlowInEasing)))
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      if (live) {
        com.example.ui.components.SparkleSpinner(size = 13.dp)
        Spacer(Modifier.width(9.dp))
      }
      if (live) {
        com.example.ui.components.StatusCrossfade(lines.last(), modifier = Modifier.weight(1f)) { s ->
          com.example.ui.components.ShimmerText(
            s, active = !reduced, color = TextSecondary, fontSize = 13.sp, maxLines = 2,
            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
          )
        }
      } else {
        Text("Last run · ${lines.size} steps", color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
      }
      Text(if (open) "Hide" else "${lines.size} steps", color = TextMuted, fontSize = 12.sp)
    }
    if (open) {
      Column(
        modifier = Modifier.padding(top = 8.dp).heightIn(max = 260.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(4.dp)
      ) {
        lines.forEachIndexed { i, it ->
          val running = live && i == lines.lastIndex
          Text(
            (if (running) "… " else "✓ ") + it,
            color = if (it.startsWith("exit ") && !it.startsWith("exit 0")) com.example.ui.theme.CyberCoralError else TextMuted,
            fontSize = 12.sp,
            lineHeight = 16.sp,
            fontFamily = if (it.contains("$ ") || it.startsWith("exit ")) FontFamily.Monospace else null
          )
        }
      }
    }
  }
}

private val FILE_CHIP = Regex("""\n?\[\[file:[^\]]*\]\]\n?""")
