package com.example.chat

import com.example.transparency.AttachedFile
import com.example.transparency.Tokens
import java.io.File

/** v1.6: an image ready to send: downscaled JPEG as a data URL, plus a small file kept for the thumbnail. */
data class ImagePayload(
  val name: String,
  val width: Int,
  val height: Int,
  val bytes: Long,
  val dataUrl: String,
  val localPath: String
)

/** What the composer attaches to one send: @mentioned / picked files and images. */
data class RunAttachments(
  val files: List<AttachedFile> = emptyList(),
  val images: List<ImagePayload> = emptyList()
) {
  val isEmpty: Boolean get() = files.isEmpty() && images.isEmpty()
}

/**
 * v1.6 @mentions. Pure rules, unit tested: which "@query" is being typed, and whether attached files fit
 * the token budget.
 */
object Mentions {
  /** Per-file cap: bigger files are cut to this many characters (~6k tokens) and marked truncated. */
  const val MAX_FILE_CHARS = 24_000
  /** Ceiling of the whole @file budget whatever the context size. */
  const val MAX_TOTAL_TOKENS = 8_000

  /**
   * The query after a trailing "@" being typed at the end of [text] ("fix @ap" -> "ap"), or null when the
   * user is not typing a mention. "@" must start the text or follow whitespace (so e-mail addresses do not trigger).
   */
  fun trailingQuery(text: String): String? {
    val at = text.lastIndexOf('@')
    if (at < 0) return null
    if (at > 0 && !text[at - 1].isWhitespace()) return null
    val q = text.substring(at + 1)
    if (q.any { it.isWhitespace() }) return null
    return q
  }

  /** [text] with the trailing "@query" removed (after a file is picked). */
  fun removeTrailing(text: String): String {
    val q = trailingQuery(text) ?: return text
    return text.dropLast(q.length + 1).trimEnd() + if (text.length > q.length + 1) " " else ""
  }

  /** Token budget for @files: half the context window, capped at [MAX_TOTAL_TOKENS], at least 500. */
  fun budgetTokens(contextLength: Int): Int = (contextLength / 2).coerceIn(500, MAX_TOTAL_TOKENS)

  sealed class Check {
    object Ok : Check()
    data class Warn(val message: String) : Check()
    data class Reject(val message: String) : Check()
  }

  /**
   * Can a file of [chars] characters be added to [current]? Files over [MAX_FILE_CHARS] are accepted with
   * a truncation warning; anything that would exceed the budget is rejected with the numbers.
   */
  fun check(current: List<AttachedFile>, path: String, chars: Int, contextLength: Int): Check {
    if (current.any { it.path == path }) return Check.Reject("$path is already attached.")
    val budget = budgetTokens(contextLength)
    val used = current.sumOf { it.tokens }
    val add = Tokens.estimate(minOf(chars, MAX_FILE_CHARS))
    if (used + add > budget) return Check.Reject("$path needs ≈$add tokens but only ≈${(budget - used).coerceAtLeast(0)} of the ≈$budget-token file budget is left. Remove a file or raise the context window.")
    if (chars > MAX_FILE_CHARS) return Check.Warn("$path is large: only the first ${MAX_FILE_CHARS / 1000}k characters are sent.")
    if (used + add > budget * 3 / 4) return Check.Warn("Attached files now use ≈${used + add} of ≈$budget tokens. Answers may get shorter.")
    return Check.Ok
  }

  /** Project files the picker offers for [query]: text files, no dot folders or build output, best match first. */
  fun candidates(root: File, query: String, limit: Int = 30): List<String> {
    if (!root.isDirectory) return emptyList()
    val q = query.lowercase()
    val all = root.walkTopDown()
      .onEnter { it == root || (!it.name.startsWith(".") && it.name !in setOf("build", "node_modules")) }
      .filter { it.isFile && !it.name.startsWith(".") && it.length() < 2_000_000 }
      .map { it.relativeTo(root).invariantSeparatorsPath }
      .take(2000)
      .toList()
    return rank(all, q).take(limit)
  }

  /** Name-prefix matches first, then name contains, then path contains; shorter paths first. */
  fun rank(paths: List<String>, q: String): List<String> {
    if (q.isEmpty()) return paths.sortedBy { it.length }
    fun score(p: String): Int {
      val name = p.substringAfterLast('/').lowercase()
      return when {
        name.startsWith(q) -> 0
        name.contains(q) -> 1
        p.lowercase().contains(q) -> 2
        else -> 9
      }
    }
    return paths.map { it to score(it) }.filter { it.second < 9 }.sortedWith(compareBy({ it.second }, { it.first.length })).map { it.first }
  }

  /** The text block the model receives for one file. */
  fun block(path: String, text: String): String = "File $path:\n```\n$text\n```"
}

/** v1.6 image sizing (pure, unit tested). */
object ImageSizing {
  const val MAX_SIDE = 1568

  /** Target size that keeps the aspect ratio with the longer side at most [max]. Never upscales. */
  fun fit(w: Int, h: Int, max: Int = MAX_SIDE): Pair<Int, Int> {
    if (w <= 0 || h <= 0) return 0 to 0
    val longest = maxOf(w, h)
    if (longest <= max) return w to h
    val scale = max.toDouble() / longest
    return maxOf(1, Math.round(w * scale).toInt()) to maxOf(1, Math.round(h * scale).toInt())
  }

  /** Largest power-of-two BitmapFactory sample size that still decodes at least the target size. */
  fun sampleSize(w: Int, h: Int, max: Int = MAX_SIDE): Int {
    var s = 1
    while (maxOf(w, h) / (s * 2) >= max) s *= 2
    return s
  }
}

/**
 * v1.6: can this model take images? Remote OpenAI-compatible only, judged by well-known vision model names.
 * Local GGUF models in this app are text-only (no mmproj support), so they never get images.
 */
object VisionSupport {
  private val VISION = Regex(
    "gpt-4o|gpt-4\\.1|gpt-4-turbo|gpt-4-vision|gpt-5|\\bo[134](-mini|-pro|\\b)|chatgpt-4o|vision|-vl|vl-|\\bvl\\b|llava|bakllava|pixtral|gemini|claude-3|claude-(sonnet|opus|haiku)-4|" +
      "gemma-?3|gemma-?4|minicpm-v|moondream|llama-?4|llama-3\\.2-(11|90)b|qwen2\\.5-vl|qwen-vl|qvq|internvl|phi-3\\.5-vision|phi-4-multimodal|grok-(2-)?vision|mistral-small-3\\.[12]|mistral-medium|maverick|scout",
    RegexOption.IGNORE_CASE
  )

  sealed class Verdict {
    object Ok : Verdict()
    data class No(val reason: String) : Verdict()
  }

  fun check(backendMode: String, model: String): Verdict = when {
    backendMode != "remote" -> Verdict.No("On-device models in this app read text only, so the image was not sent. Switch Models to a remote vision model (for example gpt-4o-mini or a Qwen2.5-VL server) to send images.")
    model.isBlank() -> Verdict.No("No model is selected, so the app cannot tell whether the server can read images. Pick a vision model first; the image was not sent.")
    !VISION.containsMatchIn(model) -> Verdict.No("\"$model\" is not a known vision model, so the image was not sent. Pick a vision model (names with vision, -vl, gpt-4o, gemini, llava, pixtral…).")
    else -> Verdict.Ok
  }
}
