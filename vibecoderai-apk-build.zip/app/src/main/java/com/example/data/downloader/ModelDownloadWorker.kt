package com.example.data.downloader

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.ServiceInfo
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.work.CoroutineWorker
import androidx.work.ForegroundInfo
import androidx.work.WorkerParameters
import androidx.work.workDataOf
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

/**
 * v1.4: downloads one GGUF file in the background (WorkManager foreground worker, dataSync type) with
 * HTTP Range resume into "<name>.part". Pausing cancels the work and keeps the partial file; resuming
 * enqueues the same unique work again, which continues from the bytes on disk. Survives app close.
 */
class ModelDownloadWorker(appContext: Context, params: WorkerParameters) : CoroutineWorker(appContext, params) {

  companion object {
    const val KEY_MODEL_ID = "modelId"
    const val KEY_FILE_NAME = "fileName"
    const val KEY_TOTAL = "total"
    const val KEY_DIR = "dir"
    const val KEY_DOWNLOADED = "downloaded"
    const val KEY_ERROR = "error"
    const val CHANNEL_ID = "model_downloads"
    private const val MAX_ATTEMPTS = 3
  }

  private val modelId = inputData.getString(KEY_MODEL_ID).orEmpty()
  private val fileName = inputData.getString(KEY_FILE_NAME).orEmpty()
  private val dir = File(inputData.getString(KEY_DIR).orEmpty())
  private val notificationId = ("$modelId/$fileName").hashCode()

  override suspend fun getForegroundInfo(): ForegroundInfo = foregroundInfo(0L, inputData.getLong(KEY_TOTAL, 0L))

  private fun foregroundInfo(done: Long, total: Long): ForegroundInfo {
    val nm = applicationContext.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
    if (Build.VERSION.SDK_INT >= 26 && nm.getNotificationChannel(CHANNEL_ID) == null) {
      nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Model downloads", NotificationManager.IMPORTANCE_LOW))
    }
    val pct = if (total > 0) ((done * 100) / total).toInt().coerceIn(0, 100) else 0
    val cancel = androidx.work.WorkManager.getInstance(applicationContext).createCancelPendingIntent(id)
    val n = NotificationCompat.Builder(applicationContext, CHANNEL_ID)
      .setSmallIcon(android.R.drawable.stat_sys_download)
      .setContentTitle("Downloading ${fileName.substringAfterLast('/')}")
      .setContentText(if (total > 0) "$pct% · ${done / 1048576} of ${total / 1048576} MB" else "${done / 1048576} MB")
      .setProgress(100, pct, total <= 0)
      .setOngoing(true)
      .setOnlyAlertOnce(true)
      .addAction(android.R.drawable.ic_media_pause, "Pause", cancel)
      .build()
    return if (Build.VERSION.SDK_INT >= 29) ForegroundInfo(notificationId, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
    else ForegroundInfo(notificationId, n)
  }

  private suspend fun tryForeground(done: Long, total: Long) {
    // Android 12+ may refuse to start a foreground service from the background: the download still runs.
    try {
      setForeground(foregroundInfo(done, total))
    } catch (e: CancellationException) {
      throw e
    } catch (_: Throwable) {
    }
  }

  override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
    if (modelId.isEmpty() || fileName.isEmpty()) return@withContext Result.failure(workDataOf(KEY_ERROR to "Missing download parameters."))
    val destName = fileName.substringAfterLast('/')
    val dest = File(dir, destName)
    val part = File(dir, "$destName.part")
    dir.mkdirs()
    var total = inputData.getLong(KEY_TOTAL, 0L)
    var conn: HttpURLConnection? = null
    try {
      tryForeground(if (part.exists()) part.length() else 0L, total)
      var done = if (part.exists()) part.length() else 0L
      if (total > 0 && done >= total) {
        // Finished earlier but not renamed (app killed at the last moment).
        if (dest.exists()) dest.delete()
        if (!part.renameTo(dest)) throw IOException("Could not save the model file.")
        return@withContext Result.success(workDataOf(KEY_DOWNLOADED to total, KEY_TOTAL to total))
      }
      if (total > 0 && dir.usableSpace < total - done + 100L * 1024 * 1024) {
        return@withContext Result.failure(workDataOf(KEY_ERROR to "Not enough free storage."))
      }
      val url = "${HuggingFaceApi.BASE}/$modelId/resolve/main/${fileName.replace(" ", "%20")}"
      conn = (URL(url).openConnection() as HttpURLConnection).apply {
        connectTimeout = 15_000
        readTimeout = 30_000
        setRequestProperty("User-Agent", HuggingFaceApi.USER_AGENT)
        if (done > 0) setRequestProperty("Range", "bytes=$done-")
      }
      val code = conn.responseCode
      if (code == 416 && total > 0 && done >= total) {
        if (!part.renameTo(dest)) throw IOException("Could not save the model file.")
        return@withContext Result.success(workDataOf(KEY_DOWNLOADED to total, KEY_TOTAL to total))
      }
      if (code in 400..499) return@withContext Result.failure(workDataOf(KEY_ERROR to "Download failed: HTTP $code"))
      if (code != 200 && code != 206) throw IOException("Download failed: HTTP $code")
      if (code == 200 && done > 0) {
        // Server ignored the Range header: start over.
        part.delete()
        done = 0L
      }
      if (total <= 0) total = done + conn.contentLengthLong.coerceAtLeast(0L)
      setProgress(workDataOf(KEY_DOWNLOADED to done, KEY_TOTAL to total))

      var lastUi = 0L
      conn.inputStream.use { input ->
        FileOutputStream(part, done > 0).use { out ->
          val buf = ByteArray(256 * 1024)
          while (true) {
            val n = input.read(buf)
            if (n < 0) break
            currentCoroutineContext().ensureActive() // Pause = cancel; the partial file stays for Resume.
            out.write(buf, 0, n)
            done += n
            val now = System.currentTimeMillis()
            if (now - lastUi > 700) {
              lastUi = now
              setProgress(workDataOf(KEY_DOWNLOADED to done, KEY_TOTAL to total))
              tryForeground(done, total)
            }
          }
        }
      }
      if (total > 0 && part.length() < total) throw IOException("Connection closed early.")
      if (dest.exists()) dest.delete()
      if (!part.renameTo(dest)) throw IOException("Could not save the model file.")
      Result.success(workDataOf(KEY_DOWNLOADED to dest.length(), KEY_TOTAL to dest.length()))
    } catch (e: CancellationException) {
      throw e
    } catch (e: IOException) {
      if (runAttemptCount + 1 < MAX_ATTEMPTS) Result.retry()
      else Result.failure(workDataOf(KEY_ERROR to (e.message ?: "Network error"), KEY_DOWNLOADED to (if (part.exists()) part.length() else 0L)))
    } catch (e: Exception) {
      Result.failure(workDataOf(KEY_ERROR to (e.message ?: e.javaClass.simpleName)))
    } finally {
      conn?.disconnect()
    }
  }
}
