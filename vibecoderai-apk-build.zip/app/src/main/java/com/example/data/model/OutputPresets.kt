package com.example.data.model

import kotlin.math.abs

/** v1.5: one-tap sampling presets. [topK] null = the preset leaves Top-K as it is. */
data class SamplingPreset(val id: String, val label: String, val temperature: Float, val topP: Float, val topK: Int? = null)

object OutputPresets {
  val all = listOf(
    SamplingPreset("coding", "Coding", 0.2f, 0.95f, 40),
    SamplingPreset("balanced", "Balanced", 0.6f, 0.9f),
    SamplingPreset("creative", "Creative", 0.8f, 1.0f)
  )

  private fun same(a: Float, b: Float) = abs(a - b) < 0.001f

  /** The preset the current values equal, or null ("Custom"). Checked in list order. */
  fun match(temperature: Float, topP: Float, topK: Int): SamplingPreset? =
    all.firstOrNull { p -> same(p.temperature, temperature) && same(p.topP, topP) && (p.topK == null || p.topK == topK) }

  fun label(s: SettingsState): String = match(s.temperature, s.topP, s.topK)?.label ?: "Custom"

  fun apply(s: SettingsState, p: SamplingPreset): SettingsState =
    s.copy(temperature = p.temperature, topP = p.topP, topK = p.topK ?: s.topK)
}
