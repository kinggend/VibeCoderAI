package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

/** v1.4: chat history and token usage. Version 1 (first Room schema of the app). */
@Database(
  entities = [ChatSessionEntity::class, ChatMessageEntity::class, TokenUsageEntity::class],
  version = 1,
  exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
  abstract fun chatDao(): ChatDao
  abstract fun tokenUsageDao(): TokenUsageDao

  companion object {
    @Volatile private var instance: AppDatabase? = null

    fun get(context: Context): AppDatabase =
      instance ?: synchronized(this) {
        instance ?: Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "vibecoder.db")
          .build()
          .also { instance = it }
      }
  }
}
