package com.example.phone

/** v1.7.0: an installed app the launcher can open. */
data class InstalledApp(val label: String, val pkg: String)

object AppMatcher {
  private val ALIASES = mapOf(
    "yt" to "youtube", "youtube music" to "yt music", "insta" to "instagram", "ig" to "instagram", "wa" to "whatsapp",
    "whats app" to "whatsapp", "fb" to "facebook", "gmaps" to "maps", "google maps" to "maps", "playstore" to "play store",
    "gpay" to "google pay", "cap cut" to "capcut", "x" to "x", "twitter" to "x", "browser" to "chrome", "mail" to "gmail",
    "calculator" to "calculator", "camera" to "camera", "settings" to "settings", "phone" to "phone", "dialer" to "phone",
    "messages" to "messages", "sms" to "messages", "photos" to "photos", "gallery" to "gallery"
  )

  fun normalize(s: String): String = s.lowercase().replace(Regex("[^\\p{L}\\p{N} ]"), " ").replace(Regex("\\s+"), " ").trim()

  private fun squash(s: String) = normalize(s).replace(" ", "")

  fun levenshtein(a: String, b: String): Int {
    val d = IntArray(b.length + 1) { it }
    for (i in 1..a.length) {
      var prev = d[0]; d[0] = i
      for (j in 1..b.length) {
        val t = d[j]
        d[j] = minOf(d[j] + 1, d[j - 1] + 1, prev + if (a[i - 1] == b[j - 1]) 0 else 1)
        prev = t
      }
    }
    return d[b.length]
  }

  /** The installed app [name] means, or null. Exact label first, then alias, prefix, contains, near-spelling. */
  fun match(name: String, apps: List<InstalledApp>): InstalledApp? {
    val q0 = normalize(name)
    if (q0.isEmpty()) return null
    val q = squash(ALIASES[q0] ?: q0)
    var best: InstalledApp? = null
    var bestScore = 0
    for (a in apps) {
      val l = squash(a.label)
      if (l.isEmpty()) continue
      val score = when {
        l == q -> 100
        a.pkg.lowercase().endsWith(".$q") -> 90
        l.startsWith(q) && q.length >= 3 -> 80 - (l.length - q.length).coerceAtMost(20)
        q.length >= 4 && l.contains(q) -> 55
        q.length >= 5 && levenshtein(l, q) <= 2 -> 40
        else -> 0
      }
      if (score > bestScore) { best = a; bestScore = score }
    }
    return best
  }
}

/**
 * v1.7.0: tasks that intents can start faster and more reliably than tapping through the UI.
 * The agent loop takes over after the fast path (for example to tap the first YouTube result).
 */
object FastPaths {
  const val YOUTUBE_PKG = "com.google.android.youtube"

  fun youtubeSearchUrl(query: String): String =
    "https://www.youtube.com/results?search_query=" + java.net.URLEncoder.encode(query.trim(), "UTF-8")

  sealed class Route {
    data class YouTube(val query: String) : Route()
    data class App(val name: String) : Route()
    data class Url(val url: String) : Route()
  }

  // Telugu/Hindi/English verbs that end a task sentence ("play cheyyi", "open karo", "chupinchu").
  private const val TAIL = "(?:\\s+(?:play|search|open|start|chesi|cheyyi|cheyyu|chey|cheyandi|karo|kar|do|pettu|vinipinchu|chupinchu|please|pls))*\\s*$"
  private val YT_LO = Regex("^(?:open\\s+)?(?:youtube|yt)\\s*(?:lo|లో|me|mein|on|in|pe|par)?\\s+(.+?)$TAIL", RegexOption.IGNORE_CASE)
  private val YT_ON = Regex("^(?:play|search)\\s+(.+?)\\s+(?:on|in)\\s+(?:youtube|yt)\\s*$", RegexOption.IGNORE_CASE)
  private val OPEN_FIRST = Regex("^(?:open|launch|start)\\s+([\\p{L}\\p{N} ]{2,30}?)(?:\\s+(?:app|and|chesi|then|lo)\\b.*)?$", RegexOption.IGNORE_CASE)
  private val OPEN_LAST = Regex("^([\\p{L}\\p{N} ]{2,30}?)\\s+(?:app\\s+)?(?:open|launch|start)(?:\\s+(?:cheyyi|cheyyu|chey|cheyandi|karo|kar|chesi)\\b.*)?$", RegexOption.IGNORE_CASE)
  private val APP_LO = Regex("^([\\p{L}\\p{N}]{2,20}(?:\\s[\\p{L}\\p{N}]{2,20})?)\\s+(?:lo|లో|me|mein|pe|par)\\s+.+$", RegexOption.IGNORE_CASE)
  private val URL = Regex("(https?://\\S+|www\\.\\S+)", RegexOption.IGNORE_CASE)

  private fun tidyQuery(q: String): String = q.trim().trimEnd('.', '!', '?').replace(Regex("\\s+"), " ")

  /** The fast path for [task], or null when the agent should start from the current screen. */
  fun route(task: String): Route? {
    val t = task.trim().replace(Regex("\\s+"), " ")
    URL.find(t)?.let { m -> val u = m.value.trimEnd('.', ',', ')'); return Route.Url(if (u.startsWith("www.", true)) "https://$u" else u) }
    YT_ON.find(t)?.let { return Route.YouTube(tidyQuery(it.groupValues[1])) }
    YT_LO.find(t)?.let { m ->
      val q = tidyQuery(m.groupValues[1])
      return if (q.isEmpty() || q.equals("open", true)) Route.App("YouTube") else Route.YouTube(q)
    }
    (OPEN_FIRST.find(t) ?: OPEN_LAST.find(t))?.let { return Route.App(tidyQuery(it.groupValues[1])) }
    APP_LO.find(t)?.let { return Route.App(tidyQuery(it.groupValues[1])) }
    return null
  }
}
