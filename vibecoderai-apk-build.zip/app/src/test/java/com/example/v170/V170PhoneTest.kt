package com.example.v170

import com.example.phone.AppMatcher
import com.example.phone.FastPaths
import com.example.phone.InstalledApp
import com.example.phone.PhoneAction
import com.example.phone.PhoneActionParser
import com.example.phone.RiskGuard
import com.example.phone.ScreenCompactor
import com.example.phone.ScreenElement
import com.example.phone.SensitiveApps
import com.example.phone.UiNode
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class V170PhoneTest {
  private fun n(id: Int, text: String? = null, desc: String? = null, cls: String = "android.widget.TextView", click: Boolean = false, edit: Boolean = false,
                scroll: Boolean = false, pw: Boolean = false, top: Int = id * 100, kids: List<UiNode> = emptyList()) =
    UiNode(id, text = text, desc = desc, cls = cls, left = 0, top = top, right = 1080, bottom = top + 90, clickable = click, editable = edit, scrollable = scroll, password = pw, children = kids)

  @Test fun compactMergesRowTextAndKeepsActions() {
    val row = n(3, cls = "android.widget.LinearLayout", click = true, kids = listOf(n(4, "Biryani House"), n(5, "4.2 · 30 min")))
    val tree = listOf(n(1, cls = "android.widget.FrameLayout", kids = listOf(
      n(2, cls = "android.widget.EditText", edit = true, desc = "Search"), row, n(6, cls = "androidx.recyclerview.widget.RecyclerView", scroll = true)
    )))
    val s = ScreenCompactor.compact("Swiggy", "in.swiggy.android", tree, 2000)
    assertTrue(s.text, s.text.contains("#2 edit \"Search\" [type]"))
    assertTrue(s.text, s.text.contains("#3 button \"Biryani House, 4.2 · 30 min\" [tap]"))
    assertFalse("children merged into the row", s.elements.any { it.id == 4 })
    assertTrue(s.text.contains("#6 list [scroll]"))
  }

  @Test fun compactRespectsBudgetKeepingEditsFirst() {
    val kids = listOf(n(2, cls = "android.widget.EditText", edit = true, desc = "Search")) + (10..80).map { n(it, "Item number $it with a long label", click = true) }
    val s = ScreenCompactor.compact("App", "a.b", listOf(n(1, cls = "android.widget.FrameLayout", kids = kids)), 600)
    assertTrue(s.text.length <= 700)
    assertTrue(s.elements.first().editable)
    assertTrue(s.dropped > 0 && s.text.contains("more elements not shown"))
  }

  @Test fun passwordFieldsAreMarked() {
    val s = ScreenCompactor.compact("A", "a", listOf(n(1, cls = "android.widget.EditText", edit = true, pw = true, desc = "Password")), 500)
    assertTrue(s.text.contains("[password]"))
    assertTrue(RiskGuard.isSecretField(s.elements.single()))
  }

  @Test fun parsesActionsFromNoisyReplies() {
    assertEquals(PhoneAction.Tap(12), PhoneActionParser.parse("Sure!\n```json\n{\"action\":\"tap\",\"id\":12}\n```"))
    assertEquals(PhoneAction.Type(5, "telugu songs"), PhoneActionParser.parse("{\"action\":\"type\",\"id\":\"#5\",\"text\":\"telugu songs\"}"))
    assertEquals(PhoneAction.Scroll("down", null), PhoneActionParser.parse("{\"action\":\"scroll\"}"))
    assertEquals(PhoneAction.OpenApp("Swiggy"), PhoneActionParser.parse("<think>open it</think>{\"action\":\"open_app\",\"name\":\"Swiggy\"}"))
    assertTrue(PhoneActionParser.parse("{\"action\":\"done\",\"summary\":\"Playing\"}") is PhoneAction.Done)
  }

  @Test fun badActionsGiveFixableErrors() {
    for (bad in listOf("no json here", "{\"action\":\"tap\"}", "{\"action\":\"fly\"}", "{\"action\":\"scroll\",\"direction\":\"sideways\"}")) {
      try { PhoneActionParser.parse(bad); throw AssertionError("parsed: $bad") } catch (e: PhoneActionParser.ParseError) { assertTrue(e.message!!.isNotBlank()) }
    }
  }

  @Test fun riskyButtonsAreDetected() {
    assertEquals(RiskGuard.Risk.PAYMENT, RiskGuard.classify("Place Order ₹249"))
    assertEquals(RiskGuard.Risk.PAYMENT, RiskGuard.classify("Proceed to Pay"))
    assertEquals(RiskGuard.Risk.SEND, RiskGuard.classify("Send"))
    assertEquals(RiskGuard.Risk.DELETE, RiskGuard.classify("Delete chat"))
    assertEquals(RiskGuard.Risk.PAYMENT, RiskGuard.classify("చెల్లించు"))
    assertNull(RiskGuard.classify("Search"))
    assertNull(RiskGuard.classify("Add to cart"))
    assertNull(RiskGuard.classify("Sender name"))
    assertNull(RiskGuard.classify("Playlist"))
    assertTrue(RiskGuard.looksSecret("482913"))
    assertFalse(RiskGuard.looksSecret("telugu songs 2024"))
  }

  @Test fun bankingAppsAreSkipped() {
    assertTrue(SensitiveApps.isSensitive("com.phonepe.app"))
    assertTrue(SensitiveApps.isSensitive("com.sbi.lotusintouch"))
    assertTrue(SensitiveApps.isSensitive("com.x.y", "Google Pay"))
    assertFalse(SensitiveApps.isSensitive("com.google.android.youtube", "YouTube"))
    assertFalse(SensitiveApps.isSensitive("com.android.vending", "Play Store"))
  }

  @Test fun appNamesMatch() {
    val apps = listOf(InstalledApp("YouTube", "com.google.android.youtube"), InstalledApp("YT Music", "com.google.android.apps.youtube.music"),
      InstalledApp("Swiggy", "in.swiggy.android"), InstalledApp("CapCut", "com.lemon.lvoverseas"), InstalledApp("WhatsApp", "com.whatsapp"))
    assertEquals("com.google.android.youtube", AppMatcher.match("youtube", apps)?.pkg)
    assertEquals("com.google.android.youtube", AppMatcher.match("yt", apps)?.pkg)
    assertEquals("com.lemon.lvoverseas", AppMatcher.match("Cap Cut", apps)?.pkg)
    assertEquals("in.swiggy.android", AppMatcher.match("swigy", apps)?.pkg)
    assertEquals("com.whatsapp", AppMatcher.match("whats app", apps)?.pkg)
    assertNull(AppMatcher.match("zomato", apps))
  }

  @Test fun fastPathsRouteTeluguAndEnglishTasks() {
    assertEquals(FastPaths.Route.YouTube("Telugu songs"), FastPaths.route("YouTube lo Telugu songs play cheyyi"))
    assertEquals(FastPaths.Route.YouTube("arijit singh"), FastPaths.route("play arijit singh on youtube"))
    assertEquals(FastPaths.Route.App("Swiggy"), FastPaths.route("Swiggy lo biryani order cheyyi"))
    assertEquals(FastPaths.Route.App("CapCut"), FastPaths.route("CapCut open chesi video edit cheyyi"))
    assertEquals(FastPaths.Route.App("YouTube"), FastPaths.route("youtube open cheyyi"))
    assertEquals(FastPaths.Route.App("whatsapp"), FastPaths.route("open whatsapp"))
    assertEquals(FastPaths.Route.Url("https://www.google.com"), FastPaths.route("www.google.com open cheyyi"))
    assertNull(FastPaths.route("turn on wifi"))
    assertEquals("https://www.youtube.com/results?search_query=telugu+songs+%26+more", FastPaths.youtubeSearchUrl("telugu songs & more"))
  }

  @Test fun systemPromptStaysSmall() {
    // Sent every step: keep it under ~350 tokens.
    assertTrue(com.example.phone.PhoneAgent.SYSTEM.length < 1400)
  }
}
